import fitz


def extract_pdf_data(file_path):
    """Extract text and basic metadata from a PDF file."""
    try:
        with fitz.open(file_path) as pdf:
            if pdf.is_encrypted:
                return {
                    "success": False,
                    "error": "This PDF is password-protected."
                }

            text = "\n".join(page.get_text() for page in pdf)
            metadata = pdf.metadata or {}

            return {
                "success": True,
                "title": metadata.get("title") or "",
                "author": metadata.get("author") or "",
                "page_count": len(pdf),
                "text": text.strip(),
                "has_text": bool(text.strip())
            }

    except Exception:
        return {
            "success": False,
            "error": "The file could not be read as a valid PDF."
        }