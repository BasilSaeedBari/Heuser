from pathlib import Path
import sys

# Find the main project folder before importing the service.
PROJECT_FOLDER = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_FOLDER))

from services.pdf_extract import extract_pdf_data

uploads_folder = PROJECT_FOLDER / "uploads"

pdf_files = [
    file for file in uploads_folder.glob("*.pdf")
    if file.is_file() and file.stat().st_size > 0
]

if not pdf_files:
    print("No non-empty PDF found in the uploads folder.")
else:
    pdf_file = max(pdf_files, key=lambda file: file.stat().st_mtime)
    print("Testing file:", pdf_file.name)

    result = extract_pdf_data(str(pdf_file))

    if result["success"]:
        print("PDF extraction succeeded!")
        print("Title:", result["title"] or "Not available")
        print("Author:", result["author"] or "Not available")
        print("Pages:", result["page_count"])
        print("Text extracted:", result["has_text"])
        print(
            "Text preview:",
            result["text"][:300] or "No selectable text found"
        )
    else:
        print("Extraction failed:", result["error"])