# Research Paper Library & Knowledge Graph

A local web application for storing research papers, managing topic tags, and exploring connections between papers and topics.

## Features

- Upload PDF research papers.
- Extract text and basic metadata from PDFs.
- View saved papers on a dashboard.
- Search papers using live search.
- View and edit paper information.
- Add and save topic tags.
- Explore paper-topic relationships using an interactive Knowledge Graph.
- Review library actions in the Activity Log.
- Delete papers when they are no longer needed.

## Technology Stack

- Python 3.13.17
- Flask 3.1.3
- SQLite
- PyMuPDF 2.0
- HTML, CSS, and vanilla JavaScript
- vis-network 10.1.2 (loaded through a CDN)

## Requirements

- Python 3.11 or later
- Internet connection for the vis-network CDN
- A modern web browser

## Installation

1. Open a terminal in the project folder.
2. Create a virtual environment:

   ```bash
   python -m venv .venv
   ```

3. Activate the virtual environment on Windows:

   ```bash
   .venv\Scripts\activate
   ```

4. Install the required packages:

   ```bash
   python -m pip install -r requirements.txt
   ```

## Running the Application

1. Activate the virtual environment.
2. Run the Flask application:

   ```bash
   python app.py
   ```

3. Open this address in your browser:

   http://127.0.0.1:5000

The SQLite database is initialized by the application. Keep the terminal open while using the application.

## Main Pages

- `/` — Research Paper Library dashboard
- `/paper/<paper_id>` — Paper details
- `/paper/<paper_id>/edit` — Edit paper information
- `/activity` — Activity Log
- `/graph` — Interactive Knowledge Graph
- `/api/graph-data` — Knowledge Graph data API

## File Upload Limit

PDF uploads are limited to 20 MB. Password-protected PDFs and invalid PDF files are rejected.

## Limitations

- The application is designed for local, single-user use.
- Scanned PDFs without an extractable text layer may not provide useful extracted text.
- OCR is not included.
- The Knowledge Graph requires an internet connection to load vis-network from its CDN.
- The application has not been configured for public internet deployment.

## Safety and Privacy

Run the application locally and do not expose it to the public internet without additional security work. Keep your database and uploaded PDFs backed up.

## Project Structure

- `app.py` — Flask routes and application logic
- `database.py` — SQLite database setup and connections
- `services/` — PDF extraction services
- `templates/` — HTML pages
- `static/` — CSS and other static assets
- `uploads/` — Uploaded PDF files
- `requirements.txt` — Python dependencies
- `research_library.db` — SQLite database, created when the app runs

## License and Third-Party Components

Flask, PyMuPDF, and vis-network have their own licensing terms. Review their licenses before redistributing this application.