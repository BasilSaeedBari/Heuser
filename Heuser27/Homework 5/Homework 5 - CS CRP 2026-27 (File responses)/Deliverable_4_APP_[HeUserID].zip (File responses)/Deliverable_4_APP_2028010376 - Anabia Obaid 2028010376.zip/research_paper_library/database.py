import sqlite3
from pathlib import Path

DATABASE = Path(__file__).parent / "research_library.db"


def get_connection():
    connection = sqlite3.connect(DATABASE)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    return connection


def init_db():
    with get_connection() as connection:
        connection.executescript("""
            CREATE TABLE IF NOT EXISTS papers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                abstract TEXT,
                doi TEXT,
                publication_year INTEGER,
                journal TEXT,
                pdf_path TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS authors (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE
            );

            CREATE TABLE IF NOT EXISTS paper_authors (
                paper_id INTEGER NOT NULL,
                author_id INTEGER NOT NULL,
                PRIMARY KEY (paper_id, author_id),
                FOREIGN KEY (paper_id) REFERENCES papers(id)
                    ON DELETE CASCADE,
                FOREIGN KEY (author_id) REFERENCES authors(id)
                    ON DELETE CASCADE
            );

            CREATE TABLE IF NOT EXISTS topics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE
            );

            CREATE TABLE IF NOT EXISTS paper_topics (
                paper_id INTEGER NOT NULL,
                topic_id INTEGER NOT NULL,
                PRIMARY KEY (paper_id, topic_id),
                FOREIGN KEY (paper_id) REFERENCES papers(id)
                    ON DELETE CASCADE,
                FOREIGN KEY (topic_id) REFERENCES topics(id)
                    ON DELETE CASCADE
            );

            CREATE TABLE IF NOT EXISTS activity_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                action TEXT NOT NULL,
                paper_id INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (paper_id) REFERENCES papers(id)
                    ON DELETE SET NULL
            );
        """)


if __name__ == "__main__":
    init_db()
    print(f"Database initialized at: {DATABASE}")