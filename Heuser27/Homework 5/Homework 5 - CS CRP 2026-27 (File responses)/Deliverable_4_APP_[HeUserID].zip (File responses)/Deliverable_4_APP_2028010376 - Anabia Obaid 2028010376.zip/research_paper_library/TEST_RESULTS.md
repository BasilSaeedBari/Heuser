# Research Paper Library — Test Results

## Test 1: PDF Text Extraction

- **Test file:** `tests/test_pdf_extract.py`
- **Purpose:** Check whether the application can extract text and basic metadata from a PDF.
- **Method:** Run `python tests\test_pdf_extract.py` from the project folder with the virtual environment activated.
- **Expected result:** The test identifies a non-empty PDF and displays the extraction result.
- **Observed result:** The test reported `PDF extraction succeeded!`.
- **Status:** PASS

## Note

This test checks PDF extraction using the newest non-empty PDF in the `uploads` folder. It does not by itself verify every application feature.