from flask import Flask, render_template, request, redirect, jsonify
from database import init_db
from services.pdf_extract import extract_pdf_data
from pathlib import Path
from werkzeug.utils import secure_filename
import uuid

app = Flask(__name__)

BASE_DIR = Path(__file__).parent
UPLOAD_FOLDER = BASE_DIR / "uploads"
UPLOAD_FOLDER.mkdir(exist_ok=True)

app.config["UPLOAD_FOLDER"] = str(UPLOAD_FOLDER)
app.config["MAX_CONTENT_LENGTH"] = 20 * 1024 * 1024

init_db()


@app.route("/")
def home():
    with get_connection() as connection:
        papers = connection.execute(
            """
            SELECT id, title, abstract, publication_year, journal, created_at
            FROM papers
            ORDER BY id DESC
            """
        ).fetchall()

    return render_template("index.html", papers=papers)

@app.route("/graph")
def knowledge_graph():
    return render_template("graph.html")
@app.route("/api/graph-data")
def graph_data():
    with get_connection() as connection:
        papers = connection.execute(
            "SELECT id, title FROM papers ORDER BY title"
        ).fetchall()

        topics = connection.execute(
            "SELECT id, name FROM topics ORDER BY name"
        ).fetchall()

        relationships = connection.execute(
            "SELECT paper_id, topic_id FROM paper_topics"
        ).fetchall()

    nodes = []

    for paper in papers:
        nodes.append({
            "id": f"paper-{paper['id']}",
            "label": paper["title"],
            "group": "paper",
            "shape": "box"
        })

    for topic in topics:
        nodes.append({
            "id": f"topic-{topic['id']}",
            "label": topic["name"],
            "group": "topic",
            "shape": "dot"
        })

    edges = []

    for relationship in relationships:
        edges.append({
            "from": f"paper-{relationship['paper_id']}",
            "to": f"topic-{relationship['topic_id']}"
        })

    return jsonify({
        "nodes": nodes,
        "edges": edges
    })


from database import get_connection

@app.route("/upload", methods=["POST"])
def upload_pdf():
    if "pdf_file" not in request.files:
        return "No file selected.", 400

    file = request.files["pdf_file"]

    if not file.filename:
        return "No file selected.", 400

    if Path(file.filename).suffix.lower() != ".pdf":
        return "Only PDF files are allowed.", 400

    safe_name = secure_filename(file.filename)
    unique_name = f"{uuid.uuid4().hex}_{safe_name}"
    save_path = UPLOAD_FOLDER / unique_name

    try:
        file.save(save_path)

        result = extract_pdf_data(str(save_path))

        if not result["success"]:
            save_path.unlink(missing_ok=True)
            return result["error"], 400

        extracted_text = result["text"]
        title = result["title"] or Path(safe_name).stem

        # Use the first paragraph as a temporary abstract.
        # We will improve abstract extraction later.
        abstract = extracted_text[:1000] or None

        with get_connection() as connection:
            cursor = connection.execute(
                """
                INSERT INTO papers
                    (title, abstract, pdf_path)
                VALUES (?, ?, ?)
                """,
                (title, abstract, unique_name)
            )

            paper_id = cursor.lastrowid

            connection.execute(
                "INSERT INTO activity_log (action, paper_id) VALUES (?, ?)",
                ("Uploaded paper", paper_id)
            )

        return render_template(
    "upload_success.html", paper_id=paper_id
)
    except Exception:
        if save_path.exists():
            save_path.unlink(missing_ok=True)
        app.logger.exception("PDF upload failed")
        return "The PDF could not be added to the library. Please try again.", 500

@app.route("/paper/<int:paper_id>")
def paper_detail(paper_id):
    with get_connection() as connection:
        paper = connection.execute(
            "SELECT * FROM papers WHERE id = ?",
            (paper_id,)
        ).fetchone()

        if paper is None:
            return "Paper not found.", 404

        tags = connection.execute(
            """
            SELECT topics.name
            FROM topics
            JOIN paper_topics
                ON topics.id = paper_topics.topic_id
            WHERE paper_topics.paper_id = ?
            ORDER BY topics.name
            """,
            (paper_id,)
        ).fetchall()

    return render_template(
        "paper_detail.html",
        paper=paper,
        tags=tags
    )
@app.route("/paper/<int:paper_id>/edit", methods=["GET", "POST"])
def edit_paper(paper_id):
    with get_connection() as connection:
        paper = connection.execute(
            "SELECT * FROM papers WHERE id = ?",
            (paper_id,)
        ).fetchone()

        if paper is None:
            return "Paper not found.", 404

        if request.method == "POST":
            title = request.form.get("title", "").strip()
            abstract = request.form.get("abstract", "").strip()
            year_text = request.form.get("publication_year", "").strip()
            journal = request.form.get("journal", "").strip()

            if not title:
                return "Title cannot be empty.", 400

            try:
                year = int(year_text) if year_text else None
            except ValueError:
                return "Publication year must be a number.", 400

            connection.execute(
                """
                UPDATE papers
                SET title = ?, abstract = ?,
                    publication_year = ?, journal = ?
                WHERE id = ?
                """,
                (title, abstract or None, year, journal or None, paper_id)
            )

            connection.execute(
                "INSERT INTO activity_log (action, paper_id) VALUES (?, ?)",
                ("Edited paper", paper_id)
            )

            return redirect(f"/paper/{paper_id}")
    return render_template(
        "edit_paper.html",
        paper=paper
    )
@app.route("/paper/<int:paper_id>/delete", methods=["POST"])
def delete_paper(paper_id):
    with get_connection() as connection:
        paper = connection.execute(
            "SELECT pdf_path FROM papers WHERE id = ?",
            (paper_id,)
        ).fetchone()

        if paper is None:
            return "Paper not found.", 404

        connection.execute(
            "INSERT INTO activity_log (action, paper_id) VALUES (?, ?)",
            ("Deleted paper", paper_id)
        )

        connection.execute(
            "DELETE FROM papers WHERE id = ?",
            (paper_id,)
        )

    if paper["pdf_path"]:
        pdf_file = UPLOAD_FOLDER / paper["pdf_path"]
        pdf_file.unlink(missing_ok=True)

    return redirect("/")

    return render_template("edit_paper.html", paper=paper)
@app.route("/paper/<int:paper_id>/tags", methods=["POST"])
def update_paper_tags(paper_id):
    tag_text = request.form.get("tags", "")
    tag_names = sorted({
        name.strip()
        for name in tag_text.split(",")
        if name.strip()
    })

    with get_connection() as connection:
        paper = connection.execute(
            "SELECT id FROM papers WHERE id = ?",
            (paper_id,)
        ).fetchone()

        if paper is None:
            return "Paper not found.", 404

        connection.execute(
            "DELETE FROM paper_topics WHERE paper_id = ?",
            (paper_id,)
        )

        for name in tag_names:
            connection.execute(
                "INSERT OR IGNORE INTO topics (name) VALUES (?)",
                (name,)
            )
            topic = connection.execute(
                "SELECT id FROM topics WHERE name = ?",
                (name,)
            ).fetchone()

            connection.execute(
                """
                INSERT INTO paper_topics (paper_id, topic_id)
                VALUES (?, ?)
                """,
                (paper_id, topic["id"])
            )

        connection.execute(
            "INSERT INTO activity_log (action, paper_id) VALUES (?, ?)",
            ("Updated topic tags", paper_id)
        )

    return redirect(f"/paper/{paper_id}")
@app.route("/activity")
def activity_log():
    with get_connection() as connection:
        activities = connection.execute(
            """
            SELECT activity_log.id,
                   activity_log.action,
                   activity_log.paper_id,
                   activity_log.created_at,
                   papers.title
            FROM activity_log
            LEFT JOIN papers
                ON papers.id = activity_log.paper_id
            ORDER BY activity_log.id DESC
            """
        ).fetchall()

    return render_template(
        "activity.html",
        activities=activities
    )


@app.errorhandler(413)
def file_too_large(error):
    return "File is too large. Maximum size is 20 MB.", 413

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
