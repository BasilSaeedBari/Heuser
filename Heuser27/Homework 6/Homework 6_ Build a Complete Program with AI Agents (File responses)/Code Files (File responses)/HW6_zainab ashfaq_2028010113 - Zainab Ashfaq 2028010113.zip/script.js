"use strict";

// =====================================================
// CATCH GAME - ORCHARD HARVEST
// STAGE 4: STATE & STORAGE
// =====================================================
//
// Existing gameplay rules preserved.
//
// GREEN APPLE:
// +10 points
//
// RED APPLE:
// -1 life
//
// MISSED APPLES:
// No penalty
//
// STARTING LIVES:
// 3
//
// Stage 4 adds:
// - Persistent high score
// - Persistent mute setting
// - Storage schema version
// - Safe reset-data confirmation
// - Input and visibility bug fixes
//
// =====================================================


// =====================================================
// CANVAS
// =====================================================

const canvas = document.getElementById("gameCanvas");

const ctx = canvas.getContext("2d");

const canvasWidth = canvas.width;
const canvasHeight = canvas.height;


// =====================================================
// GAME CONSTANTS
// =====================================================

const STARTING_LIVES = 3;

const GOOD_POINTS = 10;

const BASKET_WIDTH = 100;
const BASKET_HEIGHT = 20;
const BASKET_SPEED = 400;

const ITEM_SIZE = 30;

const BASE_FALL_SPEED = 120;
const MAX_FALL_SPEED = 400;

const BASE_SPAWN_INTERVAL = 1.2;
const MIN_SPAWN_INTERVAL = 0.4;

const BASE_BAD_CHANCE = 0.25;
const MAX_BAD_CHANCE = 0.5;

const MAX_DELTA_TIME = 0.05;


// =====================================================
// GAME STATES
// =====================================================

const STATES = {

    MENU: "MENU",

    PLAYING: "PLAYING",

    PAUSED: "PAUSED",

    GAMEOVER: "GAMEOVER"

};

let currentState = STATES.MENU;


// =====================================================
// GAME VARIABLES
// =====================================================

let score = 0;

let lives = STARTING_LIVES;

let finalScore = 0;

let fallingItems = [];

let spawnTimer = 0;

let spawnInterval = BASE_SPAWN_INTERVAL;

let fallSpeed = BASE_FALL_SPEED;

let badChance = BASE_BAD_CHANCE;

let elapsedTime = 0;


// =====================================================
// STAGE 4: STORAGE CONSTANTS
// =====================================================

const MUTED_KEY = "orchardHarvestMuted";

const HIGH_SCORE_KEY = "orchardHarvestHighScore";

const VERSION_KEY = "orchardHarvestDataVersion";

const CURRENT_VERSION = "1";


// =====================================================
// STAGE 4: PERSISTENT DATA VARIABLES
// =====================================================

let highScore = 0;

let isNewHighScore = false;


// =====================================================
// STAGE 4: RESET DATA VARIABLES
// =====================================================

const RESET_CONFIRM_WINDOW_MS = 5000;

let resetConfirmPending = false;

let resetConfirmTimeoutId = null;

const resetDataButton = document.getElementById(
    "resetDataButton"
);

const resetStatusMessage = document.getElementById(
    "resetStatusMessage"
);


// =====================================================
// BASKET
// =====================================================

const basket = {

    x: canvasWidth / 2 - BASKET_WIDTH / 2,

    y: canvasHeight - 40,

    width: BASKET_WIDTH,

    height: BASKET_HEIGHT,

    speed: BASKET_SPEED

};


// =====================================================
// INPUT
// =====================================================

const input = {

    left: false,

    right: false,

    pointerX: null

};

const heldLeftKeys = new Set();

const heldRightKeys = new Set();


// =====================================================
// STAGE 3 - FEEDBACK CONFIGURATION
// =====================================================

const FEEDBACK = {

    GOOD_PARTICLE_COUNT: 12,

    BAD_PARTICLE_COUNT: 10,

    MAX_PARTICLES: 150,

    GOOD_PARTICLE_LIFE: 0.6,

    BAD_PARTICLE_LIFE: 0.4,

    FLOATING_TEXT_LIFE: 0.8,

    FLOATING_TEXT_SPEED: 40,

    SHAKE_DURATION: 0.18,

    SHAKE_INTENSITY: 4,

    DAMAGE_FLASH_DURATION: 0.2,

    SCORE_PULSE_DURATION: 0.2,

    LIVES_PULSE_DURATION: 0.2,

    BASKET_BOUNCE_DURATION: 0.15,

    START_TRANSITION_DURATION: 0.25,

    PAUSE_FADE_DURATION: 0.2,

    GAMEOVER_TRANSITION_DURATION: 0.5,

    MASTER_VOLUME: 0.3

};


// =====================================================
// REDUCED MOTION
// =====================================================

const reducedMotionQuery = window.matchMedia(
    "(prefers-reduced-motion: reduce)"
);

function prefersReducedMotion() {

    return reducedMotionQuery.matches;

}


// =====================================================
// PARTICLE VARIABLES
// =====================================================

let particles = [];

let floatingTexts = [];

let screenShake = {

    duration: 0,

    intensity: 0

};

let damageFlashTimer = 0;

let scorePulseTimer = 0;

let livesPulseTimer = 0;

let basketBounceTimer = 0;

let basketTiltTimer = 0;


// =====================================================
// TRANSITION VARIABLES
// =====================================================

let startTransitionTimer = 0;

let pauseFadeTimer = 0;

let gameOverTransitionTimer = 0;


// =====================================================
// AUDIO VARIABLES
// =====================================================

let audioContext = null;

let masterGain = null;

let isMuted = false;

const muteButton = document.getElementById(
    "muteButton"
);


// =====================================================
// STAGE 4: LOAD GAME DATA
// =====================================================

function loadGameData() {

    let storedVersion = null;

    // Read mute independently.
    // A version-write failure must not erase it.

    try {

        isMuted =
            localStorage.getItem(MUTED_KEY) === "true";

    }

    catch (error) {

        isMuted = false;

    }


    // Read storage version independently.

    try {

        storedVersion =
            localStorage.getItem(VERSION_KEY);

    }

    catch (error) {

        storedVersion = null;

    }


    // Only trust high scores from the current schema.

    if (storedVersion === CURRENT_VERSION) {

        try {

            const rawHighScore =
                localStorage.getItem(HIGH_SCORE_KEY);

            const parsed =
                parseInt(rawHighScore, 10);

            highScore = (
                Number.isFinite(parsed) &&
                parsed >= 0
            ) ? parsed : 0;

        }

        catch (error) {

            highScore = 0;

        }

    }

    else {

        highScore = 0;

        // BUG FIX:
        // Version writes use their own try/catch.
        // A failed write cannot discard loaded mute data.

        try {

            localStorage.setItem(
                VERSION_KEY,
                CURRENT_VERSION
            );

        }

        catch (error) {

            // Storage unavailable.
            // Existing in-memory values remain valid.

        }

    }

}


// =====================================================
// STAGE 4: SAVE HIGH SCORE
// =====================================================

function saveHighScore(value) {

    try {

        localStorage.setItem(
            HIGH_SCORE_KEY,
            String(value)
        );

    }

    catch (error) {

        // High score remains in memory.
        // Gameplay continues normally.

    }

}


// =====================================================
// UPDATE MUTE BUTTON
// =====================================================

function updateMuteButton() {

    if (isMuted) {

        muteButton.textContent = "🔇 Sound Off";

        muteButton.setAttribute(
            "aria-label",
            "Unmute game sounds"
        );

        muteButton.setAttribute(
            "aria-pressed",
            "true"
        );

        muteButton.classList.add("muted");

    }

    else {

        muteButton.textContent = "🔊 Sound On";

        muteButton.setAttribute(
            "aria-label",
            "Mute game sounds"
        );

        muteButton.setAttribute(
            "aria-pressed",
            "false"
        );

        muteButton.classList.remove("muted");

    }

}


// =====================================================
// INITIALIZE AUDIO
// =====================================================

function initializeAudio() {

    try {

        if (!audioContext) {

            const AudioContextClass =
                window.AudioContext ||
                window.webkitAudioContext;

            if (!AudioContextClass) {

                return;

            }

            audioContext = new AudioContextClass();

            masterGain = audioContext.createGain();

            masterGain.gain.value =
                isMuted ? 0 : FEEDBACK.MASTER_VOLUME;

            masterGain.connect(
                audioContext.destination
            );

        }

        if (audioContext.state === "suspended") {

            audioContext.resume().catch(() => {});

        }

    }

    catch (error) {

        // Audio is optional.
        // Never interrupt gameplay.

    }

}


// =====================================================
// MASTER VOLUME
// =====================================================

function updateMasterVolume() {

    if (!audioContext || !masterGain) {

        return;

    }

    const now = audioContext.currentTime;

    const targetVolume =
        isMuted ? 0 : FEEDBACK.MASTER_VOLUME;

    masterGain.gain.cancelScheduledValues(now);

    masterGain.gain.setTargetAtTime(
        targetVolume,
        now,
        0.01
    );

}


// =====================================================
// TOGGLE MUTE
// =====================================================

function toggleMute() {

    isMuted = !isMuted;

    updateMuteButton();

    try {

        localStorage.setItem(
            MUTED_KEY,
            String(isMuted)
        );

    }

    catch (error) {

        // Ignore storage errors.

    }

    initializeAudio();

    updateMasterVolume();

    if (!isMuted) {

        playTone(
            660,
            0.08,
            "sine",
            0.15
        );

    }

}


// =====================================================
// MUTE BUTTON EVENT
// =====================================================

muteButton.addEventListener("click", function() {

    toggleMute();

    // BUG FIX:
    // Release button focus after clicking.
    // Keyboard gameplay controls work immediately.

    muteButton.blur();

});


// =====================================================
// STAGE 4: ENTER RESET CONFIRMATION
// =====================================================

function enterResetConfirmState() {

    resetConfirmPending = true;

    resetDataButton.textContent =
        "⚠️ Click again to confirm";

    resetDataButton.classList.add(
        "confirm-pending"
    );

    resetStatusMessage.textContent =
        "Press Reset again within 5 seconds to confirm, " +
        "or press Escape to cancel.";

    resetConfirmTimeoutId = setTimeout(
        cancelResetConfirmation,
        RESET_CONFIRM_WINDOW_MS
    );

}


// =====================================================
// STAGE 4: CANCEL RESET CONFIRMATION
// =====================================================

function cancelResetConfirmation() {

    resetConfirmPending = false;

    clearTimeout(resetConfirmTimeoutId);

    resetConfirmTimeoutId = null;

    resetDataButton.textContent =
        "🗑️ Reset Data";

    resetDataButton.classList.remove(
        "confirm-pending"
    );

    resetStatusMessage.textContent = "";

}


// =====================================================
// STAGE 4: PERFORM DATA RESET
// =====================================================

function performDataReset() {

    highScore = 0;

    isMuted = false;

    isNewHighScore = false;

    try {

        localStorage.removeItem(
            HIGH_SCORE_KEY
        );

        localStorage.setItem(
            MUTED_KEY,
            "false"
        );

        localStorage.setItem(
            VERSION_KEY,
            CURRENT_VERSION
        );

    }

    catch (error) {

        // In-memory values still reset.
        // Storage failures never interrupt gameplay.

    }

    updateMuteButton();

    updateMasterVolume();

    cancelResetConfirmation();

    resetStatusMessage.textContent =
        "Game data has been reset.";

}


// =====================================================
// STAGE 4: RESET BUTTON HANDLER
// =====================================================

function handleResetButtonClick() {

    if (
        currentState !== STATES.MENU &&
        currentState !== STATES.GAMEOVER
    ) {

        return;

    }

    if (!resetConfirmPending) {

        enterResetConfirmState();

    }

    else {

        performDataReset();

    }

}


// =====================================================
// STAGE 4: RESET BUTTON EVENT
// =====================================================

resetDataButton.addEventListener(
    "click",
    function() {

        handleResetButtonClick();

        // BUG FIX:
        // Prevent button focus from blocking game keys.

        resetDataButton.blur();

    }
);


// =====================================================
// STAGE 4: CANCEL CONFIRMATION ON OUTSIDE CLICK
// =====================================================

document.addEventListener("click", function(event) {

    if (
        resetConfirmPending &&
        event.target !== resetDataButton
    ) {

        cancelResetConfirmation();

    }

});


// =====================================================
// STAGE 4: CANCEL CONFIRMATION WITH ESCAPE
// =====================================================

document.addEventListener("keydown", function(event) {

    if (
        resetConfirmPending &&
        event.key === "Escape"
    ) {

        cancelResetConfirmation();

    }

});


// =====================================================
// REUSABLE WEB AUDIO TONE
// =====================================================

function playTone(
    frequency,
    duration,
    waveform = "sine",
    volume = 0.2,
    endFrequency = null,
    delay = 0
) {

    if (isMuted) {

        return;

    }

    initializeAudio();

    if (!audioContext || !masterGain) {

        return;

    }

    if (audioContext.state !== "running") {

        return;

    }

    try {

        const oscillator =
            audioContext.createOscillator();

        const gain =
            audioContext.createGain();

        const now =
            audioContext.currentTime + delay;

        const endTime = now + duration;

        oscillator.type = waveform;

        oscillator.frequency.setValueAtTime(
            frequency,
            now
        );

        if (endFrequency !== null) {

            oscillator.frequency.exponentialRampToValueAtTime(
                Math.max(1, endFrequency),
                endTime
            );

        }

        gain.gain.setValueAtTime(
            0.001,
            now
        );

        gain.gain.linearRampToValueAtTime(
            volume,
            now + Math.min(0.015, duration / 3)
        );

        gain.gain.exponentialRampToValueAtTime(
            0.001,
            endTime
        );

        oscillator.connect(gain);

        gain.connect(masterGain);

        oscillator.start(now);

        oscillator.stop(endTime + 0.01);

        oscillator.onended = function() {

            oscillator.disconnect();

            gain.disconnect();

        };

    }

    catch (error) {

        // Sound failures never affect gameplay.

    }

}


// =====================================================
// GREEN APPLE SOUND
// =====================================================

function playCatchSound() {

    playTone(
        520,
        0.08,
        "sine",
        0.22
    );

    playTone(
        780,
        0.10,
        "sine",
        0.20,
        null,
        0.07
    );

}


// =====================================================
// RED APPLE SOUND
// =====================================================

function playDamageSound() {

    playTone(
        300,
        0.2,
        "triangle",
        0.28,
        120
    );

}


// =====================================================
// START SOUND
// =====================================================

function playStartSound() {

    playTone(
        440,
        0.1,
        "sine",
        0.18
    );

    playTone(
        660,
        0.1,
        "sine",
        0.18,
        null,
        0.09
    );

    playTone(
        880,
        0.13,
        "sine",
        0.18,
        null,
        0.18
    );

}


// =====================================================
// PAUSE SOUND
// =====================================================

function playPauseSound() {

    playTone(
        440,
        0.12,
        "triangle",
        0.18,
        330
    );

}


// =====================================================
// RESUME SOUND
// =====================================================

function playResumeSound() {

    playTone(
        330,
        0.12,
        "sine",
        0.18,
        440
    );

}


// =====================================================
// GAME OVER SOUND
// =====================================================

function playGameOverSound() {

    playTone(
        392,
        0.15,
        "triangle",
        0.20
    );

    playTone(
        294,
        0.18,
        "triangle",
        0.20,
        null,
        0.15
    );

    playTone(
        196,
        0.3,
        "triangle",
        0.20,
        null,
        0.33
    );

}


// =====================================================
// CREATE PARTICLES
// =====================================================

function createParticles(
    x,
    y,
    colors,
    count,
    lifetime,
    speed
) {

    if (prefersReducedMotion()) {

        count = Math.ceil(count / 3);

    }

    for (let i = 0; i < count; i++) {

        const angle =
            Math.random() * Math.PI * 2;

        const velocity =
            speed * (0.5 + Math.random());

        const particle = {

            x: x,

            y: y,

            vx: Math.cos(angle) * velocity,

            vy: Math.sin(angle) * velocity - 25,

            size: 2 + Math.random() * 4,

            color: colors[
                Math.floor(
                    Math.random() * colors.length
                )
            ],

            life: lifetime,

            maxLife: lifetime

        };

        particles.push(particle);

    }

    while (
        particles.length >
        FEEDBACK.MAX_PARTICLES
    ) {

        particles.shift();

    }

}


// =====================================================
// GOOD CATCH PARTICLES
// =====================================================

function createGoodCatchParticles(x, y) {

    createParticles(

        x,

        y,

        [
            "#A6E07A",
            "#3E8E41",
            "#FFF8E1",
            "#CDE7C5"
        ],

        FEEDBACK.GOOD_PARTICLE_COUNT,

        FEEDBACK.GOOD_PARTICLE_LIFE,

        110

    );

}


// =====================================================
// BAD CATCH PARTICLES
// =====================================================

function createBadCatchParticles(x, y) {

    createParticles(

        x,

        y,

        [
            "#E57373",
            "#B23A2E",
            "#7F0000",
            "#3E2723"
        ],

        FEEDBACK.BAD_PARTICLE_COUNT,

        FEEDBACK.BAD_PARTICLE_LIFE,

        150

    );

}


// =====================================================
// UPDATE PARTICLES
// =====================================================

function updateParticles(dt) {

    for (
        let i = particles.length - 1;
        i >= 0;
        i--
    ) {

        const particle = particles[i];

        particle.x += particle.vx * dt;

        particle.y += particle.vy * dt;

        particle.vy += 80 * dt;

        particle.life -= dt;

        if (particle.life <= 0) {

            particles.splice(i, 1);

        }

    }

}


// =====================================================
// DRAW PARTICLES
// =====================================================

function drawParticles() {

    ctx.save();

    for (const particle of particles) {

        const alpha =
            particle.life / particle.maxLife;

        ctx.globalAlpha = alpha;

        ctx.fillStyle = particle.color;

        ctx.beginPath();

        ctx.arc(
            particle.x,
            particle.y,
            particle.size,
            0,
            Math.PI * 2
        );

        ctx.fill();

    }

    ctx.restore();

}


// =====================================================
// CREATE FLOATING TEXT
// =====================================================

function createFloatingText(
    x,
    y,
    text,
    color
) {

    floatingTexts.push({

        x: x,

        y: y,

        text: text,

        color: color,

        life: FEEDBACK.FLOATING_TEXT_LIFE,

        maxLife: FEEDBACK.FLOATING_TEXT_LIFE

    });

}


// =====================================================
// UPDATE FLOATING TEXT
// =====================================================

function updateFloatingTexts(dt) {

    for (
        let i = floatingTexts.length - 1;
        i >= 0;
        i--
    ) {

        const text = floatingTexts[i];

        if (!prefersReducedMotion()) {

            text.y -=
                FEEDBACK.FLOATING_TEXT_SPEED * dt;

        }

        text.life -= dt;

        if (text.life <= 0) {

            floatingTexts.splice(i, 1);

        }

    }

}


// =====================================================
// DRAW FLOATING TEXT
// =====================================================

function drawFloatingTexts() {

    ctx.save();

    ctx.textAlign = "center";

    ctx.textBaseline = "middle";

    ctx.font = "bold 22px Georgia";

    for (const text of floatingTexts) {

        ctx.globalAlpha =
            text.life / text.maxLife;

        ctx.lineWidth = 4;

        ctx.strokeStyle = "#FFF8E1";

        ctx.strokeText(
            text.text,
            text.x,
            text.y
        );

        ctx.fillStyle = text.color;

        ctx.fillText(
            text.text,
            text.x,
            text.y
        );

    }

    ctx.restore();

}


// =====================================================
// SCREEN SHAKE
// =====================================================

function triggerScreenShake() {

    if (prefersReducedMotion()) {

        return;

    }

    screenShake.duration =
        FEEDBACK.SHAKE_DURATION;

    screenShake.intensity =
        FEEDBACK.SHAKE_INTENSITY;

}


// =====================================================
// UPDATE SCREEN SHAKE
// =====================================================

function updateScreenShake(dt) {

    screenShake.duration = Math.max(
        0,
        screenShake.duration - dt
    );

}


// =====================================================
// APPLY SCREEN SHAKE
// =====================================================

function applyScreenShake() {

    if (screenShake.duration <= 0) {

        return;

    }

    const progress =
        screenShake.duration /
        FEEDBACK.SHAKE_DURATION;

    const intensity =
        screenShake.intensity * progress;

    const offsetX =
        (Math.random() * 2 - 1) * intensity;

    const offsetY =
        (Math.random() * 2 - 1) * intensity;

    ctx.translate(offsetX, offsetY);

}


// =====================================================
// DAMAGE FLASH
// =====================================================

function triggerDamageFlash() {

    if (prefersReducedMotion()) {

        return;

    }

    damageFlashTimer =
        FEEDBACK.DAMAGE_FLASH_DURATION;

}


// =====================================================
// DRAW DAMAGE FLASH
// =====================================================

function drawDamageFlash() {

    if (damageFlashTimer <= 0) {

        return;

    }

    const alpha =
        damageFlashTimer /
        FEEDBACK.DAMAGE_FLASH_DURATION;

    ctx.save();

    ctx.fillStyle =
        `rgba(178,58,46,${alpha * 0.18})`;

    ctx.fillRect(
        0,
        0,
        canvasWidth,
        canvasHeight
    );

    ctx.restore();

}


// =====================================================
// HUD ANIMATIONS
// =====================================================

function triggerScorePulse() {

    scorePulseTimer =
        FEEDBACK.SCORE_PULSE_DURATION;

}

function triggerLivesPulse() {

    livesPulseTimer =
        FEEDBACK.LIVES_PULSE_DURATION;

}


// =====================================================
// BASKET ANIMATIONS
// =====================================================

function triggerBasketBounce() {

    if (!prefersReducedMotion()) {

        basketBounceTimer =
            FEEDBACK.BASKET_BOUNCE_DURATION;

    }

}

function triggerBasketTilt() {

    if (!prefersReducedMotion()) {

        basketTiltTimer =
            FEEDBACK.BASKET_BOUNCE_DURATION;

    }

}


// =====================================================
// UPDATE GAMEPLAY FEEDBACK
// =====================================================

function updateGameplayFeedback(dt) {

    updateParticles(dt);

    updateFloatingTexts(dt);

    updateScreenShake(dt);

    damageFlashTimer = Math.max(
        0,
        damageFlashTimer - dt
    );

    scorePulseTimer = Math.max(
        0,
        scorePulseTimer - dt
    );

    livesPulseTimer = Math.max(
        0,
        livesPulseTimer - dt
    );

    basketBounceTimer = Math.max(
        0,
        basketBounceTimer - dt
    );

    basketTiltTimer = Math.max(
        0,
        basketTiltTimer - dt
    );

}


// =====================================================
// UPDATE UI FEEDBACK
// =====================================================

function updateUIFeedback(dt) {

    startTransitionTimer = Math.max(
        0,
        startTransitionTimer - dt
    );

    pauseFadeTimer = Math.max(
        0,
        pauseFadeTimer - dt
    );

    gameOverTransitionTimer = Math.max(
        0,
        gameOverTransitionTimer - dt
    );

}


// =====================================================
// RESET FEEDBACK
// =====================================================

function resetFeedback() {

    particles = [];

    floatingTexts = [];

    screenShake.duration = 0;

    screenShake.intensity = 0;

    damageFlashTimer = 0;

    scorePulseTimer = 0;

    livesPulseTimer = 0;

    basketBounceTimer = 0;

    basketTiltTimer = 0;

    startTransitionTimer = 0;

    pauseFadeTimer = 0;

    gameOverTransitionTimer = 0;

}


// =====================================================
// RESET GAME
// =====================================================

function resetGame() {

    score = 0;

    lives = STARTING_LIVES;

    finalScore = 0;

    fallingItems = [];

    spawnTimer = 0;

    spawnInterval = BASE_SPAWN_INTERVAL;

    fallSpeed = BASE_FALL_SPEED;

    badChance = BASE_BAD_CHANCE;

    elapsedTime = 0;

    basket.x =
        canvasWidth / 2 - basket.width / 2;

    input.left = false;

    input.right = false;

    input.pointerX = null;

    heldLeftKeys.clear();

    heldRightKeys.clear();

    resetFeedback();

}


// =====================================================
// START GAME
// =====================================================

function startGame() {

    initializeAudio();

    resetGame();

    isNewHighScore = false;

    // STAGE 4:
    // Reset data is unavailable during gameplay.

    cancelResetConfirmation();

    resetDataButton.disabled = true;

    currentState = STATES.PLAYING;

    startTransitionTimer =
        FEEDBACK.START_TRANSITION_DURATION;

    playStartSound();

}


// =====================================================
// PAUSE / RESUME
// =====================================================

function togglePause() {

    if (currentState === STATES.PLAYING) {

        currentState = STATES.PAUSED;

        pauseFadeTimer =
            FEEDBACK.PAUSE_FADE_DURATION;

        playPauseSound();

    }

    else if (currentState === STATES.PAUSED) {

        currentState = STATES.PLAYING;

        pauseFadeTimer = 0;

        playResumeSound();

    }

}


// =====================================================
// KEYBOARD INPUT
// =====================================================

window.addEventListener("keydown", function(event) {

    const target = event.target;

    if (
        target instanceof Element &&
        target.closest(
            "button, input, select, textarea, a[href], [contenteditable]"
        )
    ) {

        return;

    }

    const key = event.code;

    if (
        key === "ArrowLeft" ||
        key === "ArrowRight" ||
        key === "Space"
    ) {

        event.preventDefault();

    }


    // =================================================
    // BUG FIX: KEYBOARD OVERRIDES MOUSE
    // =================================================
    //
    // When a movement key is pressed, clear pointerX.
    // The basket immediately returns to keyboard control.
    //
    // Moving the mouse again restores mouse control.
    //
    // =================================================

    if (
        key === "ArrowLeft" ||
        key === "ArrowRight" ||
        key === "KeyA" ||
        key === "KeyD"
    ) {

        input.pointerX = null;

    }


    if (key === "ArrowLeft" || key === "KeyA") {

        heldLeftKeys.add(key);

        input.left = true;

    }

    if (key === "ArrowRight" || key === "KeyD") {

        heldRightKeys.add(key);

        input.right = true;

    }

    if (event.repeat) {

        return;

    }

    if (
        key === "Space" ||
        key === "Enter"
    ) {

        if (
            currentState === STATES.MENU ||
            currentState === STATES.GAMEOVER
        ) {

            startGame();

        }

    }

    if (key === "KeyP") {

        initializeAudio();

        togglePause();

    }

    if (key === "KeyR") {

        startGame();

    }

});


// =====================================================
// KEY RELEASE
// =====================================================

window.addEventListener("keyup", function(event) {

    const key = event.code;

    if (
        key === "ArrowLeft" ||
        key === "KeyA"
    ) {

        heldLeftKeys.delete(key);

        input.left = heldLeftKeys.size > 0;

    }

    if (
        key === "ArrowRight" ||
        key === "KeyD"
    ) {

        heldRightKeys.delete(key);

        input.right = heldRightKeys.size > 0;

    }

});


// =====================================================
// POINTER COORDINATES
// =====================================================

function getCanvasPointerPosition(clientX, clientY) {

    const rect =
        canvas.getBoundingClientRect();

    const styles =
        window.getComputedStyle(canvas);

    const borderLeft =
        parseFloat(styles.borderLeftWidth) || 0;

    const borderRight =
        parseFloat(styles.borderRightWidth) || 0;

    const borderTop =
        parseFloat(styles.borderTopWidth) || 0;

    const borderBottom =
        parseFloat(styles.borderBottomWidth) || 0;

    const scaleX =
        canvasWidth /
        (rect.width - borderLeft - borderRight);

    const scaleY =
        canvasHeight /
        (rect.height - borderTop - borderBottom);

    const borderScaleX =
        rect.width / canvas.offsetWidth;

    const borderScaleY =
        rect.height / canvas.offsetHeight;

    return {

        x:
            (clientX - rect.left -
            borderLeft * borderScaleX) * scaleX,

        y:
            (clientY - rect.top -
            borderTop * borderScaleY) * scaleY

    };

}


// =====================================================
// EXISTING POINTER X CONVERSION
// =====================================================

function getCanvasPointerX(clientX) {

    const rect = canvas.getBoundingClientRect();

    const scaleX = canvasWidth / rect.width;

    return (clientX - rect.left) * scaleX;

}


// =====================================================
// MOUSE INPUT
// =====================================================

canvas.addEventListener("mousemove", function(event) {

    input.pointerX =
        getCanvasPointerX(event.clientX);

});

canvas.addEventListener("mouseleave", function() {

    input.pointerX = null;

});

canvas.addEventListener("click", function() {

    initializeAudio();

    if (
        currentState === STATES.MENU ||
        currentState === STATES.GAMEOVER
    ) {

        startGame();

    }

});


// =====================================================
// TOUCH INPUT
// =====================================================

canvas.addEventListener("touchstart", function(event) {

    event.preventDefault();

    initializeAudio();

    if (
        currentState === STATES.MENU ||
        currentState === STATES.GAMEOVER
    ) {

        startGame();

    }

    const touch = event.touches[0];

    if (touch) {

        input.pointerX =
            getCanvasPointerX(touch.clientX);

    }

}, { passive: false });


canvas.addEventListener("touchmove", function(event) {

    event.preventDefault();

    const touch = event.touches[0];

    if (touch) {

        input.pointerX =
            getCanvasPointerX(touch.clientX);

    }

}, { passive: false });


canvas.addEventListener("touchend", function(event) {

    event.preventDefault();

    input.pointerX = null;

}, { passive: false });


canvas.addEventListener("touchcancel", function() {

    input.pointerX = null;

});


// =====================================================
// RESET ACTIVE INPUT
// =====================================================

function clearActiveInput() {

    input.left = false;

    input.right = false;

    input.pointerX = null;

    heldLeftKeys.clear();

    heldRightKeys.clear();

}


// =====================================================
// WINDOW BLUR
// =====================================================

window.addEventListener("blur", function() {

    clearActiveInput();

    if (currentState === STATES.PLAYING) {

        currentState = STATES.PAUSED;

        pauseFadeTimer =
            FEEDBACK.PAUSE_FADE_DURATION;

    }

});


// =====================================================
// BUG FIX: PAUSE WHEN TAB BECOMES HIDDEN
// =====================================================
//
// Some browsers do not reliably fire blur when
// switching tabs.
//
// visibilitychange provides additional protection.
//
// =====================================================

document.addEventListener(
    "visibilitychange",
    function() {

        if (document.hidden) {

            clearActiveInput();

            if (currentState === STATES.PLAYING) {

                currentState = STATES.PAUSED;

                pauseFadeTimer =
                    FEEDBACK.PAUSE_FADE_DURATION;

            }

        }

    }
);


// =====================================================
// UPDATE BASKET
// =====================================================

function updateBasket(dt) {

    if (input.pointerX !== null) {

        basket.x =
            input.pointerX - basket.width / 2;

    }

    else {

        let direction = 0;

        if (input.left) {

            direction -= 1;

        }

        if (input.right) {

            direction += 1;

        }

        basket.x +=
            direction * basket.speed * dt;

    }

    basket.x = Math.max(
        0,
        Math.min(
            canvasWidth - basket.width,
            basket.x
        )
    );

}


// =====================================================
// SPAWN ITEM
// =====================================================

function spawnItem() {

    const x =
        Math.random() * (canvasWidth - ITEM_SIZE);

    const isBad =
        Math.random() < badChance;

    const item = {

        x: x,

        y: -ITEM_SIZE,

        width: ITEM_SIZE,

        height: ITEM_SIZE,

        vy: fallSpeed,

        type: isBad ? "bad" : "good",

        points: isBad ? 0 : GOOD_POINTS

    };

    fallingItems.push(item);

}


// =====================================================
// UPDATE SPAWNING
// =====================================================

function updateSpawning(dt) {

    spawnTimer += dt;

    while (spawnTimer >= spawnInterval) {

        spawnTimer -= spawnInterval;

        spawnItem();

    }

}


// =====================================================
// DIFFICULTY SCALING
// =====================================================

function updateDifficulty(dt) {

    elapsedTime += dt;

    fallSpeed = Math.min(

        MAX_FALL_SPEED,

        BASE_FALL_SPEED +
        (elapsedTime / 10) * 15

    );

    spawnInterval = Math.max(

        MIN_SPAWN_INTERVAL,

        BASE_SPAWN_INTERVAL -
        (elapsedTime / 10) * 0.05

    );

    badChance = Math.min(

        MAX_BAD_CHANCE,

        BASE_BAD_CHANCE +
        (elapsedTime / 15) * 0.02

    );

}


// =====================================================
// COLLISION DETECTION
// =====================================================

function isColliding(a, b) {

    return (

        a.x < b.x + b.width &&

        a.x + a.width > b.x &&

        a.y < b.y + b.height &&

        a.y + a.height > b.y

    );

}


// =====================================================
// GOOD CATCH FEEDBACK
// =====================================================

function triggerGoodCatchFeedback(item) {

    const centerX =
        item.x + item.width / 2;

    const centerY =
        item.y + item.height / 2;

    createGoodCatchParticles(
        centerX,
        centerY
    );

    createFloatingText(
        centerX,
        centerY,
        "+" + item.points,
        "#2E7D32"
    );

    triggerScorePulse();

    triggerBasketBounce();

    playCatchSound();

}


// =====================================================
// BAD CATCH FEEDBACK
// =====================================================

function triggerBadCatchFeedback(item) {

    const centerX =
        item.x + item.width / 2;

    const centerY =
        item.y + item.height / 2;

    createBadCatchParticles(
        centerX,
        centerY
    );

    createFloatingText(
        centerX,
        centerY,
        "-1 Life",
        "#B23A2E"
    );

    triggerScreenShake();

    triggerDamageFlash();

    triggerLivesPulse();

    triggerBasketTilt();

}


// =====================================================
// UPDATE FALLING ITEMS
// =====================================================

function updateItems(dt) {

    let damageOccurred = false;

    for (
        let i = fallingItems.length - 1;
        i >= 0;
        i--
    ) {

        const item = fallingItems[i];

        item.y += item.vy * dt;

        if (isColliding(item, basket)) {

            if (item.type === "good") {

                // EXISTING GAMEPLAY RULE

                score += item.points;

                // STAGE 3 FEEDBACK

                triggerGoodCatchFeedback(item);

            }

            else if (item.type === "bad") {

                // EXISTING GAMEPLAY RULE

                lives -= 1;

                // STAGE 3 FEEDBACK

                triggerBadCatchFeedback(item);

                damageOccurred = true;

            }

            fallingItems.splice(i, 1);

            continue;

        }

        if (item.y > canvasHeight) {

            // Missing apples has no penalty.

            fallingItems.splice(i, 1);

        }

    }

    // Game-over audio takes priority over damage audio.

    if (damageOccurred && lives > 0) {

        playDamageSound();

    }

}


// =====================================================
// CHECK GAME OVER
// =====================================================

function checkGameOver() {

    if (lives <= 0) {

        lives = 0;

        finalScore = score;

        fallingItems = [];


        // =============================================
        // STAGE 4: HIGH SCORE CHECK
        // =============================================

        isNewHighScore =
            finalScore > highScore;

        if (isNewHighScore) {

            highScore = finalScore;

            saveHighScore(highScore);

            resetStatusMessage.textContent =
                "New High Score! " + highScore;

        }


        // =============================================
        // STAGE 4: ENABLE RESET DATA
        // =============================================

        resetDataButton.disabled = false;


        // EXISTING GAME OVER LOGIC

        currentState = STATES.GAMEOVER;

        gameOverTransitionTimer =
            FEEDBACK.GAMEOVER_TRANSITION_DURATION;

        playGameOverSound();

    }

}


// =====================================================
// MAIN UPDATE
// =====================================================

function update(dt) {

    switch (currentState) {

        case STATES.MENU:

            break;


        case STATES.PLAYING:

            updateBasket(dt);

            updateDifficulty(dt);

            updateSpawning(dt);

            updateItems(dt);

            checkGameOver();

            break;


        case STATES.PAUSED:

            break;


        case STATES.GAMEOVER:

            break;

    }

}


// =====================================================
// ROUNDED RECTANGLE
// =====================================================

function drawRoundedRect(x, y, w, h, radius) {

    ctx.beginPath();

    ctx.moveTo(x + radius, y);

    ctx.arcTo(
        x + w,
        y,
        x + w,
        y + h,
        radius
    );

    ctx.arcTo(
        x + w,
        y + h,
        x,
        y + h,
        radius
    );

    ctx.arcTo(
        x,
        y + h,
        x,
        y,
        radius
    );

    ctx.arcTo(
        x,
        y,
        x + w,
        y,
        radius
    );

    ctx.closePath();

}


// =====================================================
// DRAW CLOUD
// =====================================================

function drawCloud(x, y, scale) {

    ctx.save();

    ctx.translate(x, y);

    ctx.scale(scale, scale);

    ctx.fillStyle = "#D7E6EE";

    ctx.beginPath();

    ctx.arc(0, 4, 18, 0, Math.PI * 2);

    ctx.arc(22, 4, 18, 0, Math.PI * 2);

    ctx.fill();

    ctx.fillStyle = "#FFFFFF";

    ctx.beginPath();

    ctx.arc(0, 0, 18, 0, Math.PI * 2);

    ctx.arc(20, -6, 14, 0, Math.PI * 2);

    ctx.arc(-18, -4, 12, 0, Math.PI * 2);

    ctx.fill();

    ctx.restore();

}


// =====================================================
// DRAW TREE
// =====================================================

function drawTree(x, baseY, scale) {

    ctx.save();

    ctx.translate(x, baseY);

    ctx.scale(scale, scale);

    ctx.fillStyle = "#6B4226";

    ctx.fillRect(-4, -10, 8, 14);

    ctx.fillStyle = "#4F8A3D";

    ctx.beginPath();

    ctx.arc(0, -22, 16, 0, Math.PI * 2);

    ctx.arc(-12, -14, 12, 0, Math.PI * 2);

    ctx.arc(12, -14, 12, 0, Math.PI * 2);

    ctx.fill();

    ctx.fillStyle = "#6FB04F";

    ctx.beginPath();

    ctx.arc(-4, -26, 8, 0, Math.PI * 2);

    ctx.fill();

    ctx.restore();

}


// =====================================================
// DRAW APPLE
// =====================================================

function drawApple(x, y, size, type) {

    const r = size / 2;

    const cx = x + r;

    const cy = y + r;

    ctx.fillStyle = "rgba(0,0,0,0.15)";

    ctx.beginPath();

    ctx.ellipse(
        cx,
        y + size + 2,
        r * 0.7,
        3,
        0,
        0,
        Math.PI * 2
    );

    ctx.fill();

    const grad = ctx.createRadialGradient(

        cx - r * 0.3,
        cy - r * 0.3,
        r * 0.2,

        cx,
        cy,
        r

    );

    if (type === "good") {

        grad.addColorStop(0, "#A6E07A");

        grad.addColorStop(1, "#2E7D32");

    }

    else {

        grad.addColorStop(0, "#E57373");

        grad.addColorStop(1, "#7F0000");

    }

    ctx.fillStyle = grad;

    ctx.beginPath();

    ctx.arc(
        cx,
        cy,
        r,
        0,
        Math.PI * 2
    );

    ctx.fill();

    ctx.strokeStyle = "#5A3815";

    ctx.lineWidth = 2;

    ctx.beginPath();

    ctx.moveTo(cx, cy - r);

    ctx.lineTo(cx + 1, cy - r - 5);

    ctx.stroke();

    if (type === "good") {

        ctx.fillStyle = "#3E8E41";

        ctx.beginPath();

        ctx.ellipse(
            cx + 5,
            cy - r - 3,
            5,
            3,
            Math.PI / 4,
            0,
            Math.PI * 2
        );

        ctx.fill();

    }

    else {

        ctx.fillStyle = "#3E2723";

        ctx.beginPath();

        ctx.arc(
            cx - r * 0.3,
            cy + r * 0.2,
            r * 0.18,
            0,
            Math.PI * 2
        );

        ctx.arc(
            cx + r * 0.25,
            cy - r * 0.1,
            r * 0.12,
            0,
            Math.PI * 2
        );

        ctx.fill();

    }

}


// =====================================================
// DRAW ORCHARD BACKGROUND
// =====================================================

function drawBackground(timestamp) {

    const t = timestamp / 1000;

    const sky = ctx.createLinearGradient(
        0,
        0,
        0,
        canvasHeight
    );

    sky.addColorStop(0, "#AEE1F9");

    sky.addColorStop(1, "#EAF7FF");

    ctx.fillStyle = sky;

    ctx.fillRect(
        0,
        0,
        canvasWidth,
        canvasHeight
    );

    const sunX = canvasWidth - 70;

    const sunY = 70;

    const sunGlow = ctx.createRadialGradient(
        sunX,
        sunY,
        5,
        sunX,
        sunY,
        60
    );

    sunGlow.addColorStop(
        0,
        "#FFF4B8"
    );

    sunGlow.addColorStop(
        1,
        "rgba(255,244,184,0)"
    );

    ctx.fillStyle = sunGlow;

    ctx.beginPath();

    ctx.arc(
        sunX,
        sunY,
        60,
        0,
        Math.PI * 2
    );

    ctx.fill();

    ctx.fillStyle = "#FFF4B8";

    ctx.beginPath();

    ctx.arc(
        sunX,
        sunY,
        26,
        0,
        Math.PI * 2
    );

    ctx.fill();

    drawCloud(
        60 + Math.sin(t * 0.1) * 15,
        60,
        1
    );

    drawCloud(
        220 + Math.sin(t * 0.08 + 2) * 20,
        100,
        0.7
    );

    const groundY = canvasHeight - 70;

    for (let i = 0; i < 6; i++) {

        drawTree(
            30 + i * 90,
            groundY,
            1
        );

    }

    const grass = ctx.createLinearGradient(
        0,
        groundY,
        0,
        canvasHeight
    );

    grass.addColorStop(0, "#8BC34A");

    grass.addColorStop(1, "#558B2F");

    ctx.fillStyle = grass;

    ctx.fillRect(
        0,
        groundY,
        canvasWidth,
        canvasHeight - groundY
    );

    ctx.strokeStyle = "rgba(0,0,0,0.1)";

    ctx.lineWidth = 2;

    ctx.beginPath();

    ctx.moveTo(0, groundY);

    ctx.lineTo(canvasWidth, groundY);

    ctx.stroke();

}


// =====================================================
// DRAW BASKET
// =====================================================

function drawBasket() {

    const { x, y, width, height } = basket;

    ctx.save();

    // STAGE 3: VISUAL BASKET RESPONSE

    const centerX = x + width / 2;

    const centerY = y + height / 2;

    ctx.translate(centerX, centerY);

    if (basketBounceTimer > 0) {

        const progress =
            basketBounceTimer /
            FEEDBACK.BASKET_BOUNCE_DURATION;

        ctx.scale(
            1.03,
            1 - Math.sin(progress * Math.PI) * 0.08
        );

    }

    if (basketTiltTimer > 0) {

        const progress =
            basketTiltTimer /
            FEEDBACK.BASKET_BOUNCE_DURATION;

        ctx.rotate(
            Math.sin(progress * Math.PI) * 0.05
        );

    }

    ctx.translate(-centerX, -centerY);


    // ORIGINAL BASKET ARTWORK

    ctx.fillStyle = "rgba(0,0,0,0.25)";

    ctx.beginPath();

    ctx.ellipse(
        x + width / 2,
        y + height + 6,
        width / 2.2,
        6,
        0,
        0,
        Math.PI * 2
    );

    ctx.fill();

    const inset = width * 0.12;

    const bodyGrad = ctx.createLinearGradient(
        x,
        y,
        x,
        y + height
    );

    bodyGrad.addColorStop(0, "#C68642");

    bodyGrad.addColorStop(1, "#5A3815");

    ctx.fillStyle = bodyGrad;

    ctx.beginPath();

    ctx.moveTo(x, y);

    ctx.lineTo(x + width, y);

    ctx.lineTo(
        x + width - inset,
        y + height
    );

    ctx.lineTo(
        x + inset,
        y + height
    );

    ctx.closePath();

    ctx.fill();

    ctx.strokeStyle = "#4A2F1C";

    ctx.lineWidth = 2;

    for (let i = 1; i <= 2; i++) {

        const lineY =
            y + (height / 3) * i;

        ctx.beginPath();

        ctx.moveTo(
            x + inset * (i / 3),
            lineY
        );

        ctx.lineTo(
            x + width - inset * (i / 3),
            lineY
        );

        ctx.stroke();

    }

    ctx.fillStyle = "#C68642";

    ctx.beginPath();

    ctx.ellipse(
        x + width / 2,
        y,
        width / 2,
        5,
        0,
        0,
        Math.PI * 2
    );

    ctx.fill();

    ctx.strokeStyle = "#4A2F1C";

    ctx.lineWidth = 2;

    ctx.beginPath();

    ctx.ellipse(
        x + width / 2,
        y,
        width / 2,
        5,
        0,
        0,
        Math.PI * 2
    );

    ctx.stroke();

    ctx.restore();

}


// =====================================================
// DRAW ITEMS
// =====================================================

function drawItems() {

    for (const item of fallingItems) {

        drawApple(
            item.x,
            item.y,
            item.width,
            item.type
        );

    }

}


// =====================================================
// HUD PANEL HELPER
// =====================================================

function drawHUDPanel(
    x,
    y,
    width,
    height,
    pulseTimer,
    pulseDuration
) {

    ctx.save();

    if (
        pulseTimer > 0 &&
        !prefersReducedMotion()
    ) {

        const progress =
            pulseTimer / pulseDuration;

        const scale =
            1 + Math.sin(progress * Math.PI) * 0.04;

        ctx.translate(
            x + width / 2,
            y + height / 2
        );

        ctx.scale(scale, scale);

        ctx.translate(
            -(x + width / 2),
            -(y + height / 2)
        );

    }

    const gradient = ctx.createLinearGradient(
        x,
        y,
        x,
        y + height
    );

    gradient.addColorStop(
        0,
        "#6D4C25"
    );

    gradient.addColorStop(
        1,
        "#4A3418"
    );

    drawRoundedRect(
        x,
        y,
        width,
        height,
        10
    );

    ctx.fillStyle = gradient;

    ctx.fill();

    ctx.strokeStyle = "#2F2013";

    ctx.lineWidth = 2;

    ctx.stroke();

    ctx.restore();

}


// =====================================================
// DRAW HUD
// =====================================================

function drawHUD() {

    drawHUDPanel(
        10,
        10,
        140,
        38,
        scorePulseTimer,
        FEEDBACK.SCORE_PULSE_DURATION
    );

    ctx.fillStyle = "#FFF8E1";

    ctx.font = "bold 18px Georgia";

    ctx.textAlign = "left";

    ctx.textBaseline = "middle";

    ctx.fillText(
        "Score: " + score,
        22,
        29
    );


    const panelWidth = 140;

    const panelX =
        canvasWidth - 10 - panelWidth;

    drawHUDPanel(
        panelX,
        10,
        panelWidth,
        38,
        livesPulseTimer,
        FEEDBACK.LIVES_PULSE_DURATION
    );


    // LIFE DAMAGE HIGHLIGHT

    if (livesPulseTimer > 0) {

        ctx.save();

        const alpha =
            livesPulseTimer /
            FEEDBACK.LIVES_PULSE_DURATION;

        ctx.strokeStyle =
            `rgba(229,115,115,${alpha})`;

        ctx.lineWidth = 3;

        drawRoundedRect(
            panelX,
            10,
            panelWidth,
            38,
            10
        );

        ctx.stroke();

        ctx.restore();

    }


    ctx.fillStyle = "#FFF8E1";

    ctx.textAlign = "left";

    ctx.fillText(
        "Lives:",
        panelX + 12,
        29
    );

    for (let i = 0; i < lives; i++) {

        drawApple(
            panelX + 70 + i * 20,
            15,
            16,
            "bad"
        );

    }

    ctx.textBaseline = "alphabetic";

}


// =====================================================
// DRAW CENTERED TEXT
// =====================================================

function drawCenteredText(text, y, size, color) {

    ctx.textBaseline = "alphabetic";

    ctx.textAlign = "center";

    ctx.font =
        "bold " + size + "px Georgia";

    ctx.lineWidth = 4;

    ctx.strokeStyle =
        "rgba(255,248,225,0.9)";

    ctx.strokeText(
        text,
        canvasWidth / 2,
        y
    );

    ctx.fillStyle = color;

    ctx.fillText(
        text,
        canvasWidth / 2,
        y
    );

}


// =====================================================
// MENU SCREEN
// =====================================================

function drawMenuScreen() {

    drawApple(
        canvasWidth / 2 - 160,
        170,
        40,
        "good"
    );

    drawApple(
        canvasWidth / 2 + 120,
        170,
        40,
        "bad"
    );

    drawCenteredText(
        "CATCH GAME",
        200,
        36,
        "#4A2F1C"
    );

    drawCenteredText(
        "Catch GREEN apples",
        260,
        20,
        "#2E7D32"
    );

    drawCenteredText(
        "Avoid RED apples",
        295,
        20,
        "#B23A2E"
    );

    drawRoundedRect(
        canvasWidth / 2 - 140,
        345,
        280,
        60,
        12
    );

    ctx.fillStyle =
        "rgba(255,248,225,0.85)";

    ctx.fill();

    ctx.strokeStyle = "#4A2F1C";

    ctx.lineWidth = 2;

    ctx.stroke();

    drawCenteredText(
        "Press SPACE or ENTER",
        370,
        18,
        "#4A2F1C"
    );

    drawCenteredText(
        "or CLICK / TAP to start",
        393,
        16,
        "#4A2F1C"
    );


    // =============================================
    // STAGE 4: DISPLAY HIGH SCORE
    // =============================================

    drawCenteredText(
        "Best: " + highScore,
        445,
        22,
        "#6D4C25"
    );

}


// =====================================================
// PAUSE OVERLAY
// =====================================================

function drawPauseOverlay() {

    let opacity = 1;

    if (
        pauseFadeTimer > 0 &&
        !prefersReducedMotion()
    ) {

        opacity =
            1 -
            pauseFadeTimer /
            FEEDBACK.PAUSE_FADE_DURATION;

    }

    ctx.save();

    ctx.globalAlpha = opacity;

    ctx.fillStyle =
        "rgba(43,27,14,0.55)";

    ctx.fillRect(
        0,
        0,
        canvasWidth,
        canvasHeight
    );

    ctx.fillStyle = "#FFF8E1";

    ctx.fillRect(
        canvasWidth / 2 - 22,
        220,
        14,
        40
    );

    ctx.fillRect(
        canvasWidth / 2 + 8,
        220,
        14,
        40
    );

    drawCenteredText(
        "PAUSED",
        300,
        40,
        "#FFF8E1"
    );

    drawCenteredText(
        "Press P to Resume",
        340,
        20,
        "#FFF8E1"
    );

    ctx.restore();

}


// =====================================================
// GAME OVER SCREEN
// =====================================================

function drawGameOverScreen() {

    let opacity = 1;

    if (
        gameOverTransitionTimer > 0 &&
        !prefersReducedMotion()
    ) {

        opacity =
            1 -
            gameOverTransitionTimer /
            FEEDBACK.GAMEOVER_TRANSITION_DURATION;

    }

    ctx.save();

    ctx.globalAlpha = opacity;

    ctx.fillStyle =
        "rgba(43,27,14,0.55)";

    ctx.fillRect(
        0,
        0,
        canvasWidth,
        canvasHeight
    );

    drawApple(
        canvasWidth / 2 - 20,
        150,
        40,
        "bad"
    );

    drawCenteredText(
        "GAME OVER",
        230,
        40,
        "#C62828"
    );

    drawRoundedRect(
        canvasWidth / 2 - 120,
        260,
        240,
        50,
        12
    );

    ctx.fillStyle =
        "rgba(255,248,225,0.9)";

    ctx.fill();

    ctx.strokeStyle = "#4A2F1C";

    ctx.lineWidth = 2;

    ctx.stroke();

    drawCenteredText(
        "Final Score: " + finalScore,
        292,
        24,
        "#4A2F1C"
    );


    // =============================================
    // STAGE 4: DISPLAY HIGH SCORE
    // =============================================

    drawCenteredText(
        "Best: " + highScore,
        325,
        18,
        "#FFF8E1"
    );


    // EXISTING RESTART INSTRUCTIONS

    drawCenteredText(
        "Press R to Restart",
        360,
        20,
        "#FFF8E1"
    );

    drawCenteredText(
        "or SPACE / CLICK / TAP",
        388,
        16,
        "#FFF8E1"
    );


    // =============================================
    // STAGE 4: NEW HIGH SCORE MESSAGE
    // =============================================

    if (isNewHighScore) {

        drawCenteredText(
            "New High Score!",
            440,
            24,
            "#FFD54F"
        );

    }

    ctx.restore();

}


// =====================================================
// START TRANSITION
// =====================================================

function drawStartTransition() {

    if (startTransitionTimer <= 0) {

        return;

    }

    if (prefersReducedMotion()) {

        return;

    }

    const progress =
        startTransitionTimer /
        FEEDBACK.START_TRANSITION_DURATION;

    ctx.save();

    ctx.globalAlpha = progress * 0.8;

    drawCenteredText(
        "GO!",
        300,
        42,
        "#3E8E41"
    );

    ctx.restore();

}


// =====================================================
// RENDER GAMEPLAY SCENE
// =====================================================

function drawGameplayScene() {

    ctx.save();

    applyScreenShake();

    drawBasket();

    drawItems();

    drawParticles();

    drawFloatingTexts();

    ctx.restore();

    drawDamageFlash();

    drawHUD();

}


// =====================================================
// RENDER
// =====================================================

function render(timestamp) {

    ctx.clearRect(
        0,
        0,
        canvasWidth,
        canvasHeight
    );

    drawBackground(timestamp);

    switch (currentState) {

        case STATES.MENU:

            drawMenuScreen();

            break;


        case STATES.PLAYING:

            drawGameplayScene();

            drawStartTransition();

            break;


        case STATES.PAUSED:

            drawGameplayScene();

            drawPauseOverlay();

            break;


        case STATES.GAMEOVER:

            drawGameOverScreen();

            break;

    }

}


// =====================================================
// GAME LOOP
// =====================================================

let lastTime = null;

function gameLoop(timestamp) {

    if (lastTime === null) {

        lastTime = timestamp;

    }

    let dt =
        (timestamp - lastTime) / 1000;

    lastTime = timestamp;

    dt = Math.min(
        dt,
        MAX_DELTA_TIME
    );


    // EXISTING GAMEPLAY UPDATE

    update(dt);


    // STAGE 3 GAMEPLAY FEEDBACK
    // Freeze while paused.

    if (currentState === STATES.PLAYING) {

        updateGameplayFeedback(dt);

    }


    // UI ANIMATIONS
    // Continue during pause and game over.

    updateUIFeedback(dt);


    // RENDER

    render(timestamp);


    // NEXT FRAME

    requestAnimationFrame(gameLoop);

}


// =====================================================
// STAGE 4: INITIALIZE STORAGE
// =====================================================

loadGameData();

updateMuteButton();


// =====================================================
// INITIALIZE GAME
// =====================================================

resetGame();

currentState = STATES.MENU;

resetDataButton.disabled = false;


// =====================================================
// START MAIN LOOP
// =====================================================

requestAnimationFrame(gameLoop);