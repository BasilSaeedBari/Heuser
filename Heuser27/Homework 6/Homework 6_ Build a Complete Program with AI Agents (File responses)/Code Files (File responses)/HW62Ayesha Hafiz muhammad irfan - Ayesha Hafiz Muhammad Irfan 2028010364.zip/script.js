/**
 * Capybara Virtual Pet — Core Logic Implementation
 * Features:
 * - Pixel Operator typography everywhere
 * - Pure SVG procedural messier vines with fixed seeds (non-mirrored)
 * - Realistic layered spiral yellow roses and arching moth orchids (Phalaenopsis)
 * - Scattered fallen autumn leaves that build up with bonding
 * - Dialogue written directly onto the tablecloth frill (left of treats dock)
 * - Bug-free resetSalad() and unblurred goodbye / restart modals
 * - Complete removal of emojis from UI, dialogues, and toast notifications
 */

// ============================================================================
// 1. Constants & Configuration
// ============================================================================

const STORAGE_KEY = 'capybara_pet_data';

const GAME_STATES = {
  IDLE: 'IDLE',
  BEING_PET: 'BEING_PET',
  BEING_FED: 'BEING_FED',
  GOODBYE: 'GOODBYE',
  GAME_OVER_RESTART: 'GAME_OVER_RESTART',
};

// Dialogue pool without emojis (written directly to the yellow frill)
const DIALOGUE_POOL = [
  "The capybara sniffs the gentle breeze peacefully.",
  "*Soft squeak* Capybara leans pleasantly into your hand.",
  "The warm sun makes the capybara's fur feel toasty.",
  "Capybara blinks slowly in pure contentment.",
  "The tall grass tickles, and capybara wiggles its ears.",
  "You feel a calming wave of quiet companionship.",
  "A soft splash from the river ripples nearby.",
  "Capybara rests its chin comfortably, enjoying your presence.",
  "It looks like it wouldn't mind a yuzu fruit on its head someday.",
  "Soft purr-like vibration echoes as you gently stroke its back."
];

// Feeding acknowledgement phrases without emojis
const FEEDING_PHRASES = [
  "Nom nom nom!",
  "Crunch crunch... delicious!",
  "Chomp chomp! Crispy greens!",
  "Gulp! Capybara is thoroughly satisfied!"
];

// Head posture ranges derived from bonding (rotates SVG head group silently)
const HEAD_POSTURES = [
  { max: 20, className: 'head-posture-0' },
  { max: 40, className: 'head-posture-1' },
  { max: 60, className: 'head-posture-2' },
  { max: 80, className: 'head-posture-3' },
  { max: 100, className: 'head-posture-4' }
];

// Deterministic PRNG for procedural organic vines & leaves
function createPrng(seed) {
  let s = seed % 2147483647;
  if (s <= 0) s += 2147483646;
  return function() {
    s = (s * 16807) % 2147483647;
    return (s - 1) / 2147483646;
  };
}

// ============================================================================
// 2. State & Data Structure
// ============================================================================

let state = {
  currentState: GAME_STATES.IDLE,
  happiness: 30,         // Range 0-100, starts at 30
  bonding: 0,            // Range 0-100, starts at 0
  scene: 1,              // 1 or 2
  lastDialogueIndex: -1, // No consecutive dialogue repeats
  scrapbookShown: false, // One-shot scrapbook trigger at bonding >= 50
  vinesGrownSoundPlayed: false,
  flowersSoundPlayed: false
};

// Timers
let dialogueTimer = null;
let feedAnimTimer = null;
let blinkInterval = null;

// ============================================================================
// 3. Web Audio Engine (Boops, Purrs, Crunches, Ambience)
// ============================================================================

class CapyAudioEngine {
  constructor() {
    this.ctx = null;
    this.masterGain = null;
    this.ambienceGain = null;
    this.ambientSource = null;
    this.cricketTimer = null;
    this.isInitialized = false;
    this.isSuspended = false;
  }

  init() {
    if (this.isInitialized) return;
    try {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (!AudioCtx) return;
      this.ctx = new AudioCtx();
      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.setValueAtTime(0.7, this.ctx.currentTime);
      this.masterGain.connect(this.ctx.destination);

      this.isInitialized = true;
      this.startAmbientSoundscape();
    } catch (e) {
      console.warn('Web Audio API unavailable:', e);
    }
  }

  ensureContext() {
    if (!this.isInitialized) {
      this.init();
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  playBoop() {
    this.ensureContext();
    if (!this.ctx) return;
    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const now = this.ctx.currentTime;

      osc.type = 'sine';
      osc.frequency.setValueAtTime(440, now);
      osc.frequency.exponentialRampToValueAtTime(520, now + 0.12);

      gain.gain.setValueAtTime(0.18, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.16);

      osc.connect(gain);
      gain.connect(this.masterGain);

      osc.start(now);
      osc.stop(now + 0.17);
    } catch (e) {}
  }

  playPurr() {
    this.ensureContext();
    if (!this.ctx) return;
    try {
      const now = this.ctx.currentTime;
      const bufferSize = Math.floor(this.ctx.sampleRate * 0.6);
      const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        data[i] = Math.random() * 2 - 1;
      }

      const noise = this.ctx.createBufferSource();
      noise.buffer = buffer;

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(80, now);

      const gain = this.ctx.createGain();
      gain.gain.setValueAtTime(0.001, now);
      gain.gain.linearRampToValueAtTime(0.14, now + 0.15);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.6);

      noise.connect(filter);
      filter.connect(gain);
      gain.connect(this.masterGain);

      noise.start(now);
      noise.stop(now + 0.62);
    } catch (e) {}
  }

  playCrunch() {
    this.ensureContext();
    if (!this.ctx) return;
    try {
      const now = this.ctx.currentTime;
      const bufferSize = Math.floor(this.ctx.sampleRate * 0.08);
      const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        data[i] = Math.random() * 2 - 1;
      }

      const noise = this.ctx.createBufferSource();
      noise.buffer = buffer;

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(2000, now);
      filter.Q.setValueAtTime(3, now);

      const gain = this.ctx.createGain();
      gain.gain.setValueAtTime(0.25, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.08);

      noise.connect(filter);
      filter.connect(gain);
      gain.connect(this.masterGain);

      noise.start(now);
      noise.stop(now + 0.09);
    } catch (e) {}
  }

  playHappyHum() {
    this.ensureContext();
    if (!this.ctx) return;
    try {
      const now = this.ctx.currentTime;
      const freqs = [261.63, 329.63, 392.00];
      freqs.forEach(f => {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(f, now);

        gain.gain.setValueAtTime(0.001, now);
        gain.gain.linearRampToValueAtTime(0.08, now + 0.15);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.45);

        osc.connect(gain);
        gain.connect(this.masterGain);

        osc.start(now);
        osc.stop(now + 0.46);
      });
    } catch (e) {}
  }

  playPaperRustle() {
    this.ensureContext();
    if (!this.ctx) return;
    try {
      const now = this.ctx.currentTime;
      const bufferSize = Math.floor(this.ctx.sampleRate * 0.22);
      const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        data[i] = Math.random() * 2 - 1;
      }

      const noise = this.ctx.createBufferSource();
      noise.buffer = buffer;

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(1000, now);
      filter.frequency.exponentialRampToValueAtTime(4000, now + 0.2);

      const gain = this.ctx.createGain();
      gain.gain.setValueAtTime(0.12, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);

      noise.connect(filter);
      filter.connect(gain);
      gain.connect(this.masterGain);

      noise.start(now);
      noise.stop(now + 0.22);
    } catch (e) {}
  }

  playStamp() {
    this.ensureContext();
    if (!this.ctx) return;
    try {
      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'square';
      osc.frequency.setValueAtTime(120, now);
      osc.frequency.exponentialRampToValueAtTime(50, now + 0.03);

      gain.gain.setValueAtTime(0.15, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.035);

      osc.connect(gain);
      gain.connect(this.masterGain);

      osc.start(now);
      osc.stop(now + 0.04);
    } catch (e) {}
  }

  playPip() {
    this.ensureContext();
    if (!this.ctx) return;
    try {
      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(880, now);

      gain.gain.setValueAtTime(0.035, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.05);

      osc.connect(gain);
      gain.connect(this.masterGain);

      osc.start(now);
      osc.stop(now + 0.055);
    } catch (e) {}
  }

  playVineGrow() {
    this.ensureContext();
    if (!this.ctx) return;
    try {
      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(200, now);
      osc.frequency.exponentialRampToValueAtTime(800, now + 1.5);

      gain.gain.setValueAtTime(0.001, now);
      gain.gain.linearRampToValueAtTime(0.09, now + 0.4);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 1.5);

      osc.connect(gain);
      gain.connect(this.masterGain);

      osc.start(now);
      osc.stop(now + 1.55);
    } catch (e) {}
  }

  playFlowerBloom() {
    this.ensureContext();
    if (!this.ctx) return;
    try {
      const now = this.ctx.currentTime;
      const carrier = this.ctx.createOscillator();
      const carrierGain = this.ctx.createGain();
      const modulator = this.ctx.createOscillator();
      const modGain = this.ctx.createGain();

      carrier.type = 'sine';
      carrier.frequency.setValueAtTime(1200, now);

      modulator.type = 'sine';
      modulator.frequency.setValueAtTime(8, now);

      modGain.gain.setValueAtTime(0.5, now);
      modulator.connect(modGain);

      carrierGain.gain.setValueAtTime(0.09, now);
      carrierGain.gain.exponentialRampToValueAtTime(0.001, now + 0.8);

      carrier.connect(carrierGain);
      carrierGain.connect(this.masterGain);

      carrier.start(now);
      carrier.stop(now + 0.85);
      modulator.start(now);
      modulator.stop(now + 0.85);
    } catch (e) {}
  }

  startAmbientSoundscape() {
    if (!this.ctx) return;
    try {
      const bufferSize = this.ctx.sampleRate * 2;
      const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const data = buffer.getChannelData(0);
      let lastOut = 0.0;
      for (let i = 0; i < bufferSize; i++) {
        const white = Math.random() * 2 - 1;
        data[i] = (lastOut + (0.02 * white)) / 1.02;
        lastOut = data[i];
        data[i] *= 3.5;
      }

      this.ambientSource = this.ctx.createBufferSource();
      this.ambientSource.buffer = buffer;
      this.ambientSource.loop = true;

      const lowpass = this.ctx.createBiquadFilter();
      lowpass.type = 'lowpass';
      lowpass.frequency.setValueAtTime(200, this.ctx.currentTime);

      this.ambienceGain = this.ctx.createGain();
      this.ambienceGain.gain.setValueAtTime(0.035, this.ctx.currentTime);

      this.ambientSource.connect(lowpass);
      lowpass.connect(this.ambienceGain);
      this.ambienceGain.connect(this.masterGain);

      this.ambientSource.start();
      this.scheduleCricketChirp();
    } catch (e) {}
  }

  scheduleCricketChirp() {
    if (!this.ctx || this.isSuspended) return;
    const nextIn = 2500 + Math.random() * 3500;
    this.cricketTimer = setTimeout(() => {
      this.playCricketBurst();
      this.scheduleCricketChirp();
    }, nextIn);
  }

  playCricketBurst() {
    if (!this.ctx || this.isSuspended) return;
    const pings = 2 + Math.floor(Math.random() * 3);
    for (let i = 0; i < pings; i++) {
      setTimeout(() => {
        if (!this.ctx || this.isSuspended) return;
        try {
          const now = this.ctx.currentTime;
          const osc = this.ctx.createOscillator();
          const gain = this.ctx.createGain();
          const freq = 4400 + Math.random() * 600;

          osc.type = 'sine';
          osc.frequency.setValueAtTime(freq, now);

          gain.gain.setValueAtTime(0.012, now);
          gain.gain.exponentialRampToValueAtTime(0.001, now + 0.04);

          osc.connect(gain);
          gain.connect(this.masterGain);

          osc.start(now);
          osc.stop(now + 0.045);
        } catch (e) {}
      }, i * 45);
    }
  }

  playLullaby() {
    this.ensureContext();
    if (!this.ctx) return;
    try {
      const now = this.ctx.currentTime;
      const freqs = [261.63, 329.63, 392.00, 523.25];
      freqs.forEach(f => {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(f, now);

        gain.gain.setValueAtTime(0.001, now);
        gain.gain.linearRampToValueAtTime(0.06, now + 0.6);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + 3.0);

        osc.connect(gain);
        gain.connect(this.masterGain);

        osc.start(now);
        osc.stop(now + 3.05);
      });
    } catch (e) {}
  }

  stopAll() {
    this.isSuspended = true;
    if (this.cricketTimer) {
      clearTimeout(this.cricketTimer);
      this.cricketTimer = null;
    }
    if (!this.ctx || !this.masterGain) return;
    try {
      const now = this.ctx.currentTime;
      this.masterGain.gain.linearRampToValueAtTime(0.0001, now + 2.0);
      setTimeout(() => {
        if (this.ctx && this.ctx.state !== 'closed') {
          this.ctx.suspend();
        }
      }, 2500);
    } catch (e) {}
  }

  resumeAll() {
    this.isSuspended = false;
    if (this.ctx && this.masterGain) {
      this.ctx.resume();
      this.masterGain.gain.setValueAtTime(0.7, this.ctx.currentTime);
      if (!this.cricketTimer) {
        this.scheduleCricketChirp();
      }
    }
  }
}

const CapyAudio = new CapyAudioEngine();

// ============================================================================
// 4. DOM Elements
// ============================================================================

const gameContainer = document.getElementById('game-container');
const sceneWorld = document.getElementById('scene-world');
const happinessValEl = document.getElementById('happiness-val');
const happinessBarEl = document.getElementById('happiness-bar');
const bondingValEl = document.getElementById('bonding-val');
const bondingBarEl = document.getElementById('bonding-bar');

const waveBtn = document.getElementById('wave-btn');
const dialogueContainer = document.getElementById('dialogue-container');
const dialogueText = document.getElementById('dialogue-text');
const feedPopup = document.getElementById('feed-popup');

const capybaraInteractive = document.getElementById('capybara-interactive');
const capybaraHeadGroup = document.getElementById('capybara-head-group');
const eyeBall = document.getElementById('eye-ball');
const eyeSparkle = document.getElementById('eye-sparkle');
const eyeHappy = document.getElementById('eye-happy');
const yuzuAccessory = document.getElementById('yuzu-accessory');
const heartsLayer = document.getElementById('pet-hearts-layer');

const saladItem = document.getElementById('salad-item');
const constructionHat = document.getElementById('construction-hat');

const goodbyeModal = document.getElementById('goodbye-modal');
const goodbyeStayBtn = document.getElementById('goodbye-stay-btn');
const goodbyeRestartBtn = document.getElementById('goodbye-restart-btn');

const restartConfirmModal = document.getElementById('restart-confirm-modal');
const confirmCancelBtn = document.getElementById('confirm-cancel-btn');
const confirmResetBtn = document.getElementById('confirm-reset-btn');

const scrapbookOverlay = document.getElementById('scrapbook-overlay');
const scrapbookStickersContainer = document.getElementById('scrapbook-stickers-container');
const farewellMessage = document.getElementById('farewell-message');

// Container hooks for procedurally generated scenery
const foliageLeftContainer = document.getElementById('foliage-left-container');
const foliageRightContainer = document.getElementById('foliage-right-container');
const topVinesLayer = document.getElementById('top-vines-layer');
const frillVinesLayer = document.getElementById('frill-vines-layer');
const fallenLeavesLayer = document.getElementById('fallen-leaves-layer');
const orchidSprayLeft = document.getElementById('orchid-spray-left');
const orchidSprayCenter = document.getElementById('orchid-spray-center');
const orchidSprayRight = document.getElementById('orchid-spray-right');

// ============================================================================
// 5. Bug Fix 1: Unified Robust resetSalad()
// ============================================================================

/**
 * Completely resets the cabbage sandwich to its clean dock state,
 * removing any leftover drag, flight animations, transforms or inline styles.
 */
function resetSalad() {
  if (!saladItem) return;
  saladItem.classList.remove('salad-flying', 'is-dragging');
  saladItem.style.removeProperty('--fly-x');
  saladItem.style.removeProperty('--fly-y');
  saladItem.style.transform = '';
  saladItem.style.transition = '';
  saladItem.style.opacity = '';
  saladItem.style.pointerEvents = '';
  if (capybaraInteractive) {
    capybaraInteractive.classList.remove('drag-hover');
  }
}

// ============================================================================
// 6. Persistence (Save & Load)
// ============================================================================

function saveGame() {
  try {
    const dataToSave = {
      happiness: state.happiness,
      bonding: state.bonding,
      scene: state.scene,
      lastDialogueIndex: state.lastDialogueIndex,
      scrapbookShown: state.scrapbookShown
    };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(dataToSave));
  } catch (err) {
    console.warn('Could not save game:', err);
  }
}

function loadGame() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return;

    const data = JSON.parse(raw);
    if (typeof data.happiness === 'number' && !isNaN(data.happiness)) {
      state.happiness = Math.max(0, Math.min(100, Math.round(data.happiness)));
    }
    if (typeof data.bonding === 'number' && !isNaN(data.bonding)) {
      state.bonding = Math.max(0, Math.min(100, Math.round(data.bonding)));
    }
    if (data.scene === 1 || data.scene === 2) {
      state.scene = data.scene;
    }
    if (typeof data.lastDialogueIndex === 'number') {
      state.lastDialogueIndex = data.lastDialogueIndex;
    }
    if (typeof data.scrapbookShown === 'boolean') {
      state.scrapbookShown = data.scrapbookShown;
    }

    if (state.bonding >= 40) state.vinesGrownSoundPlayed = true;
    if (state.bonding >= 55) state.flowersSoundPlayed = true;
  } catch (err) {
    console.warn('Corrupted save data:', err);
  }
}

function clearSaveData() {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch (err) {}
}

// ============================================================================
// 7. Head Posture Logic (Silent Articulation)
// ============================================================================

function getHeadPostureInfo(bondingValue) {
  for (const item of HEAD_POSTURES) {
    if (bondingValue <= item.max) {
      return item;
    }
  }
  return HEAD_POSTURES[HEAD_POSTURES.length - 1];
}

function updateHeadPosture() {
  const posture = getHeadPostureInfo(state.bonding);
  HEAD_POSTURES.forEach(p => capybaraHeadGroup.classList.remove(p.className));
  capybaraHeadGroup.classList.add(posture.className);
}

// ============================================================================
// 8. UI Synchronization & Render
// ============================================================================

function updateUI() {
  // Stats
  happinessValEl.textContent = `${state.happiness}%`;
  happinessBarEl.style.width = `${state.happiness}%`;

  bondingValEl.textContent = `${state.bonding}%`;
  bondingBarEl.style.width = `${state.bonding}%`;

  // Visual state classes on #game-container
  const bondLevels = [0, 25, 30, 40, 50, 55, 60, 75, 100];
  bondLevels.forEach(lvl => gameContainer.classList.remove(`scene-bond-${lvl}`));
  const activeBond = [...bondLevels].reverse().find(lvl => state.bonding >= lvl) ?? 0;
  gameContainer.classList.add(`scene-bond-${activeBond}`);

  // Quiet scene presentation (No badges, no popups)
  if (state.scene === 2) {
    gameContainer.classList.remove('scene-1');
    gameContainer.classList.add('scene-2');
    yuzuAccessory.classList.remove('hidden');
  } else {
    gameContainer.classList.remove('scene-2');
    gameContainer.classList.add('scene-1');
    yuzuAccessory.classList.add('hidden');
  }

  // Update head posture silently
  updateHeadPosture();

  // Wave button interaction guard
  const isBusy = (state.currentState === GAME_STATES.BEING_PET ||
                  state.currentState === GAME_STATES.BEING_FED ||
                  state.currentState === GAME_STATES.GOODBYE);
  waveBtn.disabled = isBusy;
}

// Eye expression toggle
function setEyesHappy(happy) {
  if (happy) {
    eyeBall.classList.add('hidden');
    eyeSparkle.classList.add('hidden');
    eyeHappy.classList.remove('hidden');
  } else {
    eyeBall.classList.remove('hidden');
    eyeSparkle.classList.remove('hidden');
    eyeHappy.classList.add('hidden');
  }
}

// Pixel-Art floating heart burst (No text emojis)
function spawnHeart() {
  const group = document.createElementNS("http://www.w3.org/2000/svg", "g");
  group.setAttribute("class", "floating-heart");

  const scale = (0.85 + Math.random() * 0.4).toFixed(2);
  const sway = (Math.random() > 0.5 ? 1 : -1) * (10 + Math.random() * 8);
  group.style.setProperty('--heart-scale', scale);
  group.style.setProperty('--sway-dir', `${sway}px`);

  const spawnX = 210 + (Math.random() * 40 - 20);
  const spawnY = 85 + (Math.random() * 20 - 10);
  group.setAttribute("transform", `translate(${spawnX}, ${spawnY})`);

  // Sharp 8-bit pixel heart path
  const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
  const pixelHeartD = "M 1 0 h 3 v 1 h -3 z M 5 0 h 3 v 1 h -3 z M 0 1 h 9 v 3 h -9 z M 1 4 h 7 v 1 h -7 z M 2 5 h 5 v 1 h -5 z M 3 6 h 3 v 1 h -3 z M 4 7 h 1 v 1 h -1 z";
  path.setAttribute("d", pixelHeartD);
  path.setAttribute("fill", Math.random() > 0.35 ? "#FF4081" : "#FFD700");
  path.setAttribute("transform", "scale(1.8)");
  path.setAttribute("shape-rendering", "crispEdges");

  group.appendChild(path);
  heartsLayer.appendChild(group);

  setTimeout(() => {
    if (group.parentNode) {
      group.parentNode.removeChild(group);
    }
  }, 1400);
}

// ============================================================================
// 9. Procedural Organic Foliage & Flowers (Fixed Seed Generation)
// ============================================================================

/**
 * Builds an organic, non-mirrored vine SVG structure with wobbly main stems,
 * side branches, curling tendrils, drooping strands, varied leaves (green & yellowing),
 * and yellow spiral roses.
 */
function generateVineSvg(seed, width, height, isRightSide) {
  const rand = createPrng(seed);
  const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute("class", "vine-svg swaying-vine");
  svg.setAttribute("viewBox", `0 0 ${width} ${height}`);
  svg.setAttribute("preserveAspectRatio", "none");

  // Generate wobbly main stem points
  const points = [];
  const segments = 6;
  const startX = isRightSide ? width - 15 : 15;
  points.push({ x: startX, y: height });

  for (let i = 1; i <= segments; i++) {
    const y = height - (i * (height / segments));
    const wobble = (rand() - 0.5) * 35;
    const inward = isRightSide ? -((i / segments) * 25) : ((i / segments) * 25);
    const x = Math.max(10, Math.min(width - 10, startX + inward + wobble));
    points.push({ x, y });
  }

  // Draw main stem curve
  let d = `M ${points[0].x} ${points[0].y}`;
  for (let i = 1; i < points.length; i++) {
    const prev = points[i - 1];
    const curr = points[i];
    const cx = (prev.x + curr.x) / 2 + (rand() - 0.5) * 15;
    const cy = (prev.y + curr.y) / 2;
    d += ` Q ${cx} ${cy} ${curr.x} ${curr.y}`;
  }

  const mainStem = document.createElementNS("http://www.w3.org/2000/svg", "path");
  mainStem.setAttribute("d", d);
  mainStem.setAttribute("fill", "none");
  mainStem.setAttribute("stroke", "#2E7D32");
  mainStem.setAttribute("stroke-width", "5");
  mainStem.setAttribute("stroke-linecap", "round");
  svg.appendChild(mainStem);

  // Side branches, curling tendrils & leaves
  const leafColors = ["#2E7D32", "#388E3C", "#43A047", "#66BB6A", "#81C784", "#C0CA33", "#FDD835"];
  const rosePositions = [1, 3, 5];

  for (let i = 1; i < points.length; i++) {
    const pt = points[i];

    // Branch path
    const branchDir = (rand() > 0.4 ? 1 : -1);
    const bx = Math.max(8, Math.min(width - 8, pt.x + branchDir * (20 + rand() * 25)));
    const by = pt.y + (rand() - 0.5) * 25;
    const bCurve = `M ${pt.x} ${pt.y} Q ${(pt.x + bx)/2 + (rand()-0.5)*10} ${pt.y - 10} ${bx} ${by}`;

    const branch = document.createElementNS("http://www.w3.org/2000/svg", "path");
    branch.setAttribute("d", bCurve);
    branch.setAttribute("fill", "none");
    branch.setAttribute("stroke", "#388E3C");
    branch.setAttribute("stroke-width", "3");
    branch.setAttribute("stroke-linecap", "round");
    svg.appendChild(branch);

    // Curling tendril
    if (rand() > 0.3) {
      const tx = bx + branchDir * (12 + rand() * 14);
      const ty = by + (rand() > 0.5 ? -18 : 18);
      const tendrilPath = `M ${bx} ${by} Q ${bx + branchDir * 15} ${by - 10} ${tx} ${ty}`;
      const tendril = document.createElementNS("http://www.w3.org/2000/svg", "path");
      tendril.setAttribute("d", tendrilPath);
      tendril.setAttribute("fill", "none");
      tendril.setAttribute("stroke", "#66BB6A");
      tendril.setAttribute("stroke-width", "1.6");
      tendril.setAttribute("stroke-linecap", "round");
      svg.appendChild(tendril);
    }

    // Varied Leaves
    const leafCount = 2 + Math.floor(rand() * 2);
    for (let l = 0; l < leafCount; l++) {
      const lx = (l === 0) ? pt.x : bx;
      const ly = (l === 0) ? pt.y : by;
      const leafGroup = document.createElementNS("http://www.w3.org/2000/svg", "g");

      const rot = Math.round(rand() * 360);
      const scale = (0.7 + rand() * 0.5).toFixed(2);
      leafGroup.setAttribute("transform", `translate(${lx}, ${ly}) rotate(${rot}) scale(${scale})`);

      const col = leafColors[Math.floor(rand() * leafColors.length)];
      const leafShape = document.createElementNS("http://www.w3.org/2000/svg", "path");
      leafShape.setAttribute("d", "M 0 0 C 12 -8, 22 -6, 26 0 C 22 6, 12 8, 0 0 Z");
      leafShape.setAttribute("fill", col);

      const vein = document.createElementNS("http://www.w3.org/2000/svg", "line");
      vein.setAttribute("x1", "0");
      vein.setAttribute("y1", "0");
      vein.setAttribute("x2", "24");
      vein.setAttribute("y2", "0");
      vein.setAttribute("stroke", "#1B5E20");
      vein.setAttribute("stroke-width", "0.8");
      vein.setAttribute("opacity", "0.6");

      leafGroup.appendChild(leafShape);
      leafGroup.appendChild(vein);
      svg.appendChild(leafGroup);
    }

    // Yellow Rose bloom node
    if (rosePositions.includes(i)) {
      const roseNode = document.createElementNS("http://www.w3.org/2000/svg", "use");
      roseNode.setAttributeNS("http://www.w3.org/1999/xlink", "href", "#def-yellow-rose");
      roseNode.setAttribute("href", "#def-yellow-rose");
      roseNode.setAttribute("class", "rose-flower-node");
      roseNode.setAttribute("x", `${bx - 14}`);
      roseNode.setAttribute("y", `${by - 14}`);
      svg.appendChild(roseNode);
    }
  }

  return svg;
}

/**
 * Builds top corner draping vines with leaves and yellow roses.
 */
function initTopCornerVines() {
  if (!topVinesLayer) return;
  topVinesLayer.innerHTML = '';
  const rand = createPrng(4321);

  const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute("width", "100%");
  svg.setAttribute("height", "100%");
  svg.setAttribute("viewBox", "0 0 760 140");
  svg.setAttribute("preserveAspectRatio", "none");

  // Top Left cluster
  const leftStrand = document.createElementNS("http://www.w3.org/2000/svg", "path");
  leftStrand.setAttribute("d", "M 0 0 Q 60 40 110 35 Q 160 30 190 75 Q 150 90 120 125");
  leftStrand.setAttribute("fill", "none");
  leftStrand.setAttribute("stroke", "#2E7D32");
  leftStrand.setAttribute("stroke-width", "3.5");
  leftStrand.setAttribute("stroke-linecap", "round");
  svg.appendChild(leftStrand);

  // Top Right cluster
  const rightStrand = document.createElementNS("http://www.w3.org/2000/svg", "path");
  rightStrand.setAttribute("d", "M 760 0 Q 700 45 640 40 Q 580 35 560 80 Q 590 105 610 130");
  rightStrand.setAttribute("fill", "none");
  rightStrand.setAttribute("stroke", "#2E7D32");
  rightStrand.setAttribute("stroke-width", "3.5");
  rightStrand.setAttribute("stroke-linecap", "round");
  svg.appendChild(rightStrand);

  // Roses on top strands
  const leftRose = document.createElementNS("http://www.w3.org/2000/svg", "use");
  leftRose.setAttribute("href", "#def-yellow-rose");
  leftRose.setAttribute("class", "rose-flower-node");
  leftRose.setAttribute("x", "175");
  leftRose.setAttribute("y", "62");
  svg.appendChild(leftRose);

  const rightRose = document.createElementNS("http://www.w3.org/2000/svg", "use");
  rightRose.setAttribute("href", "#def-yellow-rose");
  rightRose.setAttribute("class", "rose-flower-node");
  rightRose.setAttribute("x", "545");
  rightRose.setAttribute("y", "68");
  svg.appendChild(rightRose);

  topVinesLayer.appendChild(svg);
}

/**
 * Builds the hanging vine tendrils draping along the frill's top scalloped edge.
 */
function initFrillVines() {
  if (!frillVinesLayer) return;
  frillVinesLayer.innerHTML = '';
  const rand = createPrng(9876);

  const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute("width", "100%");
  svg.setAttribute("height", "100%");
  svg.setAttribute("viewBox", "0 0 760 60");
  svg.setAttribute("preserveAspectRatio", "none");

  // Trailing vine path along scalloped edge
  const strandPath = document.createElementNS("http://www.w3.org/2000/svg", "path");
  strandPath.setAttribute("d", "M 0 10 Q 70 30 150 15 Q 230 0 310 20 Q 390 40 470 18 Q 550 -4 630 22 Q 700 40 760 12");
  strandPath.setAttribute("fill", "none");
  strandPath.setAttribute("stroke", "#388E3C");
  strandPath.setAttribute("stroke-width", "3");
  strandPath.setAttribute("stroke-linecap", "round");
  svg.appendChild(strandPath);

  // Yellow roses along the frill edge
  const roseSpots = [140, 310, 480, 620];
  roseSpots.forEach(x => {
    const rose = document.createElementNS("http://www.w3.org/2000/svg", "use");
    rose.setAttribute("href", "#def-yellow-rose");
    rose.setAttribute("class", "rose-flower-node");
    rose.setAttribute("x", `${x - 14}`);
    rose.setAttribute("y", `${5}`);
    svg.appendChild(rose);
  });

  frillVinesLayer.appendChild(svg);
}

/**
 * Renders the Moth Orchids (Phalaenopsis) arching sprays with multi-blooms.
 */
function initMothOrchids() {
  const configs = [
    { container: orchidSprayLeft, type: '#def-orchid-white', height: 130 },
    { container: orchidSprayCenter, type: '#def-orchid-yellow', height: 140 },
    { container: orchidSprayRight, type: '#def-orchid-pink', height: 130 }
  ];

  configs.forEach((cfg, idx) => {
    if (!cfg.container) return;
    cfg.container.innerHTML = '';

    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.setAttribute("viewBox", "0 0 130 140");
    svg.setAttribute("width", "100%");
    svg.setAttribute("height", "100%");

    // Slender arching green stem
    const stem = document.createElementNS("http://www.w3.org/2000/svg", "path");
    const stemD = idx === 2 
      ? "M 110 140 C 95 90, 70 50, 20 25" 
      : "M 20 140 C 35 90, 60 50, 110 25";
    stem.setAttribute("d", stemD);
    stem.setAttribute("fill", "none");
    stem.setAttribute("stroke", "#2E7D32");
    stem.setAttribute("stroke-width", "3");
    stem.setAttribute("stroke-linecap", "round");
    svg.appendChild(stem);

    // Multi-blooms along the stem
    const flowerCoords = idx === 2 
      ? [{ x: 60, y: 55 }, { x: 35, y: 30 }, { x: 10, y: 15 }]
      : [{ x: 45, y: 55 }, { x: 70, y: 30 }, { x: 95, y: 15 }];

    flowerCoords.forEach(c => {
      const orchid = document.createElementNS("http://www.w3.org/2000/svg", "use");
      orchid.setAttribute("href", cfg.type);
      orchid.setAttribute("x", `${c.x - 30}`);
      orchid.setAttribute("y", `${c.y - 20}`);
      svg.appendChild(orchid);
    });

    cfg.container.appendChild(svg);
  });
}

/**
 * Scatters fallen leaves across the ground and frill.
 * Leaves are carefully routed outside the dialogue area (left of treats dock).
 */
function initFallenLeaves() {
  if (!fallenLeavesLayer) return;
  fallenLeavesLayer.innerHTML = '';

  const rand = createPrng(777);
  const colors = ["#E65100", "#F57F17", "#FBC02D", "#8D6E63", "#689F38", "#C0CA33"];
  const leafCount = 22;

  for (let i = 0; i < leafCount; i++) {
    let x = 10 + rand() * 740;
    let y = 490 + rand() * 135;

    // Avoid dialogue region on the frill
    if (x >= 20 && x <= 460 && y >= 555 && y <= 635) {
      y = 490 + rand() * 55; // relocate above frill text area
    }

    const leaf = document.createElement('div');
    leaf.className = 'fallen-leaf';

    // Tier based appearance matching bonding build-up
    if (i < 8) {
      leaf.classList.add('leaf-tier-1');
    } else if (i < 16) {
      leaf.classList.add('leaf-tier-2');
    } else {
      leaf.classList.add('leaf-tier-3');
    }

    const rot = Math.round((rand() - 0.5) * 120);
    const scale = (0.7 + rand() * 0.5).toFixed(2);
    leaf.style.left = `${x}px`;
    leaf.style.top = `${y}px`;
    leaf.style.setProperty('--rot', `${rot}deg`);

    const col = colors[Math.floor(rand() * colors.length)];
    leaf.innerHTML = `
      <svg viewBox="0 0 24 16" width="22" height="15">
        <path d="M 0 8 C 8 0, 16 2, 24 8 C 16 14, 8 16, 0 8 Z" fill="${col}"/>
        <line x1="0" y1="8" x2="22" y2="8" stroke="#3E2600" stroke-width="0.8" opacity="0.45"/>
      </svg>
    `;

    fallenLeavesLayer.appendChild(leaf);
  }
}

// ============================================================================
// 10. Interactions (Petting & Feeding)
// ============================================================================

/**
 * Tap to Pet Capybara
 */
function handlePet() {
  if (state.currentState !== GAME_STATES.IDLE) {
    return;
  }

  state.currentState = GAME_STATES.BEING_PET;

  const prevBonding = state.bonding;
  state.happiness = Math.min(100, state.happiness + 5);
  state.bonding = Math.min(100, state.bonding + 3);

  // Audio: Boop immediately + Purr
  CapyAudio.playBoop();
  setTimeout(() => CapyAudio.playPurr(), 150);

  spawnHeart();
  setEyesHappy(true);
  capybaraInteractive.classList.add('petting-active');

  const dialogueLine = selectNextDialogue();
  showDialogue(dialogueLine);

  checkBondingMilestones(prevBonding, state.bonding);

  updateUI();
  saveGame();

  setTimeout(() => {
    capybaraInteractive.classList.remove('petting-active');
  }, 500);

  clearTimeout(dialogueTimer);
  dialogueTimer = setTimeout(() => {
    hideDialogue();
    setEyesHappy(false);

    if (prevBonding < 70 && state.bonding >= 70 && state.scene === 1) {
      triggerQuietSceneUnlock();
    } else {
      state.currentState = GAME_STATES.IDLE;
      updateUI();
    }
  }, 2800);
}

function selectNextDialogue() {
  if (DIALOGUE_POOL.length <= 1) {
    state.lastDialogueIndex = 0;
    return DIALOGUE_POOL[0];
  }

  let nextIdx;
  do {
    nextIdx = Math.floor(Math.random() * DIALOGUE_POOL.length);
  } while (nextIdx === state.lastDialogueIndex);

  state.lastDialogueIndex = nextIdx;
  return DIALOGUE_POOL[nextIdx];
}

function blinkSequence(count = 2 + Math.round(Math.random())) {
  if (blinkInterval) {
    clearInterval(blinkInterval);
    blinkInterval = null;
  }
  let i = 0;
  blinkInterval = setInterval(() => {
    if (!eyeBall || !eyeSparkle) return;
    eyeBall.setAttribute('ry', '0.5');
    eyeSparkle.style.opacity = '0';
    CapyAudio.playPip();
    setTimeout(() => {
      eyeBall.setAttribute('ry', '4');
      eyeSparkle.style.opacity = '1';
    }, 120);
    if (++i >= count) {
      clearInterval(blinkInterval);
      blinkInterval = null;
    }
  }, 300);
}

function showScrapbook() {
  if (!scrapbookOverlay || !scrapbookStickersContainer) return;
  state.scrapbookShown = true;
  saveGame();

  scrapbookStickersContainer.innerHTML = '';
  scrapbookOverlay.classList.remove('hidden');
  scrapbookOverlay.classList.remove('fade-out');
  CapyAudio.playPaperRustle();

  const stickerCount = 8 + Math.floor(Math.random() * 5);
  for (let i = 0; i < stickerCount; i++) {
    const sticker = document.createElement('div');
    sticker.className = 'capy-sticker';

    const left = 10 + Math.random() * 75;
    const top = 10 + Math.random() * 70;
    const rot = -25 + Math.random() * 50;
    const scale = (0.75 + Math.random() * 0.5).toFixed(2);
    const delay = (i * 120);

    sticker.style.left = `${left}%`;
    sticker.style.top = `${top}%`;
    sticker.style.setProperty('--rot', `${rot}deg`);
    sticker.style.setProperty('--scale', scale);
    sticker.style.animationDelay = `${delay}ms`;

    // Capybara sticker mini SVG (Clean text, no emojis)
    sticker.innerHTML = `
      <svg viewBox="0 0 70 70" width="100%" height="100%">
        <rect x="2" y="2" width="66" height="66" rx="16" fill="#FFF8E1" stroke="#FFD54F" stroke-width="2.5"/>
        <ellipse cx="35" cy="38" rx="22" ry="16" fill="#A47148"/>
        <ellipse cx="44" cy="30" rx="14" ry="12" fill="#8B572A"/>
        <circle cx="48" cy="28" r="2.5" fill="#2E1B0E"/>
        <ellipse cx="56" cy="32" rx="3.5" ry="2.5" fill="#3E2600"/>
        <ellipse cx="38" cy="20" rx="4" ry="6" fill="#6D3D16" transform="rotate(-15 38 20)"/>
        <text x="35" y="60" font-size="10" text-anchor="middle" fill="#5D4037" font-weight="bold">CAPY</text>
      </svg>
    `;

    scrapbookStickersContainer.appendChild(sticker);

    setTimeout(() => {
      CapyAudio.playStamp();
    }, delay + 200);
  }

  setTimeout(() => {
    scrapbookOverlay.classList.add('fade-out');
    setTimeout(() => {
      scrapbookOverlay.classList.add('hidden');
      scrapbookOverlay.classList.remove('fade-out');
    }, 800);
  }, 3300);
}

function showDialogue(text) {
  dialogueContainer.classList.remove('dialogue-fading');
  dialogueText.textContent = text;
  dialogueContainer.classList.remove('hidden');
  blinkSequence();
}

function hideDialogue() {
  dialogueContainer.classList.add('hidden');
  dialogueContainer.classList.remove('dialogue-fading');
}

function checkBondingMilestones(prevBonding, currentBonding) {
  if (prevBonding < 40 && currentBonding >= 40 && !state.vinesGrownSoundPlayed) {
    state.vinesGrownSoundPlayed = true;
    CapyAudio.playVineGrow();
  }

  if (prevBonding < 55 && currentBonding >= 55 && !state.flowersSoundPlayed) {
    state.flowersSoundPlayed = true;
    CapyAudio.playFlowerBloom();
  }

  if (prevBonding < 50 && currentBonding >= 50 && !state.scrapbookShown) {
    setTimeout(() => {
      showScrapbook();
    }, 600);
  }
}

/**
 * Drag Salad to Feed Capybara
 */
function handleFeed() {
  if (state.currentState === GAME_STATES.BEING_PET) {
    clearTimeout(dialogueTimer);
    hideDialogue();
  }

  if (state.currentState === GAME_STATES.BEING_FED || 
      state.currentState === GAME_STATES.GOODBYE) {
    return;
  }

  triggerSaladFlightAndChomp();
}

function triggerSaladFlightAndChomp() {
  state.currentState = GAME_STATES.BEING_FED;

  const prevBonding = state.bonding;
  state.happiness = Math.min(100, state.happiness + 10);
  state.bonding = Math.min(100, state.bonding + 8);

  const saladRect = saladItem.getBoundingClientRect();
  const capyRect = capybaraInteractive.getBoundingClientRect();
  const targetX = (capyRect.left + capyRect.width * 0.45) - (saladRect.left + saladRect.width / 2);
  const targetY = (capyRect.top + capyRect.height * 0.45) - (saladRect.top + saladRect.height / 2);

  saladItem.style.setProperty('--fly-x', `${targetX}px`);
  saladItem.style.setProperty('--fly-y', `${targetY}px`);
  saladItem.classList.add('salad-flying');

  setTimeout(() => {
    CapyAudio.playCrunch();
    setTimeout(() => CapyAudio.playHappyHum(), 200);

    const nomText = FEEDING_PHRASES[Math.floor(Math.random() * FEEDING_PHRASES.length)];
    feedPopup.textContent = nomText;
    feedPopup.classList.remove('hidden');

    setEyesHappy(true);
    capybaraInteractive.classList.add('feeding-active');
    capybaraInteractive.classList.add('happy-wiggle');

    spawnHeart();
    spawnHeart();
    spawnHeart();

    checkBondingMilestones(prevBonding, state.bonding);

    updateUI();
    saveGame();
  }, 380);

  clearTimeout(feedAnimTimer);
  feedAnimTimer = setTimeout(() => {
    feedPopup.classList.add('hidden');
    capybaraInteractive.classList.remove('feeding-active');
    capybaraInteractive.classList.remove('happy-wiggle');
    setEyesHappy(false);

    // Guaranteed salad reset
    resetSalad();

    if (prevBonding < 70 && state.bonding >= 70 && state.scene === 1) {
      triggerQuietSceneUnlock();
    } else {
      state.currentState = GAME_STATES.IDLE;
      updateUI();
    }
  }, 1900);
}

/**
 * Scene 2 Unlock: Shifts quietly with no badge or message overlay
 */
function triggerQuietSceneUnlock() {
  state.scene = 2;
  updateUI();
  saveGame();
  state.currentState = GAME_STATES.IDLE;
}

// ============================================================================
// 11. Wave Button, Goodbye & Reset Flow
// ============================================================================

function handleWave() {
  if (state.currentState !== GAME_STATES.IDLE) {
    return;
  }

  state.currentState = GAME_STATES.GOODBYE;
  updateUI();

  CapyAudio.playLullaby();

  // Apply fadeout to background scene world only (modals stay crisp)
  if (sceneWorld) {
    sceneWorld.classList.add('goodbye-fading');
  }

  setTimeout(() => {
    farewellMessage.classList.remove('hidden');
  }, 2200);

  setTimeout(() => {
    CapyAudio.stopAll();
  }, 3800);

  setTimeout(() => {
    goodbyeModal.classList.remove('hidden');
  }, 4600);
}

function handleGoodbyeStay() {
  goodbyeModal.classList.add('hidden');
  farewellMessage.classList.add('hidden');
  if (sceneWorld) {
    sceneWorld.classList.remove('goodbye-fading');
  }
  CapyAudio.resumeAll();

  // Reset salad to ensure it reappears on Stay
  resetSalad();

  state.currentState = GAME_STATES.IDLE;
  updateUI();
}

function handleGoodbyeRestart() {
  goodbyeModal.classList.add('hidden');
  farewellMessage.classList.add('hidden');
  if (sceneWorld) {
    sceneWorld.classList.remove('goodbye-fading');
  }
  executeRestart();
}

function executeRestart() {
  state.currentState = GAME_STATES.GAME_OVER_RESTART;

  clearTimeout(dialogueTimer);
  clearTimeout(feedAnimTimer);
  if (blinkInterval) {
    clearInterval(blinkInterval);
    blinkInterval = null;
  }
  hideDialogue();
  feedPopup.classList.add('hidden');
  setEyesHappy(false);

  // Reset salad completely on restart
  resetSalad();

  state.happiness = 30;
  state.bonding = 0;
  state.scene = 1;
  state.lastDialogueIndex = -1;
  state.scrapbookShown = false;
  state.vinesGrownSoundPlayed = false;
  state.flowersSoundPlayed = false;

  clearSaveData();
  saveGame();

  CapyAudio.resumeAll();

  state.currentState = GAME_STATES.IDLE;
  updateUI();
}

// ============================================================================
// 12. Drag & Drop Feed Mechanics
// ============================================================================

function setupDragAndDrop() {
  saladItem.addEventListener('dragstart', (e) => {
    saladItem.classList.add('is-dragging');
    e.dataTransfer.setData('text/plain', 'salad');
    e.dataTransfer.effectAllowed = 'move';

    if (state.currentState === GAME_STATES.BEING_PET) {
      clearTimeout(dialogueTimer);
      hideDialogue();
    }
  });

  saladItem.addEventListener('dragend', () => {
    resetSalad();
  });

  capybaraInteractive.addEventListener('dragover', (e) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    capybaraInteractive.classList.add('drag-hover');
  });

  capybaraInteractive.addEventListener('dragleave', () => {
    capybaraInteractive.classList.remove('drag-hover');
  });

  capybaraInteractive.addEventListener('drop', (e) => {
    e.preventDefault();
    capybaraInteractive.classList.remove('drag-hover');
    handleFeed();
  });

  // Pointer/Touch Fallback Drag
  let isPointerDragging = false;
  let startX = 0;
  let startY = 0;

  saladItem.addEventListener('pointerdown', (e) => {
    if (e.button !== 0) return;

    if (state.currentState === GAME_STATES.BEING_PET) {
      clearTimeout(dialogueTimer);
      hideDialogue();
    }

    isPointerDragging = true;
    startX = e.clientX;
    startY = e.clientY;
    saladItem.setPointerCapture(e.pointerId);
  });

  saladItem.addEventListener('pointermove', (e) => {
    if (!isPointerDragging) return;

    const dx = e.clientX - startX;
    const dy = e.clientY - startY;
    saladItem.style.transform = `translate(${dx}px, ${dy}px) scale(1.08)`;

    const capyRect = capybaraInteractive.getBoundingClientRect();
    if (
      e.clientX >= capyRect.left &&
      e.clientX <= capyRect.right &&
      e.clientY >= capyRect.top &&
      e.clientY <= capyRect.bottom
    ) {
      capybaraInteractive.classList.add('drag-hover');
    } else {
      capybaraInteractive.classList.remove('drag-hover');
    }
  });

  const endPointerDrag = (e) => {
    if (!isPointerDragging) return;
    isPointerDragging = false;

    const capyRect = capybaraInteractive.getBoundingClientRect();
    const isOverCapy = (
      e.clientX >= capyRect.left &&
      e.clientX <= capyRect.right &&
      e.clientY >= capyRect.top &&
      e.clientY <= capyRect.bottom
    );

    resetSalad();

    if (isOverCapy) {
      handleFeed();
    }
  };

  saladItem.addEventListener('pointerup', endPointerDrag);
  saladItem.addEventListener('pointercancel', endPointerDrag);
}

// ============================================================================
// 13. Event Listeners & Game Bootstrap
// ============================================================================

function initEventListeners() {
  const unlockAudio = () => {
    CapyAudio.init();
    document.removeEventListener('click', unlockAudio);
    document.removeEventListener('touchstart', unlockAudio);
    document.removeEventListener('keydown', unlockAudio);
  };
  document.addEventListener('click', unlockAudio, { once: true });
  document.addEventListener('touchstart', unlockAudio, { once: true });
  document.addEventListener('keydown', unlockAudio, { once: true });

  if (dialogueContainer) {
    dialogueContainer.addEventListener('click', () => {
      dialogueContainer.classList.add('dialogue-fading');
      CapyAudio.playPip();
      setTimeout(() => {
        hideDialogue();
      }, 500);
    });
  }

  capybaraInteractive.addEventListener('click', handlePet);
  capybaraInteractive.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      handlePet();
    }
  });

  if (waveBtn) {
    waveBtn.addEventListener('click', handleWave);
  }

  confirmCancelBtn.addEventListener('click', () => {
    restartConfirmModal.classList.add('hidden');
  });

  confirmResetBtn.addEventListener('click', () => {
    restartConfirmModal.classList.add('hidden');
    executeRestart();
  });

  goodbyeStayBtn.addEventListener('click', handleGoodbyeStay);
  goodbyeRestartBtn.addEventListener('click', handleGoodbyeRestart);

  if (constructionHat) {
    constructionHat.addEventListener('click', (e) => {
      e.stopPropagation();
      if (constructionHat.classList.contains('hat-hidden')) {
        constructionHat.classList.remove('hat-hidden');
        constructionHat.classList.add('hat-visible');
      } else {
        constructionHat.classList.remove('hat-visible');
        constructionHat.classList.add('hat-hidden');
      }
    });
  }

  setupDragAndDrop();
}

function initProceduralElements() {
  // Generate distinct non-mirrored side vines
  if (foliageLeftContainer) {
    foliageLeftContainer.innerHTML = '';
    foliageLeftContainer.appendChild(generateVineSvg(10482, 110, 300, false));
  }
  if (foliageRightContainer) {
    foliageRightContainer.innerHTML = '';
    foliageRightContainer.appendChild(generateVineSvg(73915, 110, 300, true));
  }

  // Top corner vines & frill tendrils
  initTopCornerVines();
  initFrillVines();

  // Moth orchids & fallen autumn leaves
  initMothOrchids();
  initFallenLeaves();
}

function initGame() {
  loadGame();
  initProceduralElements();
  initEventListeners();
  updateUI();
  console.log('Capybara Virtual Pet initialized with Pixel Operator visuals.');
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initGame);
} else {
  initGame();
}
