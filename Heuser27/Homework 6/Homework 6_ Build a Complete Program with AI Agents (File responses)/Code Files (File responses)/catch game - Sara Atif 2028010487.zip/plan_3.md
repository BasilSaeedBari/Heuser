# Stage 3 Implementation Plan: Sensory Feedback & Code-Generated Audio

## 1. Overview
The goal of Stage 3 is to elevate the Catch Game with rich sensory feedback, dynamic visual animations, visual particle impacts, and **100% code-generated audio** without any external sound or image assets:
- **Audio Generation via Web Audio API & Speech Synthesis**:
  - **"Watch Out" Warning**: Synthesized spoken alert ("Watch out!") using browser `speechSynthesis` or accompanied by a low-pitched descending warning synth when the **first** good object (green ball) is missed in a match.
  - **"Boom" Explosion Sound**: Code-generated realistic explosion for bomb detonations using Web Audio API buffer noise passed through low-pass filters + frequency-decaying dual oscillators.
  - **Catch Sound Effect**: Pleasant dual-tone high arpeggio chime for successful green ball catches.
  - **Subtle Warning/Damage Thud**: Impactful low rumble for subsequent life loss.
  - **Round Advance Chime**: Celebratory ascending major chord when completing rounds.
- **Mute Toggle System**:
  - Interactive mute button integrated directly into the top HUD status bar with clear visual states (🔊 Sound On / 🔇 Muted).
  - Persists state across sessions (`localStorage`) and allows one-click muting of both Web Audio synthesis and speech synthesis.
  - Handles modern browser autoplay policies cleanly by initializing/resuming `AudioContext` on the first user interaction (click, keypress, or Start button).
- **Sensory Visual Animations & Effects**:
  - **Screen Shake**: Dynamic container shudder on bomb detonations or missed good items.
  - **Particle Burst System**: Particle emitter in canvas for both green sparkle bursts (upon ball catch) and fiery smoke debris (upon bomb explosion).
  - **Paddle Motion Sway & Tilt**: Dynamic micro-tilt and trail reflection based on paddle velocity.
  - **Falling Item Pulse & Flame Glow**: Oscillating spark flicker on bomb fuses and breathing glow aura on green spheres.
  - **HUD Life Flash Effect**: Visual flash on the HUD life indicator upon damage.
- **Preservation**:
  - Khaki Beige (`#b7ad99`) and Vintage Lavender (`#a06b9a`) aesthetic maintained.
  - 3 lives, score, round progression, delta-time physics, and completely offline standalone execution preserved.
  - Strict adherence to zero external asset files (no images, no audio files, no remote libraries).

## 2. Technical Architecture for Code-Generated Audio
1. **Audio Engine (`SoundController`)**:
   - Lazily created `AudioContext` on first user gesture.
   - Master Gain Node connected directly to `ctx.destination` with an internal `isMuted` boolean flag.
   - `playCatch()`: Two sine oscillators at 587Hz (D5) and 880Hz (A5) with quick decay exponential ramps.
   - `playBoom()`: White noise audio buffer generator with a lowpass biquad filter sweeping down from 800Hz to 40Hz, combined with an 80Hz pitch drop oscillator simulating real punchy detonation reverberation.
   - `playWatchOut()`: Triggered strictly once per match on the first dropped green ball using `window.speechSynthesis` speaking `"Watch out!"` along with a synthesized warning tone alert.
   - `playGameOver()`: Melancholy pitch decay chord.
2. **Visual Particles & Camera Shake Engine**:
   - `particles` array updated every frame with position, velocity, decay, alpha, and color.
   - Screen shake offset `shakeTime` and `shakeMagnitude` applied to the canvas transform matrix during render.

## 3. Detailed File Updates
- **`index.html`**: Add sound toggle button in HUD, update banner to "Stage 3 • Sensory Edition", preserve semantic IDs.
- **`style.css`**: Add styling for mute button, camera shake CSS animation keyframes, particle/glow transitions, button press ripple.
- **`script.js`**: Implement `SoundController`, particle engine, screen shake, paddle tilt physics, and hook events cleanly.

## 4. Verification Checklist
- [x] Zero sound files (.mp3, .wav, .ogg, etc.) and zero image files.
- [x] Code-generated "Boom" explosion sound via Web Audio API.
- [x] Code-generated "Watch Out" warning upon missing the first good item.
- [x] Interactive Mute toggle button in HUD.
- [x] Dynamic animations (screen shake, particle bursts, paddle response).
- [x] Works 100% offline via direct HTML double-click.
- [x] All 3 code files separated and synchronized.
