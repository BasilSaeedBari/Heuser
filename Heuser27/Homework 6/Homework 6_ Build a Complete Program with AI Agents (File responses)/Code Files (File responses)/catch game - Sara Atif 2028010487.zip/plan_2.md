# Stage 2 Implementation Plan: Visual Vibe & Aesthetic Refresh

## 1. Overview
The goal of Stage 2 is to transform the Catch Game's visual aesthetics by establishing a cohesive visual theme and layout featuring:
- Primary Color Palette: **Khaki Beige (`#b7ad99`)** and **Vintage Lavender (`#a06b9a` / `#a06b9aff`)**.
- Clean, refined game board and layout with title heading "Catch Game".
- High quality CSS-styled and Canvas-rendered objects (paddle, green balls, bombs) without external images, fonts, sounds, or libraries.
- Preservation of all Stage 1 gameplay mechanics (3 lives, scoring, bomb collisions, round/speed progression, delta-time game loop, fully offline).

## 2. Palette & Thematic Harmonization
- **Khaki Beige (`#b7ad99`)**: Warm, soft, grounded tone used for page accents, card borders, subtle backgrounds, paddle body/trim, and HUD highlights.
- **Vintage Lavender (`#a06b9a`)**: Elegant, retro-modern primary theme color applied to titles, headers, glow accents, primary interactive buttons, and canvas ambient gradient.
- **Canvas Backdrop**: Deep vintage gradient transitioning from deep lavender slate (`#261d2a`) into twilight plum (`#18131d`).
- **Player Paddle**: Styled with sleek vintage lavender/khaki gradients with refined chamfered rounded edges, glowing trim, and crisp highlight bar.
- **Green Ball**: Rich emerald-jade radial gradient (`#a7f3d0` -> `#22c55e` -> `#166534`) with soft glass glow.
- **Bomb**: Stylized dark charcoal/crimson sphere with vintage lavender/burnt orange fuse and spark (`#fbbf24`), distinct and clear.

## 3. Detailed File Changes

### A. `plan_2.md`
- Documentation of visual architecture, style specifications, color tokens, and verification checklist.

### B. `index.html`
- Ensure header/layout structure clearly features "Catch Game".
- Update typography containers, badge representations, and semantic structure for clean presentation without external dependencies.
- Retain complete DOM element IDs required by `script.js`.

### C. `style.css`
- Introduce CSS custom properties (`--khaki-beige`, `--vintage-lavender`, etc.).
- Restyle the background, game container border, shadow, and HUD status bar.
- Create polished vintage-lavender and khaki-styled buttons with smooth hover/active transitions.
- Restyle start/game-over overlay screens and rule badges.

### D. `script.js`
- Keep core logic, 3 lives, collision detection, progression, and delta-time loop 100% intact.
- Enhance the canvas `render()` function to style the paddle, falling balls, and bombs according to the Stage 2 visual vibe with custom radial gradients, shadows, and crisp rendering.

## 4. Verification Checklist
- [x] Zero external assets (no external images, audio, web fonts, or CDN libraries).
- [x] Exactly 3 code files: `index.html`, `style.css`, `script.js`.
- [x] Clean and simple layout with "Catch Game" heading.
- [x] Colors `#b7ad99` (Khaki Beige) and `#a06b9a` (Vintage Lavender) harmoniously integrated.
- [x] Paddle, balls, and bombs clearly visible and distinct.
- [x] 100% offline functionality.
