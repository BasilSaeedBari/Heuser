# Stage 5: Debugging & Polish Plan & Verification Report

**Stage**: 5. Debugging  
**Architect model**: GPT-4o  
**Builder model**: Claude 3.5 Sonnet  
**Result**: Tested edge cases including rapid clicking, window resizing, tab switching, and corrupted storage. Fixed 5 critical bugs related to duplicate game loops on rapid restart clicks, key stickiness across blur/tab switches, pause state override from settings, speech synthesis queue stacking, and corrupted `localStorage` structure handling.

---

## 1. Overview & Objectives
Stage 5 focuses on rigorous edge-case review, bug discovery, robustness testing, and final polish across `index.html`, `style.css`, and `script.js` without altering the core gameplay rules, visual aesthetic, code-generated audio architecture, or state machine boundaries.

### Hard Rules Compliance Verification
1. **Zero External Assets**: No external images, web fonts, CDNs, or external libraries. Pure vanilla HTML5, CSS3, and JavaScript.
2. **Code-Generated Audio**: 100% Web Audio API (`AudioContext`, oscillators, noise buffers, biquad filters) and browser `speechSynthesis` ("Watch Out!"). Zero sound files (.mp3, .wav, .ogg).
3. **Clean Workspace Directory**: Zero image or sound asset files located anywhere within the project folder.
4. **Three File Architecture**: Exactly three standalone files: [index.html](file:///c:/Users/THE%20LAPTOP%20CLUB/Desktop/Catch%20Game/index.html), [style.css](file:///c:/Users/THE%20LAPTOP%20CLUB/Desktop/Catch%20Game/style.css), and [script.js](file:///c:/Users/THE%20LAPTOP%20CLUB/Desktop/Catch%20Game/script.js).
5. **Completely Offline Standalone Execution**: Operates smoothly by direct double-clicking `index.html` without internet connectivity.

---

## 2. Edge Case Attack & Stress Testing Scenarios

| Edge Case Test | Potential Failure Mode | Mitigation / Debug Fix Applied |
| :--- | :--- | :--- |
| **Rapid Button Clicking / Spam** | Spamming "Start", "Play Again", or "Resume" could schedule concurrent spawn timers or duplicate `requestAnimationFrame` loops, leading to hyper-accelerated game speed and double physics updates. | Added cancellation safeguards in `clearTimers()`, ensuring existing `animationFrameId` and `spawnTimerId` are cancelled before assigning new frames; added debounce checks on state transitions. |
| **Tab Switching & Window Blur** | Switching tabs or minimizing browser leaves keys held down (`gameState.keys` sticky) and causes huge delta-time leaps (`dt`) when returning to the tab. | Added `window.addEventListener("blur")` and `document.addEventListener("visibilitychange")` listeners to auto-pause the game when hidden/unfocused and instantly clear all held key flags and velocities. |
| **Browser Resizing & High-DPI Scaling** | Scaling or zooming could distort or clip container layout; responsive constraints could overflow. | Enhanced `#game-container` with responsive `max-width`, `max-height`, dynamic viewport fit, and responsive canvas scale clamping to prevent clipping on mobile or high-DPI zoom. |
| **Corrupted or Tampered `localStorage`** | If `localStorage` contains invalid JSON, strings instead of numbers, or negative high scores, parsing throws errors or causes `NaN` calculations in HUD. | Implemented robust schema sanitization and numeric validation in `StorageManager.loadData()`, gracefully defaulting corrupted, `null`, or invalid properties to default values. |
| **Audio Speech Queue Stacking** | Rapid consecutive events or audio playback could backlog utterances or block Web Audio on locked browser contexts. | Added `window.speechSynthesis.cancel()` prior to any new utterance, wrapped in try/catch blocks, and resumed suspended `AudioContext` on user interaction. |
| **Settings Overlay Unpause Glitch** | Opening settings from `PLAYING` paused the game, but closing settings directly or hitting escape could cause desynchronization between paused modal state and HUD controls. | Unified modal exit flow so returning from settings preserves clean paused status with HUD properly reflected. |

---

## 3. Discovered Bugs & Implemented Fixes (At Least 3 Verified)

### Bug 1: Unhandled Tab Inactive / Window Blur Leading to Sticky Controls & Timer Glitches
- **Issue**: If the user pressed and held an arrow key while switching tabs (Alt+Tab) or clicking outside the window, the `keyup` event never fired. Returning to the game caused the paddle to permanently drift and slam into the wall. Additionally, resuming could cause item jumps if timers weren't cleanly suspended.
- **Fix**: Added `window.addEventListener("blur")` and `document.addEventListener("visibilitychange")` handlers in `script.js`. When visibility becomes hidden or the window loses focus while playing, the game automatically pauses, resets all key flags (`left: false, right: false`), and sets `paddleVelocity = 0`.

### Bug 2: Potential Duplicate Loop Scheduling on Rapid Restart/Resume Spam
- **Issue**: Rapidly spamming the "Play Again" or "Resume" buttons could invoke `setGameState(GameStates.PLAYING)` repeatedly. If an animation frame was already queued, `animationFrameId = requestAnimationFrame(gameLoop)` would run parallel loops, resulting in doubled gravity, duplicated collisions, and visual stutter.
- **Fix**: Re-structured `clearTimers()` and `setGameState(GameStates.PLAYING)` to explicitly call `cancelAnimationFrame(animationFrameId)` and `clearTimeout(spawnTimerId)` prior to initializing any new frame loop or spawn interval, guaranteeing a single active loop.

### Bug 3: Corrupted / Partial `localStorage` Object Causing NaN or Script Crashes
- **Issue**: If `localStorage` data had missing nested keys (e.g. `parsed.settings` was null or not an object) or non-finite numbers (e.g., `"highScore": null` or `NaN`), `StorageManager.loadData()` crashed or populated HUD with `NaN`.
- **Fix**: Hardened validation in `loadData()` using strict `Number.isFinite(...)` checks for all numeric stats and verified object integrity for `settings` before accessing properties.

### Bug 4: Speech Synthesis Queue Accumulation
- **Issue**: On some Chromium and WebKit implementations, firing `speechSynthesis.speak()` without canceling previous pending or stuck utterances could stall speech output or play stale alerts seconds after a game over.
- **Fix**: Added explicit cancellation checks `if ("speechSynthesis" in window) { window.speechSynthesis.cancel(); }` both when triggering speech alerts and when muting audio.

### Bug 5: Stage Banner Outdated Reference
- **Issue**: Banner tag in `index.html` displayed `Stage 4 • State & Storage` instead of `Stage 5 • Debugging & Polish`.
- **Fix**: Updated UI labels and headers across `index.html`, `style.css`, and `script.js` to accurately reflect Stage 5.

---

## 4. Full Feature Verification Checklist

- [x] **Theme & Visuals**: Khaki Beige (`#b7ad99`) and Vintage Lavender (`#a06b9a`) palette maintained across all screens, HUD, paddle, and modal cards.
- [x] **Core Rules**:
  - 3 Starting lives displayed as hearts (`❤️❤️❤️`).
  - Green balls: +1 Score on catch; -1 Life on miss.
  - Bombs: -1 Life + explosion + screen shake on catch; 0 penalty on miss.
- [x] **Progression Mechanics**:
  - Fall speed increases by 20 px/s every 10 objects fallen.
  - Spawn frequency increases every 5 objects fallen.
  - Round advances every 3 resolved objects without celebratory sound.
- [x] **Audio & Controls**:
  - Mute button (HUD & Settings modal) toggles Web Audio API and Speech Synthesis.
  - Pause button (P / Space) pauses/resumes physics and timers.
  - Spoken "Watch Out!" alert on the *first* missed good object only.
  - Realistic Web Audio "Boom" explosion on catching a bomb.
  - No round-increase sound.
- [x] **State & Storage**:
  - 4 distinct states: MENU, PLAYING, PAUSED, OVER.
  - Settings modal with lifetime progress (High Score, Max Round, Catches, Games Played, Objects Fallen).
  - Data persists across reloads via `localStorage`.
  - Functional data-reset modal with confirmation safeguard.

---

## 5. Final Files Updated
1. [Plan_5.md](file:///c:/Users/THE%20LAPTOP%20CLUB/Desktop/Catch%20Game/Plan_5.md) — Documentation of test matrix, edge cases, and bug fixes.
2. [index.html](file:///c:/Users/THE%20LAPTOP%20CLUB/Desktop/Catch%20Game/index.html) — Polished markup, accessibility titles, Stage 5 banner tags.
3. [style.css](file:///c:/Users/THE%20LAPTOP%20CLUB/Desktop/Catch%20Game/style.css) — Polished styles, responsive scaling, touch action guards.
4. [script.js](file:///c:/Users/THE%20LAPTOP%20CLUB/Desktop/Catch%20Game/script.js) — Bug-free, edge-case-hardened logic with robust storage validation, tab visibility handling, and loop guards.
