// Game Elements
const gameContainer = document.getElementById('game-container');
const playArea = document.getElementById('play-area');
const player = document.getElementById('player');
const scoreEl = document.getElementById('score');
const highScoreEl = document.getElementById('high-score');
const livesEl = document.getElementById('lives');
const finalScoreEl = document.getElementById('final-score');
const finalHighScoreEl = document.getElementById('final-high-score');

// Buttons & Overlays
const startBtn = document.getElementById('start-btn');
const resetBtn = document.getElementById('reset-btn');
const pauseBtn = document.getElementById('pause-btn');
const resumeBtn = document.getElementById('resume-btn');
const restartBtn = document.getElementById('restart-btn');
const muteBtn = document.getElementById('mute-btn');

const overlay = document.getElementById('overlay');
const menuScreen = document.getElementById('menu-screen');
const pauseScreen = document.getElementById('pause-screen');
const gameoverScreen = document.getElementById('gameover-screen');

// Game State Variables
let gameState = 'MENU'; // MENU, PLAYING, PAUSED, GAMEOVER
let score = 0;
let lives = 3;
let highScore = 0;
let isMuted = false;

// Movement & Loop Variables
let playerX = 170;
const playerSpeed = 6;
const keysPressed = {};
let fallingItems = [];
let spawnTimer = 0;
let animationFrameId = null;

// Web Audio API Sound Generator
const AudioCtx = window.AudioContext || window.webkitAudioContext;
let audioCtx = null;

function initAudio() {
  if (!audioCtx) {
    audioCtx = new AudioCtx();
  }
}

function playSound(type) {
  if (isMuted || !audioCtx) return;
  
  const osc = audioCtx.createOscillator();
  const gain = audioCtx.createGain();
  osc.connect(gain);
  gain.connect(audioCtx.destination);
  
  const now = audioCtx.currentTime;

  if (type === 'catch') {
    osc.type = 'sine';
    osc.frequency.setValueAtTime(587.33, now); // D5
    osc.frequency.exponentialRampToValueAtTime(880, now + 0.1); // A5
    gain.gain.setValueAtTime(0.15, now);
    gain.gain.linearRampToValueAtTime(0.01, now + 0.1);
    osc.start(now);
    osc.stop(now + 0.1);
  } else if (type === 'hit') {
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(200, now);
    osc.frequency.linearRampToValueAtTime(80, now + 0.2);
    gain.gain.setValueAtTime(0.2, now);
    gain.gain.linearRampToValueAtTime(0.01, now + 0.2);
    osc.start(now);
    osc.stop(now + 0.2);
  } else if (type === 'start') {
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(440, now);
    osc.frequency.exponentialRampToValueAtTime(880, now + 0.15);
    gain.gain.setValueAtTime(0.1, now);
    gain.gain.linearRampToValueAtTime(0.01, now + 0.15);
    osc.start(now);
    osc.stop(now + 0.15);
  } else if (type === 'gameover') {
    osc.type = 'square';
    osc.frequency.setValueAtTime(300, now);
    osc.frequency.linearRampToValueAtTime(100, now + 0.4);
    gain.gain.setValueAtTime(0.2, now);
    gain.gain.linearRampToValueAtTime(0.01, now + 0.4);
    osc.start(now);
    osc.stop(now + 0.4);
  }
}

// Local Storage Helper
function loadStoredData() {
  const savedHighScore = parseInt(localStorage.getItem('catchGameHighScore'), 10);
  highScore = !isNaN(savedHighScore) ? savedHighScore : 0;
  highScoreEl.textContent = highScore;

  isMuted = localStorage.getItem('catchGameMuted') === 'true';
  muteBtn.textContent = isMuted ? '🔇' : '🔊';
}

function updateHighScore() {
  if (score > highScore) {
    highScore = score;
    localStorage.setItem('catchGameHighScore', highScore);
    highScoreEl.textContent = highScore;
  }
}

// Controls Handling
window.addEventListener('keydown', (e) => {
  keysPressed[e.key] = true;
  if ((e.key === 'p' || e.key === 'P' || e.key === 'Escape') && gameState === 'PLAYING') {
    pauseGame();
  } else if ((e.key === 'p' || e.key === 'P' || e.key === 'Escape') && gameState === 'PAUSED') {
    resumeGame();
  }
});

window.addEventListener('keyup', (e) => {
  keysPressed[e.key] = false;
});

// Spawn Item
function spawnItem() {
  const item = document.createElement('div');
  const isGood = Math.random() > 0.3; // 70% chance good, 30% bad
  
  item.classList.add('falling-item', isGood ? 'good-item' : 'bad-item');
  
  // Inline SVG visual assets
  if (isGood) {
    item.innerHTML = `<svg viewBox="0 0 24 24"><polygon points="12,2 22,12 12,22 2,12" fill="#ff007f" stroke="#ffffff" stroke-width="1"/></svg>`;
  } else {
    item.innerHTML = `<svg viewBox="0 0 24 24"><polygon points="12,2 22,22 2,22" fill="#ffb700" stroke="#000000" stroke-width="1"/></svg>`;
  }

  const posX = Math.floor(Math.random() * (playArea.clientWidth - 24));
  item.style.left = `${posX}px`;
  item.style.top = `0px`;

  playArea.appendChild(item);

  fallingItems.push({
    element: item,
    x: posX,
    y: 0,
    speed: 2.5 + Math.random() * 2,
    isGood: isGood
  });
}

// Show Float Text
function showPopText(text, x, y) {
  const pop = document.createElement('div');
  pop.classList.add('score-pop');
  pop.textContent = text;
  pop.style.left = `${x}px`;
  pop.style.top = `${y}px`;
  playArea.appendChild(pop);
  setTimeout(() => pop.remove(), 600);
}

// Game Loop
function updateGame() {
  if (gameState !== 'PLAYING') return;

  // Move Player
  if (keysPressed['ArrowLeft'] || keysPressed['a'] || keysPressed['A']) {
    playerX -= playerSpeed;
  }
  if (keysPressed['ArrowRight'] || keysPressed['d'] || keysPressed['D']) {
    playerX += playerSpeed;
  }

  // Clamping player boundary
  playerX = Math.max(0, Math.min(playArea.clientWidth - player.clientWidth, playerX));
  player.style.left = `${playerX}px`;

  // Spawning Items
  spawnTimer++;
  if (spawnTimer > 45) {
    spawnItem();
    spawnTimer = 0;
  }

  // Move & Collision Check on Items
  const playerRect = player.getBoundingClientRect();

  for (let i = fallingItems.length - 1; i >= 0; i--) {
    const itemObj = fallingItems[i];
    itemObj.y += itemObj.speed;
    itemObj.element.style.top = `${itemObj.y}px`;

    const itemRect = itemObj.element.getBoundingClientRect();

    // AABB Collision Detection
    const hasCollided = !(
      itemRect.right < playerRect.left ||
      itemRect.left > playerRect.right ||
      itemRect.bottom < playerRect.top ||
      itemRect.top > playerRect.bottom
    );

    if (hasCollided) {
      if (itemObj.isGood) {
        score += 10;
        scoreEl.textContent = score;
        showPopText('+10', itemObj.x, itemObj.y);
        playSound('catch');
      } else {
        lives--;
        livesEl.textContent = lives;
        gameContainer.classList.add('damage-flash');
        setTimeout(() => gameContainer.classList.remove('damage-flash'), 200);
        playSound('hit');
      }

      itemObj.element.remove();
      fallingItems.splice(i, 1);
      continue;
    }

    // Hit Bottom Floor
    if (itemObj.y > playArea.clientHeight - 24) {
      if (itemObj.isGood) {
        lives--;
        livesEl.textContent = lives;
        gameContainer.classList.add('damage-flash');
        setTimeout(() => gameContainer.classList.remove('damage-flash'), 200);
        playSound('hit');
      }
      itemObj.element.remove();
      fallingItems.splice(i, 1);
    }
  }

  // Check Game Over
  if (lives <= 0) {
    triggerGameOver();
    return;
  }

  animationFrameId = requestAnimationFrame(updateGame);
}

// State Control Functions
function startGame() {
  initAudio();
  playSound('start');
  
  score = 0;
  lives = 3;
  spawnTimer = 0;
  scoreEl.textContent = score;
  livesEl.textContent = lives;
  
  // Clear lingering items
  fallingItems.forEach(item => item.element.remove());
  fallingItems = [];

  gameState = 'PLAYING';
  overlay.classList.add('hidden');
  menuScreen.classList.add('hidden');
  gameoverScreen.classList.add('hidden');

  animationFrameId = requestAnimationFrame(updateGame);
}

function pauseGame() {
  if (gameState !== 'PLAYING') return;
  gameState = 'PAUSED';
  cancelAnimationFrame(animationFrameId);
  overlay.classList.remove('hidden');
  pauseScreen.classList.remove('hidden');
}

function resumeGame() {
  if (gameState !== 'PAUSED') return;
  gameState = 'PLAYING';
  overlay.classList.add('hidden');
  pauseScreen.classList.add('hidden');
  animationFrameId = requestAnimationFrame(updateGame);
}

function triggerGameOver() {
  gameState = 'GAMEOVER';
  cancelAnimationFrame(animationFrameId);
  updateHighScore();
  playSound('gameover');

  finalScoreEl.textContent = score;
  finalHighScoreEl.textContent = highScore;

  overlay.classList.remove('hidden');
  gameoverScreen.classList.remove('hidden');
}

// Event Listeners
startBtn.addEventListener('click', startGame);
restartBtn.addEventListener('click', startGame);
pauseBtn.addEventListener('click', () => {
  if (gameState === 'PLAYING') pauseGame();
  else if (gameState === 'PAUSED') resumeGame();
});
resumeBtn.addEventListener('click', resumeGame);

resetBtn.addEventListener('click', () => {
  localStorage.removeItem('catchGameHighScore');
  highScore = 0;
  highScoreEl.textContent = 0;
  alert('High score data reset!');
});

muteBtn.addEventListener('click', () => {
  isMuted = !isMuted;
  localStorage.setItem('catchGameMuted', isMuted);
  muteBtn.textContent = isMuted ? '🔇' : '🔊';
});

// Edge Case Handler: Auto-pause when switching tabs to prevent item overflow
document.addEventListener('visibilitychange', () => {
  if (document.hidden && gameState === 'PLAYING') {
    pauseGame();
  }
});

// Initialize Stored State
loadStoredData();