const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");
const scoreEl = document.getElementById("score");
const bestEl = document.getElementById("best");
const livesEl = document.getElementById("lives");
const levelEl = document.getElementById("level");
const overlay = document.getElementById("overlay");
const overlayEyebrow = document.getElementById("overlayEyebrow");
const overlayTitle = document.getElementById("overlayTitle");
const overlayText = document.getElementById("overlayText");
const mainBtn = document.getElementById("mainBtn");
const soundBtn = document.getElementById("soundBtn");
const resetBtn = document.getElementById("resetBtn");

function readSavedValue(key, fallback = null) {
  try {
    const value = window.localStorage.getItem(key);
    return value === null ? fallback : value;
  } catch (error) {
    return fallback;
  }
}
function saveValue(key, value) {
  try {
    window.localStorage.setItem(key, value);
  } catch (error) {
    // Storage may be blocked for local files; gameplay should still work.
  }
}
function removeSavedValue(key) {
  try {
    window.localStorage.removeItem(key);
  } catch (error) {
    // Storage may be blocked for local files; gameplay should still work.
  }
}

const W = canvas.width;
const H = canvas.height;
let score = 0;
let lives = 3;
let level = 1;
let best = Number(readSavedValue("starcatchBest", "0")) || 0;
let soundOn = readSavedValue("starcatchSound", "on") !== "off";
let running = false;
let paused = false;
let gameOver = false;
let lastTime = 0;
let spawnTimer = 0;
let objects = [];
let keys = {};
let dragging = false;
let audioContext = null;

const ship = { x: W / 2, y: H - 48, w: 54, h: 34, speed: 380 };
const stars = [];
for (let i = 0; i < 90; i++) {
  stars.push({ x: Math.random() * W, y: Math.random() * H, size: Math.random() * 1.8 + .4, twinkle: Math.random() * 5 });
}
bestEl.textContent = best;
soundBtn.textContent = soundOn ? "Sound: On" : "Sound: Off";
soundBtn.setAttribute("aria-pressed", String(!soundOn));

function playTone(frequency, duration, type = "sine") {
  if (!soundOn) return;
  try {
    audioContext = audioContext || new (window.AudioContext || window.webkitAudioContext)();
    if (audioContext.state === "suspended") audioContext.resume();
    const oscillator = audioContext.createOscillator();
    const gain = audioContext.createGain();
    oscillator.type = type;
    oscillator.frequency.value = frequency;
    gain.gain.setValueAtTime(0.08, audioContext.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, audioContext.currentTime + duration);
    oscillator.connect(gain);
    gain.connect(audioContext.destination);
    oscillator.start();
    oscillator.stop(audioContext.currentTime + duration);
  } catch (error) {
    // The game continues if the browser does not support generated audio.
  }
}

function updateStats() {
  scoreEl.textContent = score;
  bestEl.textContent = best;
  livesEl.textContent = "♥ ".repeat(lives).trim() || "—";
  levelEl.textContent = level;
}

function showOverlay(eyebrow, title, message, buttonText) {
  overlayEyebrow.textContent = eyebrow;
  overlayTitle.textContent = title;
  overlayText.textContent = message;
  mainBtn.textContent = buttonText;
  overlay.classList.remove("hidden");
}
function hideOverlay() { overlay.classList.add("hidden"); }

function resetGame() {
  score = 0; lives = 3; level = 1; objects = [];
  ship.x = W / 2; spawnTimer = 0; lastTime = 0;
  gameOver = false; paused = false; running = true;
  updateStats(); hideOverlay();
}
function pauseGame() {
  if (!running || gameOver) return;
  paused = !paused;
  if (paused) showOverlay("MISSION PAUSED", "Take a breath.", "Your score is safe. Resume when you're ready.", "Resume mission");
  else { hideOverlay(); lastTime = 0; }
}

function spawnObject() {
  const isStar = Math.random() < 0.7;
  const radius = isStar ? 11 : 14;
  objects.push({
    x: radius + Math.random() * (W - radius * 2),
    y: -radius,
    r: radius,
    type: isStar ? "star" : "meteor",
    speed: (isStar ? 150 : 180) + level * 17 + Math.random() * 50,
    rotation: Math.random() * Math.PI,
    spin: (Math.random() - .5) * 2.5
  });
}

function drawBackground(time) {
  const gradient = ctx.createLinearGradient(0, 0, 0, H);
  gradient.addColorStop(0, "#09142b");
  gradient.addColorStop(1, "#111b36");
  ctx.fillStyle = gradient; ctx.fillRect(0, 0, W, H);
  for (const star of stars) {
    const alpha = .35 + .55 * (Math.sin(time / 600 + star.twinkle) + 1) / 2;
    ctx.globalAlpha = alpha; ctx.fillStyle = "#d9eaff";
    ctx.beginPath(); ctx.arc(star.x, star.y, star.size, 0, Math.PI * 2); ctx.fill();
  }
  ctx.globalAlpha = 1;
}
function drawShip() {
  ctx.save(); ctx.translate(ship.x, ship.y);
  ctx.fillStyle = "#62e7ff";
  ctx.beginPath(); ctx.moveTo(0, -ship.h / 2); ctx.lineTo(ship.w / 2, ship.h / 2);
  ctx.lineTo(0, ship.h / 3); ctx.lineTo(-ship.w / 2, ship.h / 2); ctx.closePath(); ctx.fill();
  ctx.fillStyle = "#d8fbff"; ctx.beginPath(); ctx.ellipse(0, -2, 7, 10, 0, 0, Math.PI * 2); ctx.fill();
  ctx.fillStyle = "#ffb86b"; ctx.beginPath(); ctx.moveTo(-9, ship.h / 2 - 1); ctx.lineTo(0, ship.h / 2 + 13 + Math.random() * 5); ctx.lineTo(9, ship.h / 2 - 1); ctx.closePath(); ctx.fill();
  ctx.restore();
}
function drawStar(x, y, r, rotation) {
  ctx.save(); ctx.translate(x, y); ctx.rotate(rotation); ctx.fillStyle = "#ffd166";
  ctx.shadowColor = "#ffd166"; ctx.shadowBlur = 13; ctx.beginPath();
  for (let i = 0; i < 10; i++) {
    const angle = -Math.PI / 2 + i * Math.PI / 5;
    const radius = i % 2 === 0 ? r : r * .45;
    const px = Math.cos(angle) * radius, py = Math.sin(angle) * radius;
    if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
  }
  ctx.closePath(); ctx.fill(); ctx.restore();
}
function drawMeteor(x, y, r, rotation) {
  ctx.save(); ctx.translate(x, y); ctx.rotate(rotation);
  ctx.fillStyle = "#ff5d78"; ctx.shadowColor = "#ff405e"; ctx.shadowBlur = 9;
  ctx.beginPath();
  for (let i = 0; i < 9; i++) {
    const angle = i * Math.PI * 2 / 9;
    const radius = r * (i % 2 === 0 ? 1 : .78);
    const px = Math.cos(angle) * radius, py = Math.sin(angle) * radius;
    if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
  }
  ctx.closePath(); ctx.fill(); ctx.restore();
}
function draw(time = 0) {
  drawBackground(time);
  for (const obj of objects) {
    if (obj.type === "star") drawStar(obj.x, obj.y, obj.r, obj.rotation);
    else drawMeteor(obj.x, obj.y, obj.r, obj.rotation);
  }
  drawShip();
}

function endGame() {
  running = false; gameOver = true;
  showOverlay("MISSION COMPLETE", "Game over!", "Final score: " + score + ". Ready for another run?", "Play again");
  playTone(160, .25, "triangle");
}

function update(delta) {
  if (keys.ArrowLeft || keys.a || keys.A) ship.x -= ship.speed * delta;
  if (keys.ArrowRight || keys.d || keys.D) ship.x += ship.speed * delta;
  ship.x = Math.max(ship.w / 2, Math.min(W - ship.w / 2, ship.x));

  spawnTimer += delta;
  const spawnEvery = Math.max(.28, .8 - (level - 1) * .045);
  if (spawnTimer >= spawnEvery) { spawnTimer = 0; spawnObject(); }

  for (let i = objects.length - 1; i >= 0; i--) {
    const obj = objects[i];
    obj.y += obj.speed * delta; obj.rotation += obj.spin * delta;
    const hit = Math.abs(obj.x - ship.x) < obj.r + ship.w * .38 &&
                Math.abs(obj.y - ship.y) < obj.r + ship.h * .45;
    if (hit) {
      if (obj.type === "star") {
        score += 10;
        const newLevel = Math.floor(score / 100) + 1;
        if (newLevel > level) { level = newLevel; playTone(780, .13); }
        playTone(520, .08);
        if (score > best) { best = score; saveValue("starcatchBest", String(best)); }
      } else {
        lives--;
        playTone(120, .2, "sawtooth");
        if (lives <= 0) { objects.splice(i, 1); updateStats(); endGame(); return; }
      }
      objects.splice(i, 1); updateStats();
    } else if (obj.y > H + obj.r) {
      objects.splice(i, 1);
    }
  }
}

function frame(time) {
  if (running && !paused) {
    if (!lastTime) lastTime = time;
    const delta = Math.min((time - lastTime) / 1000, .04);
    lastTime = time;
    update(delta);
  }
  draw(time);
  requestAnimationFrame(frame);
}

mainBtn.addEventListener("click", () => {
  if (paused && !gameOver) {
    paused = false;
    hideOverlay();
    lastTime = 0;
  } else {
    resetGame();
  }
});
soundBtn.addEventListener("click", () => {
  soundOn = !soundOn;
  saveValue("starcatchSound", soundOn ? "on" : "off");
  soundBtn.textContent = soundOn ? "Sound: On" : "Sound: Off";
  soundBtn.setAttribute("aria-pressed", String(!soundOn));
  if (soundOn) playTone(500, .08);
});
resetBtn.addEventListener("click", () => {
  if (confirm("Clear the saved best score and sound preference?")) {
    removeSavedValue("starcatchBest");
    removeSavedValue("starcatchSound");
    best = 0; soundOn = true; updateStats();
    soundBtn.textContent = "Sound: On"; soundBtn.setAttribute("aria-pressed", "false");
  }
});
window.addEventListener("keydown", (event) => {
  keys[event.key] = true;
  if (["ArrowLeft", "ArrowRight", " "].includes(event.key)) event.preventDefault();
  if (event.key === " " || event.key === "Escape") {
    if (!running && !gameOver) return;
    pauseGame();
  }
});
window.addEventListener("keyup", (event) => { keys[event.key] = false; });
function moveShipToPointer(event) {
  const rect = canvas.getBoundingClientRect();
  const scaleX = W / rect.width;
  ship.x = Math.max(ship.w / 2, Math.min(W - ship.w / 2, (event.clientX - rect.left) * scaleX));
}
canvas.addEventListener("pointerdown", (event) => { dragging = true; canvas.setPointerCapture(event.pointerId); moveShipToPointer(event); });
canvas.addEventListener("pointermove", (event) => { if (dragging) moveShipToPointer(event); });
canvas.addEventListener("pointerup", () => { dragging = false; });
canvas.addEventListener("pointercancel", () => { dragging = false; });

draw(0);
requestAnimationFrame(frame);
updateStats();
showOverlay("READY, PILOT?", "Catch the stars.", "Move your ship to collect gold stars. Dodge red meteors and stay in the game!", "Start mission");
