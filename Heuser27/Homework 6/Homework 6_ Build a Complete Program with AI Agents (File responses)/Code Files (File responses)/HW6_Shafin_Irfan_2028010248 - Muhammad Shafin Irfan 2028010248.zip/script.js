// Virtual Pet Game - Pixel
// CS CRP Homework 6 Implementation

class VirtualPet {
    constructor() {
        // State variables
        self = this;
        this.stats = {
            hunger: 80,
            happiness: 80,
            energy: 80
        };
        this.isSleeping = false;
        this.isGameOver = false;
        this.isPaused = false;
        this.soundMuted = false;
        this.timeSurvived = 0; // seconds
        this.actionCooldown = false;
        
        // Timer references
        this.gameLoopInterval = null;
        this.sleepParticleInterval = null;

        // Audio Context initialization (Web Audio API)
        this.audioCtx = null;

        // DOM Elements
        this.initDOMElements();
        
        // Load initial state from LocalStorage
        this.loadState();

        // Bind Event Listeners
        this.bindEvents();

        // Start Game Loop
        this.startGameLoop();

        // UI Initial Refresh
        this.updateUI();
        this.showMessage("Pixel is awake and happy to see you!");
    }

    initDOMElements() {
        this.hungerVal = document.getElementById('hunger-val');
        this.hungerBar = document.getElementById('hunger-bar');
        this.happinessVal = document.getElementById('happiness-val');
        this.happinessBar = document.getElementById('happiness-bar');
        this.energyVal = document.getElementById('energy-val');
        this.energyBar = document.getElementById('energy-bar');

        this.messageBanner = document.getElementById('message-banner');
        this.statusBadge = document.getElementById('pet-status-badge');
        this.timeSurvivedDisplay = document.getElementById('time-survived');

        this.feedBtn = document.getElementById('feed-btn');
        this.playBtn = document.getElementById('play-btn');
        this.sleepBtn = document.getElementById('sleep-btn');
        this.sleepText = document.getElementById('sleep-text');
        this.sleepIcon = document.getElementById('sleep-icon');

        this.soundBtn = document.getElementById('sound-btn');
        this.soundIcon = document.getElementById('sound-icon');
        this.pauseBtn = document.getElementById('pause-btn');
        this.pauseIcon = document.getElementById('pause-icon');

        this.restartBtn = document.getElementById('restart-btn');
        this.resetDataBtn = document.getElementById('reset-data-btn');
        
        this.gameOverModal = document.getElementById('game-over-modal');
        this.gameOverReason = document.getElementById('game-over-reason');
        this.finalTime = document.getElementById('final-time');
        this.modalRestartBtn = document.getElementById('modal-restart-btn');

        this.petContainer = document.getElementById('pet-container');
        this.effectsLayer = document.getElementById('effects-layer');
        
        // SVG Elements
        this.eyesOpen = document.getElementById('eyes-open');
        this.eyesClosed = document.getElementById('eyes-closed');
        this.mouthHappy = document.getElementById('mouth-happy');
        this.mouthSad = document.getElementById('mouth-sad');
        this.mouthEating = document.getElementById('mouth-eating');
    }

    bindEvents() {
        this.feedBtn.addEventListener('click', () => this.handleFeed());
        this.playBtn.addEventListener('click', () => this.handlePlay());
        this.sleepBtn.addEventListener('click', () => this.toggleSleep());

        this.soundBtn.addEventListener('click', () => this.toggleSound());
        this.pauseBtn.addEventListener('click', () => this.togglePause());

        this.restartBtn.addEventListener('click', () => this.restartGame());
        this.resetDataBtn.addEventListener('click', () => this.resetSavedData());
        this.modalRestartBtn.addEventListener('click', () => this.restartGame());

        // Save state on visibility change/unload
        document.addEventListener('visibilitychange', () => {
            if (document.hidden) this.saveState();
        });
    }

    initAudio() {
        if (!this.audioCtx) {
            const AudioContext = window.AudioContext || window.webkitAudioContext;
            if (AudioContext) {
                this.audioCtx = new AudioContext();
            }
        }
        if (this.audioCtx && this.audioCtx.state === 'suspended') {
            this.audioCtx.resume();
        }
    }

    playSound(type) {
        if (this.soundMuted) return;
        this.initAudio();
        if (!this.audioCtx) return;

        const ctx = this.audioCtx;
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.connect(gain);
        gain.connect(ctx.destination);

        const now = ctx.currentTime;

        if (type === 'feed') {
            osc.type = 'sine';
            osc.frequency.setValueAtTime(300, now);
            osc.frequency.exponentialRampToValueAtTime(600, now + 0.15);
            gain.gain.setValueAtTime(0.2, now);
            gain.gain.exponentialRampToValueAtTime(0.01, now + 0.15);
            osc.start(now);
            osc.stop(now + 0.15);
        } else if (type === 'play') {
            osc.type = 'triangle';
            osc.frequency.setValueAtTime(400, now);
            osc.frequency.setValueAtTime(600, now + 0.08);
            osc.frequency.setValueAtTime(800, now + 0.16);
            gain.gain.setValueAtTime(0.2, now);
            gain.gain.exponentialRampToValueAtTime(0.01, now + 0.25);
            osc.start(now);
            osc.stop(now + 0.25);
        } else if (type === 'sleep') {
            osc.type = 'sine';
            osc.frequency.setValueAtTime(400, now);
            osc.frequency.exponentialRampToValueAtTime(200, now + 0.3);
            gain.gain.setValueAtTime(0.2, now);
            gain.gain.exponentialRampToValueAtTime(0.01, now + 0.3);
            osc.start(now);
            osc.stop(now + 0.3);
        } else if (type === 'gameover') {
            osc.type = 'sawtooth';
            osc.frequency.setValueAtTime(300, now);
            osc.frequency.linearRampToValueAtTime(100, now + 0.6);
            gain.gain.setValueAtTime(0.3, now);
            gain.gain.exponentialRampToValueAtTime(0.01, now + 0.6);
            osc.start(now);
            osc.stop(now + 0.6);
        } else if (type === 'click') {
            osc.type = 'sine';
            osc.frequency.setValueAtTime(800, now);
            gain.gain.setValueAtTime(0.1, now);
            gain.gain.exponentialRampToValueAtTime(0.01, now + 0.05);
            osc.start(now);
            osc.stop(now + 0.05);
        }
    }

    startGameLoop() {
        if (this.gameLoopInterval) clearInterval(this.gameLoopInterval);
        this.gameLoopInterval = setInterval(() => {
            if (this.isPaused || this.isGameOver) return;

            this.timeSurvived++;
            this.timeSurvivedDisplay.textContent = `${this.timeSurvived}s`;

            if (this.isSleeping) {
                // Sleep restores energy, slowly reduces hunger, unchanged happiness
                this.stats.energy = Math.min(100, this.stats.energy + 4);
                this.stats.hunger = Math.max(0, this.stats.hunger - 1);
                
                if (this.stats.energy >= 100) {
                    this.toggleSleep(false); // Auto-wake when full energy
                    this.showMessage("Pixel woke up fully rested!");
                }
            } else {
                // Decay rates when awake
                this.stats.hunger = Math.max(0, this.stats.hunger - 2);
                this.stats.happiness = Math.max(0, this.stats.happiness - 2);
                this.stats.energy = Math.max(0, this.stats.energy - 1);
            }

            this.checkGameOver();
            this.updateUI();
            this.saveState();
        }, 1000);
    }

    handleFeed() {
        if (this.isSleeping || this.isGameOver || this.isPaused || this.actionCooldown) return;
        if (this.stats.hunger >= 100) {
            this.showMessage("Pixel is full and can't eat any more!");
            return;
        }

        this.setCooldown(600);
        this.playSound('feed');
        this.stats.hunger = Math.min(100, this.stats.hunger + 25);
        this.showMessage("Nom nom nom! Pixel loved the meal! 🍔");

        // Visual animation & effects
        this.spawnParticle('🍔', 'food');
        this.triggerPetAnimation('pet-eating');
        this.setMouth('eating');

        setTimeout(() => {
            this.setMouth('happy');
            this.updateUI();
        }, 1200);
    }

    handlePlay() {
        if (this.isSleeping || this.isGameOver || this.isPaused || this.actionCooldown) return;
        if (this.stats.energy < 15) {
            this.showMessage("Pixel is too tired to play! Let Pixel sleep.");
            return;
        }

        this.setCooldown(800);
        this.playSound('play');
        this.stats.happiness = Math.min(100, this.stats.happiness + 25);
        this.stats.energy = Math.max(0, this.stats.energy - 15);
        this.showMessage("Yay! Pixel had a blast playing! ⚽✨");

        // Visual animation & effects
        this.spawnParticle('✨', 'star');
        this.spawnParticle('⭐', 'star');
        this.triggerPetAnimation('pet-play');

        setTimeout(() => {
            this.updateUI();
        }, 800);
    }

    toggleSleep(forceState = null) {
        if (this.isGameOver || this.isPaused) return;

        const targetState = forceState !== null ? forceState : !this.isSleeping;
        this.isSleeping = targetState;

        this.playSound('sleep');

        if (this.isSleeping) {
            this.sleepText.textContent = "Wake Up";
            this.sleepIcon.textContent = "☀️";
            this.showMessage("Shh... Pixel is sleeping. Zzz...");
            this.feedBtn.disabled = true;
            this.playBtn.disabled = true;
            
            // Visual Sleeping Appearance
            this.eyesOpen.style.display = 'none';
            this.eyesClosed.style.display = 'block';
            this.petContainer.className = 'pet-container pet-sleeping';

            // Zzz Particles
            this.sleepParticleInterval = setInterval(() => {
                if (this.isSleeping) this.spawnParticle('Zzz', 'z');
            }, 1500);
        } else {
            this.sleepText.textContent = "Sleep";
            this.sleepIcon.textContent = "🌙";
            this.showMessage("Pixel woke up!");
            this.feedBtn.disabled = false;
            this.playBtn.disabled = false;

            // Visual Awake Appearance
            this.eyesOpen.style.display = 'block';
            this.eyesClosed.style.display = 'none';
            this.petContainer.className = 'pet-container pet-idle';

            if (this.sleepParticleInterval) clearInterval(this.sleepParticleInterval);
        }

        this.updateUI();
        this.saveState();
    }

    triggerPetAnimation(animClass) {
        this.petContainer.className = `pet-container ${animClass}`;
        setTimeout(() => {
            if (!this.isSleeping) {
                this.petContainer.className = 'pet-container pet-idle';
            }
        }, 800);
    }

    setMouth(state) {
        this.mouthHappy.style.display = state === 'happy' ? 'block' : 'none';
        this.mouthSad.style.display = state === 'sad' ? 'block' : 'none';
        this.mouthEating.style.display = state === 'eating' ? 'block' : 'none';
    }

    spawnParticle(symbol, type) {
        const particle = document.createElement('div');
        particle.textContent = symbol;
        
        if (type === 'food') {
            particle.className = 'particle-food';
        } else if (type === 'star') {
            particle.className = 'particle-star';
            particle.style.left = `${30 + Math.random() * 40}%`;
            particle.style.top = `${40 + Math.random() * 20}%`;
        } else if (type === 'z') {
            particle.className = 'particle-z';
            particle.style.right = '25%';
            particle.style.top = '25%';
        }

        this.effectsLayer.appendChild(particle);
        setTimeout(() => particle.remove(), 2000);
    }

    setCooldown(ms) {
        this.actionCooldown = true;
        setTimeout(() => {
            this.actionCooldown = false;
        }, ms);
    }

    checkGameOver() {
        if (this.stats.hunger <= 0 || this.stats.happiness <= 0 || this.stats.energy <= 0) {
            let reason = "";
            if (this.stats.hunger <= 0) reason = "Pixel starved from hunger!";
            else if (this.stats.happiness <= 0) reason = "Pixel became too heartbroken and ran away!";
            else if (this.stats.energy <= 0) reason = "Pixel completely collapsed from exhaustion!";

            this.triggerGameOver(reason);
        }
    }

    triggerGameOver(reason) {
        this.isGameOver = true;
        this.playSound('gameover');
        this.gameOverReason.textContent = reason;
        this.finalTime.textContent = `${this.timeSurvived}s`;
        this.gameOverModal.style.display = 'flex';
        
        this.feedBtn.disabled = true;
        this.playBtn.disabled = true;
        this.sleepBtn.disabled = true;

        this.statusBadge.textContent = "GAME OVER";
        this.statusBadge.className = "status-badge critical";
        this.setMouth('sad');
    }

    restartGame() {
        this.playSound('click');
        this.stats = { hunger: 80, happiness: 80, energy: 80 };
        this.isSleeping = false;
        this.isGameOver = false;
        this.isPaused = false;
        this.timeSurvived = 0;

        if (this.sleepParticleInterval) clearInterval(this.sleepParticleInterval);

        this.gameOverModal.style.display = 'none';
        this.feedBtn.disabled = false;
        this.playBtn.disabled = false;
        this.sleepBtn.disabled = false;

        this.sleepText.textContent = "Sleep";
        this.sleepIcon.textContent = "🌙";
        this.eyesOpen.style.display = 'block';
        this.eyesClosed.style.display = 'none';
        this.setMouth('happy');
        this.petContainer.className = 'pet-container pet-idle';

        this.pauseIcon.textContent = "⏸️";
        this.showMessage("Game restarted! Pixel is ready for adventure.");

        this.updateUI();
        this.saveState();
    }

    resetSavedData() {
        if (confirm("Are you sure you want to clear all saved progress?")) {
            localStorage.removeItem('pixel_pet_state');
            this.restartGame();
            this.showMessage("Saved data reset successfully!");
        }
    }

    toggleSound() {
        this.soundMuted = !this.soundMuted;
        this.soundIcon.textContent = this.soundMuted ? "🔇" : "🔊";
        this.showMessage(this.soundMuted ? "Audio muted" : "Audio unmuted");
    }

    togglePause() {
        if (this.isGameOver) return;
        this.isPaused = !this.isPaused;
        this.pauseIcon.textContent = this.isPaused ? "▶️" : "⏸️";
        this.showMessage(this.isPaused ? "Game Paused" : "Game Resumed");
    }

    updateUI() {
        // Update percentages
        this.hungerVal.textContent = `${this.stats.hunger}%`;
        this.hungerBar.style.width = `${this.stats.hunger}%`;
        this.updateBarColor(this.hungerBar, this.stats.hunger);

        this.happinessVal.textContent = `${this.stats.happiness}%`;
        this.happinessBar.style.width = `${this.stats.happiness}%`;
        this.updateBarColor(this.happinessBar, this.stats.happiness);

        this.energyVal.textContent = `${this.stats.energy}%`;
        this.energyBar.style.width = `${this.stats.energy}%`;
        this.updateBarColor(this.energyBar, this.stats.energy);

        // Update Badge
        if (!this.isGameOver) {
            if (this.isSleeping) {
                this.statusBadge.textContent = "SLEEPING";
                this.statusBadge.className = "status-badge sleeping";
            } else if (this.stats.hunger < 30 || this.stats.happiness < 30 || this.stats.energy < 30) {
                this.statusBadge.textContent = "NEED CARE";
                this.statusBadge.className = "status-badge critical";
                this.setMouth('sad');
            } else {
                this.statusBadge.textContent = "HAPPY";
                this.statusBadge.className = "status-badge alive";
                this.setMouth('happy');
            }
        }
    }

    updateBarColor(barElement, val) {
        barElement.classList.remove('warning', 'critical');
        if (val <= 20) {
            barElement.classList.add('critical');
        } else if (val <= 45) {
            barElement.classList.add('warning');
        }
    }

    showMessage(text) {
        this.messageBanner.textContent = text;
    }

    saveState() {
        try {
            const data = {
                stats: this.stats,
                isSleeping: this.isSleeping,
                isGameOver: this.isGameOver,
                timeSurvived: this.timeSurvived
            };
            localStorage.setItem('pixel_pet_state', JSON.stringify(data));
        } catch (e) {
            console.warn("Could not save to localStorage", e);
        }
    }

    loadState() {
        try {
            const saved = localStorage.getItem('pixel_pet_state');
            if (saved) {
                const data = JSON.parse(saved);
                if (data && data.stats && typeof data.stats.hunger === 'number') {
                    this.stats = data.stats;
                    this.isSleeping = !!data.isSleeping;
                    this.isGameOver = !!data.isGameOver;
                    this.timeSurvived = data.timeSurvived || 0;

                    if (this.isSleeping) {
                        this.toggleSleep(true);
                    }
                    if (this.isGameOver) {
                        this.triggerGameOver("Restored game over state");
                    }
                }
            }
        } catch (e) {
            console.error("Corrupted localStorage data, resetting", e);
            localStorage.removeItem('pixel_pet_state');
        }
    }
}

// Initialize when page loads
document.addEventListener('DOMContentLoaded', () => {
    window.petGame = new VirtualPet();
});
