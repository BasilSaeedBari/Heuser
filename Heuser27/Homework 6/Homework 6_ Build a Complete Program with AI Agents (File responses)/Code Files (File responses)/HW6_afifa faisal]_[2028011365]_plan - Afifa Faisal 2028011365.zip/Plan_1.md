# MD.plan1 – Galaxy Catcher (Stage 1) – Full Source

> **Architect model:** Claude Sonnet 4.6 (Thinking)
> **Builder model:** Claude Sonnet 4.6 (Thinking)
> **Project folder:** `c:\Users\abdul\Downloads\catch game`

Below are all three source files that make up the Stage 1 game (core logic, simple rectangles, no visual styling).

---

## `index.html`
```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Galaxy Catcher</title>
    <link rel="stylesheet" href="style.css" />
</head>
<body>
    <canvas id="gameCanvas"></canvas>
    <script src="script.js"></script>
</body>
</html>
```

---

## `style.css`
```css
/* style.css – Galaxy Catcher (Stage 1) */
html, body {
    margin: 0;
    padding: 0;
    height: 100%;
    overflow: hidden;
    background: #000;
}

canvas {
    display: block;
    width: 100vw;
    height: 100vh;
    background: #000;
}
```

---

## `script.js`
```javascript
// script.js – Galaxy Catcher (Stage 1)
// Architect model : Claude Sonnet 4.6 (Thinking)
// Builder  model  : Claude Sonnet 4.6 (Thinking)
// -------------------------------------------------------

// ── Canvas / logical dimensions ────────────────────────
const CANVAS_W = 480;
const CANVAS_H = 720;

// ── Spaceship configuration ────────────────────────────
const SHIP_W        = 60;
const SHIP_H        = 40;
const SHIP_Y        = CANVAS_H - 70;   // fixed vertical position
const SHIP_SPEED    = 7;               // px per frame (keyboard)

// ── Falling-object configuration ──────────────────────
const OBJ_W               = 24;
const OBJ_H               = 24;
const INITIAL_FALL_SPEED  = 2;         // px per frame
const MAX_FALL_SPEED      = 9;
const SPEED_INCREMENT     = 0.4;       // added every SPEED_STEP_SCORE points
const SPEED_STEP_SCORE    = 30;        // score threshold between speed bumps
const SPAWN_INTERVAL_BASE = 900;       // ms between spawns (shrinks over time)
const SPAWN_INTERVAL_MIN  = 350;       // floor
const MAX_LIVES           = 3;
const ASTEROID_CHANCE     = 0.30;      // 30 % of spawns are asteroids
const POINTS_PER_STAR     = 10;

// ── Game-state machine ─────────────────────────────────
// Valid values: "menu" | "playing" | "paused" | "gameover"
let state = "menu";

// ── Mutable game data ──────────────────────────────────
let score        = 0;
let lives        = MAX_LIVES;
let fallSpeed    = INITIAL_FALL_SPEED;
let lastSpawnTime = 0;
let objects      = [];          // active falling objects
let ship         = { x: (CANVAS_W - SHIP_W) / 2, y: SHIP_Y, w: SHIP_W, h: SHIP_H };
let keysDown     = new Set();
let highScore    = 0;
let flash        = { type: null, until: 0 };   // brief screen-flash on event

// ── Canvas setup ───────────────────────────────────────
const canvas = document.getElementById("gameCanvas");
const ctx    = canvas.getContext("2d");
canvas.width  = CANVAS_W;
canvas.height = CANVAS_H;

// ═══════════════════════════════════════════════════════
// UTILITY FUNCTIONS
// ═══════════════════════════════════════════════════════

/** Returns a random integer in [min, max). */
function randInt(min, max) {
    return Math.floor(Math.random() * (max - min)) + min;
}

/** AABB rectangle collision test. Both objects need {x,y,w,h}. */
function collides(a, b) {
    return a.x < b.x + b.w &&
           a.x + a.w > b.x &&
           a.y < b.y + b.h &&
           a.y + a.h > b.y;
}

/** Current spawn interval (shrinks as score rises, floors at min). */
function getSpawnInterval() {
    return Math.max(SPAWN_INTERVAL_MIN, SPAWN_INTERVAL_BASE - score * 4);
}

/** Current fall speed computed from score (capped at MAX). */
function computeFallSpeed() {
    const steps = Math.floor(score / SPEED_STEP_SCORE);
    return Math.min(MAX_FALL_SPEED, INITIAL_FALL_SPEED + steps * SPEED_INCREMENT);
}

function saveHighScore() {
    try { localStorage.setItem("galaxyCatcherHighScore", String(highScore)); }
    catch (_) { /* ignore */ }
}

function loadHighScore() {
    try {
        const v = localStorage.getItem("galaxyCatcherHighScore");
        if (v !== null) highScore = parseInt(v, 10) || 0;
    } catch (_) { highScore = 0; }
}

// ═══════════════════════════════════════════════════════
// GAME LIFECYCLE FUNCTIONS
// ═══════════════════════════════════════════════════════

/** Boot: attach events, load persistence, kick off the loop. */
function init() {
    window.addEventListener("keydown", onKeyDown);
    window.addEventListener("keyup",   onKeyUp);
    loadHighScore();
    requestAnimationFrame(gameLoop);
}

/** Full reset – returns everything to initial values, sets state = "menu". */
function resetGame() {
    score     = 0;
    lives     = MAX_LIVES;
    fallSpeed = INITIAL_FALL_SPEED;
    objects   = [];
    ship.x    = (CANVAS_W - SHIP_W) / 2;
    keysDown.clear();
    flash     = { type: null, until: 0 };
    state     = "menu";
}

/** Transition from menu/gameover → playing. */
function startGame() {
    state         = "playing";
    lastSpawnTime = performance.now();
}

/** Restart: reset then start immediately. */
function restartGame() {
    resetGame();
    startGame();
}

/** Triggered when lives reach zero. */
function endGame() {
    state = "gameover";
    if (score > highScore) {
        highScore = score;
        saveHighScore();
    }
}

/** Toggle between playing ↔ paused. */
function togglePause() {
    if (state === "playing") {
        state = "paused";
    } else if (state === "paused") {
        state = "playing";
        lastSpawnTime = performance.now();
    }
}

// ═══════════════════════════════════════════════════════
// INPUT HANDLING
// ═══════════════════════════════════════════════════════

function onKeyDown(e) {
    keysDown.add(e.key);

    switch (state) {
        case "menu":
            if (e.key === "Enter" || e.key === " ") {
                startGame();
                e.preventDefault();
            }
            break;
        case "playing":
            if (e.key === "p" || e.key === "P" || e.key === "Escape") {
                togglePause();
                e.preventDefault();
            }
            break;
        case "paused":
            if (e.key === "p" || e.key === "P" || e.key === "Escape") {
                togglePause();
                e.preventDefault();
            }
            break;
        case "gameover":
            if (e.key === "Enter" || e.key === " " || e.key === "r" || e.key === "R") {
                restartGame();
                e.preventDefault();
            }
            break;
    }
}

function onKeyUp(e) {
    keysDown.delete(e.key);
}

/** Move the spaceship based on current key state; clamp to canvas. */
function moveSpaceship() {
    if (keysDown.has("ArrowLeft")) {
        ship.x -= SHIP_SPEED;
    }
    if (keysDown.has("ArrowRight")) {
        ship.x += SHIP_SPEED;
    }
    // Boundary clamp
    if (ship.x < 0)              ship.x = 0;
    if (ship.x + SHIP_W > CANVAS_W) ship.x = CANVAS_W - SHIP_W;
}

// ═══════════════════════════════════════════════════════
// FALLING OBJECTS – CREATION & UPDATE
// ═══════════════════════════════════════════════════════

/** Spawn one falling object (star or asteroid) if interval has elapsed. */
function createFallingObject(now) {
    if (now - lastSpawnTime < getSpawnInterval()) return;
    lastSpawnTime = now;

    const isAsteroid = Math.random() < ASTEROID_CHANCE;
    const x          = randInt(0, CANVAS_W - OBJ_W);

    objects.push({
        x,
        y:    -OBJ_H,
        w:    OBJ_W,
        h:    OBJ_H,
        type: isAsteroid ? "asteroid" : "star",
        hit:  false,
    });
}

/** Advance every object downward and prune off-screen ones. */
function updateObjectPositions() {
    for (let i = objects.length - 1; i >= 0; i--) {
        objects[i].y += fallSpeed;
        if (objects[i].y > CANVAS_H) {
            objects.splice(i, 1);
        }
    }
}

// ═══════════════════════════════════════════════════════
// COLLISION DETECTION
// ═══════════════════════════════════════════════════════

/** Check every live object against the spaceship. */
function checkCollisions() {
    for (let i = objects.length - 1; i >= 0; i--) {
        const obj = objects[i];
        if (obj.hit) continue;
        if (!collides(obj, ship)) continue;

        obj.hit = true;
        if (obj.type === "star") {
            updateScore(POINTS_PER_STAR);
            triggerFlash("star");
        } else {
            loseLife();
            triggerFlash("asteroid");
        }
        objects.splice(i, 1);
    }
}

// ═══════════════════════════════════════════════════════
// SCORE & LIVES
// ═══════════════════════════════════════════════════════

/** Add points and re-evaluate difficulty. */
function updateScore(points) {
    score     += points;
    fallSpeed  = computeFallSpeed();
}

/** Subtract one life; trigger game-over if none remain. */
function loseLife() {
    lives -= 1;
    if (lives <= 0) {
        lives = 0;
        endGame();
    }
}

// ═══════════════════════════════════════════════════════
// VISUAL FLASH FEEDBACK
// ═══════════════════════════════════════════════════════

function triggerFlash(type) {
    flash.type  = type;
    flash.until = performance.now() + 120;
}

// ═══════════════════════════════════════════════════════
// RENDERING
// ═══════════════════════════════════════════════════════

/** Fill the canvas with a plain dark background. */
function drawBackground() {
    ctx.fillStyle = "#0a0a1a";
    ctx.fillRect(0, 0, CANVAS_W, CANVAS_H);
}

/** Draw the spaceship as a simple triangle + body rectangle. */
function drawSpaceship() {
    const { x, y, w, h } = ship;

    // Body rectangle
    ctx.fillStyle = "#4af";
    ctx.fillRect(x + w * 0.2, y + h * 0.3, w * 0.6, h * 0.7);

    // Nose triangle
    ctx.beginPath();
    ctx.moveTo(x + w / 2, y);
    ctx.lineTo(x + w * 0.15, y + h * 0.4);
    ctx.lineTo(x + w * 0.85, y + h * 0.4);
    ctx.closePath();
    ctx.fillStyle = "#8df";
    ctx.fill();

    // Left fin
    ctx.beginPath();
    ctx.moveTo(x,            y + h);
    ctx.lineTo(x + w * 0.2,  y + h * 0.5);
    ctx.lineTo(x + w * 0.35, y + h);
    ctx.closePath();
    ctx.fillStyle = "#37b";
    ctx.fill();

    // Right fin
    ctx.beginPath();
    ctx.moveTo(x + w,         y + h);
    ctx.lineTo(x + w * 0.8,  y + h * 0.5);
    ctx.lineTo(x + w * 0.65, y + h);
    ctx.closePath();
    ctx.fillStyle = "#37b";
    ctx.fill();

    // Engine glow
    ctx.fillStyle = "rgba(255, 160, 50, 0.85)";
    ctx.fillRect(x + w * 0.35, y + h, w * 0.3, 6);
}

/** Draw all active falling objects. Stars = yellow ★, Asteroids = grey ✕. */
function drawFallingObjects() {
    for (const obj of objects) {
        if (obj.type === "star") {
            ctx.fillStyle = "#ffe94a";
        } else {
            ctx.fillStyle = "#a0896a";
        }
        ctx.fillRect(obj.x, obj.y, obj.w, obj.h);

        ctx.font         = "14px monospace";
        ctx.textAlign    = "center";
        ctx.textBaseline = "middle";
        ctx.fillStyle    = "#000";
        ctx.fillText(obj.type === "star" ? "★" : "✕",
                     obj.x + OBJ_W / 2,
                     obj.y + OBJ_H / 2);
    }
}

/** HUD: score (top-left) and lives (top-right). */
function drawHUD() {
    ctx.textBaseline = "top";
    ctx.font         = "18px monospace";

    ctx.fillStyle = "#fff";
    ctx.textAlign = "left";
    ctx.fillText(`Score: ${score}`, 10, 10);

    ctx.textAlign = "right";
    ctx.fillStyle = "#f55";
    const heartStr = "♥ ".repeat(lives).trimEnd();
    ctx.fillText(heartStr, CANVAS_W - 10, 10);
}

/** Draw a brief translucent overlay on star catch or asteroid hit. */
function drawFlash() {
    if (!flash.type || performance.now() > flash.until) {
        flash.type = null;
        return;
    }
    ctx.fillStyle = flash.type === "star"
        ? "rgba(255, 240, 80, 0.18)"
        : "rgba(255, 50,  50, 0.25)";
    ctx.fillRect(0, 0, CANVAS_W, CANVAS_H);
}

/** ── Screen: MENU ── */
function drawMenu() {
    drawBackground();
    ctx.textAlign = "center";

    ctx.fillStyle = "#ffe94a";
    ctx.font      = "40px monospace";
    ctx.fillText("GALAXY CATCHER", CANVAS_W / 2, CANVAS_H / 4);

    ctx.fillStyle = "#adf";
    ctx.font      = "16px monospace";
    ctx.fillText("Catch falling stars. Avoid asteroids.", CANVAS_W / 2, CANVAS_H / 4 + 55);
    ctx.fillText("← → Arrow keys to move", CANVAS_W / 2, CANVAS_H / 4 + 85);
    ctx.fillText("P or Esc  → Pause", CANVAS_W / 2, CANVAS_H / 4 + 110);

    const bw = 200, bh = 44;
    const bx = CANVAS_W / 2 - bw / 2;
    const by = CANVAS_H / 2 + 10;
    ctx.fillStyle   = "#ffe94a";
    ctx.fillRect(bx, by, bw, bh);
    ctx.fillStyle   = "#000";
    ctx.font        = "20px monospace";
    ctx.fillText("▶  START GAME", CANVAS_W / 2, by + bh / 2 + 1);

    ctx.fillStyle = "#666";
    ctx.font      = "14px monospace";
    ctx.fillText("or press Enter / Space", CANVAS_W / 2, by + bh + 22);

    if (highScore > 0) {
        ctx.fillStyle = "#8f8";
        ctx.font      = "16px monospace";
        ctx.fillText(`Best: ${highScore}`, CANVAS_W / 2, by + bh + 50);
    }
}

/** ── Screen: PAUSED overlay ── */
function drawPaused() {
    drawBackground();
    drawFallingObjects();
    drawSpaceship();
    drawHUD();

    ctx.fillStyle = "rgba(0, 0, 0, 0.55)";
    ctx.fillRect(0, 0, CANVAS_W, CANVAS_H);

    ctx.textAlign = "center";
    ctx.fillStyle = "#ffe94a";
    ctx.font      = "36px monospace";
    ctx.fillText("PAUSED", CANVAS_W / 2, CANVAS_H / 2 - 20);

    ctx.fillStyle = "#adf";
    ctx.font      = "16px monospace";
    ctx.fillText("Press P or Esc to resume", CANVAS_W / 2, CANVAS_H / 2 + 20);
}

/** ── Screen: GAME OVER ── */
function drawGameOver() {
    drawBackground();
    ctx.textAlign = "center";

    ctx.fillStyle = "#f55";
    ctx.font      = "38px monospace";
    ctx.fillText("GAME OVER", CANVAS_W / 2, CANVAS_H / 4);

    ctx.fillStyle = "#fff";
    ctx.font      = "22px monospace";
    ctx.fillText(`Score: ${score}`, CANVAS_W / 2, CANVAS_H / 4 + 60);

    if (highScore > 0) {
        ctx.fillStyle = "#8f8";
        ctx.font      = "18px monospace";
        ctx.fillText(`Best:  ${highScore}`, CANVAS_W / 2, CANVAS_H / 4 + 92);
    }

    const bw = 200, bh = 44;
    const bx = CANVAS_W / 2 - bw / 2;
    const by = CANVAS_H / 2 + 10;
    ctx.fillStyle   = "#ffe94a";
    ctx.fillRect(bx, by, bw, bh);
    ctx.fillStyle   = "#000";
    ctx.font        = "20px monospace";
    ctx.fillText("↺  RESTART", CANVAS_W / 2, by + bh / 2 + 1);

    ctx.fillStyle = "#666";
    ctx.font      = "14px monospace";
    ctx.fillText("or press Enter / R", CANVAS_W / 2, by + bh + 22);
}

/** ── Screen: PLAYING ── */
function drawPlaying() {
    drawBackground();
    drawFallingObjects();
    drawSpaceship();
    drawHUD();
    drawFlash();
}

/** Master render dispatcher. */
function render() {
    switch (state) {
        case "menu":     drawMenu();     break;
        case "playing":  drawPlaying();  break;
        case "paused":   drawPaused();   break;
        case "gameover": drawGameOver(); break;
    }
}

// ═══════════════════════════════════════════════════════
// MAIN GAME LOOP
// ═══════════════════════════════════════════════════════

function gameLoop(timestamp) {
    requestAnimationFrame(gameLoop);

    if (state === "playing") {
        moveSpaceship();
        createFallingObject(timestamp);
        updateObjectPositions();
        checkCollisions();
    }

    render();
}

// ── Bootstrap ──────────────────────────────────────────
init();
```

---

*Stage 1 source archived here. See `MD.plan2.md` for Stage 2 (Visual Vibe) source.*
