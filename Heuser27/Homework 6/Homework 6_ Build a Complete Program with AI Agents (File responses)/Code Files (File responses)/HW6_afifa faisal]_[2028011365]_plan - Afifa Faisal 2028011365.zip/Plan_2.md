# MD.plan2 – Galaxy Catcher (Stage 2 – Visual Vibe) – Full Source

> **Architect model:** Claude Sonnet 4.6 (Thinking)
> **Builder model:** Claude Sonnet 4.6 (Thinking)
> **Project folder:** `c:\Users\abdul\Downloads\catch game`

## Stage 2 – What changed from Stage 1
| Area | Change |
|---|---|
| `style.css` | Flex-centred layout, `aspect-ratio: 2/3`, outer nebula `box-shadow` |
| `script.js` | Offscreen nebula backdrop (prerendered once), 210 twinkling bg-stars, purple/cyan spaceship with animated engine flame, 5-point golden collectible star with pulsing sparkle lines, rotating dark asteroid with glowing orange cracks, neon HUD, glowing rounded buttons on all screens |
| `index.html` | Unchanged from Stage 1 |
| Game logic | **Identical to Stage 1** – no rules, collision or scoring code altered |

---

## `index.html`
```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Galaxy Catcher</title>
    <link rel="stylesheet" href="style.css" />
</head>
<body>
    <canvas id="gameCanvas"></canvas>
    <script src="script.js"></script>
</body>
</html>
```

---

## `style.css`
```css
/* style.css – Galaxy Catcher (Stage 2 – Visual Vibe) */

html, body {
    margin: 0;
    padding: 0;
    width: 100%;
    height: 100%;
    overflow: hidden;
    background: #05010f;          /* deep space colour behind the canvas */
    display: flex;
    align-items: center;
    justify-content: center;
}

canvas {
    display: block;
    /* maintain 2:3 (480×720) ratio at any viewport size */
    aspect-ratio: 2 / 3;
    max-width: 100vw;
    max-height: 100vh;
    /* outer glow to frame the game area */
    box-shadow:
        0 0  60px rgba(130,  0, 255, 0.45),
        0 0 120px rgba(  0, 80, 255, 0.18);
}
```

---

## `script.js`
```javascript
// script.js – Galaxy Catcher (Stage 2 – Visual Vibe)
// Architect model : Claude Sonnet 4.6 (Thinking)
// Builder  model  : Claude Sonnet 4.6 (Thinking)
// -------------------------------------------------------
// Stage 2 adds full galaxy visuals.
// All game-logic functions are identical to Stage 1.
// Only rendering and visual-init code has been added/changed.
// -------------------------------------------------------

// ── Canvas / logical dimensions ────────────────────────
const CANVAS_W = 480;
const CANVAS_H = 720;

// ── Spaceship configuration ────────────────────────────
const SHIP_W     = 60;
const SHIP_H     = 40;
const SHIP_Y     = CANVAS_H - 70;
const SHIP_SPEED = 7;

// ── Falling-object configuration ──────────────────────
const OBJ_W               = 24;    // hitbox – unchanged from Stage 1
const OBJ_H               = 24;
const INITIAL_FALL_SPEED  = 2;
const MAX_FALL_SPEED      = 9;
const SPEED_INCREMENT     = 0.4;
const SPEED_STEP_SCORE    = 30;
const SPAWN_INTERVAL_BASE = 900;
const SPAWN_INTERVAL_MIN  = 350;
const MAX_LIVES           = 3;
const ASTEROID_CHANCE     = 0.30;
const POINTS_PER_STAR     = 10;

// ── Game-state machine ─────────────────────────────────
let state = "menu";

// ── Mutable game data ──────────────────────────────────
let score         = 0;
let lives         = MAX_LIVES;
let fallSpeed     = INITIAL_FALL_SPEED;
let lastSpawnTime = 0;
let objects       = [];
let ship          = { x: (CANVAS_W - SHIP_W) / 2, y: SHIP_Y, w: SHIP_W, h: SHIP_H };
let keysDown      = new Set();
let highScore     = 0;
let flash         = { type: null, until: 0 };

// ── Visual globals (Stage 2) ───────────────────────────
let animTime = 0;       // frame counter – drives every animation
let bgStars  = [];      // decorative twinkling background stars
let offBg    = null;    // offscreen canvas for the static nebula backdrop

// ── Canvas setup ───────────────────────────────────────
const canvas = document.getElementById("gameCanvas");
const ctx    = canvas.getContext("2d");
canvas.width  = CANVAS_W;
canvas.height = CANVAS_H;

// ═══════════════════════════════════════════════════════
// UTILITY FUNCTIONS  (unchanged from Stage 1)
// ═══════════════════════════════════════════════════════

/** Returns a random integer in [min, max). */
function randInt(min, max) {
    return Math.floor(Math.random() * (max - min)) + min;
}

/** AABB rectangle collision test. Both objects need {x,y,w,h}. */
function collides(a, b) {
    return a.x < b.x + b.w &&
           a.x + a.w > b.x &&
           a.y < b.y + b.h &&
           a.y + a.h > b.y;
}

/** Current spawn interval – shrinks as score rises. */
function getSpawnInterval() {
    return Math.max(SPAWN_INTERVAL_MIN, SPAWN_INTERVAL_BASE - score * 4);
}

/** Current fall speed computed from score. */
function computeFallSpeed() {
    const steps = Math.floor(score / SPEED_STEP_SCORE);
    return Math.min(MAX_FALL_SPEED, INITIAL_FALL_SPEED + steps * SPEED_INCREMENT);
}

function saveHighScore() {
    try { localStorage.setItem("galaxyCatcherHighScore", String(highScore)); }
    catch (_) { /* ignore storage errors */ }
}

function loadHighScore() {
    try {
        const v = localStorage.getItem("galaxyCatcherHighScore");
        if (v !== null) highScore = parseInt(v, 10) || 0;
    } catch (_) { highScore = 0; }
}

// ── Visual drawing helpers (Stage 2) ──────────────────

/**
 * Build a rounded-rectangle path (call fill/stroke after).
 */
function roundRect(x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + w - r, y);
    ctx.quadraticCurveTo(x + w, y,     x + w, y + r);
    ctx.lineTo(x + w, y + h - r);
    ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    ctx.lineTo(x + r, y + h);
    ctx.quadraticCurveTo(x,     y + h, x, y + h - r);
    ctx.lineTo(x, y + r);
    ctx.quadraticCurveTo(x, y,         x + r, y);
    ctx.closePath();
}

/**
 * Build a 5-point star path centred at (cx, cy).
 */
function starPath(cx, cy, outerR, innerR) {
    ctx.beginPath();
    for (let i = 0; i < 10; i++) {
        const r     = i % 2 === 0 ? outerR : innerR;
        const angle = (i * Math.PI) / 5 - Math.PI / 2;
        const px    = cx + Math.cos(angle) * r;
        const py    = cy + Math.sin(angle) * r;
        i === 0 ? ctx.moveTo(px, py) : ctx.lineTo(px, py);
    }
    ctx.closePath();
}

/**
 * Draw a glowing, labelled rounded button.
 */
function drawGlowButton(label, cx, cy, bw, bh, fill, glowColor) {
    const bx = cx - bw / 2;
    const by = cy - bh / 2;
    ctx.save();

    ctx.shadowColor = glowColor;
    ctx.shadowBlur  = 22;
    ctx.strokeStyle = glowColor;
    ctx.lineWidth   = 1.5;
    roundRect(bx, by, bw, bh, 12);
    ctx.stroke();

    ctx.shadowBlur = 10;
    ctx.fillStyle  = fill;
    roundRect(bx, by, bw, bh, 12);
    ctx.fill();

    ctx.shadowColor  = "#ffffff";
    ctx.shadowBlur   = 8;
    ctx.fillStyle    = "#ffffff";
    ctx.font         = 'bold 17px "Courier New", monospace';
    ctx.textAlign    = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(label, cx, cy + 1);

    ctx.restore();
}

// ═══════════════════════════════════════════════════════
// GAME LIFECYCLE FUNCTIONS  (unchanged from Stage 1)
// ═══════════════════════════════════════════════════════

function init() {
    window.addEventListener("keydown", onKeyDown);
    window.addEventListener("keyup",   onKeyUp);
    loadHighScore();
    initVisuals();
    requestAnimationFrame(gameLoop);
}

function resetGame() {
    score     = 0;
    lives     = MAX_LIVES;
    fallSpeed = INITIAL_FALL_SPEED;
    objects   = [];
    ship.x    = (CANVAS_W - SHIP_W) / 2;
    keysDown.clear();
    flash     = { type: null, until: 0 };
    state     = "menu";
}

function startGame() {
    state         = "playing";
    lastSpawnTime = performance.now();
}

function restartGame() {
    resetGame();
    startGame();
}

function endGame() {
    state = "gameover";
    if (score > highScore) {
        highScore = score;
        saveHighScore();
    }
}

function togglePause() {
    if (state === "playing") {
        state = "paused";
    } else if (state === "paused") {
        state         = "playing";
        lastSpawnTime = performance.now();
    }
}

// ═══════════════════════════════════════════════════════
// INPUT HANDLING  (unchanged from Stage 1)
// ═══════════════════════════════════════════════════════

function onKeyDown(e) {
    keysDown.add(e.key);

    switch (state) {
        case "menu":
            if (e.key === "Enter" || e.key === " ") {
                startGame();
                e.preventDefault();
            }
            break;
        case "playing":
            if (e.key === "p" || e.key === "P" || e.key === "Escape") {
                togglePause();
                e.preventDefault();
            }
            break;
        case "paused":
            if (e.key === "p" || e.key === "P" || e.key === "Escape") {
                togglePause();
                e.preventDefault();
            }
            break;
        case "gameover":
            if (e.key === "Enter" || e.key === " " || e.key === "r" || e.key === "R") {
                restartGame();
                e.preventDefault();
            }
            break;
    }
}

function onKeyUp(e) {
    keysDown.delete(e.key);
}

function moveSpaceship() {
    if (keysDown.has("ArrowLeft"))  ship.x -= SHIP_SPEED;
    if (keysDown.has("ArrowRight")) ship.x += SHIP_SPEED;
    if (ship.x < 0)                ship.x = 0;
    if (ship.x + SHIP_W > CANVAS_W) ship.x = CANVAS_W - SHIP_W;
}

// ═══════════════════════════════════════════════════════
// FALLING OBJECTS – CREATION & UPDATE
// (game logic unchanged; visual properties added for Stage 2)
// ═══════════════════════════════════════════════════════

function createFallingObject(now) {
    if (now - lastSpawnTime < getSpawnInterval()) return;
    lastSpawnTime = now;

    const isAsteroid = Math.random() < ASTEROID_CHANCE;
    const x          = randInt(0, CANVAS_W - OBJ_W);

    const obj = {
        x,
        y:    -OBJ_H,
        w:    OBJ_W,
        h:    OBJ_H,
        type: isAsteroid ? "asteroid" : "star",
        hit:  false,
    };

    if (isAsteroid) {
        const numVerts = 7 + randInt(0, 4);
        obj.vertices   = [];
        for (let i = 0; i < numVerts; i++) {
            obj.vertices.push({
                angle:  (i / numVerts) * Math.PI * 2,
                radius: 0.60 + Math.random() * 0.40,
            });
        }
        const numCracks = 2 + randInt(0, 2);
        obj.cracks      = [];
        for (let i = 0; i < numCracks; i++) {
            const a   = Math.random() * Math.PI * 2;
            const len = 3 + Math.random() * 5;
            obj.cracks.push([
                { x: Math.cos(a) * 1.5, y: Math.sin(a) * 1.5 },
                { x: Math.cos(a) * len, y: Math.sin(a) * len  },
            ]);
        }
        obj.rotSpeed  = (Math.random() - 0.5) * 0.045;
        obj.rotOffset = Math.random() * Math.PI * 2;
    } else {
        obj.phase = Math.random() * Math.PI * 2;
    }

    objects.push(obj);
}

function updateObjectPositions() {
    for (let i = objects.length - 1; i >= 0; i--) {
        objects[i].y += fallSpeed;
        if (objects[i].y > CANVAS_H) {
            objects.splice(i, 1);
        }
    }
}

// ═══════════════════════════════════════════════════════
// COLLISION DETECTION  (unchanged from Stage 1)
// ═══════════════════════════════════════════════════════

function checkCollisions() {
    for (let i = objects.length - 1; i >= 0; i--) {
        const obj = objects[i];
        if (obj.hit)              continue;
        if (!collides(obj, ship)) continue;

        obj.hit = true;
        if (obj.type === "star") {
            updateScore(POINTS_PER_STAR);
            triggerFlash("star");
        } else {
            loseLife();
            triggerFlash("asteroid");
        }
        objects.splice(i, 1);
    }
}

// ═══════════════════════════════════════════════════════
// SCORE & LIVES  (unchanged from Stage 1)
// ═══════════════════════════════════════════════════════

function updateScore(points) {
    score     += points;
    fallSpeed  = computeFallSpeed();
}

function loseLife() {
    lives -= 1;
    if (lives <= 0) {
        lives = 0;
        endGame();
    }
}

// ═══════════════════════════════════════════════════════
// VISUAL FLASH FEEDBACK  (unchanged from Stage 1)
// ═══════════════════════════════════════════════════════

function triggerFlash(type) {
    flash.type  = type;
    flash.until = performance.now() + 130;
}

// ═══════════════════════════════════════════════════════
// VISUAL INITIALISATION  (Stage 2)
// ═══════════════════════════════════════════════════════

function initVisuals() {
    const starColors = ["#ffffff", "#b4d8ff", "#d8b4ff", "#ffb4d8", "#80ffff", "#ffffe0"];
    bgStars = [];
    for (let i = 0; i < 210; i++) {
        bgStars.push({
            x:     Math.random() * CANVAS_W,
            y:     Math.random() * CANVAS_H,
            r:     Math.random() * 1.5 + 0.25,
            color: starColors[randInt(0, starColors.length)],
            phase: Math.random() * Math.PI * 2,
            speed: Math.random() * 0.025 + 0.007,
        });
    }

    offBg        = document.createElement("canvas");
    offBg.width  = CANVAS_W;
    offBg.height = CANVAS_H;
    const octx   = offBg.getContext("2d");

    const base = octx.createLinearGradient(0, 0, CANVAS_W * 0.5, CANVAS_H);
    base.addColorStop(0,    "#0e0030");
    base.addColorStop(0.3,  "#080040");
    base.addColorStop(0.65, "#0a0025");
    base.addColorStop(1,    "#050015");
    octx.fillStyle = base;
    octx.fillRect(0, 0, CANVAS_W, CANVAS_H);

    const nebulas = [
        { x:  50, y:  90, r: 220, c0: "rgba( 90,  0,170,0.42)", c1: "rgba(45,0,100,0.10)" },
        { x: 400, y: 190, r: 185, c0: "rgba(  0, 50,190,0.38)", c1: "rgba( 0,25,100,0.08)" },
        { x: 180, y: 370, r: 240, c0: "rgba( 85,  0,130,0.32)", c1: "rgba(45,0, 80,0.06)" },
        { x: 430, y: 460, r: 165, c0: "rgba(  0, 75,165,0.30)", c1: "rgba( 0,35, 85,0.06)" },
        { x:  90, y: 575, r: 185, c0: "rgba(140,  0, 90,0.26)", c1: "rgba(65,0, 45,0.05)" },
        { x: 310, y: 650, r: 145, c0: "rgba( 65,  0,150,0.30)", c1: "rgba(30,0, 80,0.06)" },
        { x: 240, y: 210, r: 120, c0: "rgba(  0, 90,110,0.22)", c1: "rgba( 0,45, 60,0.05)" },
        { x: 350, y: 340, r: 100, c0: "rgba(160,  0,100,0.18)", c1: "rgba(70,0, 50,0.04)" },
    ];
    for (const n of nebulas) {
        const g = octx.createRadialGradient(n.x, n.y, 0, n.x, n.y, n.r);
        g.addColorStop(0,    n.c0);
        g.addColorStop(0.55, n.c1);
        g.addColorStop(1,    "rgba(0,0,0,0)");
        octx.fillStyle = g;
        octx.fillRect(0, 0, CANVAS_W, CANVAS_H);
    }

    const accents = [
        { x: 390, y: 110, r:  65, c: "rgba(  0,190,255,0.14)" },
        { x: 100, y: 440, r:  85, c: "rgba(210,  0,255,0.11)" },
        { x: 265, y: 585, r:  55, c: "rgba(255,  0,185,0.09)" },
        { x: 450, y: 610, r:  70, c: "rgba(  0,130,255,0.11)" },
        { x: 165, y: 170, r:  50, c: "rgba(255,100,255,0.08)" },
    ];
    for (const a of accents) {
        const g = octx.createRadialGradient(a.x, a.y, 0, a.x, a.y, a.r);
        g.addColorStop(0, a.c);
        g.addColorStop(1, "rgba(0,0,0,0)");
        octx.fillStyle = g;
        octx.fillRect(0, 0, CANVAS_W, CANVAS_H);
    }
}

// ═══════════════════════════════════════════════════════
// RENDERING  (Stage 2 – fully visual)
// ═══════════════════════════════════════════════════════

function drawBackground() {
    ctx.drawImage(offBg, 0, 0);
}

function drawBackgroundStars() {
    ctx.save();
    for (const s of bgStars) {
        const alpha = 0.35 + 0.65 * Math.abs(Math.sin(animTime * s.speed + s.phase));
        ctx.globalAlpha = alpha;
        ctx.fillStyle   = s.color;
        ctx.shadowColor = s.color;
        ctx.shadowBlur  = s.r > 1.0 ? 5 : 1;
        ctx.beginPath();
        ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
        ctx.fill();
    }
    ctx.restore();
}

function drawSpaceship() {
    const { x, y, w, h } = ship;
    const cx = x + w / 2;
    ctx.save();

    const flameLen = 8 + 5 * Math.abs(Math.sin(animTime * 0.18));
    const flameMid = y + h + flameLen * 0.5;
    const flameG   = ctx.createRadialGradient(cx, y + h, 0, cx, flameMid, flameLen + 6);
    flameG.addColorStop(0,    "rgba(200,245,255,1.0)");
    flameG.addColorStop(0.25, "rgba(  0,200,255,0.85)");
    flameG.addColorStop(0.65, "rgba( 80,  0,220,0.45)");
    flameG.addColorStop(1,    "rgba(  0,  0,  0,0.0)");
    ctx.fillStyle = flameG;
    ctx.beginPath();
    ctx.ellipse(cx, y + h + flameLen * 0.5, w * 0.14, flameLen, 0, 0, Math.PI * 2);
    ctx.fill();

    ctx.shadowColor = "#00e5ff";
    ctx.shadowBlur  = 18;

    ctx.fillStyle = "#5010a8";
    ctx.beginPath();
    ctx.moveTo(x + w * 0.35, y + h * 0.60);
    ctx.lineTo(x,             y + h * 0.98);
    ctx.lineTo(x + w * 0.18, y + h * 0.78);
    ctx.closePath();
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(x + w * 0.65, y + h * 0.60);
    ctx.lineTo(x + w,         y + h * 0.98);
    ctx.lineTo(x + w * 0.82, y + h * 0.78);
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = "#7828d0";
    ctx.beginPath();
    ctx.moveTo(cx,            y);
    ctx.lineTo(x + w * 0.15, y + h * 0.75);
    ctx.lineTo(x + w * 0.35, y + h * 0.60);
    ctx.lineTo(x + w * 0.65, y + h * 0.60);
    ctx.lineTo(x + w * 0.85, y + h * 0.75);
    ctx.closePath();
    ctx.fill();

    ctx.shadowColor = "#00ffff";
    ctx.shadowBlur  = 12;
    ctx.fillStyle   = "#00e8ff";
    ctx.beginPath();
    ctx.moveTo(cx,             y + h * 0.08);
    ctx.lineTo(cx - w * 0.10, y + h * 0.44);
    ctx.lineTo(cx + w * 0.10, y + h * 0.44);
    ctx.closePath();
    ctx.fill();

    ctx.strokeStyle = "#b060ff";
    ctx.lineWidth   = 1.2;
    ctx.shadowColor = "#c080ff";
    ctx.shadowBlur  = 7;
    ctx.beginPath();
    ctx.moveTo(cx - w * 0.20, y + h * 0.56);
    ctx.lineTo(cx + w * 0.20, y + h * 0.56);
    ctx.stroke();

    ctx.restore();
}

function drawCollectibleStar(obj) {
    const cx     = obj.x + OBJ_W / 2;
    const cy     = obj.y + OBJ_H / 2;
    const outerR = OBJ_W / 2 + 2;
    const innerR = OBJ_W / 4.8;
    const pulse  = 0.88 + 0.12 * Math.sin(animTime * 0.10 + obj.phase);

    ctx.save();
    ctx.translate(cx, cy);
    ctx.scale(pulse, pulse);

    const aura = ctx.createRadialGradient(0, 0, innerR, 0, 0, outerR + 10);
    aura.addColorStop(0, "rgba(255,220,  0,0.40)");
    aura.addColorStop(1, "rgba(255,160,  0,0.00)");
    ctx.fillStyle = aura;
    starPath(0, 0, outerR + 10, innerR + 5);
    ctx.fill();

    ctx.shadowColor = "#ffe800";
    ctx.shadowBlur  = 16;

    const grad = ctx.createRadialGradient(0, -innerR * 0.5, 0, 0, 0, outerR);
    grad.addColorStop(0,   "#fff8c0");
    grad.addColorStop(0.4, "#ffe94a");
    grad.addColorStop(1,   "#ff9500");
    ctx.fillStyle = grad;
    starPath(0, 0, outerR, innerR);
    ctx.fill();

    ctx.fillStyle  = "rgba(255,255,255,0.55)";
    ctx.shadowBlur = 2;
    ctx.beginPath();
    ctx.arc(0, -outerR * 0.32, outerR * 0.22, 0, Math.PI * 2);
    ctx.fill();

    const sparkLen  = outerR + 7 + 3 * Math.sin(animTime * 0.12 + obj.phase);
    ctx.strokeStyle = "rgba(255,255,190,0.75)";
    ctx.lineWidth   = 0.9;
    ctx.shadowColor = "#ffffff";
    ctx.shadowBlur  = 5;
    for (let i = 0; i < 4; i++) {
        const a = (i / 4) * Math.PI + animTime * 0.016;
        ctx.beginPath();
        ctx.moveTo(Math.cos(a) * (outerR + 1), Math.sin(a) * (outerR + 1));
        ctx.lineTo(Math.cos(a) * sparkLen,      Math.sin(a) * sparkLen);
        ctx.stroke();
    }

    ctx.restore();
}

function drawAsteroid(obj) {
    const cx    = obj.x + OBJ_W / 2;
    const cy    = obj.y + OBJ_H / 2;
    const r     = OBJ_W / 2;
    const angle = obj.rotOffset + animTime * obj.rotSpeed;

    ctx.save();
    ctx.translate(cx, cy);
    ctx.rotate(angle);

    ctx.shadowColor = "rgba(255,80,0,0.75)";
    ctx.shadowBlur  = 12;

    const grad = ctx.createRadialGradient(-r * 0.25, -r * 0.25, 0, 0, 0, r);
    grad.addColorStop(0,   "#7a4870");
    grad.addColorStop(0.5, "#3c2050");
    grad.addColorStop(1,   "#180e28");
    ctx.fillStyle = grad;

    ctx.beginPath();
    const verts = obj.vertices;
    for (let i = 0; i < verts.length; i++) {
        const v  = verts[i];
        const px = Math.cos(v.angle) * r * v.radius;
        const py = Math.sin(v.angle) * r * v.radius;
        i === 0 ? ctx.moveTo(px, py) : ctx.lineTo(px, py);
    }
    ctx.closePath();
    ctx.fill();

    ctx.strokeStyle = "rgba(255,120,0,0.90)";
    ctx.lineWidth   = 1.1;
    ctx.shadowColor = "#ff4400";
    ctx.shadowBlur  = 7;
    for (const crack of obj.cracks) {
        ctx.beginPath();
        ctx.moveTo(crack[0].x, crack[0].y);
        ctx.lineTo(crack[1].x, crack[1].y);
        ctx.stroke();
    }

    ctx.restore();
}

function drawFallingObjects() {
    for (const obj of objects) {
        if (obj.type === "star") {
            drawCollectibleStar(obj);
        } else {
            drawAsteroid(obj);
        }
    }
}

function drawHUD() {
    ctx.save();
    ctx.font         = 'bold 17px "Courier New", monospace';
    ctx.textBaseline = "top";

    ctx.shadowColor = "#00e5ff";
    ctx.shadowBlur  = 12;
    ctx.fillStyle   = "#a8f4ff";
    ctx.textAlign   = "left";
    ctx.fillText(`SCORE  ${score}`, 12, 12);

    ctx.shadowColor = "#ff4466";
    ctx.shadowBlur  = 12;
    ctx.fillStyle   = "#ff6688";
    ctx.textAlign   = "right";
    const hearts = ("♥  ").repeat(lives).trimEnd();
    ctx.fillText(hearts, CANVAS_W - 12, 12);

    ctx.restore();
}

function drawFlash() {
    if (!flash.type || performance.now() > flash.until) {
        flash.type = null;
        return;
    }
    ctx.fillStyle = flash.type === "star"
        ? "rgba(255,240,80,0.18)"
        : "rgba(255,50,50,0.28)";
    ctx.fillRect(0, 0, CANVAS_W, CANVAS_H);
}

function drawMenu() {
    drawBackground();
    drawBackgroundStars();

    ctx.save();
    ctx.textAlign = "center";

    ctx.font        = 'bold 46px "Courier New", monospace';
    ctx.shadowColor = "#c060ff";
    ctx.shadowBlur  = 28;
    ctx.fillStyle   = "#e0a8ff";
    ctx.fillText("GALAXY", CANVAS_W / 2, CANVAS_H / 4 - 14);

    ctx.fillStyle   = "#ffe94a";
    ctx.shadowColor = "#ffaa00";
    ctx.shadowBlur  = 24;
    ctx.fillText("CATCHER", CANVAS_W / 2, CANVAS_H / 4 + 42);

    ctx.font        = '13px "Courier New", monospace';
    ctx.shadowColor = "#00e5ff";
    ctx.shadowBlur  = 7;
    ctx.fillStyle   = "#80d8ff";
    ctx.fillText("Catch falling stars.  Avoid asteroids.", CANVAS_W / 2, CANVAS_H / 4 + 90);
    ctx.fillText("←  →   Arrow keys to move",             CANVAS_W / 2, CANVAS_H / 4 + 112);
    ctx.fillText("P  or  Esc   →   Pause",                CANVAS_W / 2, CANVAS_H / 4 + 132);
    ctx.restore();

    drawGlowButton("▶   START GAME", CANVAS_W / 2, CANVAS_H / 2 + 32, 224, 50,
                   "rgba(70,0,150,0.88)", "#c060ff");

    ctx.save();
    ctx.textAlign = "center";
    ctx.font      = '12px "Courier New", monospace';
    ctx.fillStyle = "#504868";
    ctx.fillText("or press Enter / Space", CANVAS_W / 2, CANVAS_H / 2 + 74);
    ctx.restore();

    if (highScore > 0) {
        ctx.save();
        ctx.textAlign   = "center";
        ctx.font        = 'bold 15px "Courier New", monospace';
        ctx.shadowColor = "#00ff88";
        ctx.shadowBlur  = 10;
        ctx.fillStyle   = "#80ffb8";
        ctx.fillText(`BEST  ${highScore}`, CANVAS_W / 2, CANVAS_H / 2 + 102);
        ctx.restore();
    }
}

function drawPaused() {
    drawBackground();
    drawBackgroundStars();
    drawFallingObjects();
    drawSpaceship();
    drawHUD();

    ctx.fillStyle = "rgba(0,0,20,0.62)";
    ctx.fillRect(0, 0, CANVAS_W, CANVAS_H);

    ctx.save();
    ctx.textAlign   = "center";
    ctx.font        = 'bold 46px "Courier New", monospace';
    ctx.shadowColor = "#ffe94a";
    ctx.shadowBlur  = 24;
    ctx.fillStyle   = "#ffe94a";
    ctx.fillText("PAUSED", CANVAS_W / 2, CANVAS_H / 2 - 24);
    ctx.restore();

    drawGlowButton("▶   RESUME", CANVAS_W / 2, CANVAS_H / 2 + 36, 200, 48,
                   "rgba(0,55,120,0.90)", "#00e5ff");

    ctx.save();
    ctx.textAlign = "center";
    ctx.font      = '12px "Courier New", monospace';
    ctx.fillStyle = "#504868";
    ctx.fillText("or press P / Esc", CANVAS_W / 2, CANVAS_H / 2 + 74);
    ctx.restore();
}

function drawGameOver() {
    drawBackground();
    drawBackgroundStars();

    ctx.save();
    ctx.textAlign   = "center";
    ctx.font        = 'bold 46px "Courier New", monospace';
    ctx.shadowColor = "#ff3344";
    ctx.shadowBlur  = 28;
    ctx.fillStyle   = "#ff5566";
    ctx.fillText("GAME OVER", CANVAS_W / 2, CANVAS_H / 4);

    ctx.font        = 'bold 22px "Courier New", monospace';
    ctx.shadowColor = "#00e5ff";
    ctx.shadowBlur  = 12;
    ctx.fillStyle   = "#a8f4ff";
    ctx.fillText(`SCORE  ${score}`, CANVAS_W / 2, CANVAS_H / 4 + 62);
    ctx.restore();

    if (highScore > 0) {
        ctx.save();
        ctx.textAlign   = "center";
        ctx.font        = 'bold 16px "Courier New", monospace';
        ctx.shadowColor = "#00ff88";
        ctx.shadowBlur  = 10;
        ctx.fillStyle   = "#80ffb8";
        ctx.fillText(`BEST  ${highScore}`, CANVAS_W / 2, CANVAS_H / 4 + 96);
        ctx.restore();
    }

    drawGlowButton("↺   RESTART", CANVAS_W / 2, CANVAS_H / 2 + 20, 200, 50,
                   "rgba(100,0,55,0.90)", "#ff4488");

    ctx.save();
    ctx.textAlign = "center";
    ctx.font      = '12px "Courier New", monospace';
    ctx.fillStyle = "#504868";
    ctx.fillText("or press Enter / R", CANVAS_W / 2, CANVAS_H / 2 + 60);
    ctx.restore();
}

function drawPlaying() {
    drawBackground();
    drawBackgroundStars();
    drawFallingObjects();
    drawSpaceship();
    drawHUD();
    drawFlash();
}

function render() {
    switch (state) {
        case "menu":     drawMenu();     break;
        case "playing":  drawPlaying();  break;
        case "paused":   drawPaused();   break;
        case "gameover": drawGameOver(); break;
    }
}

// ═══════════════════════════════════════════════════════
// MAIN GAME LOOP
// ═══════════════════════════════════════════════════════

function gameLoop(timestamp) {
    requestAnimationFrame(gameLoop);
    animTime++;   // always increment – drives stars, engine, sparkles, rotation

    if (state === "playing") {
        moveSpaceship();
        createFallingObject(timestamp);
        updateObjectPositions();
        checkCollisions();
    }

    render();
}

// ── Bootstrap ──────────────────────────────────────────
init();
```

---

*Stage 2 source archived here. See `MD.plan1.md` for Stage 1 (Core Logic) source.*
