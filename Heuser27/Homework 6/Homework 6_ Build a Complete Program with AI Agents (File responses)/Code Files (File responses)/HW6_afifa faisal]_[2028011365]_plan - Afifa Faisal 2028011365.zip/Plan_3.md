# MD.plan3 – Galaxy Catcher (Stage 3 – Sensory Feedback) – Full Source

> **Architect model:** Gemini 3.8 Flash  
> **Builder model:** Claude Sonnet 4.6 (Thinking)  
> **Project folder:** `c:\Users\abdul\Downloads\catch game`

## Stage 3 – Sensory Feedback Implementation Summary
| Feature | Details |
|---|---|
| **Web Audio API Synth** | Procedural space sound effects: 3-tone arpeggio on crystal catch, low sawtooth downsweep + noise crash on asteroid impact, resonant warp sound on start, soft chime on pause/resume, descending minor tones on game over. Zero external audio assets. |
| **Particle Explosions** | 18 multi-color radial sparkle particles upon collecting stars; 24 fiery rock shards + expanding shockwave ring on asteroid collisions. |
| **Screen Shake** | Realistic decay-based canvas camera shake on asteroid hit and game over. |
| **Engine Ion Trail** | Continuous cyan/violet dual-particle exhaust stream from spaceship thrusters. |
| **Spaceship Banking** | Smooth roll tilt when steering with left/right arrows, automatically leveling when keys are released. |
| **Score Animations** | Animated floating `+10` popup at collection point + bouncing HUD score pulse. |
| **Danger Warnings** | Pulsing red critical aura around remaining lives when on the last life. |
| **Button Feedback** | Mouse hover scaling (+5%), click press depression (-5%), increased neon glow blur, and audio activation. |
| **Core Integrity** | Rules, speeds, hitboxes, and game mechanics strictly preserved from Stages 1 & 2. |

---

## `index.html`
```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Galaxy Catcher</title>
    <link rel="stylesheet" href="style.css" />
</head>
<body>
    <canvas id="gameCanvas"></canvas>
    <script src="script.js"></script>
</body>
</html>
```

---

## `style.css`
```css
/* style.css – Galaxy Catcher (Stage 3 – Sensory Feedback) */

html, body {
    margin: 0;
    padding: 0;
    width: 100%;
    height: 100%;
    overflow: hidden;
    background: #05010f;          /* deep space colour behind canvas */
    display: flex;
    align-items: center;
    justify-content: center;
    user-select: none;
    -webkit-user-select: none;
    touch-action: none;
}

canvas {
    display: block;
    /* maintain 2:3 ratio */
    aspect-ratio: 2 / 3;
    max-width: 100vw;
    max-height: 100vh;
    cursor: pointer;
    box-shadow:
        0 0  60px rgba(130,  0, 255, 0.45),
        0 0 120px rgba(  0, 80, 255, 0.18);
}
```

---

## `script.js`
```javascript
// script.js – Galaxy Catcher (Stage 3 – Sensory Feedback)
// Architect model : Gemini 3.8 Flash
// Builder  model  : Claude Sonnet 4.6 (Thinking)
// -------------------------------------------------------
// Stage 3 adds procedural Web Audio, particle systems,
// screen shake, engine trails, floating scores, ship banking,
// and interactive button hover/press states.
// All core rules and collision formulas remain identical.
// -------------------------------------------------------

// ── Canvas / logical dimensions ────────────────────────
const CANVAS_W = 480;
const CANVAS_H = 720;

// ── Spaceship configuration ────────────────────────────
const SHIP_W     = 60;
const SHIP_H     = 40;
const SHIP_Y     = CANVAS_H - 70;
const SHIP_SPEED = 7;

// ── Falling-object configuration ──────────────────────
const OBJ_W               = 24;    // hitbox identical to Stages 1 & 2
const OBJ_H               = 24;
const INITIAL_FALL_SPEED  = 2;
const MAX_FALL_SPEED      = 9;
const SPEED_INCREMENT     = 0.4;
const SPEED_STEP_SCORE    = 30;
const SPAWN_INTERVAL_BASE = 900;
const SPAWN_INTERVAL_MIN  = 350;
const MAX_LIVES           = 3;
const ASTEROID_CHANCE     = 0.30;
const POINTS_PER_STAR     = 10;

// ── Game-state machine ─────────────────────────────────
let state = "menu";

// ── Mutable game data ──────────────────────────────────
let score         = 0;
let lives         = MAX_LIVES;
let fallSpeed     = INITIAL_FALL_SPEED;
let lastSpawnTime = 0;
let objects       = [];
let ship          = { x: (CANVAS_W - SHIP_W) / 2, y: SHIP_Y, w: SHIP_W, h: SHIP_H };
let keysDown      = new Set();
let highScore     = 0;
let flash         = { type: null, until: 0 };

// ── Visual globals (Stage 2 & 3) ───────────────────────
let animTime = 0;       // frame counter
let bgStars  = [];      // decorative background stars
let offBg    = null;    // pre-rendered nebula canvas

// ── Sensory Feedback Systems (Stage 3) ────────────────
let particles     = [];    // star bursts, asteroid debris, smoke
let engineTrails  = [];    // ship thruster ion trail
let floatTexts    = [];    // floating "+10" indicators
let shockwaves    = [];    // radial impact rings on hit
let shakeTime     = 0;     // frames of screen shake remaining
let shakePower    = 0;     // current pixel amplitude
let shipTilt      = 0;     // ship roll angle (-0.08 to +0.08 rad)
let scoreScale    = 1.0;   // HUD score bump pulse

// ── Pointer & Button State ─────────────────────────────
let pointerPos    = { x: -1000, y: -1000 };
let isPointerDown = false;
let hoveredButton = null;

// ── Web Audio Synth System ─────────────────────────────
let audioCtx = null;

function getAudioContext() {
    if (!audioCtx) {
        const AudioClass = window.AudioContext || window.webkitAudioContext;
        if (AudioClass) {
            audioCtx = new AudioClass();
        }
    }
    if (audioCtx && audioCtx.state === "suspended") {
        audioCtx.resume().catch(() => {});
    }
    return audioCtx;
}

// Sound generators
function playStarSound() {
    try {
        const ctxA = getAudioContext();
        if (!ctxA) return;
        const now = ctxA.currentTime;
        const freqs = [660, 880, 1320];
        freqs.forEach((f, idx) => {
            const osc = ctxA.createOscillator();
            const gain = ctxA.createGain();
            osc.type = "sine";
            osc.frequency.setValueAtTime(f, now + idx * 0.04);
            gain.gain.setValueAtTime(0.12, now + idx * 0.04);
            gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.04 + 0.16);
            osc.connect(gain);
            gain.connect(ctxA.destination);
            osc.start(now + idx * 0.04);
            osc.stop(now + idx * 0.04 + 0.17);
        });
    } catch (_) {}
}

function playHitSound() {
    try {
        const ctxA = getAudioContext();
        if (!ctxA) return;
        const now = ctxA.currentTime;

        // Low pitch downsweep
        const osc = ctxA.createOscillator();
        const gain = ctxA.createGain();
        osc.type = "sawtooth";
        osc.frequency.setValueAtTime(140, now);
        osc.frequency.exponentialRampToValueAtTime(35, now + 0.28);
        gain.gain.setValueAtTime(0.25, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.30);
        osc.connect(gain);
        gain.connect(ctxA.destination);
        osc.start(now);
        osc.stop(now + 0.30);

        // White noise burst
        const bufferSize = ctxA.sampleRate * 0.18;
        const buffer = ctxA.createBuffer(1, bufferSize, ctxA.sampleRate);
        const data = buffer.getChannelData(0);
        for (let i = 0; i < bufferSize; i++) {
            data[i] = Math.random() * 2 - 1;
        }
        const noise = ctxA.createBufferSource();
        noise.buffer = buffer;
        const nGain = ctxA.createGain();
        nGain.gain.setValueAtTime(0.2, now);
        nGain.gain.exponentialRampToValueAtTime(0.001, now + 0.18);
        noise.connect(nGain);
        nGain.connect(ctxA.destination);
        noise.start(now);
    } catch (_) {}
}

function playStartSound() {
    try {
        const ctxA = getAudioContext();
        if (!ctxA) return;
        const now = ctxA.currentTime;
        const osc = ctxA.createOscillator();
        const gain = ctxA.createGain();
        osc.type = "triangle";
        osc.frequency.setValueAtTime(190, now);
        osc.frequency.exponentialRampToValueAtTime(540, now + 0.22);
        gain.gain.setValueAtTime(0.18, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);
        osc.connect(gain);
        gain.connect(ctxA.destination);
        osc.start(now);
        osc.stop(now + 0.25);
    } catch (_) {}
}

function playPauseSound(isResume) {
    try {
        const ctxA = getAudioContext();
        if (!ctxA) return;
        const now = ctxA.currentTime;
        const f1 = isResume ? 520 : 680;
        const f2 = isResume ? 780 : 460;
        [f1, f2].forEach((f, idx) => {
            const osc = ctxA.createOscillator();
            const gain = ctxA.createGain();
            osc.type = "sine";
            osc.frequency.setValueAtTime(f, now + idx * 0.07);
            gain.gain.setValueAtTime(0.12, now + idx * 0.07);
            gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.07 + 0.14);
            osc.connect(gain);
            gain.connect(ctxA.destination);
            osc.start(now + idx * 0.07);
            osc.stop(now + idx * 0.07 + 0.15);
        });
    } catch (_) {}
}

function playGameOverSound() {
    try {
        const ctxA = getAudioContext();
        if (!ctxA) return;
        const now = ctxA.currentTime;
        const notes = [440, 370, 293, 220];
        notes.forEach((f, idx) => {
            const osc = ctxA.createOscillator();
            const gain = ctxA.createGain();
            osc.type = "sawtooth";
            osc.frequency.setValueAtTime(f, now + idx * 0.13);
            gain.gain.setValueAtTime(0.15, now + idx * 0.13);
            gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.13 + 0.26);
            osc.connect(gain);
            gain.connect(ctxA.destination);
            osc.start(now + idx * 0.13);
            osc.stop(now + idx * 0.13 + 0.27);
        });
    } catch (_) {}
}

// ── Canvas setup ───────────────────────────────────────
const canvas = document.getElementById("gameCanvas");
const ctx    = canvas.getContext("2d");
canvas.width  = CANVAS_W;
canvas.height = CANVAS_H;

// ═══════════════════════════════════════════════════════
// UTILITY FUNCTIONS
// ═══════════════════════════════════════════════════════

function randInt(min, max) {
    return Math.floor(Math.random() * (max - min)) + min;
}

function collides(a, b) {
    return a.x < b.x + b.w &&
           a.x + a.w > b.x &&
           a.y < b.y + b.h &&
           a.y + a.h > b.y;
}

function getSpawnInterval() {
    return Math.max(SPAWN_INTERVAL_MIN, SPAWN_INTERVAL_BASE - score * 4);
}

function computeFallSpeed() {
    const steps = Math.floor(score / SPEED_STEP_SCORE);
    return Math.min(MAX_FALL_SPEED, INITIAL_FALL_SPEED + steps * SPEED_INCREMENT);
}

function saveHighScore() {
    try { localStorage.setItem("galaxyCatcherHighScore", String(highScore)); }
    catch (_) {}
}

function loadHighScore() {
    try {
        const v = localStorage.getItem("galaxyCatcherHighScore");
        if (v !== null) highScore = parseInt(v, 10) || 0;
    } catch (_) { highScore = 0; }
}

function roundRect(x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + w - r, y);
    ctx.quadraticCurveTo(x + w, y,     x + w, y + r);
    ctx.lineTo(x + w, y + h - r);
    ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    ctx.lineTo(x + r, y + h);
    ctx.quadraticCurveTo(x,     y + h, x, y + h - r);
    ctx.lineTo(x, y + r);
    ctx.quadraticCurveTo(x, y,         x + r, y);
    ctx.closePath();
}

function starPath(cx, cy, outerR, innerR) {
    ctx.beginPath();
    for (let i = 0; i < 10; i++) {
        const r     = i % 2 === 0 ? outerR : innerR;
        const angle = (i * Math.PI) / 5 - Math.PI / 2;
        const px    = cx + Math.cos(angle) * r;
        const py    = cy + Math.sin(angle) * r;
        i === 0 ? ctx.moveTo(px, py) : ctx.lineTo(px, py);
    }
    ctx.closePath();
}

function drawGlowButton(id, label, cx, cy, bw, bh, fill, glowColor) {
    const isHovered = hoveredButton === id;
    const isPressed = isHovered && isPointerDown;

    const scale = isPressed ? 0.95 : (isHovered ? 1.05 : 1.0);
    const glowBlur = isHovered ? 34 : 22;

    ctx.save();
    ctx.translate(cx, cy);
    ctx.scale(scale, scale);

    const bx = -bw / 2;
    const by = -bh / 2;

    // Outer neon glow
    ctx.shadowColor = glowColor;
    ctx.shadowBlur  = glowBlur;
    ctx.strokeStyle = glowColor;
    ctx.lineWidth   = isHovered ? 2.2 : 1.5;
    roundRect(bx, by, bw, bh, 12);
    ctx.stroke();

    // Body fill
    ctx.fillStyle = isHovered ? "rgba(120,40,210,0.92)" : fill;
    ctx.shadowBlur = 10;
    roundRect(bx, by, bw, bh, 12);
    ctx.fill();

    // Text label
    ctx.shadowColor  = "#ffffff";
    ctx.shadowBlur   = isHovered ? 12 : 8;
    ctx.fillStyle    = "#ffffff";
    ctx.font         = 'bold 17px "Courier New", monospace';
    ctx.textAlign    = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(label, 0, 1);

    ctx.restore();
}

function isInsideButton(px, py, cx, cy, bw, bh) {
    return px >= cx - bw / 2 && px <= cx + bw / 2 &&
           py >= cy - bh / 2 && py <= cy + bh / 2;
}

// ═══════════════════════════════════════════════════════
// SENSORY PARTICLE EMITTERS & UPDATES
// ═══════════════════════════════════════════════════════

function triggerScreenShake(power, frames) {
    shakePower = power;
    shakeTime  = frames;
}

function spawnStarExplosion(x, y) {
    const count = 18;
    const colors = ["#fff8c0", "#ffe94a", "#ffaa00", "#00e5ff", "#ffffff"];
    for (let i = 0; i < count; i++) {
        const angle = (i / count) * Math.PI * 2 + Math.random() * 0.4;
        const spd   = 2.2 + Math.random() * 4.2;
        particles.push({
            x,
            y,
            vx: Math.cos(angle) * spd,
            vy: Math.sin(angle) * spd,
            size: 2.2 + Math.random() * 2.8,
            color: colors[randInt(0, colors.length)],
            alpha: 1.0,
            decay: 0.024 + Math.random() * 0.020,
            sparkle: true,
        });
    }

    floatTexts.push({
        x: x + (Math.random() - 0.5) * 12,
        y: y - 8,
        vy: -1.4,
        alpha: 1.0,
        text: `+${POINTS_PER_STAR}`,
    });

    scoreScale = 1.35;
}

function spawnAsteroidImpact(x, y) {
    const count = 24;
    const colors = ["#ff4400", "#ff8800", "#7a4870", "#3c2050", "#ff2244"];
    for (let i = 0; i < count; i++) {
        const angle = Math.random() * Math.PI * 2;
        const spd   = 1.5 + Math.random() * 5.5;
        particles.push({
            x,
            y,
            vx: Math.cos(angle) * spd,
            vy: Math.sin(angle) * spd,
            size: 2.5 + Math.random() * 3.5,
            color: colors[randInt(0, colors.length)],
            alpha: 1.0,
            decay: 0.020 + Math.random() * 0.022,
            gravity: 0.08,
            sparkle: false,
        });
    }

    shockwaves.push({
        x,
        y,
        radius: 6,
        maxRadius: 48,
        alpha: 1.0,
    });
}

function spawnEngineTrail() {
    const cx = ship.x + SHIP_W / 2;
    const cy = ship.y + SHIP_H + 4;
    for (let i = 0; i < 2; i++) {
        engineTrails.push({
            x: cx + (Math.random() - 0.5) * 8,
            y: cy,
            vx: (Math.random() - 0.5) * 0.8,
            vy: 2.5 + Math.random() * 2.8,
            size: 3.5,
            alpha: 1.0,
            decay: 0.05 + Math.random() * 0.03,
        });
    }
}

function updateSensoryObjects() {
    for (let i = engineTrails.length - 1; i >= 0; i--) {
        const p = engineTrails[i];
        p.x += p.vx;
        p.y += p.vy;
        p.alpha -= p.decay;
        p.size  *= 0.94;
        if (p.alpha <= 0 || p.size <= 0.4) {
            engineTrails.splice(i, 1);
        }
    }

    for (let i = particles.length - 1; i >= 0; i--) {
        const p = particles[i];
        p.x += p.vx;
        p.y += p.vy;
        if (p.gravity) p.vy += p.gravity;
        p.alpha -= p.decay;
        if (p.alpha <= 0) {
            particles.splice(i, 1);
        }
    }

    for (let i = shockwaves.length - 1; i >= 0; i--) {
        const sw = shockwaves[i];
        sw.radius += 2.8;
        sw.alpha = 1.0 - (sw.radius / sw.maxRadius);
        if (sw.alpha <= 0 || sw.radius >= sw.maxRadius) {
            shockwaves.splice(i, 1);
        }
    }

    for (let i = floatTexts.length - 1; i >= 0; i--) {
        const ft = floatTexts[i];
        ft.y += ft.vy;
        ft.alpha -= 0.022;
        if (ft.alpha <= 0) {
            floatTexts.splice(i, 1);
        }
    }

    if (scoreScale > 1.0) {
        scoreScale -= 0.03;
        if (scoreScale < 1.0) scoreScale = 1.0;
    }

    if (!keysDown.has("ArrowLeft") && !keysDown.has("ArrowRight")) {
        shipTilt *= 0.82;
    }
}

// ═══════════════════════════════════════════════════════
// GAME LIFECYCLE FUNCTIONS
// ═══════════════════════════════════════════════════════

function init() {
    window.addEventListener("keydown", onKeyDown);
    window.addEventListener("keyup",   onKeyUp);
    canvas.addEventListener("mousemove", onPointerMove);
    canvas.addEventListener("mousedown", onPointerDown);
    canvas.addEventListener("mouseup",   onPointerUp);
    canvas.addEventListener("touchstart", onTouchStart, { passive: false });
    canvas.addEventListener("touchend",   onTouchEnd,   { passive: false });

    loadHighScore();
    initVisuals();
    requestAnimationFrame(gameLoop);
}

function resetGame() {
    score        = 0;
    lives        = MAX_LIVES;
    fallSpeed    = INITIAL_FALL_SPEED;
    objects      = [];
    particles    = [];
    engineTrails = [];
    floatTexts   = [];
    shockwaves   = [];
    shakeTime    = 0;
    shakePower   = 0;
    shipTilt     = 0;
    ship.x       = (CANVAS_W - SHIP_W) / 2;
    keysDown.clear();
    flash        = { type: null, until: 0 };
    state        = "menu";
}

function startGame() {
    playStartSound();
    state         = "playing";
    lastSpawnTime = performance.now();
}

function restartGame() {
    resetGame();
    startGame();
}

function endGame() {
    playGameOverSound();
    triggerScreenShake(14, 25);
    state = "gameover";
    if (score > highScore) {
        highScore = score;
        saveHighScore();
    }
}

function togglePause() {
    if (state === "playing") {
        playPauseSound(false);
        state = "paused";
    } else if (state === "paused") {
        playPauseSound(true);
        state         = "playing";
        lastSpawnTime = performance.now();
    }
}

// ═══════════════════════════════════════════════════════
// INPUT HANDLING
// ═══════════════════════════════════════════════════════

function getCanvasPointer(e) {
    const rect = canvas.getBoundingClientRect();
    const clientX = e.clientX ?? (e.touches && e.touches[0] ? e.touches[0].clientX : null);
    const clientY = e.clientY ?? (e.touches && e.touches[0] ? e.touches[0].clientY : null);
    if (clientX === null || clientY === null) return { x: -1000, y: -1000 };
    const scaleX = CANVAS_W / rect.width;
    const scaleY = CANVAS_H / rect.height;
    return {
        x: (clientX - rect.left) * scaleX,
        y: (clientY - rect.top)  * scaleY,
    };
}

function onPointerMove(e) {
    pointerPos = getCanvasPointer(e);
    updateHoverState();
}

function onPointerDown(e) {
    getAudioContext();
    pointerPos = getCanvasPointer(e);
    isPointerDown = true;
    updateHoverState();
}

function onPointerUp(e) {
    isPointerDown = false;
    handleButtonClicks();
    updateHoverState();
}

function onTouchStart(e) {
    e.preventDefault();
    getAudioContext();
    pointerPos = getCanvasPointer(e);
    isPointerDown = true;
    updateHoverState();
}

function onTouchEnd(e) {
    e.preventDefault();
    isPointerDown = false;
    handleButtonClicks();
    pointerPos = { x: -1000, y: -1000 };
    hoveredButton = null;
}

function updateHoverState() {
    hoveredButton = null;
    const { x, y } = pointerPos;
    if (state === "menu") {
        if (isInsideButton(x, y, CANVAS_W / 2, CANVAS_H / 2 + 32, 224, 50)) {
            hoveredButton = "start";
        }
    } else if (state === "paused") {
        if (isInsideButton(x, y, CANVAS_W / 2, CANVAS_H / 2 + 36, 200, 48)) {
            hoveredButton = "resume";
        }
    } else if (state === "gameover") {
        if (isInsideButton(x, y, CANVAS_W / 2, CANVAS_H / 2 + 20, 200, 50)) {
            hoveredButton = "restart";
        }
    }
}

function handleButtonClicks() {
    if (state === "menu" && hoveredButton === "start") {
        startGame();
    } else if (state === "paused" && hoveredButton === "resume") {
        togglePause();
    } else if (state === "gameover" && hoveredButton === "restart") {
        restartGame();
    }
}

function onKeyDown(e) {
    getAudioContext();
    keysDown.add(e.key);

    switch (state) {
        case "menu":
            if (e.key === "Enter" || e.key === " ") {
                startGame();
                e.preventDefault();
            }
            break;
        case "playing":
            if (e.key === "p" || e.key === "P" || e.key === "Escape") {
                togglePause();
                e.preventDefault();
            }
            break;
        case "paused":
            if (e.key === "p" || e.key === "P" || e.key === "Escape") {
                togglePause();
                e.preventDefault();
            }
            break;
        case "gameover":
            if (e.key === "Enter" || e.key === " " || e.key === "r" || e.key === "R") {
                restartGame();
                e.preventDefault();
            }
            break;
    }
}

function onKeyUp(e) {
    keysDown.delete(e.key);
}

function moveSpaceship() {
    if (keysDown.has("ArrowLeft")) {
        ship.x -= SHIP_SPEED;
        shipTilt = Math.max(-0.12, shipTilt - 0.025);
    }
    if (keysDown.has("ArrowRight")) {
        ship.x += SHIP_SPEED;
        shipTilt = Math.min(0.12, shipTilt + 0.025);
    }
    if (ship.x < 0)                ship.x = 0;
    if (ship.x + SHIP_W > CANVAS_W) ship.x = CANVAS_W - SHIP_W;
}

// ═══════════════════════════════════════════════════════
// FALLING OBJECTS – CREATION & UPDATE
// ═══════════════════════════════════════════════════════

function createFallingObject(now) {
    if (now - lastSpawnTime < getSpawnInterval()) return;
    lastSpawnTime = now;

    const isAsteroid = Math.random() < ASTEROID_CHANCE;
    const x          = randInt(0, CANVAS_W - OBJ_W);

    const obj = {
        x,
        y:    -OBJ_H,
        w:    OBJ_W,
        h:    OBJ_H,
        type: isAsteroid ? "asteroid" : "star",
        hit:  false,
    };

    if (isAsteroid) {
        const numVerts = 7 + randInt(0, 4);
        obj.vertices   = [];
        for (let i = 0; i < numVerts; i++) {
            obj.vertices.push({
                angle:  (i / numVerts) * Math.PI * 2,
                radius: 0.60 + Math.random() * 0.40,
            });
        }
        const numCracks = 2 + randInt(0, 2);
        obj.cracks      = [];
        for (let i = 0; i < numCracks; i++) {
            const a   = Math.random() * Math.PI * 2;
            const len = 3 + Math.random() * 5;
            obj.cracks.push([
                { x: Math.cos(a) * 1.5, y: Math.sin(a) * 1.5 },
                { x: Math.cos(a) * len, y: Math.sin(a) * len  },
            ]);
        }
        obj.rotSpeed  = (Math.random() - 0.5) * 0.045;
        obj.rotOffset = Math.random() * Math.PI * 2;
    } else {
        obj.phase = Math.random() * Math.PI * 2;
    }

    objects.push(obj);
}

function updateObjectPositions() {
    for (let i = objects.length - 1; i >= 0; i--) {
        objects[i].y += fallSpeed;
        if (objects[i].y > CANVAS_H) {
            objects.splice(i, 1);
        }
    }
}

// ═══════════════════════════════════════════════════════
// COLLISION DETECTION
// ═══════════════════════════════════════════════════════

function checkCollisions() {
    for (let i = objects.length - 1; i >= 0; i--) {
        const obj = objects[i];
        if (obj.hit)              continue;
        if (!collides(obj, ship)) continue;

        obj.hit = true;
        const cx = obj.x + OBJ_W / 2;
        const cy = obj.y + OBJ_H / 2;

        if (obj.type === "star") {
            updateScore(POINTS_PER_STAR);
            playStarSound();
            spawnStarExplosion(cx, cy);
            triggerFlash("star");
        } else {
            loseLife();
            playHitSound();
            spawnAsteroidImpact(cx, cy);
            triggerScreenShake(11, 18);
            triggerFlash("asteroid");
        }
        objects.splice(i, 1);
    }
}

// ═══════════════════════════════════════════════════════
// SCORE & LIVES
// ═══════════════════════════════════════════════════════

function updateScore(points) {
    score     += points;
    fallSpeed  = computeFallSpeed();
}

function loseLife() {
    lives -= 1;
    if (lives <= 0) {
        lives = 0;
        endGame();
    }
}

function triggerFlash(type) {
    flash.type  = type;
    flash.until = performance.now() + 140;
}

// ═══════════════════════════════════════════════════════
// VISUAL INITIALISATION
// ═══════════════════════════════════════════════════════

function initVisuals() {
    const starColors = ["#ffffff", "#b4d8ff", "#d8b4ff", "#ffb4d8", "#80ffff", "#ffffe0"];
    bgStars = [];
    for (let i = 0; i < 210; i++) {
        bgStars.push({
            x:     Math.random() * CANVAS_W,
            y:     Math.random() * CANVAS_H,
            r:     Math.random() * 1.5 + 0.25,
            color: starColors[randInt(0, starColors.length)],
            phase: Math.random() * Math.PI * 2,
            speed: Math.random() * 0.025 + 0.007,
        });
    }

    offBg        = document.createElement("canvas");
    offBg.width  = CANVAS_W;
    offBg.height = CANVAS_H;
    const octx   = offBg.getContext("2d");

    const base = octx.createLinearGradient(0, 0, CANVAS_W * 0.5, CANVAS_H);
    base.addColorStop(0,    "#0e0030");
    base.addColorStop(0.3,  "#080040");
    base.addColorStop(0.65, "#0a0025");
    base.addColorStop(1,    "#050015");
    octx.fillStyle = base;
    octx.fillRect(0, 0, CANVAS_W, CANVAS_H);

    const nebulas = [
        { x:  50, y:  90, r: 220, c0: "rgba( 90,  0,170,0.42)", c1: "rgba(45,0,100,0.10)" },
        { x: 400, y: 190, r: 185, c0: "rgba(  0, 50,190,0.38)", c1: "rgba( 0,25,100,0.08)" },
        { x: 180, y: 370, r: 240, c0: "rgba( 85,  0,130,0.32)", c1: "rgba(45,0, 80,0.06)" },
        { x: 430, y: 460, r: 165, c0: "rgba(  0, 75,165,0.30)", c1: "rgba( 0,35, 85,0.06)" },
        { x:  90, y: 575, r: 185, c0: "rgba(140,  0, 90,0.26)", c1: "rgba(65,0, 45,0.05)" },
        { x: 310, y: 650, r: 145, c0: "rgba( 65,  0,150,0.30)", c1: "rgba(30,0, 80,0.06)" },
        { x: 240, y: 210, r: 120, c0: "rgba(  0, 90,110,0.22)", c1: "rgba( 0,45, 60,0.05)" },
        { x: 350, y: 340, r: 100, c0: "rgba(160,  0,100,0.18)", c1: "rgba(70,0, 50,0.04)" },
    ];
    for (const n of nebulas) {
        const g = octx.createRadialGradient(n.x, n.y, 0, n.x, n.y, n.r);
        g.addColorStop(0,    n.c0);
        g.addColorStop(0.55, n.c1);
        g.addColorStop(1,    "rgba(0,0,0,0)");
        octx.fillStyle = g;
        octx.fillRect(0, 0, CANVAS_W, CANVAS_H);
    }

    const accents = [
        { x: 390, y: 110, r:  65, c: "rgba(  0,190,255,0.14)" },
        { x: 100, y: 440, r:  85, c: "rgba(210,  0,255,0.11)" },
        { x: 265, y: 585, r:  55, c: "rgba(255,  0,185,0.09)" },
        { x: 450, y: 610, r:  70, c: "rgba(  0,130,255,0.11)" },
        { x: 165, y: 170, r:  50, c: "rgba(255,100,255,0.08)" },
    ];
    for (const a of accents) {
        const g = octx.createRadialGradient(a.x, a.y, 0, a.x, a.y, a.r);
        g.addColorStop(0, a.c);
        g.addColorStop(1, "rgba(0,0,0,0)");
        octx.fillStyle = g;
        octx.fillRect(0, 0, CANVAS_W, CANVAS_H);
    }
}

// ═══════════════════════════════════════════════════════
// RENDERING
// ═══════════════════════════════════════════════════════

function drawBackground() {
    ctx.drawImage(offBg, 0, 0);
}

function drawBackgroundStars() {
    ctx.save();
    for (const s of bgStars) {
        const alpha = 0.35 + 0.65 * Math.abs(Math.sin(animTime * s.speed + s.phase));
        ctx.globalAlpha = alpha;
        ctx.fillStyle   = s.color;
        ctx.shadowColor = s.color;
        ctx.shadowBlur  = s.r > 1.0 ? 5 : 1;
        ctx.beginPath();
        ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
        ctx.fill();
    }
    ctx.restore();
}

function drawEngineTrails() {
    ctx.save();
    for (const p of engineTrails) {
        ctx.globalAlpha = p.alpha;
        ctx.fillStyle   = "#00e5ff";
        ctx.shadowColor = "#00e5ff";
        ctx.shadowBlur  = 8;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
    }
    ctx.restore();
}

function drawSpaceship() {
    const { x, y, w, h } = ship;
    const cx = x + w / 2;
    ctx.save();

    ctx.translate(cx, y + h / 2);
    ctx.rotate(shipTilt);
    ctx.translate(-cx, -(y + h / 2));

    const flameLen = 8 + 5 * Math.abs(Math.sin(animTime * 0.18));
    const flameMid = y + h + flameLen * 0.5;
    const flameG   = ctx.createRadialGradient(cx, y + h, 0, cx, flameMid, flameLen + 6);
    flameG.addColorStop(0,    "rgba(200,245,255,1.0)");
    flameG.addColorStop(0.25, "rgba(  0,200,255,0.85)");
    flameG.addColorStop(0.65, "rgba( 80,  0,220,0.45)");
    flameG.addColorStop(1,    "rgba(  0,  0,  0,0.0)");
    ctx.fillStyle = flameG;
    ctx.beginPath();
    ctx.ellipse(cx, y + h + flameLen * 0.5, w * 0.14, flameLen, 0, 0, Math.PI * 2);
    ctx.fill();

    ctx.shadowColor = "#00e5ff";
    ctx.shadowBlur  = 18;
    ctx.fillStyle   = "#5010a8";
    ctx.beginPath();
    ctx.moveTo(x + w * 0.35, y + h * 0.60);
    ctx.lineTo(x,             y + h * 0.98);
    ctx.lineTo(x + w * 0.18, y + h * 0.78);
    ctx.closePath();
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(x + w * 0.65, y + h * 0.60);
    ctx.lineTo(x + w,         y + h * 0.98);
    ctx.lineTo(x + w * 0.82, y + h * 0.78);
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = "#7828d0";
    ctx.beginPath();
    ctx.moveTo(cx,            y);
    ctx.lineTo(x + w * 0.15, y + h * 0.75);
    ctx.lineTo(x + w * 0.35, y + h * 0.60);
    ctx.lineTo(x + w * 0.65, y + h * 0.60);
    ctx.lineTo(x + w * 0.85, y + h * 0.75);
    ctx.closePath();
    ctx.fill();

    ctx.shadowColor = "#00ffff";
    ctx.shadowBlur  = 12;
    ctx.fillStyle   = "#00e8ff";
    ctx.beginPath();
    ctx.moveTo(cx,             y + h * 0.08);
    ctx.lineTo(cx - w * 0.10, y + h * 0.44);
    ctx.lineTo(cx + w * 0.10, y + h * 0.44);
    ctx.closePath();
    ctx.fill();

    ctx.strokeStyle = "#b060ff";
    ctx.lineWidth   = 1.2;
    ctx.shadowColor = "#c080ff";
    ctx.shadowBlur  = 7;
    ctx.beginPath();
    ctx.moveTo(cx - w * 0.20, y + h * 0.56);
    ctx.lineTo(cx + w * 0.20, y + h * 0.56);
    ctx.stroke();

    ctx.restore();
}

function drawCollectibleStar(obj) {
    const cx     = obj.x + OBJ_W / 2;
    const cy     = obj.y + OBJ_H / 2;
    const outerR = OBJ_W / 2 + 2;
    const innerR = OBJ_W / 4.8;
    const pulse  = 0.88 + 0.12 * Math.sin(animTime * 0.10 + obj.phase);

    ctx.save();
    ctx.translate(cx, cy);
    ctx.scale(pulse, pulse);

    const aura = ctx.createRadialGradient(0, 0, innerR, 0, 0, outerR + 10);
    aura.addColorStop(0, "rgba(255,220,  0,0.40)");
    aura.addColorStop(1, "rgba(255,160,  0,0.00)");
    ctx.fillStyle = aura;
    starPath(0, 0, outerR + 10, innerR + 5);
    ctx.fill();

    ctx.shadowColor = "#ffe800";
    ctx.shadowBlur  = 16;

    const grad = ctx.createRadialGradient(0, -innerR * 0.5, 0, 0, 0, outerR);
    grad.addColorStop(0,   "#fff8c0");
    grad.addColorStop(0.4, "#ffe94a");
    grad.addColorStop(1,   "#ff9500");
    ctx.fillStyle = grad;
    starPath(0, 0, outerR, innerR);
    ctx.fill();

    ctx.fillStyle  = "rgba(255,255,255,0.55)";
    ctx.shadowBlur = 2;
    ctx.beginPath();
    ctx.arc(0, -outerR * 0.32, outerR * 0.22, 0, Math.PI * 2);
    ctx.fill();

    const sparkLen  = outerR + 7 + 3 * Math.sin(animTime * 0.12 + obj.phase);
    ctx.strokeStyle = "rgba(255,255,190,0.75)";
    ctx.lineWidth   = 0.9;
    ctx.shadowColor = "#ffffff";
    ctx.shadowBlur  = 5;
    for (let i = 0; i < 4; i++) {
        const a = (i / 4) * Math.PI + animTime * 0.016;
        ctx.beginPath();
        ctx.moveTo(Math.cos(a) * (outerR + 1), Math.sin(a) * (outerR + 1));
        ctx.lineTo(Math.cos(a) * sparkLen,      Math.sin(a) * sparkLen);
        ctx.stroke();
    }

    ctx.restore();
}

function drawAsteroid(obj) {
    const cx    = obj.x + OBJ_W / 2;
    const cy    = obj.y + OBJ_H / 2;
    const r     = OBJ_W / 2;
    const angle = obj.rotOffset + animTime * obj.rotSpeed;

    ctx.save();
    ctx.translate(cx, cy);
    ctx.rotate(angle);

    ctx.shadowColor = "rgba(255,80,0,0.75)";
    ctx.shadowBlur  = 12;

    const grad = ctx.createRadialGradient(-r * 0.25, -r * 0.25, 0, 0, 0, r);
    grad.addColorStop(0,   "#7a4870");
    grad.addColorStop(0.5, "#3c2050");
    grad.addColorStop(1,   "#180e28");
    ctx.fillStyle = grad;

    ctx.beginPath();
    const verts = obj.vertices;
    for (let i = 0; i < verts.length; i++) {
        const v  = verts[i];
        const px = Math.cos(v.angle) * r * v.radius;
        const py = Math.sin(v.angle) * r * v.radius;
        i === 0 ? ctx.moveTo(px, py) : ctx.lineTo(px, py);
    }
    ctx.closePath();
    ctx.fill();

    ctx.strokeStyle = "rgba(255,120,0,0.90)";
    ctx.lineWidth   = 1.1;
    ctx.shadowColor = "#ff4400";
    ctx.shadowBlur  = 7;
    for (const crack of obj.cracks) {
        ctx.beginPath();
        ctx.moveTo(crack[0].x, crack[0].y);
        ctx.lineTo(crack[1].x, crack[1].y);
        ctx.stroke();
    }

    ctx.restore();
}

function drawFallingObjects() {
    for (const obj of objects) {
        if (obj.type === "star") {
            drawCollectibleStar(obj);
        } else {
            drawAsteroid(obj);
        }
    }
}

function drawParticles() {
    ctx.save();
    for (const p of particles) {
        ctx.globalAlpha = p.alpha;
        ctx.fillStyle   = p.color;
        ctx.shadowColor = p.color;
        ctx.shadowBlur  = 6;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
    }
    ctx.restore();
}

function drawShockwaves() {
    ctx.save();
    for (const sw of shockwaves) {
        ctx.globalAlpha = sw.alpha;
        ctx.strokeStyle = "#ff4444";
        ctx.lineWidth   = 2.4;
        ctx.shadowColor = "#ff2200";
        ctx.shadowBlur  = 12;
        ctx.beginPath();
        ctx.arc(sw.x, sw.y, sw.radius, 0, Math.PI * 2);
        ctx.stroke();
    }
    ctx.restore();
}

function drawFloatingTexts() {
    ctx.save();
    ctx.font         = 'bold 16px "Courier New", monospace';
    ctx.textAlign    = "center";
    ctx.textBaseline = "middle";
    for (const ft of floatTexts) {
        ctx.globalAlpha = ft.alpha;
        ctx.shadowColor = "#ffe94a";
        ctx.shadowBlur  = 10;
        ctx.fillStyle   = "#fff8a0";
        ctx.fillText(ft.text, ft.x, ft.y);
    }
    ctx.restore();
}

function drawHUD() {
    ctx.save();
    ctx.font         = 'bold 17px "Courier New", monospace';
    ctx.textBaseline = "top";

    ctx.save();
    ctx.translate(12, 12);
    ctx.scale(scoreScale, scoreScale);
    ctx.shadowColor = "#00e5ff";
    ctx.shadowBlur  = 12;
    ctx.fillStyle   = "#a8f4ff";
    ctx.textAlign   = "left";
    ctx.fillText(`SCORE  ${score}`, 0, 0);
    ctx.restore();

    ctx.shadowColor = lives === 1 ? "#ff0000" : "#ff4466";
    ctx.shadowBlur  = lives === 1 ? (14 + 10 * Math.sin(animTime * 0.25)) : 12;
    ctx.fillStyle   = lives === 1 ? "#ff2244" : "#ff6688";
    ctx.textAlign   = "right";
    const hearts = ("♥  ").repeat(lives).trimEnd();
    ctx.fillText(hearts, CANVAS_W - 12, 12);

    ctx.restore();
}

function drawFlash() {
    if (!flash.type || performance.now() > flash.until) {
        flash.type = null;
        return;
    }
    ctx.fillStyle = flash.type === "star"
        ? "rgba(255,240,80,0.18)"
        : "rgba(255,50,50,0.30)";
    ctx.fillRect(0, 0, CANVAS_W, CANVAS_H);
}

function drawMenu() {
    drawBackground();
    drawBackgroundStars();

    ctx.save();
    ctx.textAlign = "center";

    ctx.font        = 'bold 46px "Courier New", monospace';
    ctx.shadowColor = "#c060ff";
    ctx.shadowBlur  = 28;
    ctx.fillStyle   = "#e0a8ff";
    ctx.fillText("GALAXY", CANVAS_W / 2, CANVAS_H / 4 - 14);

    ctx.fillStyle   = "#ffe94a";
    ctx.shadowColor = "#ffaa00";
    ctx.shadowBlur  = 24;
    ctx.fillText("CATCHER", CANVAS_W / 2, CANVAS_H / 4 + 42);

    ctx.font        = '13px "Courier New", monospace';
    ctx.shadowColor = "#00e5ff";
    ctx.shadowBlur  = 7;
    ctx.fillStyle   = "#80d8ff";
    ctx.fillText("Catch falling stars.  Avoid asteroids.", CANVAS_W / 2, CANVAS_H / 4 + 90);
    ctx.fillText("←  →   Arrow keys to move",             CANVAS_W / 2, CANVAS_H / 4 + 112);
    ctx.fillText("P  or  Esc   →   Pause",                CANVAS_W / 2, CANVAS_H / 4 + 132);
    ctx.restore();

    drawGlowButton("start", "▶   START GAME", CANVAS_W / 2, CANVAS_H / 2 + 32, 224, 50,
                   "rgba(70,0,150,0.88)", "#c060ff");

    ctx.save();
    ctx.textAlign = "center";
    ctx.font      = '12px "Courier New", monospace';
    ctx.fillStyle = "#504868";
    ctx.fillText("or press Enter / Space", CANVAS_W / 2, CANVAS_H / 2 + 74);
    ctx.restore();

    if (highScore > 0) {
        ctx.save();
        ctx.textAlign   = "center";
        ctx.font        = 'bold 15px "Courier New", monospace';
        ctx.shadowColor = "#00ff88";
        ctx.shadowBlur  = 10;
        ctx.fillStyle   = "#80ffb8";
        ctx.fillText(`BEST  ${highScore}`, CANVAS_W / 2, CANVAS_H / 2 + 102);
        ctx.restore();
    }
}

function drawPaused() {
    drawBackground();
    drawBackgroundStars();
    drawFallingObjects();
    drawSpaceship();
    drawHUD();

    ctx.fillStyle = "rgba(0,0,20,0.62)";
    ctx.fillRect(0, 0, CANVAS_W, CANVAS_H);

    ctx.save();
    ctx.textAlign   = "center";
    ctx.font        = 'bold 46px "Courier New", monospace';
    ctx.shadowColor = "#ffe94a";
    ctx.shadowBlur  = 24;
    ctx.fillStyle   = "#ffe94a";
    ctx.fillText("PAUSED", CANVAS_W / 2, CANVAS_H / 2 - 24);
    ctx.restore();

    drawGlowButton("resume", "▶   RESUME", CANVAS_W / 2, CANVAS_H / 2 + 36, 200, 48,
                   "rgba(0,55,120,0.90)", "#00e5ff");

    ctx.save();
    ctx.textAlign = "center";
    ctx.font      = '12px "Courier New", monospace';
    ctx.fillStyle = "#504868";
    ctx.fillText("or press P / Esc", CANVAS_W / 2, CANVAS_H / 2 + 74);
    ctx.restore();
}

function drawGameOver() {
    drawBackground();
    drawBackgroundStars();
    drawParticles();
    drawShockwaves();

    ctx.save();
    ctx.textAlign   = "center";
    ctx.font        = 'bold 46px "Courier New", monospace';
    ctx.shadowColor = "#ff3344";
    ctx.shadowBlur  = 28;
    ctx.fillStyle   = "#ff5566";
    ctx.fillText("GAME OVER", CANVAS_W / 2, CANVAS_H / 4);

    ctx.font        = 'bold 22px "Courier New", monospace';
    ctx.shadowColor = "#00e5ff";
    ctx.shadowBlur  = 12;
    ctx.fillStyle   = "#a8f4ff";
    ctx.fillText(`SCORE  ${score}`, CANVAS_W / 2, CANVAS_H / 4 + 62);
    ctx.restore();

    if (highScore > 0) {
        ctx.save();
        ctx.textAlign   = "center";
        ctx.font        = 'bold 16px "Courier New", monospace';
        ctx.shadowColor = "#00ff88";
        ctx.shadowBlur  = 10;
        ctx.fillStyle   = "#80ffb8";
        ctx.fillText(`BEST  ${highScore}`, CANVAS_W / 2, CANVAS_H / 4 + 96);
        ctx.restore();
    }

    drawGlowButton("restart", "↺   RESTART", CANVAS_W / 2, CANVAS_H / 2 + 20, 200, 50,
                   "rgba(100,0,55,0.90)", "#ff4488");

    ctx.save();
    ctx.textAlign = "center";
    ctx.font      = '12px "Courier New", monospace';
    ctx.fillStyle = "#504868";
    ctx.fillText("or press Enter / R", CANVAS_W / 2, CANVAS_H / 2 + 60);
    ctx.restore();
}

function drawPlaying() {
    drawBackground();
    drawBackgroundStars();
    drawEngineTrails();
    drawFallingObjects();
    drawSpaceship();
    drawParticles();
    drawShockwaves();
    drawFloatingTexts();
    drawHUD();
    drawFlash();
}

function render() {
    ctx.save();

    if (shakeTime > 0) {
        const ox = (Math.random() - 0.5) * shakePower;
        const oy = (Math.random() - 0.5) * shakePower;
        ctx.translate(ox, oy);
        shakePower *= 0.88;
        shakeTime--;
    }

    switch (state) {
        case "menu":     drawMenu();     break;
        case "playing":  drawPlaying();  break;
        case "paused":   drawPaused();   break;
        case "gameover": drawGameOver(); break;
    }

    ctx.restore();
}

// ═══════════════════════════════════════════════════════
// MAIN GAME LOOP
// ═══════════════════════════════════════════════════════

function gameLoop(timestamp) {
    requestAnimationFrame(gameLoop);
    animTime++;

    if (state === "playing") {
        moveSpaceship();
        spawnEngineTrail();
        createFallingObject(timestamp);
        updateObjectPositions();
        checkCollisions();
    }

    updateSensoryObjects();
    render();
}

// ── Bootstrap ──────────────────────────────────────────
init();
```

---

*Stage 3 source archived here. Prior stages: `MD.plan1.md` (Stage 1) and `MD.plan2.md` (Stage 2).*
