Stage: State & Storage
Architect model: Gemini (High-Reasoning)  
Builder model: Gemini (Builder Agent)  
Result: (To be filled after building and testing Stage 4)

## Overview
Implement robust game state control (`menu`, `playing`, `paused`, `gameover`) and persistent data storage via browser `localStorage` to save high scores and settings across sessions. Include a dedicated reset-data feature and pause functionality.

## State & Storage Breakdown

### 1. Game State Machine (`script.js`)
- Define distinct states: `MENU`, `PLAYING`, `PAUSED`, `GAMEOVER`.
- **Pause Functionality**: 
  - Add a pause button or keyboard shortcut (e.g., `ESC` or `P`).
  - Halts the `requestAnimationFrame` game loop and active item movement while overlaying a "Game Paused" screen. Resuming continues seamlessly from the exact same state.
- **State Transition Overlays**: Manage DOM visibility cleanly for Start Screen, Pause Screen, HUD, and Game Over Screen.

### 2. Local Storage Persistence (`script.js`)
- **High Score**: Automatically check current score against `localStorage.getItem('catchGameHighScore')`. If beaten, save the new score using `localStorage.setItem('catchGameHighScore', score)`. Display both current score and all-time high score on the HUD/Game Over screen.
- **Settings**: Save user preferences like the mute state (`localStorage.setItem('catchGameMuted', isMuted)`) so user preferences persist on reload.

### 3. Reset Data Button (`index.html` & `script.js`)
- Add a stylized "Reset Data" button on the main menu or settings area.
- Clicking it clears the stored high score and user settings from `localStorage`, resets the displayed high score to `0`, and provides a brief visual confirmation toast or text update.

## Done When
Refreshing the browser page keeps the all-time high score and mute preferences intact. Pausing the game stops gameplay correctly and resuming works without errors, and clicking the reset-data button successfully wipes saved statistics back to default.