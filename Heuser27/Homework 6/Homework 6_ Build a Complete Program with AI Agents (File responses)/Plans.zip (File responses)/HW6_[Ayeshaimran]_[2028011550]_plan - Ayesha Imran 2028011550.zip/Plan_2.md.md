Stage: Visual Vibe
Architect model: Gemini (High-Reasoning)  
Builder model: Gemini (Builder Agent)  
Result: (To be filled after building and testing Stage 2)

## Overview
Transform the functional grey prototype from Stage 1 into a visually distinct, cohesive theme without touching or altering any core gameplay logic or rules. Everything must be drawn using pure CSS and/or inline SVG elements created dynamically via code. Zero external assets (no `.png`, `.jpg`, `.svg` files, fonts, or external CSS libraries).

## Visual Theme & Color Palette
- **Theme**: "Retro Cyberpunk / Neon Arcade"
- **Background**: Deep space / dark grid canvas (`#0d0e15`) with a subtle CSS grid lines pattern.
- **Color Palette**:
  - Primary Accent (Player): Neon Cyan (`#00f3ff`) with a glowing box-shadow (`0 0 12px #00f3ff`).
  - Good Item (Data Core): Bright Neon Magenta (`#ff007f`) with CSS glow.
  - Bad Item (Glitch Virus): Neon Yellow/Orange (`#ffb700`) with flickering border styling.
  - UI Text / Borders: Electric Lime (`#00ff66`) and Bright Cyan (`#00f3ff`).
- **Typography**: Clean monospace fallback stack (`'Courier New', Courier, monospace`) with uppercase text and text shadows for an arcade HUD feel.

## Visual Upgrade Breakdown

### 1. Game Container & Background Design (`style.css`)
- Replace plain border with a glowing neon border frame (`box-shadow: 0 0 20px rgba(0, 243, 255, 0.4)`).
- Use a CSS radial gradient combined with `linear-gradient` to generate a subtle moving or static cyberpunk grid pattern on the background.

### 2. Player Element Design (`style.css` / `script.js`)
- Replace simple box player with a stylized hovercraft / digital paddle using CSS shapes (border-radius, clipped paths, or inline SVG).
- Add neon trail glow effects using CSS `box-shadow` or dynamic CSS custom properties.

### 3. Falling Items Design (`script.js` / `style.css`)
- **Good Items**: Rendered as glowing energy gems or digital diamonds using inline SVG shapes or CSS `transform: rotate(45deg)` with rounded corners and high brightness glow.
- **Bad Items**: Rendered as spiky glitch/hazard icons using CSS `clip-path: polygon(...)` or inline SVG warning triangles.

### 4. UI & HUD Overlay (`index.html` & `style.css`)
- Style Score, Lives, and High Score displays as a digital arcade HUD at the top of the container.
- Design overlay screens (Start, Game Over) with semi-transparent frosted glass dark backgrounds (`backdrop-filter: blur(4px)`), glowing neon action buttons, and retro-style header typography.

## Done When
The game looks like a finished retro neon arcade project, with themed CSS/SVG graphics, distinct glowing elements, and stylish HUD overlays, while the project folder still contains exactly zero image files (`.png`, `.jpg`, etc.) and game rules remain unchanged.