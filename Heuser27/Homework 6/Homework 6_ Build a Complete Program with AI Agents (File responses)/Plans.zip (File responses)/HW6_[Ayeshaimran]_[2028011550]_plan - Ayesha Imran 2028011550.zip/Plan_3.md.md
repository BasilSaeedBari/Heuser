Stage: Sensory Feedback
Architect model: Gemini (High-Reasoning)  
Builder model: Gemini (Builder Agent)  
Result: (To be filled after building and testing Stage 3)

## Overview
Add immersive sensory feedback to the neon arcade catch game. This includes smooth animations, particle/impact visual effects when items are caught or missed, dynamic hover/press states for buttons, and procedural sound effects generated via the browser's native Web Audio API (zero external sound files). A clear mute button must also be included.

## Sensory Feedback Breakdown

### 1. Animations & Visual Effects (`style.css` & `script.js`)
- **Player Movement Smoothing**: Add smooth CSS transitions or lerp interpolation in movement logic so the paddle glides rather than snaps.
- **Catch / Score Pop Effect**: When a good item is caught, spawn a temporary floating score text (`+10`) that drifts upward and fades out.
- **Hit / Damage Flash**: Flash the game container border or tint the screen red briefly when a life is lost.
- **Particle Burst**: Generate quick, temporary DOM particles or CSS div shards radiating outward when an item is caught or hits the floor.
- **Button Hover/Active States**: Scale up buttons slightly on hover (`transform: scale(1.05)`) with intensified neon glow and add a tactile click press-down effect (`transform: scale(0.95)`).

### 2. Audio System via Web Audio API (`script.js`)
- Implement a lightweight synthesized sound manager using `AudioContext` so no external `.mp3` or `.wav` files are needed:
  - **Start Sound**: Quick ascending arpeggio (tri-tone chime).
  - **Catch Good Item**: Satisfying high-pitched chime / coin sound (sine wave with quick decay).
  - **Hit Bad Item / Lose Life**: Low buzzing or downward frequency sweep (sawtooth/square wave).
  - **Game Over**: Sad descending multi-tone sequence.
- **Mute Button**: 
  - Add a toggle button (`#mute-btn`) in the HUD.
  - State variable (`isMuted`) that suppresses all audio triggers when active, reflecting the current audio state on the UI icon/text.

## Done When
Every important player action (starting the game, clicking buttons, catching a good item, hitting a bad item, losing a life, and game over) provides an immediate, noticeable visual reaction (animations/particles) and an audible reaction (Web Audio synthesizer sound), with a working mute button to silence all audio.