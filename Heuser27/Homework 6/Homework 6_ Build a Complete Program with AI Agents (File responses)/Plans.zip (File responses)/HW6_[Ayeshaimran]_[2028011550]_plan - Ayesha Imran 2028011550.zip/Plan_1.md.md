Stage: Core Logic
Architect model: Gemini (High-Reasoning)  
Builder model: Gemini (Builder Agent)  
Result: (To be filled after building and testing Stage 1)

## Overview
Build the foundational mechanics for a catching game using exactly three files: `index.html`, `style.css`, and `script.js`. No external assets, images, or libraries. Everything is styled via CSS shapes or raw DOM elements.

## Rules & Mechanics
1. **Game Area**: A constrained container acting as the game board.
2. **Player (Basket)**: A simple rectangular element at the bottom of the screen that moves left and right via Keyboard Arrow Keys or A/D keys.
3. **Falling Objects**: 
   - Items spawn at random X coordinates at the top and fall downwards at a steady speed.
   - Two types: **Good items** (gain points) and **Bad items** (lose points/lives).
4. **Scoring & Lives**:
   - Score increases when catching a good item.
   - Lives decrease when catching a bad item or letting a good item hit the floor.
   - Game over triggers when lives reach 0.
5. **Game States**: Starts on pressing a "Start Game" button, running loop, ends on Game Over with a restart option.

## File Breakdown & Implementation Details

### 1. `index.html`
- Basic semantic layout:
  - Header showing Score and Lives.
  - `#game-container` holding the player paddle (`#player`) and dynamic falling items.
  - A start/game-over overlay screen with a "Start Game" button.

### 2. `style.css`
- Centered layout, clean minimalist retro style using basic CSS blocks:
  - `#game-container`: Fixed width/height (e.g., 400px by 500px), relative positioning, overflow hidden, solid border.
  - `#player`: Absolute positioning near the bottom, colored rectangle.
  - Falling objects: Absolute positioning, styled as small squares or circles (good = green, bad = red).

### 3. `script.js`
- Event listeners for keyboard movement (`ArrowLeft`, `ArrowRight`).
- Game loop (`requestAnimationFrame`) handling:
  - Spawning falling items at intervals.
  - Updating positions of all active items.
  - Collision detection (AABB bounding box check between player and falling items).
  - Updating UI text for score and lives.
  - Ending the game when lives drop to 0.

## Done When
Someone can load `index.html`, click start, move the paddle back and forth, catch good items to score points, dodge or avoid bad items, lose lives, and see a game over screen from start to finish. It is ugly, but it works.