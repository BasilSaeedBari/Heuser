Stage: Debugging & Polish
Architect model: Gemini (High-Reasoning)  
Builder model: Gemini (Builder Agent)  
Result: Successfully attacked edge cases and resolved timing, focus, and storage bugs. The game now handles rapid inputs, tab switches, and corrupted local storage gracefully with a polished arcade feel.

## Overview
Stress-test the application against various edge cases (rapid clicking, window resizing, tab switching, unexpected keyboard input, and corrupted local storage data) and apply final code cleanup and polish.

## Edge Cases to Attack
1. **Rapid Clicking / Button Mashing**: Spamming the start, pause, or restart buttons to ensure game states do not desync or spawn multiple duplicate game loops.
2. **Window Resizing**: Ensuring paddle boundaries and container scaling do not break when the viewport changes.
3. **Tab Switching / Browser Blur**: Preventing items from falling or timers from expiring while the user is away from the active tab.
4. **Unexpected Keyboard Input**: Holding down keys, pressing unmapped keys, or conflicting modifier keys.
5. **Corrupted LocalStorage Data**: Handling malformed or invalid string inputs in browser storage without crashing the script.

## Bug List (Required for Submission)

### Bug 1: Tab-Switching Runaway Timer & Falling Objects
- **What happened**: When the player switched to another browser tab, `requestAnimationFrame` paused rendering, but item spawn intervals continued in the background. When returning to the tab, multiple falling items instantly hit the floor or overlapped, instantly ending the game unfairly.
- **How it was fixed**: Added a `visibilitychange` event listener. When `document.hidden` becomes true during a active game state, the game automatically switches to a `PAUSED` state (or suspends the active game ticker loop), ensuring safety when the user is away.

### Bug 2: Corrupted LocalStorage Causing `NaN` High Score
- **What happened**: When modifying browser storage manually during testing, passing a non-numeric string into `localStorage.getItem('catchGameHighScore')` caused the high score display to read `NaN` and break comparison logic.
- **How it was fixed**: Added input sanitization and fallback parsing (`parseInt(localStorage.getItem(...)) || 0`) with `isNaN()` checks whenever reading or writing numerical state data from `localStorage`.

### Bug 3: Paddle Glitching Out-of-Bounds on Window Resize
- **What happened**: If the browser window size changed or mobile orientation shifted, the player's absolute coordinate could exceed the maximum width of the `#game-container`, trapping the paddle outside the visible screen.
- **How it was fixed**: Clamped the player's X position variable inside the movement calculation loop to strictly stay between `0` and `gameContainer.clientWidth - player.clientWidth`.