# Prompt for LLM Agent: Space-Themed Catch Game ("Galaxy Catch")

Copy and paste the entire block inside the code fence below to instruct another LLM agent to create the complete game:

```
Act as an expert front-end web developer. Create a complete, fully functional, wide-screen 2D Space-Themed Catch Game called "Galaxy Catch" using vanilla HTML, CSS, and JavaScript. 

### Output Format Requirements
- Provide the solution across exactly three separate files:
  1. `index.html` (HTML structure)
  2. `style.css` (CSS styling & pure CSS art)
  3. `script.js` (JavaScript game loop, procedural Web Audio, & persistence)

---

### 1. COLOR PALETTE & CSS CUSTOM PROPERTIES
Use these EXACT CSS custom properties in `:root` inside `style.css`:

```css
:root {
  /* Core Palette */
  --onyx: #090c08;
  --pale-sky: #b9d6f2;
  --velvet-orchid: #631d76;
  --bubblegum-fizz: #e365c1;

  /* HSL Variations */
  --onyx-hsl: hsla(105, 20%, 4%, 1);
  --pale-sky-hsl: hsla(209, 69%, 84%, 1);
  --velvet-orchid-hsl: hsla(287, 61%, 29%, 1);
  --bubblegum-fizz-hsl: hsla(316, 69%, 64%, 1);

  /* Deep Black Asteroid Tone */
  --asteroid-dark: #030403;
  --asteroid-crater: #141a12;

  /* Pre-configured Gradients */
  --galaxy-bg: radial-gradient(circle at center, #631d76 0%, #090c08 85%);
  --planet-gradient-1: radial-gradient(circle at 30% 30%, #e365c1, #631d76);
  --planet-gradient-2: radial-gradient(circle at 30% 30%, #b9d6f2, #631d76);
  --asteroid-gradient: radial-gradient(circle at 30% 30%, var(--asteroid-crater), var(--asteroid-dark));
}
```

---

### 2. LAYOUT & WIDE-SCREEN PLAYFIELD
- The game container MUST span the full browser viewport (`100vw` × `100vh`).
- `body` must have `margin: 0; overflow: hidden;` to eliminate scroll bars.
- All game elements (player, items, HUD, overlays) live inside this container DOM structure — no `<canvas>`, everything is DOM-based with CSS art.
- On window resize, dynamically recalculate viewport dimensions and re-clamp player position within bounds.

---

### 3. VISUAL DESIGN (PURE CSS ART)
- **Galaxy Background:** Layered procedural CSS starfield with a `starTwinkle` opacity keyframe animation over `--galaxy-bg`.
- **Planets (Good Items):** Circular spheres (`32x32px`, `border-radius: 50%`) with planetary orbital rings and specular highlights using `--planet-gradient-1` and `--planet-gradient-2`.
- **Asteroids (Bad Items):** Asymmetric irregular dark rocks (`32x32px`) rendered via `--asteroid-gradient` and crater pseudo-elements (`#030403`).
- **Player Catcher:** Horizontal cosmic shield paddle (`90x20px`) with glowing border, energy arc ring, and crystal core accent.
- **Particle Effects:** DOM particles burst outward and fade on item catch (pink for planets, purple for asteroids).

---

### 4. SMOOTH MOTION & CONTROLS
- **Lerp Movement:** Linear interpolation (`lerp(current, target, factor)`) for silky smooth player gliding driven by Keyboard (`ArrowKeys` / `A` / `D`), Mouse, or Touch drag.
- **CSS-Driven Item Rotation:** Falling items receive `@keyframes itemSpin` directly via CSS animation properties for buttery smooth 60 FPS performance.
- **Screen Shake & Flash:** Full-screen red damage flash and container screen-shake on asteroid hits.

---

### 5. WEB AUDIO API (PROCEDURAL SOUNDS)
- **NO external audio files.** All sound synthesizers must use native browser `AudioContext`:
  - **Planet Catch Sound:** Ascending sine-wave chime sweep (440 Hz → 880 Hz).
  - **Asteroid Sound:** Low-frequency explosion impact (lowpass filtered noise burst + sub-bass thud).

---

### 6. LOCAL STORAGE PERSISTENCE & GAME STATES
- **Persistent Data:** Save **High Score**, **Total Planets Caught**, and **Games Played** in `localStorage`.
- **Mid-Game Pause & Save:** Pressing Pause/Esc pauses game loop and saves game state (`currentScore`, `lives`, active falling items) to `localStorage`.
- **Continue Game:** Show a "Continue Saved Game" button on the main menu when a saved session exists.
- **Reset Data:** Include a "Reset Data" button with confirmation prompt to wipe all saved stats.

---

### 7. FILE STRUCTURE REQUIREMENT
1. `index.html`: Fully semantic markup containing HUD, game stage, and modal overlays (Start, Pause, Game Over). Imports Google Fonts ('Orbitron' & 'Inter').
2. `style.css`: Contains CSS palette variables, viewport setup, starfield animations, pure CSS planet/asteroid graphics, and modal styles.
3. `script.js`: Clean JavaScript file containing the `requestAnimationFrame` game engine, AABB collision detection, Web Audio API sound generator, lerp controller, and `localStorage` state manager.
```

eof