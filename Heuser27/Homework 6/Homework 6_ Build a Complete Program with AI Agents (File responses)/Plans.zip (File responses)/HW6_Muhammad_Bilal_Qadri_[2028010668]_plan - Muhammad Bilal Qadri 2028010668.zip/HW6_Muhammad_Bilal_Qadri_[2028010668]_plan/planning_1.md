# Planning Document — 2D Catch Game

> **Purpose:** Step-by-step implementation plan for building a 2D Catch Game using vanilla HTML, CSS, and JavaScript.  
> **Source Spec:** [catch_game_specification_prompt.md](file:///c:/Users/SM Computer/Downloads/catch_game_specification_prompt.md)  
> **Date:** 2026-10-26

---

## 1. Project Structure

```
catch_game/
├── index.html      # HTML structure & markup
├── style.css       # All visual styling
└── script.js       # Game logic & rendering
```

No build tools, no frameworks — everything is vanilla web tech.

---

## 2. High-Level Architecture

The game has exactly **three states**: **Start Screen → Active Game Loop → Game Over**.

- **Start Screen** → (user clicks "Start Game") → **Active Game**
- **Active Game** → (lives reach 0) → **Game Over**
- **Game Over** → (user clicks "Play Again") → **Start Screen**

All transitions are triggered by user actions or game conditions.

---

## 3. File-by-File Breakdown

### 3.1 `index.html`

| Element | Tag / Approach | Notes |
|---|---|---|
| Document shell | `<!DOCTYPE html>`, semantic HTML5 | Link `style.css` in `<head>`, `script.js` via `<script>` at end of `<body>` |
| Game container | `<canvas id="gameCanvas">` | Fixed-size rectangular play area (e.g., 480 × 640 px) |
| Score display | `<div id="scoreBoard">` | Shows current score, positioned top-left |
| Lives display | `<div id="livesCounter">` | Shows remaining lives (e.g., heart icons or number), positioned top-right |
| Start overlay | `<div id="startScreen">` | Contains game title, brief instructions, and a **"Start Game"** `<button>` |
| Game-over overlay | `<div id="gameOverScreen">` | Shows final score and a **"Play Again"** `<button>` |

**Key point:** Overlays sit on top of the canvas and are toggled via CSS classes (e.g., `.hidden`). The canvas itself is always present underneath.

---

### 3.2 `style.css`

**Layout**
- Center the game container on the page using `flexbox` on `<body>`.
- Give the canvas a solid border or subtle shadow to define the play-area boundary.
- Use a dark or themed background outside the canvas for contrast.

**Overlays (Start & Game Over)**
- Position `absolute` over the canvas, full width/height.
- Semi-transparent dark backdrop (`rgba(0,0,0,0.7)`).
- White/light text centered vertically and horizontally.
- Styled buttons with hover/active states.

**HUD (Score & Lives)**
- Position `absolute` inside the game container, top corners.
- Bold, readable font (sans-serif, ~18-20 px).

**Item Color Scheme**

| Item Type | Color Palette | Example Shape |
|---|---|---|
| Good items (Stars/Coins) | Gold / Green (`#FFD700`, `#4CAF50`) | Circle or star |
| Bad items (Bombs) | Red / Dark (`#F44336`, `#333`) | Circle with "X" or spiky shape |

**Player Paddle**
- Distinct color (blue or white), rounded rectangle.

---

### 3.3 `script.js` — Detailed Module Plan

#### 3.3.1 Constants & Configuration

Define these at the top of the file:

- `CANVAS_WIDTH`, `CANVAS_HEIGHT`
- `PADDLE_WIDTH`, `PADDLE_HEIGHT`, `PADDLE_SPEED`
- `ITEM_SIZE` (radius or side length)
- `ITEM_BASE_SPEED`, `SPEED_INCREMENT` (for difficulty scaling)
- `SPAWN_INTERVAL_MS` (starting interval, e.g., 1000 ms)
- `GOOD_ITEM_CHANCE` (probability, e.g., 0.7 = 70% good items)
- `SCORE_PER_CATCH = +10`
- `STARTING_LIVES = 3`

#### 3.3.2 State Variables

- `score` : number — current score, starts at 0
- `lives` : number — current lives, starts at `STARTING_LIVES`
- `gameActive` : boolean — true while the game loop runs
- `itemsArray` : Item[] — pool of currently active falling items
- `player` : `{ x, y, width, height }` — paddle position
- `spawnTimer` : number — interval/counter ID for spawning items

#### 3.3.3 Player Object & Input Handling

- **Keyboard:** Listen for `keydown` / `keyup` on `ArrowLeft`, `ArrowRight`, `A`, `D`.
  - Track pressed state in a `keys` map so movement is smooth (per-frame, not per-event).
- **Mouse / Touch:** Listen for `mousemove` / `touchmove` on the canvas.
  - Set `player.x` to pointer X minus half paddle width, clamped to boundaries.
- **Boundary clamping:** Every frame, ensure `0 ≤ player.x ≤ CANVAS_WIDTH - PADDLE_WIDTH`.

#### 3.3.4 Item (Falling Object) Data Model

Each item is a plain object (or class instance) with:

- `x` : number — random in `[0, CANVAS_WIDTH - ITEM_SIZE]`
- `y` : number — starts at 0
- `speed` : number — downward velocity (px per frame)
- `type` : `'good'` or `'bad'`

**Spawning logic:**
1. A spawn function runs on a timer (`setInterval`) or a frame counter.
2. Each call creates one item with a random X, Y = 0, and a random type based on `GOOD_ITEM_CHANCE`.
3. Push the new item into `itemsArray`.
4. Optionally decrease `SPAWN_INTERVAL_MS` over time to ramp difficulty.

#### 3.3.5 Collision Detection (AABB)

Use Axis-Aligned Bounding Box collision:

```
isColliding(item, player):
    item.x < player.x + player.width
    AND item.x + ITEM_SIZE > player.x
    AND item.y < player.y + player.height
    AND item.y + ITEM_SIZE > player.y
```

- Check every item against the paddle each frame.
- On collision with a **good** item → `score += SCORE_PER_CATCH`, remove item.
- On collision with a **bad** item → `lives -= 1`, remove item, flash screen or play effect.
- If `lives <= 0` → trigger Game Over.

#### 3.3.6 Game Loop (`requestAnimationFrame`)

Each frame executes these steps in order:

1. `clearCanvas()` — wipe the previous frame
2. `updatePlayerPosition()` — apply keyboard input + clamping
3. `updateItems()` — move each item down by its speed
4. `checkCollisions()` — AABB checks, update score/lives
5. `removeOffscreenItems()` — items past bottom edge → splice from array
6. `renderPlayer()` — draw paddle
7. `renderItems()` — draw each item with type-based color
8. `renderHUD()` — update score & lives text
9. `requestAnimationFrame(gameLoop)` — schedule next frame

**Tip:** Use `timestamp` (or delta time) to make movement frame-rate-independent if desired. For simplicity, a fixed per-frame step also works at 60 fps.

#### 3.3.7 Game State Transitions

| Transition | Trigger | Actions |
|---|---|---|
| **Start → Active** | "Start Game" button click | Hide start overlay, reset `score`, `lives`, `itemsArray`, start spawn timer, call `requestAnimationFrame(gameLoop)` |
| **Active → Game Over** | `lives` reaches 0 | Set `gameActive = false`, clear spawn timer, show game-over overlay with final score |
| **Game Over → Start** | "Play Again" button click | Same as Start → Active (full reset) |

#### 3.3.8 Memory & Performance Considerations

- **Remove items** from `itemsArray` as soon as they are caught or leave the bottom edge. Filter or splice in-place each frame.
- **Clear the spawn timer** (`clearInterval`) on game over to stop creating new items.
- Avoid creating closures or DOM elements per item — everything is canvas-drawn.

---

## 4. Implementation Order (Recommended Steps)

### Step 1 — HTML Skeleton + CSS Layout
- Create `index.html` with canvas, overlays, HUD divs.
- Create `style.css` with centered layout, overlay styles, HUD positioning.
- **Verify:** Page loads, canvas visible, overlays display on top.

### Step 2 — Canvas Setup & Draw Paddle
- In `script.js`, grab canvas context (`2d`).
- Draw a static paddle rectangle at bottom-center.
- **Verify:** Paddle renders on canvas.

### Step 3 — Player Input
- Add keyboard listeners (`keydown`/`keyup`) for arrow keys and A/D.
- Add mouse/touch listener for pointer-based movement.
- Move paddle each frame, clamp to boundaries.
- **Verify:** Paddle moves smoothly left/right, stops at edges.

### Step 4 — Item Spawning & Rendering
- Implement spawn function (random X, random type).
- Start a `setInterval` to spawn items.
- Each frame, move items downward and draw them (gold circles for good, red circles for bad).
- Remove items that pass the bottom edge.
- **Verify:** Items fall continuously, different colors visible, no memory buildup.

### Step 5 — Collision Detection & Score / Lives
- Implement AABB collision check.
- On good-item catch → increment score, remove item.
- On bad-item catch → decrement lives, remove item.
- Update HUD text each frame.
- **Verify:** Score increases on catching gold items, lives decrease on catching red items.

### Step 6 — Game State Management
- Wire "Start Game" button to reset state and begin loop.
- Wire game-over condition (`lives <= 0`) to stop loop and show overlay.
- Wire "Play Again" button to full reset.
- **Verify:** Full play cycle works: start → play → die → game over → restart.

### Step 7 — Polish & Difficulty Scaling
- Gradually increase item fall speed or decrease spawn interval over time.
- Add visual feedback (screen flash on hit, brief particle on catch).
- Ensure clean code structure, add comments.
- Final cross-browser test (Chrome, Firefox, Edge).

---

## 5. Edge Cases & Testing Checklist

- [ ] Paddle cannot move outside canvas left/right boundaries.
- [ ] Items spawn within valid X range (not clipped off-screen).
- [ ] Catching the last life triggers Game Over immediately.
- [ ] Score does not go negative (if bad items deduct points instead of lives).
- [ ] "Play Again" fully resets all state — no leftover items or stale score.
- [ ] No memory leaks — `itemsArray` length stays bounded during long play sessions.
- [ ] Game loop stops cleanly on Game Over (no orphaned `requestAnimationFrame` calls).
- [ ] Keyboard input doesn't scroll the page while playing.
- [ ] Touch input works on mobile if desired.

---

## 6. Optional Enhancements (Post-MVP)

| Enhancement | Difficulty |
|---|---|
| Sound effects (catch, hit, game over) | Low |
| Particle/explosion animation on catch | Medium |
| High-score persistence (`localStorage`) | Low |
| Progressive difficulty levels with UI indicator | Medium |
| Responsive canvas sizing | Medium |
| Pause/Resume functionality | Low |

---

> **Note:** This plan covers the full scope of the specification. No code should be written until this plan is reviewed and approved. Each step above is designed to be independently testable before moving to the next.
