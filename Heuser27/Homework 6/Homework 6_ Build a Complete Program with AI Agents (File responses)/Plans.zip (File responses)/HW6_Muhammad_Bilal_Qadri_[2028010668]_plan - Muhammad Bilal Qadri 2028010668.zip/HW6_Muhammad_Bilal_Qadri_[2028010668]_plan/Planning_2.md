# Planning 2: Upgrade Galaxy Catch Game to Match Space-Theme Specification

> **Context** — Vanilla-web catch game located in `index.html`, `style.css`, and `script.js`. Refactored to fully conform to the space-theme DOM specification while keeping gameplay intact.

---

## 1. Current State Summary

| Aspect | Implementation |
|---|---|
| **Rendering** | Switch from `<canvas>` to pure DOM elements inside `#playArea` |
| **Color palette** | Strict palette variables: `--onyx`, `--pale-sky`, `--velvet-orchid`, `--bubblegum-fizz` and their gradients |
| **Good items** | Glowing planets styled with pure CSS, gradients, and pseudo-element rings (`.planet-pink`, `.planet-blue`) |
| **Bad items** | Asteroids styled with pure CSS irregular shapes (`clip-path` / asymmetric `border-radius`), crater insets |
| **Player** | Cosmic shield / basket catcher `#player` styled with glow and pure CSS |
| **Background** | Deep space `--galaxy-bg` with procedural CSS `box-shadow` star field |
| **CSS variables** | Mandatory 4-color space theme palette |
| **HTML overlays** | Clean HUD and overlays using theme styling |

---

## 2. Target Specification & Architecture

### 2.1 Color Palette — Mandatory CSS Variables

```css
:root {
  /* Color Palette Variables */
  --onyx: #090c08;
  --pale-sky: #b9d6f2;
  --velvet-orchid: #631d76;
  --bubblegum-fizz: #e365c1;

  /* Color Variations */
  --onyx-hsl: hsla(105, 20%, 4%, 1);
  --pale-sky-hsl: hsla(209, 69%, 84%, 1);
  --velvet-orchid-hsl: hsla(287, 61%, 29%, 1);
  --bubblegum-fizz-hsl: hsla(316, 69%, 64%, 1);

  /* Pre-configured Gradients */
  --galaxy-bg: radial-gradient(circle at center, #631d76 0%, #090c08 80%);
  --planet-gradient-1: radial-gradient(circle at 30% 30%, #e365c1, #631d76);
  --planet-gradient-2: radial-gradient(circle at 30% 30%, #b9d6f2, #631d76);
  --asteroid-gradient: radial-gradient(circle at 40% 40%, #631d76, #090c08);
}
```

### 2.2 DOM-Based Rendering Architecture
- Remove canvas completely.
- `#playArea` serves as the coordinate space (`480px` by `640px`, relative positioning, hidden overflow).
- Falling items are `<div>` elements with absolute positioning (`top`, `left`, `width`, `height`).
- Player is `#player` within `#playArea`, styled as a cosmic energy basket / shield.
- Items are spawned into `#playArea` and removed upon collision or passing beyond the lower boundary.

### 2.3 Pure CSS Art Specification
- **Starfield**: Created via pseudo-element on `.game-container` or `.play-area` using multi-point `box-shadow` pale-sky stars.
- **Planets (Good items)**: Circular `border-radius: 50%` with `--planet-gradient-1` or `--planet-gradient-2`. Saturn-like rings via `::before` or `::after` with elliptical borders and rotation.
- **Asteroids (Bad items)**: Asymmetric rocky geometry with `clip-path: polygon(...)` or organic `border-radius`, styled with `--asteroid-gradient` and crater shadows.
- **Player (Cosmic Shield)**: Shield/basket arc with glowing borders and box-shadow using `--pale-sky` and `--bubblegum-fizz`.

### 2.4 Mechanics & Controls
- Arrow keys (`ArrowLeft`, `ArrowRight`) & `A` / `D`.
- Mouse & Touch drag tracking within `#playArea`.
- Score tracking (+10 for planets, -1 life for asteroids).
- Screen shake and damage flash on asteroid hit.
- Difficulty scaling: falling speed and spawn rate increase with score.
