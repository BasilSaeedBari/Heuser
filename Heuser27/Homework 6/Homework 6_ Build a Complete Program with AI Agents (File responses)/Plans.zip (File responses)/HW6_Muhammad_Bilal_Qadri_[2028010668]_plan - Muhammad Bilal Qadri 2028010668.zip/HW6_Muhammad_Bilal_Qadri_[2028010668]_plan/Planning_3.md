# Planning 3: Enhanced Galaxy Catch Game — Wide-Screen, Procedural Audio & Visual Polish

> **Context** — Upgrade the existing DOM-based space-themed catch game (`index.html`, `style.css`, `script.js`) to satisfy every requirement in the [Enhanced Specification](file:///c:/Users/SM%20Computer/Downloads/enhanced_galaxy_catch_game_specification_prompt.md).  
> **Predecessor Plans:** [Planning_1](file:///d:/crp_heuser/catch_game/planning_1.md) · [Planning_2](file:///d:/crp_heuser/catch_game/Planning_2.md)  
> **Date:** 2026-10-27

---

## 0. Gap Analysis — Current State vs Enhanced Spec

| Requirement | Current State | Action Needed |
|---|---|---|
| **Wide-screen layout (100vw × 100vh)** | Fixed 480 × 640 px box | Refactor to full-viewport playfield |
| **Pointer Lock / boundary clamping** | Basic clamp on 480 px | Full viewport-width clamping + optional Pointer Lock API |
| **Web Audio API — procedural sounds** | None | Implement `AudioContext` synth for planet chime & asteroid explosion |
| **AudioContext init on user gesture** | N/A | Initialize `AudioContext` inside "Start Game" click handler |
| **CSS palette: `--asteroid-dark` & `--asteroid-crater`** | Missing; asteroid uses old gradient | Add variables `#030403`, `#141a12`; update gradient |
| **Updated `--galaxy-bg` gradient** | Ends at 80% | Change end stop to 85% per spec |
| **Updated `--asteroid-gradient`** | Uses orchid → onyx at 40% highlight | Switch to crater → dark at 30% highlight |
| **Google Font (modern/sci-fi)** | System fallback fonts only | Import `Orbitron` (headings) + `Inter` (body) from Google Fonts |
| **Smooth lerp player movement** | Instant per-frame step | Add linear interpolation (lerp) target tracking |
| **CSS rotation animations on items** | JS manual rotation per frame | Add `@keyframes` CSS spin; apply via class |
| **Asteroid deep-black treatment** | Orchid-tinted gradient | Re-style with `--asteroid-dark` / `--asteroid-crater` |

---

## 1. File-by-File Change Plan

### 1.1 `style.css` — Visual & Layout Overhaul

#### 1.1.1 CSS Custom Properties Update

Add the two new asteroid tone variables and update the pre-configured gradients to match the spec exactly:

```css
:root {
  /* Existing palette — unchanged */
  --onyx: #090c08;
  --pale-sky: #b9d6f2;
  --velvet-orchid: #631d76;
  --bubblegum-fizz: #e365c1;

  /* HSL variations — unchanged */
  --onyx-hsl: hsla(105, 20%, 4%, 1);
  --pale-sky-hsl: hsla(209, 69%, 84%, 1);
  --velvet-orchid-hsl: hsla(287, 61%, 29%, 1);
  --bubblegum-fizz-hsl: hsla(316, 69%, 64%, 1);

  /* ✅ NEW — Deep Black Asteroid Tone */
  --asteroid-dark: #030403;
  --asteroid-crater: #141a12;

  /* ✅ UPDATED — Pre-configured Gradients */
  --galaxy-bg: radial-gradient(circle at center, #631d76 0%, #090c08 85%);
  --planet-gradient-1: radial-gradient(circle at 30% 30%, #e365c1, #631d76);
  --planet-gradient-2: radial-gradient(circle at 30% 30%, #b9d6f2, #631d76);
  --asteroid-gradient: radial-gradient(circle at 30% 30%, var(--asteroid-crater), var(--asteroid-dark));
}
```

**Changes:**
- Add `--asteroid-dark: #030403` and `--asteroid-crater: #141a12`.
- Change `--galaxy-bg` end stop from `80%` → `85%`.
- Change `--asteroid-gradient` from `(circle at 40% 40%, #631d76, #090c08)` → `(circle at 30% 30%, var(--asteroid-crater), var(--asteroid-dark))`.

#### 1.1.2 Google Font Import

At the very top of `style.css`:

```css
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&family=Orbitron:wght@500;700;900&display=swap');
```

Apply:
- `font-family: 'Orbitron', sans-serif;` → overlay headings (`h1`, `h2`), HUD items.
- `font-family: 'Inter', sans-serif;` → body text, instructions, buttons.

#### 1.1.3 Wide-Screen Full-Viewport Layout

**Remove** the fixed 480 × 640 px container. Instead:

```css
.game-container {
  position: relative;
  width: 100vw;
  height: 100vh;
  background: var(--galaxy-bg);
  overflow: hidden;
  border: none;
  border-radius: 0;
  box-shadow: none;
}
```

- `.game-wrapper` → remove padding, make it fill viewport.
- `body` → keep flex centering, ensure `margin: 0; overflow: hidden;`.
- `.play-area` → stays `width: 100%; height: 100%; position: relative; overflow: hidden;`.

#### 1.1.4 Starfield Scaling

Scale the existing `::before` and `::after` box-shadow star positions to span the viewport more evenly. Use `vw`/`vh` units or significantly more star points spread across the wider canvas. Consider duplicating star layers for density.

#### 1.1.5 Asteroid Restyle (Deep Black)

```css
.asteroid {
  width: 32px;
  height: 32px;
  background: var(--asteroid-gradient);
  border-radius: 42% 58% 65% 35% / 45% 38% 62% 55%;
  border: 1px solid var(--asteroid-crater);
  box-shadow:
    inset -4px -4px 6px var(--asteroid-dark),
    inset 2px 2px 4px var(--asteroid-crater),
    0 0 6px rgba(3, 4, 3, 0.8);
}

.asteroid::before {
  /* Craters now reference deep-black palette */
  background: var(--asteroid-dark);
  box-shadow: 10px 9px 0 -1px var(--asteroid-dark),
              inset 1px 1px 1px var(--asteroid-crater);
}

.asteroid::after {
  background: var(--asteroid-dark);
  box-shadow: inset 1px 1px 1px var(--asteroid-crater);
}
```

#### 1.1.6 CSS Rotation Keyframes for Items

```css
@keyframes itemSpin {
  from { transform: rotate(0deg); }
  to   { transform: rotate(360deg); }
}

@keyframes itemSpinReverse {
  from { transform: rotate(0deg); }
  to   { transform: rotate(-360deg); }
}
```

Apply via JS-assigned class or inline style:
- Planets: `animation: itemSpin <random 4-8s> linear infinite;`
- Asteroids: `animation: itemSpinReverse <random 3-6s> linear infinite;`

> This replaces the current manual per-frame `item.rotation += item.rotSpeed` approach. JS will still control `top` / `left` position, but rotation is pure CSS.

#### 1.1.7 Player Catcher — Smoothness

Remove the `transition: box-shadow 0.15s ease;` only styling. Add:

```css
.player-catcher {
  /* Position now controlled by JS lerp via transform: translateX() */
  transition: none; /* JS handles smooth lerp — no CSS transition on transform */
  left: 0;
}
```

#### 1.1.8 Responsive HUD & Overlays

- HUD padding and font sizes remain, but use `clamp()` for responsive sizing:
  ```css
  .hud-item {
    font-family: 'Orbitron', sans-serif;
    font-size: clamp(0.9rem, 1.5vw, 1.3rem);
  }
  ```
- Overlay `max-width: 500px;` instead of 400 px to breathe on wide screens.

---

### 1.2 `index.html` — Minimal Changes

#### 1.2.1 Font Import (alternative to CSS `@import`)

Add to `<head>`:

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&family=Orbitron:wght@500;700;900&display=swap" rel="stylesheet">
```

> Prefer `<link>` over CSS `@import` for faster font loading. Use one approach — not both.

#### 1.2.2 Structure

No structural HTML changes needed. The existing `#playArea`, `#player`, HUD, overlays, and buttons all remain. The wide-screen expansion is handled entirely in CSS and JS constants.

---

### 1.3 `script.js` — Audio, Lerp, and Viewport Adaptation

#### 1.3.1 Dynamic Viewport Dimensions

Replace static constants:

```js
// Instead of fixed 480 × 640:
let FIELD_WIDTH = window.innerWidth;
let FIELD_HEIGHT = window.innerHeight;

// Re-calculate on resize
window.addEventListener('resize', () => {
  FIELD_WIDTH = window.innerWidth;
  FIELD_HEIGHT = window.innerHeight;
  // Re-clamp player position after resize
  clampPlayerPosition();
});
```

Update all references to `FIELD_WIDTH` / `FIELD_HEIGHT` (spawning, boundary checks, player positioning).

#### 1.3.2 Web Audio API — Procedural Sound Engine

```js
let audioCtx = null;

function initAudio() {
  if (!audioCtx) {
    audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  }
  // Resume if suspended (autoplay policy)
  if (audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
}
```

**Call `initAudio()` inside `startGame()` — triggered by user click (satisfies browser autoplay policy).**

##### Planet Catch Sound — Ascending Chime

```js
function playPlanetSound() {
  if (!audioCtx) return;
  const now = audioCtx.currentTime;

  const osc = audioCtx.createOscillator();
  const gain = audioCtx.createGain();

  osc.type = 'sine';
  osc.frequency.setValueAtTime(440, now);
  osc.frequency.exponentialRampToValueAtTime(880, now + 0.15);

  gain.gain.setValueAtTime(0.3, now);
  gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);

  osc.connect(gain);
  gain.connect(audioCtx.destination);

  osc.start(now);
  osc.stop(now + 0.35);
}
```

##### Asteroid Explosion Sound — Low-Frequency Impact

```js
function playAsteroidSound() {
  if (!audioCtx) return;
  const now = audioCtx.currentTime;

  // Noise-based explosion
  const bufferSize = audioCtx.sampleRate * 0.3; // 300ms of noise
  const noiseBuffer = audioCtx.createBuffer(1, bufferSize, audioCtx.sampleRate);
  const data = noiseBuffer.getChannelData(0);
  for (let i = 0; i < bufferSize; i++) {
    data[i] = (Math.random() * 2 - 1);
  }

  const noise = audioCtx.createBufferSource();
  noise.buffer = noiseBuffer;

  // Low-pass filter to shape explosion
  const filter = audioCtx.createBiquadFilter();
  filter.type = 'lowpass';
  filter.frequency.setValueAtTime(150, now);
  filter.frequency.exponentialRampToValueAtTime(30, now + 0.25);

  // Gain envelope
  const gain = audioCtx.createGain();
  gain.gain.setValueAtTime(0.5, now);
  gain.gain.exponentialRampToValueAtTime(0.001, now + 0.3);

  noise.connect(filter);
  filter.connect(gain);
  gain.connect(audioCtx.destination);

  noise.start(now);
  noise.stop(now + 0.3);

  // Sub-bass thud layer
  const osc = audioCtx.createOscillator();
  const oscGain = audioCtx.createGain();
  osc.type = 'sawtooth';
  osc.frequency.setValueAtTime(150, now);
  osc.frequency.exponentialRampToValueAtTime(30, now + 0.2);
  oscGain.gain.setValueAtTime(0.4, now);
  oscGain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);

  osc.connect(oscGain);
  oscGain.connect(audioCtx.destination);
  osc.start(now);
  osc.stop(now + 0.25);
}
```

**No external files — fully procedural via `AudioContext`.**

##### Integration Points

- Call `playPlanetSound()` in collision handler when `item.type === 'good'`.
- Call `playAsteroidSound()` in collision handler when `item.type === 'bad'`.

#### 1.3.3 Smooth Player Movement — Linear Interpolation (Lerp)

Replace the current instant-step keyboard movement with lerp-based tracking:

```js
let playerTargetX = player.x;
const LERP_FACTOR = 0.15; // Smoothing factor (0 = no move, 1 = instant)

function lerp(current, target, factor) {
  return current + (target - current) * factor;
}

function updatePlayerPosition() {
  // Keyboard input adjusts target, not position directly
  if (keys.ArrowLeft || keys.KeyA) {
    playerTargetX -= PADDLE_SPEED;
  }
  if (keys.ArrowRight || keys.KeyD) {
    playerTargetX += PADDLE_SPEED;
  }

  // Clamp target
  playerTargetX = Math.max(0, Math.min(FIELD_WIDTH - player.width, playerTargetX));

  // Lerp actual position toward target
  player.x = lerp(player.x, playerTargetX, LERP_FACTOR);

  clampPlayerPosition();
  renderPlayerPosition();
}
```

For mouse/touch input, set `playerTargetX` to the pointer position (instead of setting `player.x` directly).

#### 1.3.4 Pointer Lock (Optional Enhancement)

```js
function requestPointerLock() {
  playArea.requestPointerLock = playArea.requestPointerLock || playArea.mozRequestPointerLock;
  playArea.requestPointerLock();
}

document.addEventListener('pointerlockchange', () => {
  if (document.pointerLockElement === playArea) {
    document.addEventListener('mousemove', handleLockedMouseMove);
  } else {
    document.removeEventListener('mousemove', handleLockedMouseMove);
  }
});

function handleLockedMouseMove(e) {
  playerTargetX += e.movementX;
  playerTargetX = Math.max(0, Math.min(FIELD_WIDTH - player.width, playerTargetX));
}
```

**Fallback:** If pointer lock is not available or user declines, the current absolute mouse tracking with lerp smoothing applies as the baseline approach.

#### 1.3.5 CSS-Driven Item Rotation (Remove JS Rotation)

When creating an item element, assign a CSS animation instead of manually updating `rotation` each frame:

```js
function createItemElement(type, planetType) {
  const itemEl = document.createElement('div');
  itemEl.classList.add('game-item');

  if (type === 'good') {
    itemEl.classList.add('planet', planetType);
  } else {
    itemEl.classList.add('asteroid');
  }

  // CSS rotation — random duration and direction
  const duration = (Math.random() * 4 + 3).toFixed(2); // 3s–7s
  const direction = Math.random() < 0.5 ? 'normal' : 'reverse';
  itemEl.style.animation = `itemSpin ${duration}s linear infinite ${direction}`;

  playArea.appendChild(itemEl);
  return itemEl;
}
```

Remove `item.rotation` and `item.rotSpeed` from the item data model. Remove the `item.el.style.transform = rotate(...)` line from `updateItemsAndCheckCollisions()`.

#### 1.3.6 Player Position Rendering Update

Since the player is now positioned within a full-viewport container, the default CSS `left: 195px` (centered for 480 px) must be replaced:

```js
// In startGame():
player.x = (FIELD_WIDTH - PADDLE_WIDTH) / 2;
playerTargetX = player.x;
```

The `renderPlayerPosition()` function remains: `playerEl.style.transform = translateX(${player.x}px);`  
But the CSS `left` property on `.player-catcher` should be `0` (position driven entirely by `translateX`).

---

## 2. Implementation Order

### Phase 1 — CSS & Layout (non-breaking)

| Step | Task | Verify |
|---|---|---|
| 1a | Add `--asteroid-dark`, `--asteroid-crater` variables and update gradient definitions in `:root` | Variables exist, no visual regression on load |
| 1b | Add Google Font `<link>` to `index.html <head>` | Fonts load (check Network tab) |
| 1c | Apply `Orbitron` to headings/HUD, `Inter` to body/buttons | Text renders in correct fonts |
| 1d | Convert `.game-container` to `100vw × 100vh` | Game fills viewport |
| 1e | Scale starfield box-shadow positions for wide viewport | Stars visible across full screen |
| 1f | Restyle asteroids with deep-black palette | Asteroids appear near-black, distinct from planets |
| 1g | Add `@keyframes itemSpin` / `itemSpinReverse` to CSS | Keyframes defined (not yet applied) |

### Phase 2 — JavaScript Logic Changes

| Step | Task | Verify |
|---|---|---|
| 2a | Replace static `FIELD_WIDTH`/`FIELD_HEIGHT` with dynamic viewport values + resize listener | Game adapts to window size changes |
| 2b | Implement `initAudio()`, `playPlanetSound()`, `playAsteroidSound()` | Sounds play on catch (test manually) |
| 2c | Wire `initAudio()` into `startGame()` click handler | AudioContext created on first click |
| 2d | Wire `playPlanetSound()` / `playAsteroidSound()` into collision handler | Correct sound plays per item type |
| 2e | Implement lerp-based `updatePlayerPosition()` with `playerTargetX` | Player glides smoothly instead of snapping |
| 2f | Update `handlePointerMove()` to set `playerTargetX` | Mouse input produces smooth tracking |
| 2g | Switch item rotation from JS per-frame to CSS animation in `createItemElement()` | Items rotate smoothly via CSS; no transform jank |
| 2h | Remove `item.rotation`, `item.rotSpeed`, and JS transform rotation line | Clean item data model |

### Phase 3 — Polish & Testing

| Step | Task | Verify |
|---|---|---|
| 3a | Test full play cycle: Start → Play → Die → Game Over → Restart | All states work; no stale audio nodes |
| 3b | Test resize behavior (drag browser window, F11 fullscreen) | Layout adapts; player stays in bounds |
| 3c | Test on Chrome, Firefox, Edge | Consistent rendering and audio |
| 3d | Verify memory: no leaked DOM nodes or AudioContext nodes | Performance tab shows stable node count |
| 3e | Optional: add Pointer Lock API with graceful fallback | Pointer lock engages on click; ESC exits cleanly |

---

## 3. Specification Compliance Checklist

- [x] **Wide-screen (100vw × 100vh)** — Phase 1d
- [x] **Pointer boundary clamping** — Phase 2a (viewport-width `Math.min`/`Math.max`)
- [x] **Web Audio API — no external files** — Phase 2b/2c/2d
- [x] **Planet chime: sine 440→880 Hz ascending** — Phase 2b
- [x] **Asteroid explosion: filtered noise + sawtooth 150→30 Hz** — Phase 2b
- [x] **AudioContext init on user gesture** — Phase 2c
- [x] **CSS art: galaxy bg, twinkling stars, planet gradients, asteroid deep-black** — Phase 1a/1e/1f
- [x] **`--asteroid-dark: #030403`**, **`--asteroid-crater: #141a12`** — Phase 1a
- [x] **Updated `--asteroid-gradient`** — Phase 1a
- [x] **Updated `--galaxy-bg` (85%)** — Phase 1a
- [x] **Google Font (Orbitron + Inter)** — Phase 1b/1c
- [x] **Smooth lerp player movement** — Phase 2e/2f
- [x] **CSS rotation animations on falling items** — Phase 1g + 2g
- [x] **Controls: ArrowLeft/Right, A/D, mouse** — Already implemented
- [x] **Scoring: +10 planet, -1 life asteroid** — Already implemented
- [x] **AABB collision detection** — Already implemented
- [x] **Game states: Start → Active → Game Over** — Already implemented
- [x] **3-file structure: `index.html`, `style.css`, `script.js`** — Already implemented

---

## 4. Risk Notes

| Risk | Mitigation |
|---|---|
| Google Fonts blocked offline | Include fallback: `font-family: 'Orbitron', 'Segoe UI', sans-serif;` |
| AudioContext may be blocked by browser | `initAudio()` inside click handler + `resume()` on suspended state |
| Wide-screen starfield looks sparse | Add more box-shadow star points; consider a generated star layer via JS |
| Lerp makes keyboard feel "floaty" | Tune `LERP_FACTOR` (0.12–0.20); direct keyboard can use higher factor than mouse |
| CSS animation conflicts with JS positioning | Only `top`/`left` via JS; only `rotate` via CSS animation — no overlap |

---

> **Next step:** Review and approve this plan, then proceed with implementation following the phased order above. No code changes should be made until this plan is accepted.
