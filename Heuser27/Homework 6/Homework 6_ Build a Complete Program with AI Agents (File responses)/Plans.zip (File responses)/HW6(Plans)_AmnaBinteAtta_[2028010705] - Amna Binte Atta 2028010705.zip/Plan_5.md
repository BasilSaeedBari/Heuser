# Stage 5 Architecture & Debugging Plan: Hardening, Polish & Edge-Case Resilience
**Project:** Neon Sequence — Pattern Memory Game  
**Document:** `Plan_5.md`  
**Phase:** Stage 5 — System Verification, Dynamic Diagnostics & Final Arcade Polish  

---

## 1. Architectural Overview & Scope of Stage 5

Stage 5 represents the final hardening, stress-testing, and stabilization phase for Neon Sequence. Having implemented the core deterministic logic (Stage 1), neon visual architecture (Stage 2), Web Audio and sensory feedback (Stage 3), and persistent state storage with pause/resume controls (Stage 4), Stage 5 subjects the system to exhaustive boundary conditions, asynchronous timing races, environmental variations, and fault-injection scenarios.

### 1.1 Objectives
1. **Stress & Concurrency Hardening:** Validate that high-frequency player input, rapid state switching, and timer interruptions cannot corrupt internal states or leave orphaned Web Audio nodes.
2. **Environmental & Browser Fault Tolerance:** Ensure graceful degradation against background tab throttling (`visibilitychange`), storage denial/corruption, missing audio hardware, and viewport constraints.
3. **Accessibility & Usability Polish:** Guarantee zero visual artifacts, fluid focus rings, clean typography contrast, and compliant reduced-motion transitions.
4. **Architectural Purity Verification:** Enforce zero external assets, exactly three self-contained files (`index.html`, `style.css`, `script.js`), and complete offline operability via direct file execution.

---

## 2. Comprehensive Debugging Protocols (Scenarios 1–18)

Each protocol defines a precise diagnostic lifecycle: Setup $\rightarrow$ Expected Behavior $\rightarrow$ Failure Signature $\rightarrow$ Root Cause Investigation $\rightarrow$ Fix Strategy $\rightarrow$ Regression Verification.

---

### Scenario 1: Rapid Clicking and Repeated Key Presses
* **Setup & Reproduction Steps:**
  1. Launch game to `PLAYER_TURN`.
  2. Rapidly spam mouse clicks on a single color button (10+ clicks in < 500ms).
  3. Rapidly tap the `Enter` or `Space` key while a button is focused.
* **Expected Behavior:** Each click registers synchronously and is validated in strict chronological order. If a click triggers `ROUND_SUCCESS` or `GAME_OVER`, all subsequent clicks within the burst are dropped immediately without double-scoring or overlapping timers.
* **Failure Signature:** Fractional scores, skipped sequence rounds, overlapping audio notes playing simultaneously, or `playerStepIndex` exceeding `sequence.length`.
* **Root Cause Investigation:** Inspect event queuing and synchronous lock execution in `onGridClick` and `handleColorClick`. Verify whether `isInputLocked = true` is set synchronously on line 1 of round completion before asynchronous delays.
* **Fix Strategy:** Enforce synchronous atomic state locking:
  ```javascript
  if (gameState.isInputLocked || gameState.currentState !== GAME_STATES.PLAYER_TURN) return;
  ```
  Immediately assign `gameState.isInputLocked = true;` the instant `playerStepIndex === sequence.length` prior to queuing `safeSetTimeout`.
* **Regression Test:** Spam clicks on the final step of Round 3. Verify score increments by exactly 1, exactly one success chime sounds, and subsequent clicks produce zero feedback.

---

### Scenario 2: Clicking During Sequence Playback
* **Setup & Reproduction Steps:**
  1. Start Round 2 or higher (sequence length $\ge 2$).
  2. While the computer is flashing the buttons, click all four color buttons repeatedly.
* **Expected Behavior:** Player clicks are completely ignored. No visual flashes, audio tones, or state changes occur. Playback completes unhindered and hands turn to player.
* **Failure Signature:** Buttons flash out of sequence, player input evaluates prematurely, or the game ends in an unexpected `GAME_OVER` during playback.
* **Root Cause Investigation:** Check CSS `pointer-events` on `.color-btn:disabled` and inspect guard checks in `onGridClick` and `handleColorClick`.
* **Fix Strategy:** Ensure `.color-btn:disabled` unconditionally specifies `pointer-events: none;` in `style.css`, and `script.js` enforces `if (gameState.currentState !== GAME_STATES.PLAYER_TURN) return;`.
* **Regression Test:** Click continuously while a 5-step sequence plays. Verify zero inputs register and turn transitions smoothly to `PLAYER_TURN` after the 5th flash.

---

### Scenario 3: Pausing During Sequence Playback
* **Setup & Reproduction Steps:**
  1. Advance to a round with $\ge 3$ steps.
  2. Click `#pause-btn` exactly as the second button illuminates.
* **Expected Behavior:** Playback halts immediately. Active highlight turns off instantly, audio tone stops without clicking or buzzing, all queued timers are purged, and the game enters `PAUSED`.
* **Failure Signature:** Remaining sequence steps continue flashing in the background, audio tone hangs indefinitely, or button remains permanently stuck in `.active` illuminated state.
* **Root Cause Investigation:** Check whether `clearAllTimers()` and `clearAllActiveHighlights()` execute synchronously inside `pauseGame()`.
* **Fix Strategy:** In `pauseGame()`, explicitly call `clearAllTimers()`, `clearAllActiveHighlights()`, and silence the Web Audio master output or running oscillators.
* **Regression Test:** Pause mid-flash during step 2 of 4. Confirm total visual and acoustic silence within 0ms.

---

### Scenario 4: Resuming After a Pause
* **Setup & Reproduction Steps:**
  1. Pause game during sequence playback (Scenario 3).
  2. Wait 3 seconds, then click `#pause-btn` (`"Resume"`).
* **Expected Behavior:** Sequence restarts from step 0 of the current round after a 600ms ready pause (`CONFIG.TIMING.RESUME_DELAY`). No sequence steps are added, skipped, or duplicated. Playback finishes and prompts player turn.
* **Failure Signature:** Sequence resumes with an extra step appended, starts mid-sequence with missing steps, or immediately prompts player turn without showing the sequence.
* **Root Cause Investigation:** Trace `resumeGame()` handling of `previousState === GAME_STATES.PLAYBACK`. Verify `playSequence()` is called without invoking `startRound()` (which appends new steps).
* **Fix Strategy:** In `resumeGame()`, if `previousState === PLAYBACK`, transition to `PLAYBACK`, lock input, and call `playSequence()` via `safeSetTimeout(..., 600)`. Never call `startRound()` upon playback resumption.
* **Regression Test:** Advance to Round 4 (`sequence.length === 4`), pause on step 2, resume, and count the playback flashes. Exactly 4 flashes must occur before player turn begins.

---

### Scenario 5: Restarting During an Animation or Sound Effect
* **Setup & Reproduction Steps:**
  1. Trigger an incorrect input to induce `GAME_OVER` (chassis vibrating via `.shake-error` and error buzz sounding).
  2. Click `"Play Again"` / `"Restart"` while the 350ms shake animation is still vibrating.
* **Expected Behavior:** Active shake animation strips immediately, sound halts, score resets to 0, sequence resets to empty, and Round 1 begins cleanly.
* **Failure Signature:** Cabinet continues shaking in Round 1, error sound overlaps with Round 1's starting tone, or Round 1 flashes two buttons instead of one.
* **Root Cause Investigation:** Verify whether `startNewGame()` cleans up CSS animation classes and terminates active Web Audio oscillators.
* **Fix Strategy:** Inside `resetGameState()`, invoke `clearAllActiveHighlights()` which explicitly removes `.shake-error`, `.status-success`, and `.active`.
* **Regression Test:** Fail a round and immediately click restart within 50ms. Confirm chassis is stationary and clean Round 1 sequence plays.

---

### Scenario 6: Multiple Rapid Restarts
* **Setup & Reproduction Steps:**
  1. Click `#start-btn` 5 times in rapid succession (< 300ms).
  2. Alternatively, rapidly click `"Play Again"` immediately upon game over.
* **Expected Behavior:** The first click initiates `startNewGame()`. Subsequent clicks are ignored because the button is disabled immediately. Only one sequence plays.
* **Failure Signature:** Multiple overlapping sequences play concurrently with overlapping audio tones; game sequence array contains duplicate rounds.
* **Root Cause Investigation:** Ensure `#start-btn.disabled = true;` occurs synchronously on line 1 of `onStartButtonClick()` before any asynchronous dispatch.
* **Fix Strategy:** Guard `#start-btn`:
  ```javascript
  if (gameState.currentState !== GAME_STATES.IDLE && gameState.currentState !== GAME_STATES.GAME_OVER && gameState.currentState !== GAME_STATES.PAUSED) return;
  startButton.disabled = true;
  ```
* **Regression Test:** Spam Start button on initial load. Confirm only a single tone sounds and sequence array length is strictly 1.

---

### Scenario 7: Resizing Browser or Narrow Viewport Adaptation
* **Setup & Reproduction Steps:**
  1. Open game in desktop browser.
  2. Open DevTools device emulator and resize viewport continuously down to $320\text{px} \times 480\text{px}$.
  3. Rotate orientation from portrait to landscape.
* **Expected Behavior:** Content scales fluidly. Button grid preserves square aspect ratios (`1 / 1`), dashboard counters remain legible without text collision, and zero horizontal scrollbars appear.
* **Failure Signature:** Color buttons overflow viewport edges, control buttons wrap awkwardly onto multiple lines, or horizontal scrollbars emerge.
* **Root Cause Investigation:** Check CSS max-widths, flex wrapping, and media query thresholds at `480px` and `360px`.
* **Fix Strategy:** Ensure `.game-container` has `max-width: 400px; width: 95vw;` and `body` specifies `overflow-x: hidden;`. In mobile media queries, allow `.dashboard-strip` and `.controls` to use flexible layout.
* **Regression Test:** Verify layout at 320px width; confirm no horizontal scrolling and all buttons are fully clickable.

---

### Scenario 8: Switching Tabs During Playback and Returning
* **Setup & Reproduction Steps:**
  1. Start Round 4 (long sequence).
  2. Switch to another browser tab immediately as sequence begins.
  3. Wait 5 seconds (allowing browser to throttle background `setTimeout` timers), then switch back.
* **Expected Behavior:** The game either automatically pauses sequence playback upon tab departure via `visibilitychange` or gracefully flushes throttled timers without rapid-fire audio burst.
* **Failure Signature:** Upon returning, all queued button flashes and audio tones fire simultaneously in a rapid, distorted stutter, or input unlocks prematurely.
* **Root Cause Investigation:** Browser background throttling de-prioritizes `setTimeout` execution while Web Audio scheduling continues, causing timeline desynchronization.
* **Fix Strategy:** Implement a Page Visibility API listener:
  ```javascript
  document.addEventListener('visibilitychange', () => {
    if (document.hidden && (gameState.currentState === GAME_STATES.PLAYBACK || gameState.currentState === GAME_STATES.PLAYER_TURN)) {
      pauseGame();
    }
  });
  ```
* **Regression Test:** Switch tabs during playback, return 10 seconds later, and confirm game is cleanly paused; clicking Resume replays sequence smoothly.

---

### Scenario 9: Missing or Corrupted localStorage Data
* **Setup & Reproduction Steps:**
  1. Open browser DevTools Console.
  2. Inject corrupted values: `localStorage.setItem('neon_seq_high_score', '{"corrupted": true}'); localStorage.setItem('neon_seq_muted', 'invalid_bool');`.
  3. Reload `index.html`.
* **Expected Behavior:** Game loads cleanly without throwing uncaught exceptions. High score defaults to `0`, mute defaults to `false` (`Sound: ON`).
* **Failure Signature:** White screen, JavaScript crash (`Uncaught SyntaxError`), or `High Score: NaN` displayed in the UI.
* **Root Cause Investigation:** Check type parsing in `loadStoredData()`.
* **Fix Strategy:** Defensive parsing:
  ```javascript
  const parsed = parseInt(rawHighScore, 10);
  gameState.highScore = (Number.isInteger(parsed) && parsed >= 0 && parsed <= 99999) ? parsed : 0;
  gameState.isMuted = (rawMuted === 'true');
  ```
* **Regression Test:** Inject string `"undefined"` into storage; reload; verify high score is `0`.

---

### Scenario 10: Unexpected Types or Negative Values in Saved Data
* **Setup & Reproduction Steps:**
  1. Inject negative integer into storage: `localStorage.setItem('neon_seq_high_score', '-42');`.
  2. Reload page and complete Round 1.
* **Expected Behavior:** High score resets to `0` on load, and updates to `1` upon completing Round 1.
* **Failure Signature:** High score shows `-42` or negative numbers fail to update properly.
* **Root Cause Investigation:** Verify validation condition checks `parsed >= 0`.
* **Fix Strategy:** Enforce `parsed >= 0` check in `loadStoredData()`.
* **Regression Test:** Set `-999` in storage; reload; confirm display reads `High Score: 0`.

---

### Scenario 11: localStorage Being Completely Unavailable
* **Setup & Reproduction Steps:**
  1. Configure browser to block third-party cookies and local storage, or open in strict private mode where `window.localStorage` access throws `SecurityError`.
  2. Play 3 rounds, pause, resume, and toggle mute.
* **Expected Behavior:** Game operates 100% normally using internal in-memory cache (`memoryStorageCache`). High score and mute operate during session without unhandled errors.
* **Failure Signature:** Clicking mute or completing a round throws an unhandled exception in the console, halting game loop.
* **Root Cause Investigation:** Verify all calls to `localStorage.getItem/setItem/removeItem` are guarded by `try...catch` blocks.
* **Fix Strategy:** All storage operations route strictly through `safeStorageGet`, `safeStorageSet`, and `safeStorageRemove`.
* **Regression Test:** Override `localStorage.setItem = () => { throw new Error('QuotaExceeded'); }`; play round; verify game does not crash.

---

### Scenario 12: Muting and Unmuting During Gameplay
* **Setup & Reproduction Steps:**
  1. Start sequence playback; click `#mute-btn` mid-sequence.
  2. Let round complete; unmute during `PLAYER_TURN`.
  3. Click a color button.
* **Expected Behavior:** Sound cuts out immediately when muted. Unmuting instantly restores audio on subsequent clicks without needing page reload or restart.
* **Failure Signature:** Ongoing tone hangs indefinitely after muting, or sound remains permanently silent after unmuting.
* **Root Cause Investigation:** Check whether `playColorTone()` checks `gameState.isMuted` and disconnects nodes cleanly.
* **Fix Strategy:** Every audio generator checks `if (gameState.isMuted) return;` at entry, and mute button calls `getAudioContext()` on unmute.
* **Regression Test:** Rapidly toggle mute 6 times during playback. Verify sound tracks mute state with zero audio distortion.

---

### Scenario 13: Browser Audio Restrictions or Audio Initialization Failure
* **Setup & Reproduction Steps:**
  1. Load game without interacting with document.
  2. Inspect console to confirm no audio warnings are generated.
  3. Simulate system with no audio output or blocked Web Audio permissions.
* **Expected Behavior:** No audio errors throw on page load. When the game starts without audio, visual gameplay functions flawlessly.
* **Failure Signature:** Console error `The AudioContext was not allowed to start`, blocking execution of `init()`.
* **Root Cause Investigation:** Instantiating `new AudioContext()` before user gesture.
* **Fix Strategy:** Defer context initialization to user click handlers (`onStartButtonClick`, `handleColorClick`, `onMuteButtonClick`) and wrap synthesis calls in `try...catch`.
* **Regression Test:** Block browser audio autoplay; click Start; verify visual playback and game mechanics run completely smoothly.

---

### Scenario 14: Repeated Game-Over and Play-Again Actions
* **Setup & Reproduction Steps:**
  1. Play Round 1 and fail immediately.
  2. Click `"Play Again"`. Repeat this failure-restart cycle 10 consecutive times.
* **Expected Behavior:** Every session begins with a single step, score resets cleanly to 0, high score retains all-time best, and zero memory leaks or sluggishness occur.
* **Failure Signature:** Animations become sluggish, scores increment by erratic amounts, or button flashes stutter.
* **Root Cause Investigation:** Inspect event listener accumulation (e.g. re-adding click listeners inside `init` or `startNewGame`).
* **Fix Strategy:** Event listeners are attached exactly once during initial page load in `init()`. `startNewGame()` resets data properties only.
* **Regression Test:** Cycle through 10 quick game-overs. Inspect DevTools memory heap to confirm flat memory footprint.

---

### Scenario 15: Keyboard Focus and Unexpected Input
* **Setup & Reproduction Steps:**
  1. Navigate the interface using only the `Tab` and `Shift+Tab` keys.
  2. Press `Enter` or `Space` on focused buttons during different states (`IDLE`, `PLAYBACK`, `PAUSED`).
* **Expected Behavior:** Logical focus order (Mute $\rightarrow$ Color Buttons $\rightarrow$ Start $\rightarrow$ Pause $\rightarrow$ Reset Data). Focus indicator is clearly visible. Pressing Enter on a disabled button triggers no action.
* **Failure Signature:** Focus disappears, focus order jumps erratically, or keyboard activates buttons while in `PLAYBACK` state.
* **Root Cause Investigation:** Ensure native `<button>` elements are used with proper `:focus-visible` styles and disabled attributes.
* **Fix Strategy:** Define `button:focus-visible { outline: 3px solid #ffffff; outline-offset: 3px; }` and manage `disabled` attributes in synchronization with FSM states.
* **Regression Test:** Complete an entire game session (Start, 2 rounds of play, Game Over, Play Again) using only keyboard navigation.

---

### Scenario 16: Browser Refresh and Offline Operation
* **Setup & Reproduction Steps:**
  1. Disconnect network adapter (enable Airplane Mode).
  2. Double-click `index.html` from local file manager (`file:///` protocol).
  3. Play 3 rounds, refresh browser (`F5`), and verify persistence.
* **Expected Behavior:** Application loads instantly. All styles, fonts, sounds, and persistent high scores function 100% offline with zero console network errors.
* **Failure Signature:** Missing fonts, broken layouts, or network fetch errors in DevTools console.
* **Root Cause Investigation:** Inspect all tags for external CDN URLs or remote dependencies.
* **Fix Strategy:** Strictly verify that all `<link>` and `<script>` paths are relative local references (`style.css`, `script.js`).
* **Regression Test:** Audit browser Network tab in offline mode: 0 failed requests, 0 external requests.

---

### Scenario 17: Reduced-Motion Preferences
* **Setup & Reproduction Steps:**
  1. Enable operating system reduced-motion preference (e.g., Windows "Show animations in Windows" $\rightarrow$ Off, or DevTools Emulate `prefers-reduced-motion: reduce`).
  2. Trigger game over to observe error effect.
* **Expected Behavior:** Cabinet does not physically shake horizontally. Error is communicated purely via border perimeter color/opacity flash.
* **Failure Signature:** Cabinet vibrates violently despite accessibility preference.
* **Root Cause Investigation:** Verify `@media (prefers-reduced-motion: reduce)` block in `style.css`.
* **Fix Strategy:**
  ```css
  @media (prefers-reduced-motion: reduce) {
    .game-container.shake-error {
      animation: cabinet-error-flash 350ms ease-out !important;
      transform: none !important;
    }
  }
  ```
* **Regression Test:** Trigger error under reduced-motion emulation; verify zero `transform: translateX` displacement.

---

### Scenario 18: Missing DOM Elements or JavaScript Initialization Errors
* **Setup & Reproduction Steps:**
  1. Simulate missing DOM node (e.g., if `#high-score-display` was absent from HTML).
  2. Execute `init()`.
* **Expected Behavior:** The script checks for node existence before performing DOM mutations or attaching listeners, avoiding fatal `TypeError: Cannot read properties of null`.
* **Failure Signature:** Script crashes on line 1 of initialization, rendering all controls non-functional.
* **Root Cause Investigation:** Check for unguarded DOM element property assignments.
* **Fix Strategy:** Guard all element mutations:
  ```javascript
  if (highScoreDisplay) highScoreDisplay.textContent = '...';
  if (pauseButton) pauseButton.addEventListener('click', ...);
  ```
* **Regression Test:** Remove optional element from DOM; verify game initializes and plays without throwing exceptions.

---

## 3. Final Polish & Code Health Verification

### 3.1 Styling & Visual Polish Checklist
- [ ] **Contrast Check:** Verify all text elements meet WCAG 2.1 AA standards (minimum 4.5:1 for normal text, 3:1 for large text).
- [ ] **Spacing & Alignment:** Ensure uniform margins between header, dashboard strip, button grid, controls, and utility footer.
- [ ] **No Visual Clamping:** Verify active bloom box-shadows do not clip against parent container boundaries.
- [ ] **Button State Consistency:** Confirm hover, focus-visible, active press, and disabled states are visually coherent across all buttons (`.color-btn`, `#start-btn`, `#pause-btn`, `#mute-btn`, `#reset-data-btn`).

### 3.2 Responsive Geometry Checklist
- [ ] **Desktop Standard:** $1024\text{px} \times 768\text{px}$ — centered chassis, max-width 400px.
- [ ] **Tablet:** $768\text{px} \times 1024\text{px}$ — fluid width, balanced padding.
- [ ] **Standard Mobile:** $375\text{px} \times 667\text{px}$ — compact grid, no scrollbars.
- [ ] **Narrow Mobile:** $320\text{px} \times 568\text{px}$ — scaled fonts, single-column dashboard fallback, zero overflow.

### 3.3 Code Health & Architecture Checklist
- [ ] **Three-File Rule:** Confirm only `index.html`, `style.css`, and `script.js` exist in project root.
- [ ] **Zero External Assets:** 0 image files, 0 audio files, 0 downloaded fonts, 0 CSS frameworks, 0 JavaScript libraries.
- [ ] **Dead Code Elimination:** Remove unused variables, deprecated helper functions, and commented-out code blocks.
- [ ] **Console Cleanliness:** Zero warnings, zero uncaught errors during complete gameplay lifecycle.

---

## 4. Bug List — Complete After Testing

The Builder and Tester must record any real defects discovered during the execution of the debugging protocols in the table below. At least three genuine edge-case defects or hardening opportunities identified during Stage 5 testing must be documented with complete technical root causes, fixes applied, and regression verifications.

| Bug ID | Reproduction Steps | Actual Behavior | Expected Behavior | Root Cause | Fix Applied | Regression Test |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **BUG-01** | 1. Start Round 1.<br>2. Click Pause or Mute mid-flash while button tone is sounding. | The tone continues ringing for its full scheduled duration (~250ms) into the paused/muted state. | Sound output should cut off immediately (0ms) upon pausing or muting. | Web Audio oscillators were connected directly to `ctx.destination` and scheduled into the future; `clearAllTimers()` only cleared JavaScript timeouts, not running audio nodes. | Implemented `activeOscillators` registry and `stopAllSounds()`. Invoked `stopAllSounds()` synchronously in `pauseGame()`, `startNewGame()`, `handleIncorrectInput()`, and `onMuteButtonClick()`. | Trigger 350ms error buzz and immediately click "Play Again" within 50ms. Error sound cuts off instantly and does not overlap with Round 1 tone. |
| **BUG-02** | 1. Advance to Round 3.<br>2. Switch to another browser tab as sequence playback starts.<br>3. Wait 10 seconds and return. | Background timer throttling delays timeouts, resulting in a rapid, distorted stutter burst of all queued button flashes upon tab return. | Game should safely suspend playback while the tab is hidden and resume cleanly upon user command. | Absence of a `visibilitychange` lifecycle listener to detect when `document.hidden` becomes true during active sequence playback. | Added `document.addEventListener('visibilitychange', onVisibilityChange)` in `script.js` to automatically invoke `pauseGame()` when `document.hidden === true` during active play. | Switch tabs during playback in Round 4. Return after 10s. Game is cleanly paused; clicking Resume replays sequence smoothly with zero stutter burst. |
| **BUG-03** | 1. Start Round 2.<br>2. Click "Reset Data" while the sequence is flashing. | A modal confirmation dialog (`window.confirm`) opens, blocking the main execution thread while the sequence was supposed to be observed. | "Reset Data" should be disabled during active rounds (`PLAYBACK`, `PLAYER_TURN`, `ROUND_SUCCESS`) and only accessible when idle, paused, or game over. | `updateUI()` never managed `resetDataButton.disabled`, leaving the button interactive across all states. | Updated `updateUI()` to set `resetDataButton.disabled = isBusy` and added an early return guard in `onResetDataButtonClick()`. Added `.reset-btn:disabled` in `style.css`. | Observe `#reset-data-btn` during sequence playback and player turn. Button is visually dimmed (`opacity: 0.35`) and unclickable. In `PAUSED`, `IDLE`, and `GAME_OVER`, it is enabled. |
| **BUG-04** | 1. Pause game during sequence playback.<br>2. Click "Resume". | Status banner reads `"Resuming sequence..."` and remains stuck on that text for the entire duration of playback until player turn. | Status banner should show `"Resuming sequence..."` during the 600ms ready delay, then update to `"Watch the sequence"` as buttons flash. | `updateUI()` checked `gameState.previousState === GAME_STATES.PLAYBACK`, which was never cleared once sequence playback actively began. | In `playSequence()`, clear `gameState.previousState = null` and invoke `updateUI()`, transitioning the banner to `"Watch the sequence"` once flashes start. | Pause and resume during playback. Banner displays `"Resuming sequence..."` during the 600ms pause, then switches to `"Watch the sequence"` during flashes, then `"Your turn!"`. |

### Guidelines for Documenting Genuine Bugs:
1. **Reproducibility:** Detail exact user actions, timing, and initial game states.
2. **Precision:** Distinguish visual defects, timing race conditions, and audio synthesis quirks.
3. **Root Cause Analysis:** Identify the exact function, line number, or CSS cascade rule responsible.
4. **Targeted Fix:** Implement the minimal clean fix without breaking existing stage rules.
5. **Regression Verification:** Prove that the fix resolved the issue without causing collateral regressions in earlier stages.