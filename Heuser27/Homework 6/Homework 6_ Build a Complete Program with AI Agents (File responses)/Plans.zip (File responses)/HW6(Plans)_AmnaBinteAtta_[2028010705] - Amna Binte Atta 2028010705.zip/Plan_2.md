﻿# Stage 2 Architecture & Design Plan: Visual Vibe
**Project:** Neon Sequence — Pattern Memory Game  
**Document:** `Plan_2.md`  
**Phase:** Stage 2 — Visual Styling, Neon Theme & Responsive Presentation  

---

## 1. Design Concept & Visual Hierarchy

### 1.1 Aesthetic Identity
Stage 2 transforms Neon Sequence from a plain wireframe prototype into an immersive, retro-futuristic neon arcade cabinet. The aesthetic evokes the atmosphere of a darkened 1980s synthwave arcade room: deep, near-black backgrounds punctuated by electric cyan, magenta-pink, luminous yellow, and deep ultraviolet purple. 

Lighting is simulated entirely via pure CSS box shadows, text shadows, radial gradients, and opacity layers without any images, canvas rendering, or external assets.

```
+-------------------------------------------------------------------------+
| VIEWPORT (Near-black #0a0b10 with ambient radial neon backdrop glow)     |
|                                                                         |
|   +-----------------------------------------------------------------+   |
|   | .game-panel (Dark obsidian glass chassis #12131c, rounded 16px)  |   |
|   |                                                                 |   |
|   |   [ 1. TITLE: Neon Sequence ] (Electric Cyan & Pink Glow)       |   |
|   |                                                                 |   |
|   |   [ 2. DASHBOARD: Score & Status Pill ]                         |   |
|   |        SCORE: 04           [ WATCH SEQUENCE ]                   |   |
|   |                                                                 |   |
|   |   [ 3. ARCADE MATRIX: 2x2 Glowing Color Quadrants ]             |   |
|   |        +-------------------+ +-------------------+              |   |
|   |        |  CYAN BUTTON      | |  PINK BUTTON      |              |   |
|   |        +-------------------+ +-------------------+              |   |
|   |        +-------------------+ +-------------------+              |   |
|   |        |  YELLOW BUTTON    | |  PURPLE BUTTON    |              |   |
|   |        +-------------------+ +-------------------+              |   |
|   |                                                                 |   |
|   |   [ 4. ACTION CONTROLLER: Arcade Start / Play Again Button ]    |   |
|   |        [ ====== START GAME ====== ]                             |   |
|   +-----------------------------------------------------------------+   |
+-------------------------------------------------------------------------+
```

### 1.2 Visual Hierarchy
1. **Primary Focal Point (The Matrix):** The 2×2 button grid dominates the center. At rest, the buttons emit a subtle, saturated ambient neon aura. During playback or interaction, buttons ignite with intense brightness and bloom.
2. **Secondary Focal Point (Status & Feedback):** The dynamic status pill sits directly above the grid, giving immediate high-contrast instructions (`"Watch the sequence"`, `"Your turn!"`, `"Game Over"`).
3. **Tertiary Focal Point (Score Counter):** Monospaced arcade-style score readout displayed prominently to provide clear progression feedback.
4. **Anchor / Foundation (Header & Controls):** The glowing title anchors the top; the arcade push-button controller anchors the bottom.

---

## 2. Exact Color Palette & CSS Tokens

The color system uses high-saturation neon primaries paired with a multi-layered dark slate/obsidian background. All colors are specified in 6-digit or 8-digit hexadecimal values and RGBA equivalents.

```
  NEAR-BLACK        NEON CYAN         NEON PINK        NEON YELLOW       NEON PURPLE
   #0a0b10           #00f0ff           #ff007f           #ffe600           #b026ff
 ┌──────────┐      ┌──────────┐      ┌──────────┐      ┌──────────┐      ┌──────────┐
 │          │      │          │      │          │      │          │      │          │
 └──────────┘      └──────────┘      └──────────┘      └──────────┘      └──────────┘
  Background        Quadrant 1        Quadrant 2        Quadrant 3        Quadrant 4
```

### 2.1 Color Token Table

| Token Name | Hex Code | RGBA / Alpha Equivalent | Purpose |
| :--- | :--- | :--- | :--- |
| `--bg-body` | `#0a0b10` | `rgb(10, 11, 16)` | Viewport foundation; near-black with deep navy undertone. |
| `--bg-panel` | `#12131c` | `rgba(18, 19, 28, 0.95)` | Console chassis panel with subtle transparency. |
| `--bg-panel-border`| `#25283d` | `rgb(37, 40, 61)` | Subtle structural border framing the chassis. |
| `--neon-cyan` | `#00f0ff` | `rgb(0, 240, 255)` | Quadrant 1 (Top-Left); header accent; focus rings. |
| `--neon-pink` | `#ff007f` | `rgb(255, 0, 127)` | Quadrant 2 (Top-Right); game-over warning accent. |
| `--neon-yellow` | `#ffe600` | `rgb(255, 230, 0)` | Quadrant 3 (Bottom-Left); score highlight accent. |
| `--neon-purple` | `#b026ff` | `rgb(176, 38, 255)` | Quadrant 4 (Bottom-Right); subtle glow gradient accent. |
| `--text-primary` | `#f5f6fa` | `rgb(245, 246, 250)` | Crisp white/silver for primary labels and headers. |
| `--text-muted` | `#8a8fa3` | `rgb(138, 143, 163)` | Secondary instructions and inactive metadata. |
| `--btn-start-bg` | `#181b29` | `rgb(24, 27, 41)` | Background for the action button. |
| `--btn-start-border`| `#00f0ff` | `rgb(0, 240, 255)` | Neon border for the action button. |

### 2.2 Contrast & Readability Verification (WCAG 2.1 AA)
- Primary text (`#f5f6fa`) on panel background (`#12131c`): **Contrast Ratio 16.2:1** (Exceeds WCAG AAA requirement of 7.0:1).
- Status text (`#00f0ff`) on panel background (`#12131c`): **Contrast Ratio 11.4:1** (Exceeds WCAG AAA).
- Warning / Game Over text (`#ff007f`) on panel background (`#12131c`): **Contrast Ratio 5.1:1** (Exceeds WCAG AA requirement of 4.5:1).

---

## 3. Page Layout & Component Architecture

### 3.1 Viewport Centering & Ambient Backdrop
- The `body` element uses `display: flex; justify-content: center; align-items: center; min-height: 100vh;`.
- A radial background gradient creates an ambient light spill directly behind the chassis without external images:
  ```css
  background: radial-gradient(circle at 50% 45%, #1a1730 0%, #0d0e17 60%, #07070b 100%);
  ```

### 3.2 Arcade Chassis Panel (`.game-container`)
- Maximum width: `420px` on desktop, fluid `92vw` on small screens.
- Border radius: `18px` with clean, rounded corners.
- Border: `2px solid var(--bg-panel-border)` with an outer multi-stop glow:
  ```css
  box-shadow: 0 0 25px rgba(0, 240, 255, 0.12), 0 20px 40px rgba(0, 0, 0, 0.8);
  ```

### 3.3 Dashboard Strip (Score & Status)
- Structured horizontally or vertically with uniform spacing:
  - **Score Readout (`#score-display`):** Styled like an arcade digital LED display with letter spacing (`2px`) and yellow accent lighting.
  - **Status Pill (`#status-message`):** Encased in a pill-shaped container (`border-radius: 20px; padding: 6px 14px; background: rgba(0, 0, 0, 0.4); border: 1px solid rgba(255, 255, 255, 0.1);`) to prevent layout shifts when message lengths change.

### 3.4 2×2 Button Grid (`#button-grid`)
- Grid layout: `display: grid; grid-template-columns: repeat(2, 1fr); gap: 16px;`.
- Strict aspect ratio: 1:1 square buttons (`aspect-ratio: 1 / 1`).

---

## 4. CSS Organization & Reusable Token System

All CSS rules will be organized in `style.css` using the following strict architectural sections:

```
/* ==========================================================================
   1. ROOT DESIGN TOKENS & VARIABLES
   ========================================================================== */
   -- Color primitives, glow parameters, typography stacks, timings

/* ==========================================================================
   2. RESET & BASE LAYOUT
   ========================================================================== */
   -- Box-sizing, zero margins, viewport centering, radial background

/* ==========================================================================
   3. ARCADE CHASSIS CONTAINER
   ========================================================================== */
   -- .game-container, borders, ambient chassis glow, internal padding

/* ==========================================================================
   4. TYPOGRAPHY & HEADER STYLING
   ========================================================================== */
   -- H1 neon multi-layer text-shadow, score LED readout, status pill

/* ==========================================================================
   5. COLOR BUTTON MATRIX (2x2 GRID)
   ========================================================================== */
   -- Base button geometry, aspect ratio, dark resting state, border tints

/* ==========================================================================
   6. INTERACTIVE & PLAYBACK STATES
   ========================================================================== */
   -- :hover, :focus-visible, :active, and .active (Playback Flash Bloom)

/* ==========================================================================
   7. CONTROL BUTTON (START / PLAY AGAIN)
   ========================================================================== */
   -- Arcade push-button styling, border-glow, hover/active elevation

/* ==========================================================================
   8. RESPONSIVE BREAKPOINTS & MOBILE ADAPTATION
   ========================================================================== */
   -- Media queries for tablets (<= 768px) and narrow mobile (<= 360px)
```

---

## 5. Button Design & State Architecture

### 5.1 The Four Neon Matrix Buttons
Each button has a designated color identity. In the idle state, the button maintains a dark obsidian core with a rich, semi-transparent color tint and a visible neon edge. This ensures high visual contrast when ignited.

```
IDLE STATE                  HOVER STATE                 PLAYBACK FLASH (.active)
+-------------------+       +-------------------+       +-------------------+
| #0e1a20 (Dark)    |       | #122832 (Lifted)  |       | #ffffff (Core)    |
| Border: Cyan 30%  |  ==>  | Border: Cyan 70%  |  ==>  | Border: Pure Cyan |
| Subtle Edge Glow  |       | Outer Glow Expands|       | Massive 360° Bloom|
+-------------------+       +-------------------+       +-------------------+
```

#### Detailed State Specifications:

1. **Idle State (Resting):**
   - Background: Dark, deep tinted charcoal (e.g., Cyan button: `background: #0d1a1f;`).
   - Border: `2px solid` with 50% opacity of the neon color (e.g., `rgba(0, 240, 255, 0.5)`).
   - Inset shadow: `inset 0 0 15px rgba(0, 0, 0, 0.6)`.
   - Ambient outer glow: `box-shadow: 0 0 10px rgba(color, 0.2)`.
   - Border radius: `14px`.

2. **Hover State (`:hover:not(:disabled)`):**
   - Background brightness lifted: `filter: brightness(1.25)`.
   - Border opacity increases to `100%`.
   - Box shadow expands: `0 0 18px rgba(color, 0.5)`.
   - Cursor: `pointer`.

3. **Keyboard Focus State (`:focus-visible`):**
   - Outline: `none`.
   - Dedicated high-contrast dual-ring focus:
     ```css
     outline: 3px solid #ffffff;
     outline-offset: 3px;
     box-shadow: 0 0 20px #ffffff, 0 0 35px var(--neon-cyan);
     ```

4. **Pressed / Touch State (`:active:not(:disabled)`):**
   - Instant tactile compression via transform: `transform: scale(0.97)`.
   - Inset brightness increase: `inset 0 0 20px rgba(color, 0.6)`.

5. **Playback & Click Flash State (`.active` class):**
   - *Crucial Stage 1 contract preservation:* The JavaScript engine toggles `.active` during `flashButton()`.
   - Background shifts to radiant high-intensity tint: `background-color: var(--neon-color);`.
   - Filter: `brightness(1.6) saturate(1.4)`.
   - Multi-layered 360-degree bloom box-shadow:
     ```css
     box-shadow: 
       0 0 10px #ffffff,
       0 0 20px var(--neon-color),
       0 0 40px var(--neon-color),
       0 0 60px var(--neon-color);
     ```
   - Transform: `scale(1.02)` for prominent visual pop without disturbing the grid layout.

6. **Disabled State (`:disabled`):**
   - Opacity remains at `0.75` (preventing dull wash-out while clearly unclickable).
   - `cursor: not-allowed; pointer-events: none;`.

### 5.2 Start / Play Again Button (`#start-btn`)
- Styling: Styled like an illuminated arcade cabinet coin/push button.
- Background: `#141724` with top-to-bottom subtle gradient (`linear-gradient(180deg, #1c2135 0%, #121522 100%)`).
- Border: `2px solid var(--neon-cyan)`.
- Text: Bold, uppercase, letter-spaced (`2px`), glowing cyan (`color: #00f0ff; text-shadow: 0 0 8px rgba(0, 240, 255, 0.6);`).
- Hover: Border and text shadow intensify; subtle lift `box-shadow: 0 0 20px rgba(0, 240, 255, 0.4);`.
- Disabled state (`Playing...`): `opacity: 0.4; border-color: #4a5068; color: #8a8fa3; text-shadow: none; box-shadow: none; cursor: not-allowed;`.

---

## 6. Typography Using System Fonts

Per the hard constraints, no web fonts (Google Fonts, Adobe Fonts) or local `.woff2` files may be introduced. Premium arcade typography is achieved using modern system font stacks, disciplined letter spacing, text transformations, and multi-layered CSS `text-shadow`.

### 6.1 Font Stacks

```css
/* Primary Geometric UI Stack */
--font-sans: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;

/* Monospaced Arcade Readout Stack */
--font-mono: 'Consolas', 'SF Mono', 'Courier New', 'Roboto Mono', monospace;
```

### 6.2 Typographic Hierarchy & Scale

| Element | Font Stack | Size | Weight | Letter Spacing | Text Glow / Style |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Title (`h1`)** | `--font-sans` | `26px` | `800` (Extra Bold) | `3px` (Uppercase) | Neon Cyan/Pink dual glow: `text-shadow: 0 0 10px #00f0ff, 0 0 20px #00f0ff, 0 0 35px rgba(255, 0, 127, 0.5);` |
| **Score (`#score-display`)** | `--font-mono` | `18px` | `700` (Bold) | `2px` | Neon Yellow glow: `color: #ffe600; text-shadow: 0 0 8px rgba(255, 230, 0, 0.5);` |
| **Status (`#status-message`)** | `--font-sans` | `14px` | `600` (Semi-Bold) | `1px` (Uppercase) | Neutral Silver: `color: #f5f6fa;` with dynamic emphasis. |
| **Start Button (`#start-btn`)**| `--font-sans` | `15px` | `700` (Bold) | `2px` (Uppercase) | Neon Cyan glow: `color: #00f0ff; text-shadow: 0 0 8px rgba(0, 240, 255, 0.6);` |

---

## 7. Responsive Breakpoints & Mobile Adaptability

The layout must deliver a consistent experience across desktop displays, tablets, and narrow smartphones down to 320px width without horizontal scrolling or viewport overflow.

```
DESKTOP (> 768px)          TABLET (361px - 768px)      NARROW MOBILE (<= 360px)
+-----------------------+   +-----------------------+   +-----------------------+
| Panel: 400px fixed    |   | Panel: 90vw fluid     |   | Panel: 94vw compact   |
| Button: 125px x 125px |   | Button: 100px x 100px |   | Button: 85px x 85px   |
| Gap: 16px             |   | Gap: 12px             |   | Gap: 8px              |
| Padding: 28px         |   | Padding: 20px         |   | Padding: 14px         |
+-----------------------+   +-----------------------+   +-----------------------+
```

### 7.1 Breakpoint Strategy
1. **Desktop / Default (> 480px):**
   - `.game-container`: `width: 400px; padding: 28px 24px;`.
   - `#button-grid`: `grid-template-columns: repeat(2, 125px); gap: 16px; justify-content: center;`.
   - Button dimensions: `125px × 125px`.
2. **Standard Mobile (361px – 480px):**
   - `.game-container`: `width: 92vw; padding: 20px 16px;`.
   - `#button-grid`: `grid-template-columns: repeat(2, 1fr); gap: 12px; width: 100%; max-width: 280px;`.
   - Button dimensions: Fluid with `aspect-ratio: 1 / 1`.
3. **Narrow Mobile (<= 360px):**
   - Targeted via `@media (max-width: 360px)`.
   - `.game-container`: `padding: 14px 10px; width: 95vw;`.
   - `h1`: `font-size: 20px; margin-bottom: 8px;`.
   - `#button-grid`: `gap: 8px; max-width: 230px;`.
   - `#start-btn`: `padding: 9px 12px; font-size: 13px;`.
   - Zero horizontal scroll: Body enforces `overflow-x: hidden;`.

---

## 8. Accessibility, Contrast & Keyboard Focus

1. **Non-Color Dependent Feedback:**
   - In addition to color illumination, every state transition updates clear textual messaging in `#status-message` (`"Watch the sequence"`, `"Your turn!"`, `"Correct!"`, `"Game Over!"`).
2. **Keyboard Focus Ring (`:focus-visible`):**
   - Standard browser outline is replaced with a high-visibility, 3px solid white outline with a 3px offset:
     ```css
     button:focus-visible {
       outline: 3px solid #ffffff;
       outline-offset: 3px;
       box-shadow: 0 0 15px #ffffff, 0 0 30px var(--neon-cyan);
     }
     ```
3. **Screen Reader and Assistive Technology:**
   - Color buttons retain `aria-label` attributes (`Green button`, `Red button`, etc.).
   - `#status-message` retains live status announcements for screen readers.

---

## 9. Preservation of Stage 1 JavaScript Functionality

Stage 2 is **strictly visual and structural presentation**. The JavaScript game engine in `script.js` must continue to operate with 100% fidelity without behavioral alteration.

### 9.1 Direct Mapping of IDs and Classes
`script.js` relies on specific DOM element IDs and CSS class hooks:
- **Element IDs:** `#score-display`, `#status-message`, `#start-btn`, `#button-grid`. Must remain identical in `index.html`.
- **Button IDs:** `#btn-green`, `#btn-red`, `#btn-yellow`, `#btn-blue`.
  - *Color Palette Mapping:* To honor the Stage 2 visual mandate (Cyan, Pink, Yellow, Purple) with **zero JavaScript changes**, the buttons are mapped visually in `style.css`:
    - `#btn-green` $\rightarrow$ Styled with **Neon Cyan** (`#00f0ff`)
    - `#btn-red` $\rightarrow$ Styled with **Neon Pink** (`#ff007f`)
    - `#btn-yellow` $\rightarrow$ Styled with **Neon Yellow** (`#ffe600`)
    - `#btn-blue` $\rightarrow$ Styled with **Neon Purple** (`#b026ff`)
  - This guarantees that `CONFIG.BUTTON_IDS` in `script.js` continues to target existing DOM nodes without breaking any reference, while displaying the new neon arcade theme.
- **Dynamic Flash Class (`.active`):**
  - When `flashButton()` runs in `script.js`, it performs:
    `btn.classList.add('active');` followed by `btn.classList.remove('active');`.
  - In `style.css`, `.color-btn.active` will be configured with intense glow, scale, and brightness to provide visual sequence playback.

---

## 10. Comprehensive Stage 2 Acceptance Test Suite

The Builder must verify that all 10 visual acceptance criteria pass.

| Test ID | Test Scenario | Preconditions | Action | Expected Result |
| :--- | :--- | :--- | :--- | :--- |
| **ST2-01** | **Arcade Theme Foundations** | Page loaded in browser. | Inspect page background and chassis styling. | Background is deep navy/near-black (`#0a0b10`) with ambient radial gradient. Chassis panel is dark obsidian (`#12131c`) with rounded corners and neon border glow. |
| **ST2-02** | **Four Neon Color Quadrants** | Game in `IDLE` state. | Observe the 4 buttons in `#button-grid`. | Buttons display distinct Cyan, Pink, Yellow, and Purple neon themes with dark idle centers and colored borders. |
| **ST2-03** | **Playback Sequence Flash Bloom** | Click "Start" to trigger Round 1. | Observe the computer sequence flash. | The target button lights up with radiant bloom (`.active` class), high brightness, and multi-layer outer glow; it returns cleanly to resting state after 400ms. |
| **ST2-04** | **Button Hover & Tactile Press** | State is `PLAYER_TURN`. | Hover mouse over color buttons and press down. | Hover visibly brightens border and ambient glow; mouse-down triggers a tactile `scale(0.97)` compression. |
| **ST2-05** | **Keyboard Focus Navigation** | State is `PLAYER_TURN`. | Press `Tab` key to navigate between buttons. | Focused button displays high-visibility white dual-ring focus indicator with glowing offset outline. |
| **ST2-06** | **Start Button Visual States** | Observe button in `IDLE`, `PLAYBACK`, and `GAME_OVER`. | Transition across game states. | `IDLE`: Glowing cyan border, text "Start". `PLAYBACK`: Dimmed, disabled (`opacity: 0.4`, text "Playing..."). `GAME_OVER`: Glowing cyan border, text "Play Again". |
| **ST2-07** | **Typography & Legibility** | Inspect Title, Score, and Status. | Observe text contrast across all states. | Title displays sharp neon glow; Score displays high-contrast yellow monospaced digits; Status pill text is sharp and clearly readable (WCAG AA compliant). |
| **ST2-08** | **Narrow Mobile Adaptation** | Viewport resized to 320px width. | Inspect layout and scrollbars. | Content scales smoothly; buttons shrink proportionally via `aspect-ratio: 1/1`; zero horizontal or vertical scrollbars appear. |
| **ST2-09** | **Zero Game Logic Regression** | Play 3 rounds (success and intentional failure). | Play complete rounds. | Core rules intact: score increments by 1 per round, 1 step added per round, incorrect click triggers game-over with final score. |
| **ST2-10** | **Offline & Asset Independence** | Disconnect network; inspect project root. | Check network tab on reload. | Zero network requests; zero font, image, or SVG files; exactly 3 files (`index.html`, `style.css`, `script.js`). |

---

## 11. Likely Visual Regressions & Prevention Strategies

| Potential Regression | Root Cause | Impact | Architectural Prevention Strategy |
| :--- | :--- | :--- | :--- |
| **1. Text Illegibility via Blur Overload** | Excessive `text-shadow` radius with high spread. | Text becomes blurry, fuzzy, and unreadable on low-DPI screens. | Restrict text glow to tight radiuses (2px to 8px max); always maintain high-contrast solid foreground text (`#ffffff` or `#00f0ff`). |
| **2. Weak Playback Flash Contrast** | Idle button background too bright or `.active` state too dim. | Player cannot clearly distinguish which button flashed during fast sequence playback. | Keep idle buttons at dark core luminance (~10% lightness); configure `.active` with full `100%` saturation, `brightness(1.6)`, and multi-layer box shadows. |
| **3. Layout Shift During Text Changes** | Status banner expanding or wrapping lines on `"Game Over! Final Score: X"`. | Button grid shifts vertically, causing misclicks. | Enforce `min-height: 28px` and structured pill padding on `#status-message`; lock dimensions so status changes never cause reflow. |
| **4. Broken Keyboard Outline** | Using `outline: none` without providing `:focus-visible`. | Keyboard users cannot see which button has focus. | Explicitly define `button:focus-visible` with high-contrast dual-ring white and neon outline. |
| **5. Mobile Grid Overflow** | Using fixed pixel dimensions (`120px`) on narrow mobile screens (< 360px). | Buttons push outside viewport or cause horizontal scrolling. | Use CSS Grid with fluid fractional tracks (`1fr`), `max-width`, and `aspect-ratio: 1 / 1`. |

---

## 12. Final Asset & Dependency Compliance Checklist

- [x] **Images / Icons:** 0 image files (`.png`, `.jpg`, `.webp`, `.gif`, `.ico`).
- [x] **Vector Graphics:** 0 SVG files or inline SVG paths.
- [x] **Fonts:** 0 downloaded or external font files (`.woff`, `.woff2`, `.ttf`); 0 Google Font `<link>` or `@import` rules.
- [x] **Sound:** 0 audio files (`.mp3`, `.wav`, `.ogg`); 0 Web Audio API calls.
- [x] **Libraries:** 0 CSS frameworks (Tailwind, Bootstrap); 0 JavaScript libraries (jQuery, React, Vue, Lodash).
- [x] **File Structure:** Exactly three files in project root:
  - `index.html`
  - `style.css`
  - `script.js`
- [x] **Offline Guarantee:** 100% self-contained styling and structure executable via double-clicking `index.html`.