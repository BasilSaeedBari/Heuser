﻿# Stage 1 Implementation Plan: Core Logic Engine
**Project:** Neon Sequence (Pattern Memory Game)  
**File Reference:** `Plan_1.md`  
**Phase:** Stage 1 — Core Logic Architecture & Engine Specification  

---

## 1. Architectural Overview & System Design

### 1.1 Goal & Scope
Stage 1 focuses strictly on implementing the underlying deterministic state machine, timing controller, scoring logic, and sequence management for Neon Sequence. The implementation must function 100% offline using standard ECMAScript (vanilla JavaScript), clean semantic HTML, and basic CSS. 

### 1.2 Separation of Concerns (SoC)
To ensure the game logic remains completely decoupled from presentation and DOM manipulation:
- **Game Model (`GameState` / Core Logic):** Pure JavaScript state containers and deterministic business logic (turn validation, score calculation, sequence generation, state transitions). It does not hold direct DOM element references.
- **View Layer (`UIController` / View Bridge):** Handles DOM updates (enabling/disabling buttons, setting active styles, updating text nodes).
- **Event Controller (`InputHandler`):** Captures user events, queries the current state via the Model, and triggers Model methods while coordinating View reactions.

```mermaid
flowchart LR
    subgraph ViewLayer["View / DOM Layer"]
        DOMButtons["Button Elements (4 Colors)"]
        StartBtn["Start / Restart Button"]
        ScoreDisplay["Score & Status Labels"]
    end

    subgraph Controller["Event & Loop Controller"]
        InputHandler["Event Listeners / Input Guard"]
        PlaybackTimer["Sequence Playback Loop"]
    end

    subgraph Model["Core Logic Engine (Pure JS)"]
        StateMachine["State Machine Engine"]
        SeqGen["Sequence Generator"]
        ScoreTracker["Score & Round Logic"]
    end

    StartBtn -->|Click Event| InputHandler
    DOMButtons -->|Click Event| InputHandler
    InputHandler -->|Action if Input Enabled| StateMachine
    StateMachine -->|State & Event Notifications| Controller
    Controller -->|Step Interval| PlaybackTimer
    PlaybackTimer -->|Highlight Request| ViewLayer
    StateMachine -->|Render Updates| ScoreDisplay
```

---

## 2. Game States & State Machine

The game operates as a finite-state machine (FSM) with five distinct states.

### 2.1 State Definitions
| State Constant | Description | Permitted User Actions |
| :--- | :--- | :--- |
| `IDLE` | Initial unstarted state awaiting game start. | Clicking `Start` only. |
| `SHOWING_SEQUENCE` | The engine is presenting the current pattern to the player one step at a time. | None (All color and start inputs are locked). |
| `AWAITING_INPUT` | The player's turn to replicate the active sequence. | Clicking any of the 4 color buttons. |
| `ROUND_SUCCESS` | Transient state: the player successfully matched the full sequence for the round. | None (Input locked while engine prepares next step). |
| `GAME_OVER` | Terminal round state: the player entered an incorrect step. | Clicking `Play Again` / `Restart`. |

### 2.2 State Transitions

```mermaid
stateDiagram-v2
    [*] --> IDLE
    IDLE --> SHOWING_SEQUENCE : User clicks "Start"
    SHOWING_SEQUENCE --> AWAITING_INPUT : Sequence playback finishes
    
    AWAITING_INPUT --> AWAITING_INPUT : Correct button pressed (turn incomplete)
    AWAITING_INPUT --> ROUND_SUCCESS : Correct button pressed (turn complete)
    AWAITING_INPUT --> GAME_OVER : Incorrect button pressed
    
    ROUND_SUCCESS --> SHOWING_SEQUENCE : Increment score, append step, auto-advance
    GAME_OVER --> SHOWING_SEQUENCE : User clicks "Play Again"
```

---

## 3. Data Structures & State Variables

### 3.1 Constants & Configuration
```javascript
// Available button positions/identifiers
const BUTTON_IDS = ['btn-green', 'btn-red', 'btn-yellow', 'btn-blue'];

// FSM State Enums
const GAME_STATES = {
  IDLE: 'IDLE',
  SHOWING_SEQUENCE: 'SHOWING_SEQUENCE',
  AWAITING_INPUT: 'AWAITING_INPUT',
  ROUND_SUCCESS: 'ROUND_SUCCESS',
  GAME_OVER: 'GAME_OVER'
};

// Timing configurations (Milliseconds) - plain indicators without CSS transitions
const TIMING_CONFIG = {
  STEP_INTERVAL: 800,   // Delay between sequence step highlights
  STEP_DURATION: 400,   // Active highlight duration per button
  ROUND_DELAY: 1000     // Pause before computer starts showing next sequence
};
```

### 3.2 Dynamic State Variables
All runtime game state is encapsulated within a central `state` object:

| Variable Name | Type | Initial Value | Purpose |
| :--- | :--- | :--- | :--- |
| `currentState` | `string` (enum) | `GAME_STATES.IDLE` | Current stage of the FSM. |
| `sequence` | `Array<string>` | `[]` | Ordered list of button IDs representing the target pattern. |
| `playerStepIndex` | `number` | `0` | Tracks which step index of `sequence` the player is currently verifying. |
| `score` | `number` | `0` | Number of successfully completed rounds. |
| `isInputLocked` | `boolean` | `true` | Defensive flag preventing click handling regardless of UI state. |
| `playbackTimerId` | `number \| null` | `null` | Active `setTimeout` or `setInterval` handle (enables cleanup/cancellation). |

---

## 4. Sequence-Generation Algorithm

1. **Step Generation:**
   - The sequence starts empty: `sequence = []`.
   - At the beginning of round 1, and upon completing each subsequent round, exactly **one** new step is appended to `sequence`.
   - The position is chosen using uniform pseudorandom selection across `BUTTON_IDS`:
     $$\text{Index} = \lfloor \text{Math.random()} \times 4 \rfloor$$
     $$\text{New Step} = \text{BUTTON\_IDS}[\text{Index}]$$
2. **Determinism & Immutability:**
   - Previous steps in `sequence` are never mutated or reordered; rounds build strictly incrementally ($N, N+1, N+2$).

---

## 5. Core Functions Specification

### 5.1 Pure Engine & Model Methods

#### `initGame(): void`
- **Purpose:** Initializes all state variables to defaults and verifies game integrity.
- **Side Effects:** Resets `state` object, sets `currentState = GAME_STATES.IDLE`, `isInputLocked = true`.

#### `startNewGame(): void`
- **Purpose:** Transitions the game from `IDLE` or `GAME_OVER` to an active game session.
- **Preconditions:** `currentState` is `IDLE` or `GAME_OVER`.
- **Logic:**
  1. Reset `score = 0`.
  2. Clear `sequence = []`.
  3. Reset `playerStepIndex = 0`.
  4. Trigger `advanceRound()`.

#### `generateNextStep(): string`
- **Purpose:** Picks a random button ID from `BUTTON_IDS` and returns it.
- **Returns:** `string` (one of `'btn-green'`, `'btn-red'`, `'btn-yellow'`, `'btn-blue'`).

#### `advanceRound(): void`
- **Purpose:** Extends the pattern and transitions game to playback mode.
- **Logic:**
  1. Set `currentState = GAME_STATES.SHOWING_SEQUENCE`.
  2. Set `isInputLocked = true`.
  3. Reset `playerStepIndex = 0`.
  4. Generate and append new step: `sequence.push(generateNextStep())`.
  5. Notify View layer to update score and status.
  6. Trigger `playSequence()`.

#### `validatePlayerInput(buttonId: string): boolean`
- **Purpose:** Compares the player's button selection with the expected step.
- **Parameters:** `buttonId` (`string`)
- **Returns:** `true` if input matches `sequence[playerStepIndex]`, `false` otherwise.

#### `handleInputResult(isCorrect: boolean): void`
- **Logic:**
  - **If `false`:**
    1. Set `currentState = GAME_STATES.GAME_OVER`.
    2. Set `isInputLocked = true`.
    3. Call `endGame()`.
  - **If `true`:**
    1. Increment `playerStepIndex++`.
    2. **If `playerStepIndex === sequence.length`:** (Round complete)
       - Set `currentState = GAME_STATES.ROUND_SUCCESS`.
       - Set `isInputLocked = true`.
       - Increment `score++`.
       - Schedule `advanceRound()` after `TIMING_CONFIG.ROUND_DELAY`.
    3. **Else:** Remain in `GAME_STATES.AWAITING_INPUT`.

#### `endGame(): void`
- **Purpose:** Finalizes round loss and triggers game over presentation.
- **Side Effects:** Updates status display to show failure message and activates the restart control.

---

### 5.2 View & Controller Bridge Functions

#### `playSequence(): void`
- **Purpose:** Iterates through `sequence`, invoking a visual highlight for each step sequentially using `setTimeout` intervals.
- **Timing Flow:**
  - For step $i$ in `sequence`:
    - Schedule highlight onset at: $t = i \times \text{TIMING\_CONFIG.STEP\_INTERVAL}$.
    - Schedule highlight removal at: $t = i \times \text{TIMING\_CONFIG.STEP\_INTERVAL} + \text{TIMING\_CONFIG.STEP\_DURATION}$.
  - After the final step completes (at $t = \text{sequence.length} \times \text{TIMING\_CONFIG.STEP\_INTERVAL}$):
    - Set `currentState = GAME_STATES.AWAITING_INPUT`.
    - Set `isInputLocked = false`.
    - Update status message to `"Your turn!"`.

#### `highlightButton(buttonId: string, duration: number): void`
- **Purpose:** Applies an explicit plain active visual class (e.g., `.active` or inline opacity change) to the target button element and removes it after `duration` milliseconds. No CSS animations are used.

#### `lockInput(): void` & `unlockInput(): void`
- **Purpose:** Synchronizes both internal `isInputLocked` state and physical DOM button states (e.g., adding `disabled` attribute or `aria-disabled="true"` to prevent clicks).

#### `updateUI(): void`
- **Purpose:** Synchronizes text representations:
  - Updates Score counter element (`Score: X`).
  - Updates Game Status banner (`"Press Start"`, `"Watch sequence"`, `"Your turn"`, `"Game Over"`).
  - Toggles Start / Restart button visibility or label.

---

## 6. Event Handlers & Interaction Model

```
[Start Button Click]
   │
   ├── Is currentState in [IDLE, GAME_OVER]?
   │     ├── NO  ──> Ignore
   │     └── YES ──> Call startNewGame()

[Color Button Click (btnId)]
   │
   ├── Is isInputLocked === true OR currentState !== AWAITING_INPUT?
   │     ├── YES ──> Intercept and Discard event
   │     └── NO  ──>
   │           1. Temporarily flash button highlight (feedback)
   │           2. const isCorrect = validatePlayerInput(btnId)
   │           3. handleInputResult(isCorrect)
```

1. **Start/Restart Button Handler:**
   - Bound to the primary action button (`#start-btn`).
   - Guarded: Only active when `currentState` is `IDLE` or `GAME_OVER`.
2. **Color Grid Handler (Event Delegation):**
   - Single click event listener on the parent container (`#button-grid`).
   - Identifies clicked button via `event.target.dataset.id` or `id`.
   - Immediately rejects clicks if `isInputLocked === true` or if the clicked element is not a registered color button.

---

## 7. Scoring & Round Rules

1. **Score Accumulation:**
   - Initial Score: $0$.
   - A round is defined as successfully repeating the full generated sequence.
   - Upon matching all steps in a sequence of length $L$, the player earns $+1$ score point.
   - Formula: $\text{Current Score} = \text{Completed Rounds}$.
   - Sequence length for Round $R$ equals $R$ (Round 1: 1 step; Round 2: 2 steps; Round $N$: $N$ steps).
2. **Game Termination:**
   - Instant death: A single mismatched click terminates the round immediately.
   - Partial sequences do not award fractional points.
   - High score storage is omitted in Stage 1 (per constraints; no persistent storage).

---

## 8. Turn Order & Lifecycle Walkthrough

| Step | Actor | Phase | Action / State |
| :---: | :--- | :--- | :--- |
| 1 | **System** | Setup | Document loads. `initGame()` executes. State is `IDLE`. Score is `0`. Buttons are inactive. |
| 2 | **Player** | Trigger | Player clicks "Start". |
| 3 | **Engine** | Start | `startNewGame()` resets values, sets state to `SHOWING_SEQUENCE`, locks input. |
| 4 | **Engine** | Append | `generateNextStep()` picks position (e.g., `'btn-blue'`). `sequence = ['btn-blue']`. |
| 5 | **View** | Playback | `playSequence()` activates `'btn-blue'` for 400ms, then clears it. |
| 6 | **Engine** | Switch Turn | Playback completes. State shifts to `AWAITING_INPUT`. Input is unlocked. |
| 7 | **Player** | Input | Player clicks `'btn-blue'`. |
| 8 | **Engine** | Validation | Matches step 0. Round 1 complete. State shifts to `ROUND_SUCCESS`. Input is locked. Score becomes `1`. |
| 9 | **Engine** | Advance | 1000ms delay passes. `advanceRound()` called. State shifts to `SHOWING_SEQUENCE`. |
| 10 | **Engine** | Append | `generateNextStep()` picks `'btn-red'`. `sequence = ['btn-blue', 'btn-red']`. |
| 11 | **View** | Playback | Plays `'btn-blue'` (400ms), pauses (400ms), plays `'btn-red'` (400ms). |
| 12 | **Engine** | Switch Turn | State shifts to `AWAITING_INPUT`. Input unlocked. `playerStepIndex = 0`. |
| 13 | **Player** | Input | Player clicks `'btn-blue'`. Matches step 0. `playerStepIndex` increments to 1. |
| 14 | **Player** | Input | Player clicks `'btn-green'` (Mistake). |
| 15 | **Engine** | Game Over | Validation fails. State shifts to `GAME_OVER`. Input locked. Final Score = `1`. "Play Again" button enabled. |

---

## 9. Edge Cases & Defensive Logic

1. **Spam / Rapid Clicking During Sequence Playback:**
   - **Risk:** Clicks during playback could register prematurely and invalidate the turn.
   - **Mitigation:** The event listener checks `if (state.isInputLocked) return;` as line 1. In addition, the DOM elements are assigned the `disabled` property or CSS `pointer-events: none` while in `SHOWING_SEQUENCE`.
2. **Double-Clicking / Mashing Buttons During Player Turn:**
   - **Risk:** Rapid double clicking might evaluate two steps simultaneously or advance indices out of order.
   - **Mitigation:** Event handling is synchronous; the step index increments immediately upon click evaluation. If input fails on the first click, state shifts to `GAME_OVER` synchronously, discarding the subsequent click.
3. **Clicking the "Start" Button Repeatedly:**
   - **Risk:** Triggering multiple overlapping timers and sequence corruptions.
   - **Mitigation:** Start button is disabled (`button.disabled = true`) immediately upon entering `SHOWING_SEQUENCE` and throughout `AWAITING_INPUT`.
4. **Clicking Outside Color Buttons:**
   - **Risk:** Event delegation capturing clicks on grid margins or gaps.
   - **Mitigation:** Strict check verifying `event.target.classList.contains('game-btn')` and that the element ID exists in `BUTTON_IDS`.
5. **Page / Window Defocus or Minimization During Playback:**
   - **Risk:** Browser timer throttling (`setTimeout` de-prioritization) causing sequence desynchronization.
   - **Mitigation:** Timer tracking with clean timestamp-based delays or clearing timers via `clearTimeout` on abrupt state interrupts.

---

## 10. Acceptance Test Suite

| Test ID | Target Rule / Feature | Preconditions | Execution Action | Expected Result | Pass/Fail Criteria |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **TC-01** | Initial State Verification | Page freshly loaded. | Inspect UI and variables. | Score is 0, Start button enabled, 4 color buttons rendered and unclickable. | State is `IDLE`; input is locked. |
| **TC-02** | Start Trigger & Step 1 Generation | State is `IDLE`. | Click "Start" button. | Sequence array length becomes 1; 1 button lights up; Start button is disabled. | State shifts to `SHOWING_SEQUENCE`, then `AWAITING_INPUT`. |
| **TC-03** | Input Lock During Playback | State is `SHOWING_SEQUENCE`. | Rapidly click all 4 colored buttons while light is flashing. | No clicks register; no state change occurs; no game over triggered. | All click events are blocked and ignored. |
| **TC-04** | Valid Single Step Input | Sequence has 1 item (e.g. Red). State is `AWAITING_INPUT`. | Click "Red" button once. | Round marked success; score changes from 0 to 1; round advances. | State moves to `ROUND_SUCCESS`, then `SHOWING_SEQUENCE`. |
| **TC-05** | Sequence Extension | Round 1 completed. | Observe playback of Round 2. | Sequence length is 2; first step matches Round 1; a new random second step is displayed. | Exactly one step appended; previous steps preserved. |
| **TC-06** | Multi-Step Input Tracking | Sequence is `[Green, Blue]`. State is `AWAITING_INPUT`. | Click "Green". | Button registers; `playerStepIndex` increments to 1; game remains in `AWAITING_INPUT`. | No premature round advance until final step is clicked. |
| **TC-07** | Game Over on Wrong Input | Sequence is `[Green, Blue]`. State is `AWAITING_INPUT`. | Click "Yellow". | Game over triggered; status displays failure; color buttons disabled. | State is `GAME_OVER`; final score preserved; "Play Again" button displayed. |
| **TC-08** | Restart & Play Again Cycle | State is `GAME_OVER`, score was 5. | Click "Play Again" / "Start". | Score resets to 0; sequence resets to empty array; round 1 starts with 1 new step. | Complete state reset to initial game conditions. |
| **TC-09** | Offline Independence | Disconnect network / disable connection. | Refresh and run TC-01 through TC-08. | Game functions identically with zero external network requests or failures. | 100% functionality with local assets only. |