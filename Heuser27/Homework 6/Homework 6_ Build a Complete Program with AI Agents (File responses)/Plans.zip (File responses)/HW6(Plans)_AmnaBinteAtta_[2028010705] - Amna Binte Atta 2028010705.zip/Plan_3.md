﻿# Stage 3 Architecture & Design Plan: Sensory Feedback
**Project:** Neon Sequence — Pattern Memory Game  
**Document:** `Plan_3.md`  
**Phase:** Stage 3 — Audio Synthesis (Web Audio API) & Visual Feedback System  

---

## 1. System Overview & Architectural Objectives

### 1.1 Objective
Stage 3 layers synchronized acoustic and visual sensory feedback on top of the established Stage 1 core logic and Stage 2 visual layout. The objective is to provide a tactile, responsive arcade feel where every interaction has an immediate auditory and optical signature.

### 1.2 Core Architectural Principles
1. **Zero External Assets:** Sound is synthesized entirely at runtime via the browser's native **Web Audio API**. Zero audio files (`.mp3`, `.wav`, `.ogg`), images, or third-party sound libraries.
2. **Decoupled Audio-Visual Engine:** The game logic drives sound and animation requests via lightweight trigger hooks. If the Web Audio API fails to initialize, is blocked by browser autoplay policy, or is muted by the player, game state transitions and timers proceed without delay or exception.
3. **Restraint & Polish:** Feedback must be crisp and brief (150ms–350ms). Visual effects and synthesizer envelopes are tightly bounded to avoid visual fatigue, auditory clipping, or gameplay delays.
4. **Three-File Preservation:** All structure stays in `index.html`, all animation styling in `style.css`, and all audio synthesis and state hooks in `script.js`.

---

## 2. Feedback Matrix & Trigger Events

| Gameplay Event | Visual Animation / Effect | Audio Synthesizer Signature | Duration |
| :--- | :--- | :--- | :--- |
| **Sequence Step Playback (Computer Turn)** | Glowing bloom on target button (`.active` + keyframe pulse). | Clear, resonant harmonic synth tone unique to that color quadrant. | 350ms tone / 400ms flash |
| **Player Button Press (Intermediate Step)** | Tactile scale depression (`:active`) + rapid input bloom. | Same quadrant tone, shortened envelope (crisp feedback). | 150ms tone / 200ms flash |
| **Round Success (Turn Complete)** | Status pill glowing cyan/green border pulse (`.status-success`). | Upbeat ascending two-note major chord sweep (Arpeggio). | 250ms chord / 400ms pulse |
| **Incorrect Choice (Game Over)** | Chassis horizontal vibration (`.shake-error`) + red perimeter flash. | Low dissonant sawtooth/square buzz with rapid downward pitch drop. | 350ms buzz / 350ms shake |
| **Mute / Unmute Toggle** | Immediate button state text/icon update (`🔊 Sound: ON` $\leftrightarrow$ `🔇 Sound: OFF`). | Subtle high-frequency blip when unmuting; absolute silence when muting. | 60ms click blip |

---

## 3. Web Audio API Synthesis Architecture

```
                       [ Player / Game Trigger ]
                                  │
                                  ▼
                        Is AudioContext Ready?
                        ├── NO  ──> Lazy Init / Resume on User Gesture
                        └── YES ──> Check Mute State
                                        │
                         ┌──────────────┴──────────────┐
                         ▼                             ▼
                  [ gameState.isMuted ]         [ Sound Enabled ]
                         │                             │
                         ▼                             ▼
                    [ SILENT ]              Create OscillatorNode
                                            Create GainNode (Envelope)
                                                       │
                                                       ▼
                                            MasterGainNode (Mute Gate)
                                                       │
                                                       ▼
                                            audioCtx.destination
                                                       │
                                                       ▼
                                            Auto-Disconnect on End
```

### 3.1 AudioContext Initialization & Autoplay Compliance
- **Autoplay Policy:** Browsers block audio playback until a direct user gesture (such as clicking the Start button, the Mute button, or any game element) occurs.
- **Lazy Initialization Pattern:**
  - A global reference `audioCtx` is initialized as `null`.
  - An accessor function `getAudioContext()` initializes the context on first invocation:
    ```javascript
    function getAudioContext() {
      if (!audioCtx) {
        const AudioContextClass = window.AudioContext || window.webkitAudioContext;
        if (AudioContextClass) {
          audioCtx = new AudioContextClass();
        }
      }
      if (audioCtx && audioCtx.state === 'suspended') {
        audioCtx.resume();
      }
      return audioCtx;
    }
    ```
  - This function is invoked synchronously inside user click handlers (`onStartButtonClick`, `onGridClick`, `onMuteButtonClick`).

### 3.2 Tone Assignment & Musical Scale
The four buttons are assigned harmonious musical notes (Pentatonic / Major Triad) so that randomly generated sequences sound melodic rather than chaotic:

| Button ID | Color Identity | Note | Frequency ($Hz$) | Waveform |
| :--- | :--- | :--- | :--- | :--- |
| `#btn-green` | Neon Cyan | **C4** | `261.63 Hz` | Sine / Triangle blend |
| `#btn-red` | Neon Pink | **E4** | `329.63 Hz` | Sine / Triangle blend |
| `#btn-yellow` | Neon Yellow | **G4** | `392.00 Hz` | Sine / Triangle blend |
| `#btn-blue` | Neon Purple | **C5** | `523.25 Hz` | Sine / Triangle blend |

### 3.3 Synthesizer Node Pipelines

#### A. Standard Color Tone (`playColorTone(buttonId, durationMs)`)
- **Oscillator:** Type `'triangle'` (warm retro arcade character with soft harmonics).
- **Gain Envelope (Anti-Clicking):**
  - Instant attack: linear ramp from `0` to peak volume (`0.3`) in `0.01s`.
  - Sustain for $T - 0.05\text{s}$.
  - Exponential decay: smooth ramp down from `0.3` to `0.001` in the final `0.05s`.
  - Node stopped and disconnected at $T$.

#### B. Round Success Chime (`playSuccessChime()`)
- Dual-frequency arpeggio:
  - Step 1: Note **G4** (`392.00 Hz`) plays for `100ms`.
  - Step 2: Note **C5** (`523.25 Hz`) plays immediately for `180ms` with gentle exponential decay.
- Waveform: `'sine'` for bright, clean acoustic chime.

#### C. Game-Over Error Buzz (`playGameOverSound()`)
- **Oscillator:** Type `'sawtooth'` (abrasive, buzzer arcade feel).
- **Pitch Descent (Frequency Ramp):**
  - Starts at `160 Hz` and ramps down rapidly to `60 Hz` over `300ms` using `exponentialRampToValueAtTime`.
- **Envelope:** Linear attack to `0.35` gain in `0.02s`, holding for `150ms`, then exponential drop to `0.001` over `150ms`.

---

## 4. Mute System & Concurrency Control

### 4.1 State Representation & UI Control
- **State Variable:** `gameState.isMuted = false;` (In-memory flag; no `localStorage` per Stage 3 constraints).
- **DOM Element:** A high-contrast arcade button `#mute-btn` added inside the UI header or control section:
  ```html
  <button id="mute-btn" class="secondary-btn" aria-label="Toggle Sound" aria-pressed="false">
    <span class="mute-icon">🔊</span> <span class="mute-text">Sound: ON</span>
  </button>
  ```
- **Click Behavior:**
  - Toggles `gameState.isMuted = !gameState.isMuted`.
  - Updates button text, icon, and `aria-pressed` attribute.
  - If unmuting, calls `getAudioContext()` to resume context and plays a subtle `50ms` confirmation blip.
  - If muting, immediately silences all active sound nodes.

### 4.2 Runaway Oscillator & Leak Prevention
- **Ephemerality Rule:** Oscillators are **never** left running in a stopped or paused state.
- **Explicit Lifecycle Teardown:**
  ```javascript
  osc.stop(stopTime);
  osc.onended = () => {
    osc.disconnect();
    gainNode.disconnect();
  };
  ```
- **Master Gain Gate:** An overarching `masterGainNode` is connected to `audioCtx.destination`. When muted, `masterGainNode.gain.setValueAtTime(0, audioCtx.currentTime)` guarantees that zero sound reaches speakers, even if an asynchronous sound call is in flight.

---

## 5. CSS Animation Architecture & Keyframes

All visual feedback is orchestrated using lightweight CSS classes and transitions.

### 5.1 Keyframe Definitions (`style.css`)

```css
/* 1. Cabinet Shake for Game Over Error */
@keyframes arcade-shake {
  0% { transform: translateX(0); }
  20% { transform: translateX(-6px); }
  40% { transform: translateX(6px); }
  60% { transform: translateX(-4px); }
  80% { transform: translateX(4px); }
  100% { transform: translateX(0); }
}

/* 2. Success Status Glow */
@keyframes status-glow-pulse {
  0% { box-shadow: 0 0 5px rgba(0, 240, 255, 0.4); border-color: rgba(0, 240, 255, 0.4); }
  50% { box-shadow: 0 0 20px #00f0ff, 0 0 35px #00f0ff; border-color: #ffffff; }
  100% { box-shadow: 0 0 5px rgba(0, 240, 255, 0.4); border-color: rgba(0, 240, 255, 0.4); }
}

/* 3. Error Red Perimeter Pulse */
@keyframes cabinet-error-flash {
  0% { border-color: var(--bg-panel-border); }
  50% { border-color: #ff0055; box-shadow: 0 0 30px rgba(255, 0, 85, 0.6); }
  100% { border-color: var(--bg-panel-border); }
}
```

### 5.2 Application & Removal Classes
- `.shake-error`: Applied to `.game-container` on failure. Removed after `350ms` via `safeSetTimeout()`.
- `.status-success`: Applied to `#status-message` when a round is won. Removed after `400ms`.
- `.active`: Already integrated into `flashButton()`; enhanced with smooth brightness scale `transform: scale(1.03)`.

### 5.3 Reduced-Motion Compliance (`prefers-reduced-motion`)
For players with vestibular motion sensitivities:
```css
@media (prefers-reduced-motion: reduce) {
  .shake-error {
    animation: cabinet-error-flash 350ms ease-out !important;
    transform: none !important; /* Disables physical horizontal translation */
  }
  .color-btn, #start-btn, #mute-btn {
    transition: none !important;
  }
}
```

---

## 6. Interaction with Sequence Playback & Logic Timing

A critical requirement of Stage 3 is that audio-visual enhancements must **never desynchronize** the deterministic Stage 1 timing loop.

```
Playback Step i Timeline:
t = 0ms               t = 350ms       t = 400ms                     t = 650ms
├─────────────────────┼───────────────┼─────────────────────────────┤
│ Button Flash ON     │ Sound Ends    │ Button Flash OFF            │ Silence Gap
│ Synth Tone Starts   │ (Gain = 0)    │ (.active removed)           │ (Input Locked)
```

1. **Tone Duration Bounding:** Each playback step tone lasts strictly `350ms`, ending `50ms` before the `400ms` visual flash turns off, and a full `300ms` before the next step commences at `650ms`.
2. **Inter-Round Harmony:** The round-complete chime lasts `280ms`, fitting easily within the existing `1000ms` inter-round delay (`CONFIG.TIMING.INTER_ROUND_DELAY`) before the computer begins the next sequence.
3. **Game-Over Dissolution:** When an error occurs, `clearAllTimers()` cancels all queued playback tones, and the `playGameOverSound()` plays once without blocking the UI.

---

## 7. Component Arrangement & Header Layout Updates

The mute button is placed in the controls or header area with balanced spacing, maintaining the centered arcade chassis design:

```
+-------------------------------------------------------------------------+
| .game-container                                                         |
|                                                                         |
|   [ HEADER ROW ]                                                        |
|   TITLE: Neon Sequence                  [ 🔊 Sound: ON ] (#mute-btn)    |
|                                                                         |
|   [ DASHBOARD ]                                                         |
|   Score: 04               [ WATCH SEQUENCE ] (#status-message)          |
|                                                                         |
|   [ 2x2 ARCADE MATRIX ]                                                 |
|   [ CYAN ]      [ PINK ]                                                |
|   [ YELLOW ]    [ PURPLE ]                                              |
|                                                                         |
|   [ START / PLAY AGAIN CONTROLLER ]                                     |
|   [ ===================== START ===================== ]                 |
+-------------------------------------------------------------------------+
```

---

## 8. Common Stage 3 Bugs & Prevention Strategies

| Potential Bug | Root Cause | Impact | Prevention Strategy |
| :--- | :--- | :--- | :--- |
| **1. Audio Clicking / Popping** | Instantaneous start/stop of audio waveform at non-zero crossing. | Annoying speaker pop on every note. | Always apply linear or exponential ramps (`exponentialRampToValueAtTime`) on attack (10ms) and release (50ms). |
| **2. Autoplay Console Warnings** | Calling `new AudioContext()` or `ctx.resume()` on page load without user gesture. | Browser blocks audio; console throws warning. | Defer initialization until first user click on `#start-btn`, `#mute-btn`, or `.color-btn`. |
| **3. Audio Memory Leaks** | Creating `OscillatorNode` instances without calling `disconnect()`. | Browser audio graph consumes increasing memory. | Always bind `osc.onended = () => { osc.disconnect(); gain.disconnect(); }`. |
| **4. Stray Sounds During Mute** | Sounds triggered directly to `audioCtx.destination` bypassing mute check. | Audio leaks through when game is supposed to be silent. | Route all sounds through a centralized `masterGainNode` AND perform early return `if (gameState.isMuted) return;`. |
| **5. Animation Stacking / Desync** | Fast failure while success or active classes are still on DOM elements. | Buttons or chassis stuck in animated/shaking state. | In `handleIncorrectInput()` and `resetGameState()`, explicitly strip animation classes (`.shake-error`, `.status-success`, `.active`). |
| **6. Timer Collisions from Feedback** | Using raw `setTimeout` for feedback cleanup instead of `safeSetTimeout`. | Old feedback timers execute in new rounds. | All visual feedback removal timers must pass through `safeSetTimeout()`. |

---

## 9. Comprehensive Acceptance Test Suite (Stage 3)

| Test ID | Test Scenario | Preconditions | Action | Expected Result |
| :--- | :--- | :--- | :--- | :--- |
| **ST3-01** | **Initial Mute State & Layout** | Clean page load. | Inspect UI. | `#mute-btn` is visible in header/controls showing `🔊 Sound: ON`. `isMuted` is `false`. |
| **ST3-02** | **AudioContext Gesture Unlock** | Page loaded; audio suspended. | Click "Start" button. | `AudioContext` initializes or resumes to `'running'` state without browser console warnings. |
| **ST3-03** | **Distinct Playback Tones** | Round 1 begins; playback starts. | Observe flashing button. | The flashing button produces its distinct musical tone (C4, E4, G4, or C5) synchronized with the visual flash. |
| **ST3-04** | **Player Input Tone & Press Feel** | State is `PLAYER_TURN`. | Click any color button. | Button compresses tactually (`:active`), flashes, and immediately generates that button's pitch without lag. |
| **ST3-05** | **Round Success Audio-Visual** | State is `PLAYER_TURN`. | Complete the last step of the sequence. | Status pill glows with cyan/green pulse (`.status-success`); ascending chime plays; score increments cleanly. |
| **ST3-06** | **Game Over Error Feedback** | State is `PLAYER_TURN`. | Click the wrong color button. | Chassis vibrates briefly (`.shake-error`); low arcade error buzz plays; game-over message displays with final score. |
| **ST3-07** | **Mute Button Silencing** | Audio enabled. | Click `#mute-btn`. | Label toggles to `🔇 Sound: OFF`; `aria-pressed="true"`; all subsequent playback, click, and game-over sounds are 100% silent. |
| **ST3-08** | **Unmute Sound Restoration** | Game is muted. | Click `#mute-btn`. | Label toggles back to `🔊 Sound: ON`; confirmation blip sounds; subsequent game tones resume cleanly. |
| **ST3-09** | **Full Playability While Muted** | Game is muted. | Play 2 full rounds to victory and loss. | Game logic, scoring, sequence progression, input locking, and game-over behavior work identically with zero audio. |
| **ST3-10** | **Reduced-Motion Respect** | OS/browser `prefers-reduced-motion` enabled. | Trigger game-over error. | Chassis error flashes perimeter without horizontal shake displacement (`transform: none`). |
| **ST3-11** | **No Audio Node Leaks** | Play 5 continuous rounds. | Inspect active audio graph / memory. | All oscillator and gain nodes are disconnected immediately after `onended`; no runaway nodes remain. |
| **ST3-12** | **Strict Zero External Assets** | Disconnect network; inspect project root. | Reload page and check network tab. | 0 audio file requests, 0 external font/script fetches; exactly three code files (`index.html`, `style.css`, `script.js`). |

---

## 10. Deliberate Stage 4 Scope Boundaries

To prevent scope creep and adhere strictly to project progression rules, the following features are **explicitly excluded** from Stage 3 and reserved for Stage 4:

1. **No Persistent High Scores or Settings:** No `localStorage` or `sessionStorage`. Mute state and high scores reset on page reload.
2. **No Difficulty / Speed Selection:** Step intervals and playback tempo remain constant.
3. **No Synthesizer Sound Themes:** No selectable instrument options (e.g., 8-bit chip, piano, synthwave).
4. **No Complex Particle / Canvas FX:** No canvas fireworks, confetti, or background starfields.
5. **No Pause / Resume System:** Session runs continuously until game over.