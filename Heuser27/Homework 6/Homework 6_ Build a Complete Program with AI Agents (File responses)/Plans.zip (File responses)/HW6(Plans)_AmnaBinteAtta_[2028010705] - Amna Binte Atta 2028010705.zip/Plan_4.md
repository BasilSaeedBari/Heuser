﻿# Stage 4 Architecture & Design Plan: State & Storage
**Project:** Neon Sequence — Pattern Memory Game  
**Document:** `Plan_4.md`  
**Phase:** Stage 4 — State Machine Expansion, Session Persistence & Lifecycle Control  

---

## 1. System Overview & Architectural Objectives

### 1.1 Objective
Stage 4 elevates Neon Sequence from a transient session game into a fully state-managed, resilient arcade application. The primary objectives are:
1. **State Machine Completeness:** Formalize states including `IDLE` (Ready/Menu), `PLAYBACK`, `PLAYER_TURN`, `ROUND_SUCCESS`, `PAUSED`, and `GAME_OVER` with strict transition guards.
2. **Deterministic Pause/Resume:** Introduce a bulletproof pause mechanism capable of halting sequence playback or player input mid-stream and safely resuming without sequence corruption, timer collisions, or double-step anomalies.
3. **Safe Storage Persistence:** Persist all-time high score and sound mute preferences using `localStorage` under strict namespace isolation, defensive type-validation, and an in-memory fallback engine for restricted/private-browsing environments.
4. **Selective Reset Data:** Provide an accessible, confirmation-gated reset flow that wipes *only* Neon Sequence storage keys without affecting third-party browser storage.
5. **Architectural Invariance:** Strictly preserve the Stage 1 core rules, Stage 2 neon styling tokens, Stage 3 Web Audio synthesis, and the single-directory three-file architecture (`index.html`, `style.css`, `script.js`).

---

## 2. Expanded Game States & State-Transition Table

```mermaid
stateDiagram-v2
    [*] --> IDLE : Page Load / Init
    IDLE --> PLAYBACK : Click "Start"
    
    PLAYBACK --> PAUSED : Click "Pause"
    PAUSED --> PLAYBACK : Click "Resume" (Interrupted Playback)
    
    PLAYBACK --> PLAYER_TURN : Playback Finishes
    
    PLAYER_TURN --> PAUSED : Click "Pause"
    PAUSED --> PLAYER_TURN : Click "Resume" (Interrupted Input)
    
    PLAYER_TURN --> PLAYER_TURN : Correct Step (Partial)
    PLAYER_TURN --> ROUND_SUCCESS : Correct Step (Final)
    PLAYER_TURN --> GAME_OVER : Incorrect Step
    
    ROUND_SUCCESS --> PAUSED : Click "Pause" (During Inter-round Delay)
    PAUSED --> PLAYBACK : Click "Resume" (Advances to Next Round)
    
    ROUND_SUCCESS --> PLAYBACK : Inter-round Delay Expires
    
    GAME_OVER --> PLAYBACK : Click "Play Again"
```

### 2.1 State Definitions

| State Constant | Enum Identifier | Meaning & Context | Allowed Player Actions |
| :--- | :--- | :--- | :--- |
| `IDLE` | `GAME_STATES.IDLE` | Ready/Menu state on initial load or fresh restart. Awaiting start. | Click `Start`, Click `Mute`, Click `Reset Data`. |
| `PLAYBACK` | `GAME_STATES.PLAYBACK` | Computer is flashing the sequence with synthesized audio. | Click `Pause`, Click `Mute`. (Color buttons locked). |
| `PLAYER_TURN` | `GAME_STATES.PLAYER_TURN` | Awaiting player repetition of the pattern. | Click Color Buttons, Click `Pause`, Click `Mute`. |
| `ROUND_SUCCESS` | `GAME_STATES.ROUND_SUCCESS` | Player completed the sequence; brief inter-round transition. | Click `Pause`, Click `Mute`. (Color buttons locked). |
| `PAUSED` | `GAME_STATES.PAUSED` | Gameplay halted indefinitely. Timers suspended, buttons locked. | Click `Resume`, Click `Mute`, Click `Restart`, Click `Reset Data`. |
| `GAME_OVER` | `GAME_STATES.GAME_OVER` | Terminal round state following an error. High score verified. | Click `Play Again`, Click `Mute`, Click `Reset Data`. |

### 2.2 Comprehensive State Transition Table

| Source State | Event Trigger | Guard Conditions | Target State | State Actions & Side Effects |
| :--- | :--- | :--- | :--- | :--- |
| `IDLE` | Click `#start-btn` | None | `PLAYBACK` | Reset session `score = 0`, clear `sequence = []`, append step 1, schedule playback. |
| `PLAYBACK` | Click `#pause-btn` | `currentState === PLAYBACK` | `PAUSED` | Record `previousState = PLAYBACK`, abort active timeouts, silence oscillators, lock UI, toggle `#pause-btn` text to `"Resume"`. |
| `PLAYER_TURN` | Click `#pause-btn` | `currentState === PLAYER_TURN` | `PAUSED` | Record `previousState = PLAYER_TURN`, preserve `playerStepIndex`, lock buttons, toggle `#pause-btn` to `"Resume"`. |
| `ROUND_SUCCESS` | Click `#pause-btn` | `currentState === ROUND_SUCCESS` | `PAUSED` | Record `previousState = ROUND_SUCCESS`, cancel pending `startRound` timer, toggle `#pause-btn` to `"Resume"`. |
| `PAUSED` | Click `#pause-btn` | `currentState === PAUSED` | Dynamic (`PLAYBACK` or `PLAYER_TURN`) | Resolve target via `previousState`: If interrupted during playback or round success, replay current round's sequence from step 0; if interrupted during player turn, unlock buttons at current `playerStepIndex`. |
| `PAUSED` | Click `#restart-btn` | `currentState === PAUSED` | `PLAYBACK` | Abort paused session, reset `score = 0`, `sequence = []`, start fresh round 1. |
| `PLAYER_TURN` | Click `.color-btn` | Input matches `sequence[playerStepIndex]` AND `playerStepIndex < sequence.length - 1` | `PLAYER_TURN` | Flash button, play quadrant tone, increment `playerStepIndex++`. |
| `PLAYER_TURN` | Click `.color-btn` | Input matches `sequence[playerStepIndex]` AND `playerStepIndex === sequence.length - 1` | `ROUND_SUCCESS` | Flash button, play success chime, increment `score++`, check & persist `highScore`, schedule `advanceRound`. |
| `PLAYER_TURN` | Click `.color-btn` | Input does NOT match `sequence[playerStepIndex]` | `GAME_OVER` | Play error sound, trigger cabinet shake, check & persist `highScore`, enable `#start-btn` as `"Play Again"`. |
| `ROUND_SUCCESS` | Inter-round timer | Timer elapses ($1000\text{ms}$) | `PLAYBACK` | Append 1 random step to `sequence`, start sequence playback. |
| `GAME_OVER` | Click `#start-btn` | `currentState === GAME_OVER` | `PLAYBACK` | Reset session `score = 0`, clear `sequence = []`, start round 1. |

---

## 3. Storage Schema & Defensive Persistence Engine

### 3.1 Key Isolation & Data Schema
All keys are explicitly prefixed with `neon_seq_` to guarantee zero interference with other applications running on the same origin/host.

```
+--------------------------------------------------------------------------------+
|                             LOCALSTORAGE SCHEMA                                |
+------------------------+-------------+---------------+-------------------------+
| Key Name               | Type        | Default Value | Validation Criteria     |
+------------------------+-------------+---------------+-------------------------+
| neon_seq_high_score    | integer     | 0             | Number.isInteger(v)     |
|                        | (stringified|               | && v >= 0 && v <= 99999 |
|                        | decimal)    |               |                         |
+------------------------+-------------+---------------+-------------------------+
| neon_seq_muted         | boolean     | false         | v === "true" ||         |
|                        | (stringified|               | v === "false"           |
|                        | boolean)    |               |                         |
+------------------------+-------------+---------------+-------------------------+
```

### 3.2 In-Memory Fallback & Quota Resilience
Browsers in private-browsing modes (e.g. Safari incognito) or with hardened privacy configurations may throw `SecurityError` or `QuotaExceededError` upon accessing `window.localStorage`.
- **Architectural Solution:** The storage subsystem uses a transparent fallback memory dictionary `memoryStorageCache = {}`.
- If `localStorage` read/write operations throw an exception, operations divert to `memoryStorageCache` seamlessly without crashing the game loop or alerting the player unnecessarily.

### 3.3 Storage Access Layer (Defensive Specification)

```
[Write Request] ──> Try localStorage.setItem() ──> Catch Error ──> Write to memoryCache
[Read Request]  ──> Try localStorage.getItem() ──> Validate Schema ──> Return Validated or Default
[Reset Request] ──> Remove ONLY 'neon_seq_*' keys ──> Clear memoryCache ──> Restore Defaults
```

- **Validation Rules:**
  - `high_score`: Must parse to a finite integer $\ge 0$. If `NaN`, negative, float, or stringified garbage (`"foo"`), the parser discards the corrupted value and defaults to `0`.
  - `muted`: Must be strictly `'true'` or `'false'`. Any other value defaults to `false`.

---

## 4. Pause & Resume Operational Architecture

Pausing an arcade memory game introduces complex asynchronous edge cases. The plan establishes explicit, deterministic rules for every scenario.

### 4.1 Scenario A: Pause During Player Turn (`PLAYER_TURN`)
1. **Player clicks Pause:**
   - Set `gameState.previousState = GAME_STATES.PLAYER_TURN`.
   - Set `gameState.currentState = GAME_STATES.PAUSED`.
   - Lock player input (`setInputLocked(true)`).
   - Inactive buttons have their `:hover` and `:active` styling suppressed.
   - Any currently active click-flash highlight is immediately stripped.
   - Update `#status-message` to `"Game Paused"`.
   - Toggle `#pause-btn` label to `"Resume"`.
2. **Player clicks Resume:**
   - Set `gameState.currentState = GAME_STATES.PLAYER_TURN`.
   - Set `setInputLocked(false)`.
   - `gameState.playerStepIndex` is preserved exactly where the player left off.
   - Update `#status-message` to `"Your turn! Repeat the sequence."`.
   - Toggle `#pause-btn` label to `"Pause"`.

### 4.2 Scenario B: Pause During Sequence Playback (`PLAYBACK`)
Pausing mid-playback creates an ambiguity: if a button is halfway through a 400ms flash, resuming at millisecond 200 causes audio clicks, timer drift, and memory loss for the player.
- **Architectural Determinism (The Replay Rule):**
  1. **Player clicks Pause:**
     - Record `gameState.previousState = GAME_STATES.PLAYBACK`.
     - Set `gameState.currentState = GAME_STATES.PAUSED`.
     - Synchronously call `clearAllTimers()`: Cancels all pending `setTimeout` sequence triggers.
     - Synchronously call `clearAllActiveHighlights()`: Instantly removes `.active` from any illuminated button.
     - Silence any active Web Audio oscillators immediately.
     - Toggle `#pause-btn` to `"Resume"`.
     - Set status banner: `"Game Paused (Sequence Interrupted)"`.
  2. **Player clicks Resume:**
     - Set `gameState.currentState = GAME_STATES.PLAYBACK`.
     - Set status banner: `"Resuming sequence..."`.
     - To ensure complete fairness and zero cognitive disadvantage, the engine **replays the active round's sequence from step 0** after a brief $600\text{ms}$ readying pause.
     - No steps are added or removed; `gameState.sequence` is immutable during this replay.
     - After full playback completes, transitions cleanly to `PLAYER_TURN`.

### 4.3 Scenario C: Pause During Round Victory Delay (`ROUND_SUCCESS`)
1. **Player clicks Pause:**
   - Record `gameState.previousState = GAME_STATES.ROUND_SUCCESS`.
   - Synchronously call `clearAllTimers()`: Cancels the scheduled `startRound` execution.
   - Set `gameState.currentState = GAME_STATES.PAUSED`.
2. **Player clicks Resume:**
   - Call `startRound()` after a $500\text{ms}$ resume pause, advancing to the next round with a new step appended as normal.

---

## 5. UI Layout, Component Hierarchy & DOM Structure

To accommodate Pause, High Score, and Reset Data without cluttering the neon arcade aesthetic, the layout is extended cleanly inside `index.html` and `style.css`:

```
+-------------------------------------------------------------------------+
| .game-container                                                         |
|                                                                         |
|   [ HEADER ROW ]                                                        |
|   TITLE: Neon Sequence                  [ 🔊 Sound: ON ] (#mute-btn)    |
|                                                                         |
|   [ DASHBOARD STRIP ]                                                   |
|   +-----------------------------------------------------------------+   |
|   |  SCORE: 04               |  HIGH SCORE: 12                      |   |
|   +-----------------------------------------------------------------+   |
|   [ STATUS PILL: "Your turn! Repeat the sequence." ] (#status-message)  |
|                                                                         |
|   [ 2x2 ARCADE MATRIX ]                                                 |
|   [ CYAN ]      [ PINK ]                                                |
|   [ YELLOW ]    [ PURPLE ]                                              |
|                                                                         |
|   [ PRIMARY CONTROL BAR ]                                               |
|   +------------------------------------+ +--------------------------+   |
|   |  START / PLAY AGAIN (#start-btn)   | |  PAUSE / RESUME (#pause) |   |
|   +------------------------------------+ +--------------------------+   |
|                                                                         |
|   [ UTILITY FOOTER ]                                                    |
|   [ ↺ Reset Saved Data ] (#reset-data-btn)                              |
+-------------------------------------------------------------------------+
```

### 5.1 New DOM Elements
1. **High Score Counter (`#high-score-display`):** Positioned adjacent to `#score-display` within the dashboard strip. Styled in monospaced cyan/yellow.
2. **Pause Button (`#pause-btn`):** Positioned alongside `#start-btn` in a responsive flex row. Disabled during `IDLE` and `GAME_OVER`.
3. **Reset Data Button (`#reset-data-btn`):** Subdued, secondary arcade utility button placed at the base of the chassis. Styled with neutral borders, distinct hover glow, and accessible keyboard focus.

---

## 6. Functional Architecture & Method Specifications

```
+-----------------------------------------------------------------------------------+
|                            NEW & UPDATED MODULES                                  |
+--------------------------+------------------------------+-------------------------+
| Storage Controller       | State & Lifecycle Manager    | Pause / Resume Engine   |
+--------------------------+------------------------------+-------------------------+
| - loadStoredData()       | - setGameState(newState)     | - togglePause()         |
| - persistHighScore(val)  | - updateHighScore(newScore)  | - pauseGame()           |
| - persistMuteState(val)  | - confirmResetData()         | - resumeGame()          |
| - executeResetData()     | - updateDashboardUI()        | - replayInterruptedSeq()|
+--------------------------+------------------------------+-------------------------+
```

### 6.1 Storage Controller Functions

#### `loadStoredData(): void`
- **Responsibility:** Executes once during `init()`. Reads `neon_seq_high_score` and `neon_seq_muted`.
- **Logic:**
  1. Read raw strings from storage via `try/catch`.
  2. Parse `highScore`: convert to integer using `parseInt(val, 10)`. If invalid, negative, or `NaN`, set to `0`.
  3. Parse `muted`: check strict equivalence `val === 'true'`.
  4. Hydrate in-memory state: `gameState.highScore = parsedHighScore; gameState.isMuted = parsedMuted;`.
  5. Update DOM elements (`#high-score-display` and `#mute-btn`).

#### `persistHighScore(score: number): void`
- **Responsibility:** Saves a new high score to persistent storage and in-memory cache.
- **Logic:**
  - If `score > gameState.highScore`:
    - Set `gameState.highScore = score`.
    - Safe-write to storage: `localStorage.setItem('neon_seq_high_score', score.toString())`.
    - Update `#high-score-display` text content immediately.

#### `persistMuteState(isMuted: boolean): void`
- **Responsibility:** Persists player mute preference.
- **Logic:**
  - Safe-write: `localStorage.setItem('neon_seq_muted', isMuted ? 'true' : 'false')`.

#### `confirmResetData(): void`
- **Responsibility:** Guards data deletion behind an explicit browser confirmation dialog.
- **Logic:**
  1. Trigger standard accessible dialog: `const confirmed = window.confirm("Reset all saved data? Your high score and sound preferences will return to defaults.");`.
  2. If `confirmed === true`, call `executeResetData()`.
  3. If `confirmed === false`, take zero action.

#### `executeResetData(): void`
- **Responsibility:** Performs surgical, non-destructive deletion of game-specific storage items.
- **Logic:**
  1. Call `localStorage.removeItem('neon_seq_high_score')`.
  2. Call `localStorage.removeItem('neon_seq_muted')`.
  3. Reset in-memory state: `gameState.highScore = 0; gameState.isMuted = false;`.
  4. Update DOM: `#high-score-display` resets to `"High Score: 0"`, `#mute-btn` updates to `"🔊 Sound: ON"`.
  5. If the current game is active, update `#high-score-display` to show the current game's score if greater than 0, maintaining visual consistency.

---

### 6.2 Pause & Resume Functions

#### `togglePause(): void`
- **Responsibility:** Routes `#pause-btn` clicks to `pauseGame()` or `resumeGame()` based on `currentState`.
- **Guards:** Only operable when `currentState` is `PLAYBACK`, `PLAYER_TURN`, `ROUND_SUCCESS`, or `PAUSED`.

#### `pauseGame(): void`
- **Responsibility:** Freezes the active session without loss of progress.
- **Sequence of Actions:**
  1. Record current state: `gameState.previousState = gameState.currentState`.
  2. Set `gameState.currentState = GAME_STATES.PAUSED`.
  3. Set `setInputLocked(true)`.
  4. Clear all active timeouts: `clearAllTimers()`.
  5. Clear visual button states: `clearAllActiveHighlights()`.
  6. Update UI:
     - `#pause-btn.textContent = "Resume"`.
     - `#status-message.textContent = "Game Paused"`.
     - Disable color buttons and visual hover effects.

#### `resumeGame(): void`
- **Responsibility:** Unfreezes session and resumes the exact phase of play.
- **Sequence of Actions:**
  1. Set `#pause-btn.textContent = "Pause"`.
  2. Evaluate `gameState.previousState`:
     - **Case A (`PLAYER_TURN`):**
       - Transition: `gameState.currentState = GAME_STATES.PLAYER_TURN`.
       - Set `setInputLocked(false)`.
       - Restore status: `"Your turn! Repeat the sequence."`.
     - **Case B (`PLAYBACK`):**
       - Transition: `gameState.currentState = GAME_STATES.PLAYBACK`.
       - Set `setInputLocked(true)`.
       - Update status: `"Resuming sequence..."`.
       - Schedule `playSequence()` to replay active sequence after $600\text{ms}$.
     - **Case C (`ROUND_SUCCESS`):**
       - Transition: `gameState.currentState = GAME_STATES.ROUND_SUCCESS`.
       - Schedule `startRound()` after $500\text{ms}$.

---

## 7. High-Score Update Rules

1. **Evaluation Timing:**
   - High score is verified and updated continuously:
     - Instantly upon round success (`handleCorrectInput()` when `gameState.score > gameState.highScore`).
     - Upon game over (`handleIncorrectInput()`).
2. **Display Rules:**
   - Format: `High Score: X` (or `BEST: 00` arcade styling).
   - The display updates immediately during the round the high score is broken, giving immediate positive reinforcement.
3. **Persistence Condition:**
   - Persisted immediately to storage upon value change. If the player closes or reloads the browser mid-game, their newly achieved high score is already safely stored.

---

## 8. Timer Management & Concurrency Architecture

### 8.1 Centralized Timer Registry (`safeSetTimeout`)
The Stage 1 timer registry is preserved and reinforced for pause handling:
- Every active `setTimeout` ID is registered in `gameState.activeTimerIds`.
- Calling `clearAllTimers()` iterates through every registered handle and calls `window.clearTimeout(id)`.
- When pausing, `clearAllTimers()` executes synchronously, guaranteeing that **no stray playback callbacks can fire while the game is paused**.

### 8.2 Prevention of Zombie Callbacks
- Any asynchronous callback that wakes up checks:
  ```javascript
  if (gameState.currentState === GAME_STATES.PAUSED) {
    return; // Drop execution if state changed while callback was queued
  }
  ```

---

## 9. Comprehensive Acceptance Test Suite (Stage 4)

| Test ID | Scenario | Preconditions | Action | Expected Result |
| :--- | :--- | :--- | :--- | :--- |
| **ST4-01** | **Initial High Score Load** | No prior data in `localStorage`. | Load `index.html`. | High Score displays `0`. Storage key `neon_seq_high_score` is either absent or safely initialized. |
| **ST4-02** | **High Score Persistence** | High score is `0`. | Play and complete Round 1 (Score = 1). | High score immediately updates to `1` in UI and `localStorage.getItem('neon_seq_high_score') === '1'`. |
| **ST4-03** | **High Score Maintained on Loss** | Current score is `3`, High score is `5`. | Make an incorrect selection. | Final score is `3`; High score remains `5` in UI and storage. |
| **ST4-04** | **High Score Retained Across Reload** | High score is `7`. | Refresh page (`F5` / reload). | High Score display loads as `7` on initial load. |
| **ST4-05** | **Mute Preference Persistence** | Sound is unmuted. | Click `#mute-btn` to mute sound (`Sound: OFF`). Reload page. | Upon reload, game initializes in muted state (`Sound: OFF`, `isMuted === true`). |
| **ST4-06** | **Pause During Player Input** | State is `PLAYER_TURN` on step 2 of 4. | Click `#pause-btn`. | Game enters `PAUSED`. Buttons disable immediately. Status shows `"Game Paused"`. Button text becomes `"Resume"`. |
| **ST4-07** | **Resume During Player Input** | Game paused during `PLAYER_TURN`. | Click `#pause-btn` (`"Resume"`). | State returns to `PLAYER_TURN`. Buttons re-enable. `playerStepIndex` is still `2`. No progress lost. |
| **ST4-08** | **Pause During Sequence Playback** | Sequence is playing step 2 of 5. | Click `#pause-btn`. | All button flashes and audio tones stop immediately. All timers cleared. State becomes `PAUSED`. |
| **ST4-09** | **Resume After Interrupted Playback** | Game paused mid-playback. | Click `#pause-btn` (`"Resume"`). | Playback restarts cleanly from step 0 of the current round. No steps duplicated; array length unchanged. |
| **ST4-10** | **Input Blocked While Paused** | Game is in `PAUSED` state. | Click all 4 color buttons. | Zero button flashes, zero tones, zero input validation. Clicks are completely ignored. |
| **ST4-11** | **Restart From Paused State** | Game is in `PAUSED` state. | Click `#start-btn` / `#restart-btn`. | Current paused session cleanly aborts. State becomes `PLAYBACK` for a fresh Round 1 with `score = 0`. |
| **ST4-12** | **Selective Reset Data Execution** | Storage has `neon_seq_high_score = 10` and unrelated key `other_app_data = "safe"`. | Click `#reset-data-btn` and accept confirmation. | High score resets to `0` in UI and storage. Mute resets to default (`Sound: ON`). `other_app_data` is completely untouched. |
| **ST4-13** | **Reset Data Cancelation** | High score is `15`. | Click `#reset-data-btn` and select "Cancel" in confirmation. | High score remains `15`. No storage keys modified. |
| **ST4-14** | **Corrupted Storage Recovery** | `neon_seq_high_score` set manually to `"invalid_NaN_value"`. | Reload page. | Game loads safely without exceptions; high score falls back to default `0`. |
| **ST4-15** | **Storage Disabled / Private Mode** | `localStorage` throws `SecurityError` on access. | Play 2 full rounds. | Game functions normally using in-memory cache; no unhandled console errors crash the game. |

---

## 10. Regression Test Suite (Preservation of Stages 1–3)

| Target Area | Verification Requirement | Expected Result |
| :--- | :--- | :--- |
| **Stage 1: Core Logic** | Complete rounds 1 through 3 without pausing. | Score increments by 1 per round, sequence extends by 1 step per round, game-over triggers on first mismatch. |
| **Stage 1: Offline Access** | Open `index.html` via `file://` protocol. | Functions 100% offline with zero CDN or network dependencies. |
| **Stage 2: Neon Arcade Theme** | Inspect visual styling of buttons, chassis, and typography. | Dark navy/obsidian background, 4 neon primary quadrants (Cyan, Pink, Yellow, Purple), glowing text shadows intact. |
| **Stage 2: Responsive Matrix** | Resize viewport to narrow mobile width ($320\text{px}$). | Buttons, dashboard counters, and control buttons fit without clipping or horizontal scrollbars. |
| **Stage 3: Web Audio Synthesis** | Observe tone generation on playback and player click. | Harmonious triangle tones (C4, E4, G4, C5), victory arpeggio chime, and error buzz sound correctly without audio files. |
| **Stage 3: Sensory Animations** | Trigger error and success conditions. | Error triggers cabinet shake (`.shake-error`), success triggers status pulse (`.status-success`), button press triggers smooth scale depression. |

---

## 11. Risks, Failure Modes & Prevention Strategies

| Risk / Failure Mode | Root Cause | Architectural Mitigation Strategy |
| :--- | :--- | :--- |
| **1. Timer Drift / Overlap on Resume** | Queued timeouts resuming while new ones are dispatched. | Centralize all timer dispatching through `safeSetTimeout()`. Synchronously invoke `clearAllTimers()` on the first line of `pauseGame()` and `resetGameState()`. |
| **2. Storage Wiping Collateral Damage** | Calling `localStorage.clear()` in data reset. | Strictly forbid `localStorage.clear()`. Explicitly target only `localStorage.removeItem('neon_seq_high_score')` and `localStorage.removeItem('neon_seq_muted')`. |
| **3. Audio Desynchronization on Pause** | Audio oscillator scheduled to stop in future continues playing after pause click. | Keep active node references or ramp master gain to 0 instantly on pause; cancel scheduled Web Audio events. |
| **4. Double-Increment High Score Glitch** | Score evaluated against stale in-memory high score. | Synchronize `gameState.highScore` synchronously in the same tick that `gameState.score` increments. |
| **5. Broken UI State on Cancelled Confirm** | Modal blocks thread while browser timers continue to tick in background. | If a pause or confirm dialog opens, pause timers or ensure synchronous execution prevents state tearing. |

---

## 12. Deliberate Stage 5 Scope Boundaries

The following features are **strictly excluded** from Stage 4 and reserved for Stage 5:
1. **No Difficulty / Speed Selection:** Playback tempo remains static.
2. **No Alternate Sound Synthesizer Packs:** Waveforms remain fixed to default Stage 3 settings.
3. **No Online Leaderboards / REST APIs:** Persistence remains strictly local.
4. **No Complex Multi-Life / Streak Multipliers:** Single-error elimination rules remain unchanged.