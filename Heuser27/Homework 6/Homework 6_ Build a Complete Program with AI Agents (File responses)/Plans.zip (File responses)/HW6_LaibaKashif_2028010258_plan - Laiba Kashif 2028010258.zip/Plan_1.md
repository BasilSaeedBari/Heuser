Stage: Core Logic
Architect model: Claude Opus 4.6 (Thinking)
Builder model: Gemini 3.8 Flash (Low)
Result: Result: I implemented the core Star Seeker game with player movement, falling stars and asteroids, scoring, eternities, and start, game-over, restart functionality. Catching a star adds 10 points, missing a star decrease points by 5, hitting an asteroid costs 1 eternity, and missing an asteroid has no penalty. The game ends when the score drops below zero or eternities reach zero. The game was tested in the browser, and the implemented features worked as anticipated. Can use arrow keys to move planet left to right, or A and D to move left to right. For mobile, the player only has to touch the planet to move it left to right or vice verse (The ability to have planet moved from left to right by touch was implemented and tested in stage 4).


# Star Seeker — Stage 1: Core Logic Implementation Plan

> [!IMPORTANT]
> This document is the **complete architectural blueprint** for Stage 1. A separate Builder agent should be able to implement the entire game from this plan alone, without guessing any variable names, function signatures, or logic flows.

---

## 1. HTML Structure (`index.html`)

The HTML file is minimal. It loads the stylesheet, defines the game canvas, and loads the script.

```
DOCTYPE html
<html lang="en">
  <head>
    meta charset UTF-8
    meta viewport (width=device-width, initial-scale=1.0)
    <title>Star Seeker</title>
    link to style.css
  </head>
  <body>
    <canvas id="gameCanvas" width="800" height="600"></canvas>
    script src="script.js"
  </body>
</html>
```

### Key decisions

| Element | Detail |
|---|---|
| Single `<canvas>` | All rendering (game objects, HUD text, screens) is drawn on this one canvas. No extra DOM overlays. |
| Fixed canvas size | 800 × 600 px. Keeps coordinate math simple; responsive scaling is deferred to a later stage. |
| Script at bottom of `<body>` | Guarantees the canvas element exists before `script.js` runs — no `DOMContentLoaded` listener needed. |
| No external resources | Zero `<link>` to CDNs, zero `<img>` tags, zero font imports. Fully offline. |

---

## 2. CSS (`style.css`)

Stage 1 CSS is purely functional — enough to center the canvas and set a neutral background.

```
Responsibilities:
- body: margin 0, overflow hidden, background #111, 
         display flex, justify-content center, align-items center,
         height 100vh
- #gameCanvas: display block, background #000, 
               border 2px solid #333
```

No animations, no font-face declarations, no media queries. Those are later-stage concerns.

---

## 3. Game Loop & Object Movement

### 3.1 Loop mechanism

Use `requestAnimationFrame` for a smooth, browser-synced loop. **Delta-time** is used to keep movement frame-rate-independent.

```
Variables:
  lastTime        — timestamp of the previous frame (ms)
  animationId     — return value of requestAnimationFrame (for cancellation)

Function: gameLoop(timestamp)
  1. deltaTime = (timestamp - lastTime) / 1000   // seconds
  2. Clamp deltaTime to a max of 0.05 (50 ms) to prevent huge jumps on tab-refocus
  3. lastTime = timestamp
  4. If gameState === "playing":
       a. updateGame(deltaTime)
       b. renderGame()
     Else if gameState === "start":
       renderStartScreen()
     Else if gameState === "gameover":
       renderGameOverScreen()
  5. animationId = requestAnimationFrame(gameLoop)
```

### 3.2 Object movement

Every falling object stores its own `y` position and `speed` (pixels per second). Each frame:

```
object.y += object.speed * deltaTime
```

The planet's horizontal movement works identically:

```
planet.x += planet.dx * deltaTime
```

where `planet.dx` is set by keyboard input (see §4).

---

## 4. Planet Movement, Keyboard Input & Boundary Checks

### 4.1 Planet object

```
const planet = {
  x: 400,           // center x (starts at canvas center)
  y: 560,           // fixed y (near bottom)
  width: 60,        // collision box width
  height: 20,       // collision box height
  speed: 400,       // pixels per second
  dx: 0             // current horizontal velocity
}
```

> [!NOTE]
> In Stage 1 the planet is drawn as a simple filled rectangle (or arc). The "planet" sprite is a later-stage visual concern.

### 4.2 Keyboard input

Track key state with a `keys` object so that held-down keys produce continuous movement.

```
Variable:
  keys = {}         // e.g. { ArrowLeft: true, ArrowRight: false, ... }

Event listeners (added once at script load):
  document.addEventListener("keydown", (e) => {
    keys[e.key] = true
    // If gameState === "start"  → call startGame()
    // If gameState === "gameover" → call restartGame()
  })

  document.addEventListener("keyup", (e) => {
    keys[e.key] = false
  })
```

### 4.3 Movement resolution (called every frame inside `updateGame`)

```
Function: updatePlanet(deltaTime)
  1. planet.dx = 0
  2. If keys["ArrowLeft"] OR keys["a"] OR keys["A"] → planet.dx = -planet.speed
  3. If keys["ArrowRight"] OR keys["d"] OR keys["D"] → planet.dx = +planet.speed
  4. planet.x += planet.dx * deltaTime
  5. Clamp: if planet.x < 0 → planet.x = 0
  6. Clamp: if planet.x + planet.width > canvas.width → planet.x = canvas.width - planet.width
```

### 4.4 Preventing default scroll

Inside the `keydown` listener, call `e.preventDefault()` for arrow keys to stop the page from scrolling.

---

## 5. Star & Asteroid Spawning

### 5.1 Object schema

Every falling object is a plain JS object pushed into a single shared array.

```
Variable:
  fallingObjects = []    // array of { type, x, y, width, height, speed, counted }

Object shape:
  {
    type:    "star" | "asteroid",
    x:       <random>,           // 0 to canvas.width - width
    y:       -height,            // spawn just above visible area
    width:   20,                 // collision box
    height:  20,
    speed:   <random in range>,  // px/sec
    counted: false               // has this object already been scored/penalized?
  }
```

### 5.2 Spawn timer

```
Variables:
  spawnTimer      = 0        // accumulator (seconds)
  spawnInterval   = 1.0      // seconds between spawns (may decrease over time)

Inside updateGame(deltaTime):
  spawnTimer += deltaTime
  if spawnTimer >= spawnInterval:
    spawnTimer -= spawnInterval
    spawnFallingObject()
```

### 5.3 `spawnFallingObject()`

```
Function: spawnFallingObject()
  1. Decide type: Math.random() < 0.35 → "asteroid", else → "star"
     (65 % stars, 35 % asteroids — keeps the game fair)
  2. Set width = 20, height = 20
  3. Set x = Math.random() * (canvas.width - width)
  4. Set y = -height
  5. Set speed:
       star     → random 150–250 px/sec
       asteroid → random 200–300 px/sec (slightly faster = more threatening)
  6. Set counted = false
  7. Push object into fallingObjects[]
```

### 5.4 Gradual difficulty (optional but recommended for Stage 1)

Every 30 seconds, decrease `spawnInterval` by 0.1, with a floor of 0.4. This naturally ramps difficulty.

```
Variables:
  difficultyTimer    = 0
  difficultyInterval = 30      // seconds

Inside updateGame(deltaTime):
  difficultyTimer += deltaTime
  if difficultyTimer >= difficultyInterval:
    difficultyTimer -= difficultyInterval
    if spawnInterval > 0.4:
      spawnInterval -= 0.1
```

---

## 6. Collision Detection

### 6.1 Algorithm — Axis-Aligned Bounding Box (AABB)

```
Function: isColliding(a, b)  →  boolean
  return a.x < b.x + b.width  &&
         a.x + a.width > b.x  &&
         a.y < b.y + b.height &&
         a.y + a.height > b.y
```

Both `a` and `b` must have `{ x, y, width, height }`.

### 6.2 When to check

Inside `updateGame`, after moving all objects but **before** removing them:

```
for each obj in fallingObjects:
  if obj.counted → skip
  if isColliding(planet, obj):
    obj.counted = true          // prevent double-scoring
    if obj.type === "star":
      score += 10
    else if obj.type === "asteroid":
      lives -= 1
      if lives <= 0 → gameState = "gameover"
```

---

## 7. Scoring & Lives

### 7.1 State variables

```
let score = 0
let lives = 3
```

### 7.2 HUD rendering (inside `renderGame`)

Draw text directly onto the canvas using `ctx.fillText`:

```
ctx.fillStyle = "#FFD700"   // gold
ctx.font = "20px monospace"
ctx.textAlign = "left"
ctx.fillText("Score: " + score, 10, 30)

ctx.fillStyle = "#FF4444"   // red
ctx.textAlign = "right"
ctx.fillText("Lives: " + lives, canvas.width - 10, 30)
```

### 7.3 Scoring events summary

| Event | Effect |
|---|---|
| Star caught (collision) | +10 points |
| Asteroid caught (collision) | −1 life |
| Star missed (exits bottom) | −1 life |
| Asteroid missed (exits bottom) | No penalty |
| Lives reach 0 | Transition to `"gameover"` state |

---

## 8. Game States

### 8.1 State variable

```
let gameState = "start"     // "start" | "playing" | "gameover"
```

### 8.2 State transitions

```mermaid
stateDiagram-v2
    [*] --> start
    start --> playing : Any key press
    playing --> gameover : lives <= 0
    gameover --> playing : Any key press (calls restartGame)
```

### 8.3 Screen rendering functions

**`renderStartScreen()`**
```
1. Fill canvas with black
2. Draw title "STAR SEEKER" centered, large font, gold color
3. Draw "Press any key to start" centered below, smaller font, white
```

**`renderGameOverScreen()`**
```
1. Fill canvas with black
2. Draw "GAME OVER" centered, large font, red
3. Draw "Final Score: " + score centered, medium font, white
4. Draw "Press any key to restart" centered below, smaller font, white
```

**`renderGame()`**
```
1. ctx.clearRect(0, 0, canvas.width, canvas.height)
2. Draw planet (filled rectangle or arc, blue/cyan)
3. For each obj in fallingObjects:
     if obj.type === "star"    → draw gold rectangle/circle
     if obj.type === "asteroid" → draw red rectangle/circle
4. Draw HUD (score, lives)
```

> [!TIP]
> In Stage 1, simple `ctx.fillRect` or `ctx.beginPath(); ctx.arc(...)` calls are sufficient. Polished visuals come later.

---

## 9. Restart Behavior & Complete State Reset

### 9.1 `startGame()` function

Called on the first key press from the start screen.

```
Function: startGame()
  gameState = "playing"
  resetGameState()
```

### 9.2 `restartGame()` function

Called on key press from the game-over screen.

```
Function: restartGame()
  gameState = "playing"
  resetGameState()
```

### 9.3 `resetGameState()` function

Centralizes **all** variable resets to avoid bugs from partial resets.

```
Function: resetGameState()
  score = 0
  lives = 3
  fallingObjects = []          // clear the array entirely (new reference)
  spawnTimer = 0
  spawnInterval = 1.0          // reset difficulty
  difficultyTimer = 0
  planet.x = (canvas.width - planet.width) / 2   // re-center planet
  planet.dx = 0
  keys = {}                    // flush any stuck keys
```

> [!WARNING]
> The `keys` object **must** be reset on restart. If the player was holding a key when the game ended, the key-up event may never fire, causing the planet to drift immediately on restart.

---

## 10. Object Removal & Preventing Duplicate Collisions

### 10.1 Removal pass

After the collision check loop, remove objects that are either caught or off-screen. Use a **reverse-index splice** or a **filter** to avoid index-skipping bugs:

```
Preferred approach — rebuild array with filter:

  fallingObjects = fallingObjects.filter(obj => {
    // Remove if caught (already counted via collision)
    if (obj.counted && isColliding(planet, obj)) return false

    // If it passed the bottom of the screen:
    if (obj.y > canvas.height) {
      if (obj.type === "star" && !obj.counted) {
        lives -= 1
        if (lives <= 0) gameState = "gameover"
      }
      return false   // remove regardless of type
    }

    return true      // keep
  })
```

### 10.2 The `counted` flag — preventing duplicates

The boolean `counted` on each object ensures:
- A star awards points **exactly once** (set `counted = true` on collision).
- A star deducts a life **exactly once** if missed (checked when `y > canvas.height` and `counted` is still `false`).
- An asteroid deducts a life **exactly once** on collision.

Without this flag, fast frame rates or large hitboxes could trigger the same collision across multiple frames.

### 10.3 Recommended update order inside `updateGame(deltaTime)`

```
1. updatePlanet(deltaTime)
2. Update falling object positions (move y += speed * deltaTime)
3. Collision detection loop (set counted, adjust score/lives)
4. Check for game over (lives <= 0)
5. Removal pass (filter out caught + off-screen objects, apply miss penalty)
6. Check for game over again (a missed star may have cost the last life)
7. Spawn logic (spawnTimer, difficulty ramp)
```

> [!IMPORTANT]
> The **miss penalty** (life lost for a missed star) happens in the removal pass, not in the collision loop. This means the game-over check must happen **after** the removal pass as well.

---

## 11. File Responsibilities

### `index.html`
- Declares the document and meta tags
- Contains a single `<canvas>` element
- Links `style.css` and `script.js`
- **No inline JavaScript. No inline styles. No other DOM elements.**

### `style.css`
- Centers the canvas on the page
- Sets page background color
- Sets canvas background and border
- **Stage 1 only: ~10 lines of CSS. No animations, no transitions.**

### `script.js`
All game logic lives here. Organized into these logical sections:

| Section | Contents |
|---|---|
| **Canvas setup** | `canvas`, `ctx` references; canvas dimensions as constants |
| **Game state variables** | `gameState`, `score`, `lives`, `fallingObjects`, `spawnTimer`, `spawnInterval`, `difficultyTimer`, `keys`, `lastTime`, `animationId` |
| **Planet object** | `planet` with `x`, `y`, `width`, `height`, `speed`, `dx` |
| **Input handlers** | `keydown` and `keyup` listeners |
| **Game control functions** | `startGame()`, `restartGame()`, `resetGameState()` |
| **Update functions** | `updateGame(dt)`, `updatePlanet(dt)`, `spawnFallingObject()` |
| **Collision function** | `isColliding(a, b)` |
| **Render functions** | `renderGame()`, `renderStartScreen()`, `renderGameOverScreen()` |
| **Game loop** | `gameLoop(timestamp)` + initial `requestAnimationFrame(gameLoop)` call |

---

## 12. Manual Test Checklist

> Run each test by opening `index.html` directly in a browser (double-click). No server needed.

| # | Test | Steps | Expected Result |
|---|---|---|---|
| T1 | **File loads offline** | Double-click `index.html` | Canvas appears, start screen shows "STAR SEEKER" and "Press any key to start" |
| T2 | **Start game** | Press any key on start screen | Game begins; planet visible at bottom center; objects begin falling |
| T3 | **Move left (Arrow)** | Hold `ArrowLeft` | Planet moves left smoothly |
| T4 | **Move right (Arrow)** | Hold `ArrowRight` | Planet moves right smoothly |
| T5 | **Move left (A key)** | Hold `A` or `a` | Planet moves left smoothly |
| T6 | **Move right (D key)** | Hold `D` or `d` | Planet moves right smoothly |
| T7 | **Left boundary** | Hold left until edge | Planet stops at x = 0, does not disappear or wrap |
| T8 | **Right boundary** | Hold right until edge | Planet stops at canvas right edge, does not disappear or wrap |
| T9 | **Stars fall** | Observe gameplay | Gold objects fall from random x positions at top |
| T10 | **Asteroids fall** | Observe gameplay | Red objects fall from random x positions, slightly faster |
| T11 | **Catch a star** | Move planet under a gold star | Score increases by 10; star disappears |
| T12 | **Hit an asteroid** | Move planet under a red asteroid | Lives decrease by 1; asteroid disappears |
| T13 | **Miss a star** | Let a gold star pass the bottom | Lives decrease by 1 |
| T14 | **Miss an asteroid** | Let a red asteroid pass the bottom | No life lost; asteroid disappears |
| T15 | **Score display** | Catch several stars | "Score: N" updates correctly in top-left |
| T16 | **Lives display** | Hit an asteroid or miss a star | "Lives: N" updates correctly in top-right |
| T17 | **Game over trigger** | Lose all 3 lives | Screen changes to "GAME OVER" with final score |
| T18 | **Restart** | Press any key on game-over screen | Game resets: score = 0, lives = 3, no leftover objects, planet centered |
| T19 | **No stuck movement on restart** | Hold a key when game ends, release, restart | Planet does not drift on its own after restart |
| T20 | **No duplicate scoring** | Catch a star (watch score) | Score increases by exactly 10, not 20 or 30 |
| T21 | **Objects cleaned up** | Play for 60+ seconds | No visual glitches from accumulated off-screen objects (check via console: `fallingObjects.length` stays reasonable) |
| T22 | **Difficulty ramp** | Play for 60+ seconds | Objects spawn more frequently over time |
| T23 | **Tab away and back** | Switch tabs for 5 seconds, return | Game doesn't glitch or teleport objects (delta-time clamp handles this) |
| T24 | **Arrow keys don't scroll** | Press arrow keys during gameplay | Page does not scroll |

---

## 13. Likely Bugs & Prevention Strategies

### Bug 1: Frame-rate-dependent movement
**Cause:** Using `object.y += speed` without delta time makes the game run at different speeds on 60 Hz vs 144 Hz monitors.
**Prevention:** All movement is multiplied by `deltaTime` (seconds). See §3.

### Bug 2: Huge delta-time spike on tab refocus
**Cause:** When the browser tab is backgrounded, `requestAnimationFrame` pauses. The first frame back has a massive `deltaTime`, teleporting objects.
**Prevention:** Clamp `deltaTime` to a max of 0.05 seconds (50 ms). See §3.1 step 2.

### Bug 3: Stuck keys after game-over
**Cause:** Player holds a movement key when the game ends. The `keyup` event fires while the game is in `"gameover"` state, and the `keys` object is never cleared.
**Prevention:** `resetGameState()` resets `keys = {}`. See §9.3.

### Bug 4: Double-scoring a collision
**Cause:** A falling object overlaps the planet for 2+ frames, triggering the score/life change each frame.
**Prevention:** Each object has a `counted` flag. Once set to `true`, the collision branch is skipped. See §10.2.

### Bug 5: Index-skipping when splicing in a forward loop
**Cause:** `for (let i = 0; i < arr.length; i++) { arr.splice(i, 1); }` skips the element after each splice because indices shift.
**Prevention:** Use `Array.filter()` to rebuild the array instead of in-place splicing. See §10.1.

### Bug 6: Star miss penalty applied twice
**Cause:** A star's "miss" penalty is applied in the removal pass, but if the same star was already `counted` by a near-miss collision detection, it might or might not be penalized.
**Prevention:** The miss penalty only fires when `obj.type === "star" && !obj.counted`. A caught star always has `counted = true`, so it's never double-penalized. See §10.1.

### Bug 7: Planet drawn off-screen at startup
**Cause:** Planet's initial `x` is hard-coded to a value that doesn't account for its width.
**Prevention:** Initial `planet.x = (canvas.width - planet.width) / 2`. See §4.1.

### Bug 8: `NaN` on first frame
**Cause:** `lastTime` is undefined on the very first `requestAnimationFrame` callback, so `timestamp - undefined = NaN`.
**Prevention:** Initialize `lastTime` inside `gameLoop` on first call:
```
if (!lastTime) { lastTime = timestamp; }
```
Alternatively, set `lastTime = 0` and let the delta-time clamp handle the first large delta.

### Bug 9: Key event fires multiple times (auto-repeat)
**Cause:** Holding a key triggers repeated `keydown` events. If the start/restart logic listens on `keydown`, it could fire `startGame()` many times.
**Prevention:** Ignore repeated keys by checking `if (e.repeat) return;` at the top of the `keydown` handler. Additionally, `startGame` and `restartGame` only transition state if the current state matches (`"start"` or `"gameover"`), so redundant calls are no-ops.

### Bug 10: Falling objects accumulate in memory
**Cause:** Objects that fall off-screen are never removed.
**Prevention:** The removal pass filters out any object with `y > canvas.height`. See §10.1.

---

## Stage 1 Completion Checklist

Before Stage 1 is considered **done**, every item below must be true:

- [ ] `index.html` opens in a browser via double-click (no server)
- [ ] Start screen displays title and prompt
- [ ] Pressing a key transitions to gameplay
- [ ] Planet renders at bottom center and moves with Arrow keys and A/D
- [ ] Planet cannot move outside canvas boundaries
- [ ] Stars (gold) and asteroids (red) spawn and fall
- [ ] Catching a star adds 10 points
- [ ] Colliding with an asteroid removes 1 life
- [ ] Missing a star removes 1 life
- [ ] Missing an asteroid has no penalty
- [ ] Score and lives display correctly on the HUD
- [ ] Game transitions to game-over screen when lives reach 0
- [ ] Game-over screen shows final score
- [ ] Pressing a key on game-over restarts with full state reset
- [ ] No stuck keys, no double-scoring, no off-screen object buildup
- [ ] All 24 manual tests in §12 pass
