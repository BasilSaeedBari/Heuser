Stage: Sensory Feedback 
Architect model: Claude Opus 4.6 (Thinking)
Builder model: Gemini 3.8 Flash (Low)
Result: I implemented sensory feedback throughout Star Seeker, including visual effects for catching stars, missing stars, asteroid collisions, and game over. I added code-generated sound effects and a mute/unmute control while preserving the existing gameplay mechanics, cosmic aesthetic, and colour palette. I tested the game in the browser and confirmed that the features worked as expected (A pause and restart button were also implemented and tested during stage 4).


# Plan 3 — Stage 3: Sensory Feedback Implementation Plan

> **Role:** Architect Plan (read-only — no code changes)
> **Game:** Star Seeker
> **Stage:** 3 of 5 — Sensory Feedback
> **Files in scope:** `index.html`, `style.css`, `script.js`

---

## 1. Stage 3 Overview

Add tasteful visual effects and code-generated audio feedback to every meaningful game event — catching stars, missing stars, colliding with asteroids, and game over. Add a mute/unmute control. All effects must be brief, lightweight, and must never interfere with existing game logic, scoring, collision detection, or movement.

**What this stage does NOT do:**
- Does not change any scoring, collision, spawn, difficulty, or movement logic.
- Does not add persistent storage or a pause system (Stage 4).
- Does not add new game modes or features (Stage 5).
- Does not replace or redesign existing visuals from Stage 2.
- Does not add external files, libraries, or assets.

---

## 2. Audio System Architecture

### 2.1 Web Audio API Setup

Create a single global `AudioContext` instance. Due to browser autoplay policies, the `AudioContext` must be created or resumed on the first user interaction (key press or click).

**New global variables (add near top of `script.js`):**

```
let audioCtx = null;
let isMuted = false;
```

**Initialisation function:**

```
function initAudio():
  if audioCtx is null:
    audioCtx = new (window.AudioContext || window.webkitAudioContext)()
  if audioCtx.state === "suspended":
    audioCtx.resume()
```

**When to call `initAudio()`:**
- Inside `startGame()` (called on first key press or click from the start screen).
- Inside `restartGame()` (in case context was suspended).
- This ensures no sound plays before the player actively interacts with the game.

### 2.2 Sound Effect Design

All sounds are generated programmatically using oscillator nodes and gain nodes. Each sound function creates short-lived nodes, connects them through a gain node, and schedules their stop time. Nodes are automatically garbage-collected after they stop.

Every sound function must check `if (isMuted || !audioCtx) return;` at the top before creating any nodes.

#### Sound A — Star Collected (pleasant chime)

**Character:** A bright, short two-tone ascending chime. Evokes a "ding-ding" reward.

```
function playSoundStarCollected():
  if isMuted or !audioCtx: return

  const now = audioCtx.currentTime

  // Note 1 — short high ping
  const osc1 = audioCtx.createOscillator()
  const gain1 = audioCtx.createGain()
  osc1.type = "sine"
  osc1.frequency.setValueAtTime(880, now)           // A5
  gain1.gain.setValueAtTime(0.15, now)
  gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.12)
  osc1.connect(gain1).connect(audioCtx.destination)
  osc1.start(now)
  osc1.stop(now + 0.12)

  // Note 2 — slightly higher, slightly delayed
  const osc2 = audioCtx.createOscillator()
  const gain2 = audioCtx.createGain()
  osc2.type = "sine"
  osc2.frequency.setValueAtTime(1174.66, now + 0.06)  // D6
  gain2.gain.setValueAtTime(0.0001, now)
  gain2.gain.setValueAtTime(0.12, now + 0.06)
  gain2.gain.exponentialRampToValueAtTime(0.001, now + 0.2)
  osc2.connect(gain2).connect(audioCtx.destination)
  osc2.start(now + 0.06)
  osc2.stop(now + 0.2)
```

**Duration:** ~200ms total. Two sine tones, ascending pitch, quick decay.

#### Sound B — Star Missed (soft descending note)

**Character:** A single quiet, short descending tone. Subtle; should not be alarming.

```
function playSoundStarMissed():
  if isMuted or !audioCtx: return

  const now = audioCtx.currentTime
  const osc = audioCtx.createOscillator()
  const gain = audioCtx.createGain()
  osc.type = "sine"
  osc.frequency.setValueAtTime(440, now)            // A4
  osc.frequency.exponentialRampToValueAtTime(330, now + 0.15)  // Slide down to E4
  gain.gain.setValueAtTime(0.08, now)               // Quiet
  gain.gain.exponentialRampToValueAtTime(0.001, now + 0.15)
  osc.connect(gain).connect(audioCtx.destination)
  osc.start(now)
  osc.stop(now + 0.15)
```

**Duration:** ~150ms. Single sine, descending pitch, very quiet.

#### Sound C — Asteroid Collision (impact thud)

**Character:** A short, low-frequency thump with a bit of noise — feels like a physical impact.

```
function playSoundAsteroidHit():
  if isMuted or !audioCtx: return

  const now = audioCtx.currentTime

  // Low thump oscillator
  const osc = audioCtx.createOscillator()
  const gain = audioCtx.createGain()
  osc.type = "triangle"
  osc.frequency.setValueAtTime(150, now)
  osc.frequency.exponentialRampToValueAtTime(40, now + 0.15)   // Pitch drops
  gain.gain.setValueAtTime(0.25, now)
  gain.gain.exponentialRampToValueAtTime(0.001, now + 0.2)
  osc.connect(gain).connect(audioCtx.destination)
  osc.start(now)
  osc.stop(now + 0.2)

  // Noise burst (short buffer of random samples)
  const bufferSize = audioCtx.sampleRate * 0.08   // 80ms of noise
  const noiseBuffer = audioCtx.createBuffer(1, bufferSize, audioCtx.sampleRate)
  const data = noiseBuffer.getChannelData(0)
  for (let i = 0; i < bufferSize; i++):
    data[i] = (Math.random() * 2 - 1) * 0.3
  const noise = audioCtx.createBufferSource()
  const noiseGain = audioCtx.createGain()
  noise.buffer = noiseBuffer
  noiseGain.gain.setValueAtTime(0.12, now)
  noiseGain.gain.exponentialRampToValueAtTime(0.001, now + 0.08)
  noise.connect(noiseGain).connect(audioCtx.destination)
  noise.start(now)
  noise.stop(now + 0.08)
```

**Duration:** ~200ms. Triangle wave dropping in pitch + short noise burst layered together.

#### Sound D — Game Over (sombre descending chord)

**Character:** Two or three tones descending together, slightly longer. Final, solemn, not jarring.

```
function playSoundGameOver():
  if isMuted or !audioCtx: return

  const now = audioCtx.currentTime
  const notes = [523.25, 392.00, 261.63]   // C5, G4, C4 — descending
  const delays = [0, 0.12, 0.24]

  notes.forEach((freq, i) => {
    const osc = audioCtx.createOscillator()
    const gain = audioCtx.createGain()
    osc.type = "sine"
    osc.frequency.setValueAtTime(freq, now + delays[i])
    gain.gain.setValueAtTime(0.0001, now)
    gain.gain.setValueAtTime(0.12, now + delays[i])
    gain.gain.exponentialRampToValueAtTime(0.001, now + delays[i] + 0.35)
    osc.connect(gain).connect(audioCtx.destination)
    osc.start(now + delays[i])
    osc.stop(now + delays[i] + 0.35)
  })
```

**Duration:** ~600ms total (three staggered notes). Played once when `gameState` transitions to `"gameover"`.

### 2.3 Sound Trigger Points (where to call each function)

| Sound Function | Trigger Location in `script.js` | Exact Insertion Point |
|---|---|---|
| `playSoundStarCollected()` | `updateGame()` → collision loop → `if (obj.type === "star")` block | After `score += 10;` (line 197) |
| `playSoundStarMissed()` | `updateGame()` → filter/miss loop → `if (obj.type === "star" && !obj.counted)` block | After `score -= 5;` (line 217) |
| `playSoundAsteroidHit()` | `updateGame()` → collision loop → `if (obj.type === "asteroid")` block | After `lives -= 1;` (line 199) |
| `playSoundGameOver()` | `updateGame()` → both places where `gameState = "gameover"` is set | After `gameState = "gameover";` at line 201 AND line 219 |

**Important:** `playSoundGameOver()` is called at the same moment as `playSoundAsteroidHit()` when the last eternity is lost by an asteroid collision. This is acceptable — the two sounds layer naturally (a thud followed by the descending chord). The star-miss game-over case does not also play `playSoundStarMissed()` — only `playSoundGameOver()` should be called for that path (or both can play; they are quiet enough to layer).

**Recommendation:** For the asteroid-caused game-over, call both `playSoundAsteroidHit()` and `playSoundGameOver()`. For the score-below-zero game-over, call both `playSoundStarMissed()` and `playSoundGameOver()`. The event sounds are always relevant, and the game-over sound adds finality.

---

## 3. Visual Effect System

### 3.1 Particle / Effect Array

Add a global array to hold active visual effects:

```
let visualEffects = [];
```

Each effect object has:

```
{
  type: "sparkle" | "floatText" | "impact" | "miss",
  x: number,
  y: number,
  age: 0,               // seconds elapsed since creation
  lifetime: number,      // seconds until removal
  ...type-specific properties
}
```

### 3.2 Effect Update & Render Functions

**`updateEffects(deltaTime)`** — called inside `updateGame()` after all game logic:
```
function updateEffects(deltaTime):
  for each effect in visualEffects:
    effect.age += deltaTime
  visualEffects = visualEffects.filter(e => e.age < e.lifetime)
```

**`renderEffects(ctx)`** — called inside `renderGame()` after drawing all game objects and HUD:
```
function renderEffects(ctx):
  for each effect in visualEffects:
    switch effect.type:
      case "sparkle": renderSparkleEffect(ctx, effect); break
      case "floatText": renderFloatTextEffect(ctx, effect); break
      case "impact": renderImpactEffect(ctx, effect); break
      case "miss": renderMissEffect(ctx, effect); break
```

**Important:** Effects are render-only overlays. They do not participate in collision detection, scoring, or any game state changes.

### 3.3 Reduced Motion Support

At the top of `script.js`, detect the user's reduced-motion preference:

```
const prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
```

When `prefersReducedMotion` is `true`:
- Skip all particle/burst effects (sparkle, impact).
- Still show floating score text (it conveys important information).
- Still play sounds (audio is not motion).
- Use simpler, non-animated versions of feedback where practical (e.g., a brief opacity flash on the HUD text instead of particles).

The effect-spawning functions (Section 3.4) should check this flag and emit a simplified or no effect accordingly.

### 3.4 Effect Definitions

#### Effect A — Star Collected Sparkle

**Trigger:** When `obj.type === "star"` and collision is detected (same point where `score += 10` happens).

**Spawn function:**
```
function spawnStarCollectedEffect(x, y):
  if prefersReducedMotion:
    // Just spawn the floating score text, no particles
    spawnFloatText(x, y - 10, "+10", PERIWINKLE)
    return

  // 6-8 small sparkle particles radiating outward
  const numParticles = 7
  for i = 0 to numParticles - 1:
    const angle = (i / numParticles) * 2 * Math.PI + (Math.random() * 0.3)
    const speed = 60 + Math.random() * 40     // px/sec
    visualEffects.push({
      type: "sparkle",
      x: x,
      y: y,
      vx: Math.cos(angle) * speed,
      vy: Math.sin(angle) * speed,
      age: 0,
      lifetime: 0.35,
      radius: 1.5 + Math.random() * 1.5,
      color: (Math.random() > 0.5) ? PERIWINKLE : PINK_ORCHID
    })

  // Also spawn floating "+10" text
  spawnFloatText(x, y - 10, "+10", PERIWINKLE)
```

**Renderer — `renderSparkleEffect(ctx, e)`:**
```
function renderSparkleEffect(ctx, e):
  const progress = e.age / e.lifetime           // 0 → 1
  const opacity = 1 - progress                  // fades out
  const currentX = e.x + e.vx * e.age
  const currentY = e.y + e.vy * e.age
  const currentRadius = e.radius * (1 - progress * 0.5)   // shrinks slightly

  ctx.save()
  ctx.globalAlpha = Math.max(0, opacity)
  ctx.fillStyle = e.color
  ctx.beginPath()
  ctx.arc(currentX, currentY, currentRadius, 0, Math.PI * 2)
  ctx.fill()
  ctx.restore()
```

**Visual result:** 7 small coloured dots radiate outward from the catch point in a ring, fading and shrinking over 350ms. Accompanied by a floating "+10" text.

#### Effect B — Floating Score Text

**Trigger:** Spawned by the star-collected effect ("+10") and the star-missed effect ("−5").

**Spawn function:**
```
function spawnFloatText(x, y, text, color):
  visualEffects.push({
    type: "floatText",
    x: x,
    y: y,
    text: text,
    color: color,
    age: 0,
    lifetime: 0.7,
    floatSpeed: -40    // px/sec upward (negative Y)
  })
```

**Renderer — `renderFloatTextEffect(ctx, e)`:**
```
function renderFloatTextEffect(ctx, e):
  const progress = e.age / e.lifetime
  const opacity = 1 - progress
  const currentY = e.y + e.floatSpeed * e.age

  ctx.save()
  ctx.globalAlpha = Math.max(0, opacity)
  ctx.fillStyle = e.color
  ctx.font = "bold 16px 'Courier New', 'Lucida Console', 'Consolas', monospace"
  ctx.textAlign = "center"
  ctx.textBaseline = "middle"
  ctx.fillText(e.text, e.x, currentY)
  ctx.restore()
```

**Visual result:** The text drifts upward ~28px while fading out over 700ms. Clear and readable but does not obstruct gameplay.

#### Effect C — Star Missed Indicator

**Trigger:** When `obj.type === "star" && !obj.counted` and the star falls off the bottom of the canvas.

**Spawn function:**
```
function spawnStarMissedEffect(x):
  // x = horizontal position where the star fell off; y = bottom of canvas
  spawnFloatText(x, CANVAS_HEIGHT - 30, "−5", BUBBLEGUM_PINK)
```

No particles for a miss — just the floating text. This keeps it subtle and avoids excessive visual noise.

**Visual result:** A small "−5" text in Bubblegum Pink rises from near the bottom of the screen and fades. Brief and non-distracting.

#### Effect D — Asteroid Collision Impact

**Trigger:** When `obj.type === "asteroid"` and collision is detected (same point where `lives -= 1` happens).

**Spawn function:**
```
function spawnAsteroidHitEffect(x, y):
  if prefersReducedMotion:
    // Just flash the eternity counter (handled separately via HUD flash)
    triggerEternityFlash()
    return

  // Expanding ring effect
  visualEffects.push({
    type: "impact",
    x: x,
    y: y,
    age: 0,
    lifetime: 0.4,
    maxRadius: 35
  })

  // Also trigger HUD flash
  triggerEternityFlash()

  // Screen shake
  triggerScreenShake(0.2, 4)    // 200ms, 4px amplitude
```

**Renderer — `renderImpactEffect(ctx, e)`:**
```
function renderImpactEffect(ctx, e):
  const progress = e.age / e.lifetime
  const radius = e.maxRadius * progress
  const opacity = 1 - progress

  ctx.save()
  ctx.globalAlpha = Math.max(0, opacity * 0.6)
  ctx.strokeStyle = BUBBLEGUM_PINK
  ctx.lineWidth = 2.5 * (1 - progress)
  ctx.beginPath()
  ctx.arc(e.x, e.y, radius, 0, Math.PI * 2)
  ctx.stroke()
  ctx.restore()
```

**Visual result:** A thin Bubblegum Pink ring expands outward from the collision point, fading as it grows. Lasts 400ms. Clear impact feedback without obscuring the play area.

### 3.5 Eternity Counter Flash

When the player loses an eternity, the ETERNITIES HUD text should briefly flash to draw attention.

**Implementation:**

```
let eternityFlashTimer = 0;    // global variable, seconds remaining

function triggerEternityFlash():
  eternityFlashTimer = 0.5     // 500ms flash
```

**Modify `drawHUD()`** to check `eternityFlashTimer`:

```
// Inside drawHUD(), when drawing the ETERNITIES text:
if eternityFlashTimer > 0:
  // Alternate between BUBBLEGUM_PINK and PINK_ORCHID every ~100ms
  const flashPhase = Math.floor(eternityFlashTimer * 10) % 2
  ctx.fillStyle = (flashPhase === 0) ? BUBBLEGUM_PINK : PINK_ORCHID
else:
  ctx.fillStyle = PINK_ORCHID
```

**Decrement `eternityFlashTimer`** in `updateGame()`:
```
if eternityFlashTimer > 0:
  eternityFlashTimer -= deltaTime
```

This gives a gentle 2–3-cycle flash, not a strobe. When `prefersReducedMotion` is true, the flash should still occur (it's a colour change on existing text, not motion), but the Builder may optionally reduce it to a single brief colour swap.

### 3.6 Screen Shake

A very brief, subtle camera shake on asteroid collision.

**Implementation:**

```
let shakeTimer = 0;          // seconds remaining
let shakeIntensity = 0;      // max pixel offset

function triggerScreenShake(duration, intensity):
  if prefersReducedMotion: return    // Skip for reduced motion
  shakeTimer = duration
  shakeIntensity = intensity
```

**Modify the rendering pipeline in `renderGame()`:**

```
function renderGame():
  ctx.save()

  // Apply screen shake offset
  if shakeTimer > 0:
    const progress = shakeTimer / 0.2    // normalise (assumes max duration 0.2s)
    const currentIntensity = shakeIntensity * progress
    const offsetX = (Math.random() * 2 - 1) * currentIntensity
    const offsetY = (Math.random() * 2 - 1) * currentIntensity
    ctx.translate(offsetX, offsetY)

  // ... existing render code (background, objects, planet, HUD, effects) ...

  ctx.restore()
```

**Decrement `shakeTimer`** in `updateGame()`:
```
if shakeTimer > 0:
  shakeTimer -= deltaTime
```

**Parameters:** Duration = 200ms, intensity = 4 pixels max. This is a very subtle jitter, not a violent shake. It decays to zero over the duration.

---

## 4. Game-Over Feedback

### 4.1 Visual Transition

When the game transitions to `gameState === "gameover"`:

1. **Play `playSoundGameOver()`** (already covered in Section 2.3).
2. **Existing overlay is sufficient.** The current game-over screen already draws a dark overlay (`rgba(11, 40, 82, 0.7)`) and displays the "GAME OVER" title with a Bubblegum Pink glow.
3. **Add a brief fade-in for the overlay.** Instead of snapping instantly to the game-over screen, animate the overlay opacity from 0 to 0.7 over approximately 500ms.

**Implementation:**

Add a global variable:
```
let gameOverFadeTimer = 0;      // seconds elapsed in game-over state
const GAME_OVER_FADE_DURATION = 0.5;  // 500ms
```

Reset `gameOverFadeTimer = 0` whenever `gameState` changes to `"gameover"`.

**In `renderGameOverScreen()`**, compute the overlay opacity:
```
gameOverFadeTimer += deltaTime   // note: use frame delta or track in gameLoop

const fadeProgress = Math.min(1, gameOverFadeTimer / GAME_OVER_FADE_DURATION)
const overlayOpacity = 0.7 * fadeProgress
ctx.fillStyle = `rgba(11, 40, 82, ${overlayOpacity})`
ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT)

// Text elements also fade in with the same progress
ctx.globalAlpha = fadeProgress
// ... draw GAME OVER text, final score, restart prompt ...
ctx.globalAlpha = 1.0
```

**Tracking delta time in game-over state:** The `gameLoop()` function already computes `deltaTime`. Currently it only calls `updateGame(deltaTime)` when `gameState === "playing"`. For the fade effect, pass `deltaTime` to `renderGameOverScreen(deltaTime)` so it can advance the fade timer.

**If `prefersReducedMotion` is true:** Skip the fade animation. Show the game-over screen at full opacity immediately (existing behaviour).

### 4.2 Last Frame Preservation

During the fade-in, the gameplay scene (planet, objects, HUD) should be visible beneath the darkening overlay. To achieve this, when the game state transitions to `"gameover"`:

**Option A (Recommended — simple):** Render the last game frame (background + remaining objects + planet + HUD) as the base layer of the game-over screen, then draw the fade overlay on top, then draw the text.

The existing `renderGameOverScreen()` already draws the cosmic background. Modify it to also draw any remaining falling objects and the planet before the overlay, giving a "freeze frame" effect:

```
function renderGameOverScreen(deltaTime):
  // 1. Draw the cosmic background
  ctx.drawImage(backgroundCanvas, 0, 0)

  // 2. Draw frozen game objects (no update, just render their last positions)
  for each obj in fallingObjects:
    if obj.type === "star": drawCollectibleStar(ctx, obj)
    else: drawAsteroid(ctx, obj)
  drawPlanet(ctx, planet)

  // 3. Draw fade overlay
  gameOverFadeTimer += deltaTime
  const fadeProgress = Math.min(1, gameOverFadeTimer / GAME_OVER_FADE_DURATION)
  const overlayOpacity = 0.7 * fadeProgress
  ctx.fillStyle = `rgba(11, 40, 82, ${overlayOpacity})`
  ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT)

  // 4. Draw text (fades in)
  ctx.save()
  ctx.globalAlpha = fadeProgress
  // ... existing GAME OVER text, final score, restart prompt ...
  ctx.restore()
```

---

## 5. Mute / Unmute Control

### 5.1 Visual Placement

Place a mute/unmute button in the **top-right corner of the canvas**, positioned to the left of the ETERNITIES counter during gameplay, or at a fixed position on all screens.

**Recommended position:** `x = CANVAS_WIDTH - 45, y = 12`, rendered as a `24 × 24` clickable area.

This button is drawn on the canvas (not as an HTML element), keeping the project at three files with no additional DOM elements beyond the existing canvas.

### 5.2 Visual Design

**Unmuted (sound on):** Draw a small speaker icon using canvas lines:
- A small rectangle (speaker body) + a triangle (speaker cone) in Periwinkle.
- Two small arcs (sound waves) to the right in Periwinkle.

**Muted (sound off):** Same speaker body and cone, but:
- No sound wave arcs.
- A diagonal line (slash) through the icon in Bubblegum Pink.

**Construction (pseudocode):**

```
function drawMuteButton(ctx):
  const bx = CANVAS_WIDTH - 45
  const by = 12
  const size = 20

  ctx.save()
  ctx.strokeStyle = PERIWINKLE
  ctx.fillStyle = PERIWINKLE
  ctx.lineWidth = 1.5

  // Speaker body — small rectangle
  ctx.fillRect(bx + 2, by + 6, 5, 8)

  // Speaker cone — triangle
  ctx.beginPath()
  ctx.moveTo(bx + 7, by + 6)
  ctx.lineTo(bx + 13, by + 2)
  ctx.lineTo(bx + 13, by + 18)
  ctx.lineTo(bx + 7, by + 14)
  ctx.closePath()
  ctx.fill()

  if not isMuted:
    // Sound waves — two arcs
    ctx.beginPath()
    ctx.arc(bx + 13, by + 10, 5, -Math.PI / 4, Math.PI / 4)
    ctx.stroke()
    ctx.beginPath()
    ctx.arc(bx + 13, by + 10, 9, -Math.PI / 4, Math.PI / 4)
    ctx.stroke()
  else:
    // Mute slash — diagonal line in Bubblegum Pink
    ctx.strokeStyle = BUBBLEGUM_PINK
    ctx.lineWidth = 2
    ctx.beginPath()
    ctx.moveTo(bx + 1, by + 1)
    ctx.lineTo(bx + 19, by + 19)
    ctx.stroke()

  ctx.restore()
```

### 5.3 Click Detection

The mute button must respond to mouse clicks on the canvas. Modify the existing `canvas.addEventListener("click", ...)` handler:

```
canvas.addEventListener("click", (e) => {
  const rect = canvas.getBoundingClientRect()
  const scaleX = CANVAS_WIDTH / rect.width
  const scaleY = CANVAS_HEIGHT / rect.height
  const clickX = (e.clientX - rect.left) * scaleX
  const clickY = (e.clientY - rect.top) * scaleY

  // Check if click is on the mute button area
  const bx = CANVAS_WIDTH - 45
  const by = 12
  if (clickX >= bx && clickX <= bx + 24 && clickY >= by && clickY <= by + 24) {
    isMuted = !isMuted
    return    // Don't process as a game-start or restart click
  }

  // Existing click logic
  if (gameState === "start") {
    startGame()
  } else if (gameState === "gameover") {
    restartGame()
  }
})
```

**Key detail:** The mute-button click check must happen **before** the game-state click checks. If the click is on the mute button, `return` immediately so it does not also trigger start/restart.

### 5.4 Keyboard Shortcut

Add the **M** key as a mute toggle. In the `keydown` handler:

```
// Inside the keydown listener, before the gameState checks:
if (e.key === "m" || e.key === "M") {
  isMuted = !isMuted
  e.preventDefault()
  return
}
```

**Important:** This must be placed **before** the `if (gameState === "start") { startGame(); return; }` block, so pressing M on the start screen toggles mute instead of starting the game.

### 5.5 Rendering the Mute Button

Call `drawMuteButton(ctx)` at the end of each render function:
- `renderStartScreen()` — after all start-screen text.
- `renderGame()` — after HUD and effects.
- `renderGameOverScreen()` — after all game-over text.

This ensures the mute button is always visible and always on top.

---

## 6. Changes by File

### 6.1 `index.html`

**No changes.** The HTML structure remains exactly as-is.

### 6.2 `style.css`

**No changes.** All visual effects are rendered on the canvas.

### 6.3 `script.js`

#### A. New Global Variables (add near top, after existing declarations)

```javascript
// --- Audio ---
let audioCtx = null;
let isMuted = false;

// --- Visual Effects ---
let visualEffects = [];
let eternityFlashTimer = 0;
let shakeTimer = 0;
let shakeIntensity = 0;
let gameOverFadeTimer = 0;
const GAME_OVER_FADE_DURATION = 0.5;

// --- Reduced Motion ---
const prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
```

#### B. New Functions (add after existing helper functions)

| Function | Purpose | Approximate Length |
|---|---|---|
| `initAudio()` | Create / resume AudioContext | ~5 lines |
| `playSoundStarCollected()` | Two-tone ascending chime | ~20 lines |
| `playSoundStarMissed()` | Soft descending note | ~12 lines |
| `playSoundAsteroidHit()` | Low impact thud + noise | ~25 lines |
| `playSoundGameOver()` | Descending three-note chord | ~18 lines |
| `updateEffects(deltaTime)` | Age and cull visual effects | ~5 lines |
| `renderEffects(ctx)` | Dispatch to individual renderers | ~8 lines |
| `renderSparkleEffect(ctx, e)` | Draw fading outward particle | ~12 lines |
| `renderFloatTextEffect(ctx, e)` | Draw rising fading text | ~12 lines |
| `renderImpactEffect(ctx, e)` | Draw expanding ring | ~12 lines |
| `spawnStarCollectedEffect(x, y)` | Create sparkle particles + float text | ~15 lines |
| `spawnFloatText(x, y, text, color)` | Create floating score text | ~10 lines |
| `spawnStarMissedEffect(x)` | Create "−5" float text | ~3 lines |
| `spawnAsteroidHitEffect(x, y)` | Create impact ring + shake + flash | ~10 lines |
| `triggerEternityFlash()` | Start HUD flash timer | ~2 lines |
| `triggerScreenShake(duration, intensity)` | Start screen shake timer | ~4 lines |
| `drawMuteButton(ctx)` | Render speaker icon | ~25 lines |

#### C. Modified Functions

| Function | Modification |
|---|---|
| `startGame()` | Add `initAudio()` call |
| `restartGame()` | Add `initAudio()` call; reset `visualEffects = []`, `eternityFlashTimer = 0`, `shakeTimer = 0`, `gameOverFadeTimer = 0` |
| `resetGameState()` | Add reset of `visualEffects`, `eternityFlashTimer`, `shakeTimer`, `gameOverFadeTimer` |
| `updateGame(deltaTime)` | After `score += 10`: call `playSoundStarCollected()`, `spawnStarCollectedEffect(cx, cy)`. After `lives -= 1`: call `playSoundAsteroidHit()`, `spawnAsteroidHitEffect(cx, cy)`. After `score -= 5`: call `playSoundStarMissed()`, `spawnStarMissedEffect(obj.x + obj.width / 2)`. After each `gameState = "gameover"`: call `playSoundGameOver()`, set `gameOverFadeTimer = 0`. After all game logic: call `updateEffects(deltaTime)`. Decrement `eternityFlashTimer` and `shakeTimer`. |
| `drawHUD()` | Add eternity flash logic (conditionally change fill colour based on `eternityFlashTimer`) |
| `renderGame()` | Wrap all drawing in `ctx.save()` / `ctx.restore()` with shake translation. Call `renderEffects(ctx)` after HUD. Call `drawMuteButton(ctx)` last. |
| `renderStartScreen()` | Call `drawMuteButton(ctx)` at the end. |
| `renderGameOverScreen()` | Accept `deltaTime` parameter. Add fade-in logic. Draw frozen game objects beneath overlay. Call `drawMuteButton(ctx)` at the end. |
| `gameLoop()` | Pass `deltaTime` to `renderGameOverScreen(deltaTime)`. |
| `canvas click handler` | Add mute-button hit-test before existing game-state checks. Use `getBoundingClientRect()` and scale factors for accurate click coordinates. |
| `keydown handler` | Add M-key mute toggle before game-state checks. |

#### D. Lines That Must NOT Be Changed

All the same untouched lines from Stage 2 remain untouched:

| Code Section | Lines (approx.) | Reason |
|---|---|---|
| `isColliding()` | 148–155 | Core collision logic |
| `updatePlanet()` | 158–177 | Movement and clamping logic |
| `spawnFallingObject()` | 111–145 | Spawn logic (type, speed, probability) — no changes to probabilities or speeds |
| `generateAsteroidVertices()` | 251–260 | Asteroid shape generation |
| `generateBackground()` | 278–401 | Background rendering |
| `drawStarShape()` | 262–276 | Star shape helper |
| `drawPlanet()` | 403–443 | Planet rendering |
| `drawCollectibleStar()` | 445–471 | Star rendering |
| `drawAsteroid()` | 473–520 | Asteroid rendering |
| `planet` object properties | 36–43 | Position, size, speed |
| `MAX_LIVES`, scoring constants | 22–23 | Starting count = 7 |
| Spawn probabilities, speed ranges | 112–128 | 65/35 split, speed values |

**Scoring and game-over rules (lines 196–223) must remain exactly as-is in terms of logic.** Sound calls and effect spawns are **appended after** each scoring/state-change line, never replacing them.

---

## 7. Integration Safety

### 7.1 Effects Do Not Affect Game Logic

- The `visualEffects` array is completely independent of `fallingObjects`.
- No effect object is ever checked in `isColliding()`.
- No effect modifies `score`, `lives`, `gameState`, `planet`, or `fallingObjects`.
- Effects are only drawn after all game objects and the HUD.

### 7.2 Effects Are Properly Cleaned Up

- Every effect has a finite `lifetime`. `updateEffects()` removes expired effects every frame.
- `visualEffects` is reset to `[]` in `resetGameState()`.
- Audio nodes are `stop()`-ped with a scheduled time and auto-disconnect.
- The `AudioContext` is created once and reused — not re-created per sound.

### 7.3 Screen Shake Does Not Affect Collision

- The shake is applied as a `ctx.translate()` on the rendering context only.
- It does not modify `planet.x`, `planet.y`, or any object's position.
- It is wrapped in `ctx.save()` / `ctx.restore()`.

### 7.4 Performance

- Sparkle effects create at most 7 small particles lasting 350ms each. Even rapid star catches won't accumulate beyond ~20 particles.
- The floating text is a single `fillText()` call per effect.
- The impact ring is a single `arc()` + `stroke()` call.
- No shadow blur or composite operations are used in effects (those are expensive).
- Total overhead per frame: a handful of extra `arc()`, `fillText()`, and `translate()` calls — negligible.

---

## 8. Browser Audio Restrictions

### 8.1 Autoplay Policy Handling

Browsers (Chrome, Firefox, Safari, Edge) require a user gesture before an `AudioContext` can produce sound. The plan handles this by:

1. **Not creating the `AudioContext` until `startGame()` or `restartGame()` is called** — both are triggered by a user gesture (key press or click).
2. **Calling `audioCtx.resume()`** every time `initAudio()` runs, in case the context was suspended.
3. **Never playing sound on page load or during the start screen** (before the first interaction).

### 8.2 Fallback

If `AudioContext` is unavailable (extremely rare in modern browsers), all `playSound*` functions check `if (!audioCtx) return;` and silently skip. The game remains fully playable without audio.

---

## 9. Manual Browser Testing Checklist

Open `index.html` directly by double-clicking it (no server, fully offline). Test in at least one Chromium-based browser (Chrome or Edge).

### Start Screen
- [ ] The mute/unmute button is visible in the top-right area.
- [ ] Clicking the mute button toggles between muted (speaker with slash) and unmuted (speaker with arcs) visuals.
- [ ] Pressing M toggles mute without starting the game.
- [ ] Pressing any other key starts the game as before.
- [ ] Clicking the canvas outside the mute button starts the game.
- [ ] No sounds play while on the start screen.

### Star Collection
- [ ] Catching a star plays a short, pleasant two-note ascending chime.
- [ ] A brief sparkle burst of 6–8 coloured particles appears at the catch point.
- [ ] A floating "+10" text rises from the catch point and fades over ~700ms.
- [ ] The score increments by 10 as before.
- [ ] The sparkle particles fade completely within ~350ms.
- [ ] No particles remain or accumulate on screen after their lifetime expires.

### Star Missed
- [ ] When a star falls off the bottom without being caught, a floating "−5" text appears in Bubblegum Pink near the bottom.
- [ ] A short, quiet descending tone plays (if unmuted).
- [ ] The score decreases by 5 as before.
- [ ] The text fades within ~700ms and does not accumulate.

### Asteroid Collision
- [ ] Colliding with an asteroid plays a short, low-pitched impact sound (thud + noise).
- [ ] An expanding Bubblegum Pink ring appears at the collision point and fades over ~400ms.
- [ ] The ETERNITIES counter briefly flashes (alternates colour for ~500ms).
- [ ] A very brief, subtle screen shake occurs (~200ms, ~4px offset).
- [ ] ETERNITIES decreases by 1 as before.
- [ ] The play area is not obscured by the effect.

### Game Over
- [ ] When the game ends (score below 0 or eternities reach 0), a short descending three-note chord plays.
- [ ] The game-over screen fades in over ~500ms (dark overlay gradually darkens, text gradually appears).
- [ ] The last frame of gameplay is visible under the darkening overlay.
- [ ] "GAME OVER" appears in Bubblegum Pink with a glow, exactly as in Stage 2.
- [ ] The final score and restart prompt display correctly.
- [ ] Pressing any key restarts the game. Score resets to 0, ETERNITIES to 7.

### Mute Control
- [ ] When muted, no sounds play for any event (star catch, miss, asteroid hit, game over).
- [ ] When unmuted, all sounds play as described.
- [ ] The mute button is visible and clickable on all three screens (start, game, game-over).
- [ ] The mute state persists across game restarts within the same session.
- [ ] The mute icon clearly indicates the current state (speaker with arcs = unmuted, speaker with slash = muted).

### Reduced Motion
- [ ] With `prefers-reduced-motion: reduce` enabled in OS settings or browser DevTools:
  - Sparkle particles do NOT appear on star collection.
  - The impact ring does NOT appear on asteroid collision.
  - Screen shake does NOT occur.
  - Floating score text still appears (informational, not decorative motion).
  - Eternity counter flash still occurs (colour change, not motion).
  - The game-over overlay appears instantly without fade transition.
  - Sounds still play normally.

### General / Cross-Cutting
- [ ] All existing Stage 1 and Stage 2 functionality is preserved.
- [ ] Colours used in new effects come from the five-colour palette only.
- [ ] No external files, images, audio files, or libraries are loaded (check DevTools Network tab).
- [ ] Only three project files exist: `index.html`, `style.css`, `script.js`.
- [ ] The game works fully offline.
- [ ] Performance remains smooth (~60fps) even during multiple simultaneous effects.
- [ ] Effects do not interfere with movement, collision, scoring, or object spawning.
- [ ] Rapidly catching multiple stars in quick succession does not cause effects to pile up visually or cause lag.

---

## 10. Definition of Done — Stage 3 Complete

Stage 3: Sensory Feedback is **complete** when ALL of the following are true:

1. **Star collection feedback:** Catching a star produces a sparkle burst, a floating "+10" text, and a two-note ascending chime.

2. **Star miss feedback:** Missing a star produces a floating "−5" text and an optional quiet descending tone.

3. **Asteroid hit feedback:** Hitting an asteroid produces an expanding impact ring, a brief screen shake, an ETERNITIES counter flash, and a low-pitched impact sound.

4. **Game-over feedback:** The game-over screen fades in over ~500ms with a descending three-note chord.

5. **Mute control exists:** A visible speaker icon on all screens toggles sound on/off via click or M key. The current state is visually clear.

6. **Audio is code-generated:** All sounds use the Web Audio API with oscillators and gain nodes. No audio files exist in the project.

7. **Browser autoplay is handled:** Audio context is created/resumed only on user interaction. No sounds play before the player first interacts.

8. **Reduced motion is respected:** Particle bursts, screen shake, and fade transitions are suppressed when the user's OS or browser has `prefers-reduced-motion: reduce` enabled. Informational text and audio still function.

9. **Effects are non-disruptive:** No effect modifies game state, collision boxes, scores, or spawn logic. All effects are render-only overlays with finite lifetimes that are properly cleaned up.

10. **All existing functionality is preserved:** Scoring (+10/−5), eternity loss (−1), game-over conditions (score < 0 or eternities = 0), starting eternities (7), controls, spawn rates, difficulty ramping, and all Stage 2 visuals work exactly as before.

11. **Project constraints are met:** Exactly three files (`index.html`, `style.css`, `script.js`), no external dependencies, works offline, no persistent storage or pause system.

12. **All checklist items in Section 9 pass.**

**When these conditions are met, Stage 3 is done. Do not proceed to Stage 4 or Stage 5.**

---

*End of Plan 3 — Stage 3: Sensory Feedback*
