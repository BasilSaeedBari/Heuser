Stage: Visual Vibe
Architect model: Claude Opus 4.6 (Thinking)
Builder model: Gemini 3.8 Flash (Low)
Result: The designs were implemented well and the functions work as I had expected upon testing. The visual design is hopefully appealing and its easier to distinguish what to catch (Star) and what to avoid (asteroid).



# Plan 2 — Stage 2: Visual Vibe Implementation Plan

> **Role:** Architect Plan (read-only — no code changes)
> **Game:** Star Seeker
> **Stage:** 2 of 5 — Visual Vibe
> **Files in scope:** `index.html`, `style.css`, `script.js`

---

## 1. Visual Direction Summary

Transform the current plain black-background, rectangle-based game into a **dreamy cosmic arcade** experience. Every surface — the background, the player, the falling objects, and every UI screen — will use a cohesive five-colour palette drawn from deep space indigos, soft periwinkles, and vivid pinks. The background will be a richly layered, code-generated starfield with nebula gradients. Game objects will shift from flat rectangles to rounded, glowing, organic shapes. All text will adopt an arcade-inspired aesthetic using local system fonts and CSS enhancement. The word "Lives" will be replaced everywhere with **"Eternities"**.

No gameplay logic, collision rules, spawn rates, scoring, controls, or difficulty ramping will be altered.

---

## 2. Colour Palette & Assigned Roles

| Swatch | Name | Hex | Role |
|--------|------|-----|------|
| 🟦 | **Prussian Blue** | `#0b2852` | Deep-space background base, dark panels, canvas fill, contrast areas, game-over overlay |
| 🟪 | **Indigo Velvet** | `#533a7b` | Nebula clouds, secondary background gradients, borders, atmospheric layers, planet shading |
| 🔵 | **Periwinkle** | `#aeadf0` | Primary text, HUD labels, collectible star glow, highlight outlines, background star colour |
| 🌸 | **Pink Orchid** | `#dda9cb` | Secondary highlights, nebula accents, decorative background elements, planet rim glow |
| 🔴 | **Bubblegum Pink** | `#f7567c` | Strong accents: buttons, asteroid warning colour, game-over title, selected/hover states |

**Transparency variants** (e.g., `rgba(83, 58, 123, 0.3)`) are permitted for gradients, glows, shadows, and overlays. No colours outside this palette will be introduced.

---

## 3. Background Design

The background will be rendered **entirely via JavaScript on the canvas**. It will be generated once at game start (and on restart) into an off-screen buffer canvas, then drawn each frame as the first layer.

### 3.1 Off-Screen Background Canvas

Create a separate `OffscreenCanvas` (or a second `<canvas>` element created in JS) sized to `800 × 600`. Pre-render all static background layers onto it once. Each frame, `drawImage()` this buffer onto the main canvas as the first draw call. This avoids re-computing gradients and star positions every frame.

### 3.2 Layer Stack (bottom to top)

#### Layer 1 — Deep Space Base
- Fill the entire buffer with a **vertical linear gradient**:
  - Top: `#0b2852` (Prussian Blue)
  - Bottom: a slightly lighter blend toward `#533a7b` at ~30% opacity (`rgba(83, 58, 123, 0.3)` composited over Prussian Blue)
- This creates a subtle gradient from deep navy at the top to a faintly purple horizon at the bottom.

#### Layer 2 — Nebula Clouds (3–4 clouds)
- Draw 3–4 large, soft **radial gradients** at semi-random positions (seeded or hard-coded for consistency):
  - **Cloud A** (upper-left quadrant): Centre colour `rgba(83, 58, 123, 0.25)` (Indigo Velvet), fading to transparent. Radius ~200–250px.
  - **Cloud B** (centre-right): Centre colour `rgba(221, 169, 203, 0.15)` (Pink Orchid), radius ~180px.
  - **Cloud C** (lower-left): Centre colour `rgba(174, 173, 240, 0.12)` (Periwinkle), radius ~160px.
  - **Cloud D** (upper-right, optional): A second Indigo Velvet cloud at `rgba(83, 58, 123, 0.18)`, radius ~140px.
- Use `ctx.globalCompositeOperation = "lighter"` or `"screen"` when painting these to create a soft additive glow, then reset to `"source-over"`.

#### Layer 3 — Distant Small Stars (80–120 stars)
- Generate an array of 80–120 star objects with random `(x, y)` positions across the canvas.
- Each star has:
  - **radius:** random between `0.5` and `1.8` pixels.
  - **opacity:** random between `0.3` and `0.9`.
  - **colour:** mostly Periwinkle (`#aeadf0`), with ~20% using Pink Orchid (`#dda9cb`) for variety.
- Draw each as a filled circle (`arc`) with the assigned opacity.
- Some of the brighter stars (opacity > 0.7) get a very subtle glow: draw a second, larger circle (radius × 3) at opacity × 0.15 behind them.

#### Layer 4 — Medium Accent Stars (8–12 stars)
- Generate 8–12 slightly larger stars:
  - **radius:** `2.0` to `3.5` pixels.
  - **opacity:** `0.5` to `0.85`.
  - **colour:** Periwinkle.
- Each gets a soft glow halo: a radial gradient from `rgba(174, 173, 240, 0.3)` at centre to transparent at radius × 4.

#### Layer 5 — Large Feature Stars (2–3 stars)
- Place 2–3 prominent stars at **hard-coded positions** chosen to avoid the central play corridor (e.g., upper corners, far left/right edges):
  - **radius:** `3` to `4` pixels for the core.
  - Draw a 4-point or 6-point cross/sparkle using two thin, perpendicular lines (2px wide, ~20px long) in Periwinkle at ~0.25 opacity, creating a lens-flare-like cross.
  - Draw a soft radial glow behind (radius ~15px, Periwinkle at 0.15 opacity).
- These should be subtle enough not to be confused with collectible stars (which will be much larger and brighter during gameplay).

#### Layer 6 — Decorative Orbit Ring (1, optional)
- Draw a single thin elliptical arc (a flattened circle) in the lower-right or upper-left area of the canvas.
  - Stroke colour: `rgba(174, 173, 240, 0.08)` (very faint Periwinkle).
  - Line width: `1px`.
  - Dimensions: roughly `120px × 40px` ellipse.
- This is purely decorative atmosphere. Keep it faint enough that it never distracts.

### 3.3 Background Generation Function

```
function generateBackground():
  create backgroundCanvas (800 × 600)
  get bgCtx from backgroundCanvas
  draw Layer 1 (gradient)
  draw Layer 2 (nebula clouds)
  draw Layer 3 (distant stars)
  draw Layer 4 (medium stars)
  draw Layer 5 (feature stars)
  draw Layer 6 (orbit ring)
  store backgroundCanvas globally
```

Call `generateBackground()` once during initialization (before the first `requestAnimationFrame`) and once more on `resetGameState()` if variety is desired (or reuse the same one for consistency — consistency is preferred).

### 3.4 Drawing the Background Each Frame

In every render function (`renderStartScreen`, `renderGame`, `renderGameOverScreen`), replace the solid black `fillRect` with:

```
ctx.drawImage(backgroundCanvas, 0, 0);
```

This single call replaces the `ctx.fillStyle = "#000000"; ctx.fillRect(...)` pattern in all three render functions.

---

## 4. Typography Strategy

### 4.1 Font Stack

Use this CSS-style font stack applied via `ctx.font` in JavaScript:

```
"Courier New", "Lucida Console", "Consolas", monospace
```

**Rationale:** These monospace fonts are universally available on Windows, macOS, and Linux. Monospace fonts naturally evoke a retro terminal/arcade feel. `Courier New` is the most arcade-adjacent of the universally-installed fonts.

### 4.2 Arcade Aesthetic Enhancement

Since a true pixel font (like "Press Start 2P") is unavailable without external downloads, enhance the arcade look with:

1. **Letter Spacing:** Use `ctx.letterSpacing = "3px"` (if supported) or manually draw characters with spacing by adjusting x-offsets. *Note:* `ctx.letterSpacing` is available in modern browsers. If the Builder agent encounters compatibility issues, fall back to the default spacing which still looks good with monospace fonts.

2. **Text Shadow / Glow:** For titles and prominent text, draw the text twice:
   - First pass: draw in a glow colour (e.g., `rgba(174, 173, 240, 0.4)`) offset by `(0, 0)` with `ctx.shadowBlur = 10` and `ctx.shadowColor` set to Periwinkle.
   - Second pass: draw the actual text in the primary colour with `shadowBlur = 0`.

3. **Text Outline for Readability:** For HUD text during gameplay, optionally use `ctx.strokeText()` with a `1px` dark stroke (`#0b2852`) before `ctx.fillText()` to ensure readability against the busy background.

4. **Uppercase Convention:** All UI text should be rendered in UPPERCASE to reinforce the arcade aesthetic. The existing code already uses uppercase for titles; extend this to all labels.

### 4.3 Text Hierarchy

| Element | Font Size | Weight | Colour | Extra |
|---------|-----------|--------|--------|-------|
| Title "STAR SEEKER" (start screen) | `44px` | `bold` | Periwinkle `#aeadf0` | Glow: Pink Orchid shadow, letter-spacing 4px |
| Subtitle / tagline (start screen) | `14px` | normal | Pink Orchid `#dda9cb` | Slight letter-spacing 2px |
| "Press any key" prompt | `18px` | normal | Periwinkle `#aeadf0` | Gentle pulsing opacity animation (optional) |
| Score HUD (gameplay) | `18px` | `bold` | Periwinkle `#aeadf0` | 1px dark outline |
| Eternities HUD (gameplay) | `18px` | `bold` | Pink Orchid `#dda9cb` | 1px dark outline |
| "GAME OVER" title | `46px` | `bold` | Bubblegum Pink `#f7567c` | Glow: Bubblegum Pink shadow |
| Final score (game-over) | `22px` | normal | Periwinkle `#aeadf0` | — |
| Restart prompt (game-over) | `16px` | normal | Pink Orchid `#dda9cb` | — |

---

## 5. Redesigned Game Objects

### 5.1 Player Planet

**Current state:** A `60 × 20` cyan (`#00D2FF`) filled rectangle at `y = 560`.

**New design — a circular planet with atmosphere:**

The planet's **collision hitbox** (`planet.x`, `planet.y`, `planet.width`, `planet.height`) remains **unchanged** at `60 × 20`. The visual rendering will draw a circle that is visually centred on the hitbox but extends slightly above and below it.

Drawing steps (centred on the hitbox's centre point):

1. **Outer Glow:** Draw a radial gradient circle, radius `24px`, from `rgba(221, 169, 203, 0.2)` (Pink Orchid) at centre to transparent at edge. This is the atmospheric glow.

2. **Planet Body:** Draw a filled circle, radius `18px`, with a radial gradient:
   - Centre/top-left highlight: `#aeadf0` (Periwinkle — the "sunlit" side).
   - Edge: `#533a7b` (Indigo Velvet — the dark side).
   - This gradient should be offset slightly (centre at `(-4, -4)` from the circle centre) to simulate directional lighting.

3. **Rim Highlight:** Draw a thin arc (partial circle, ~120° on the upper-left edge) with a `1.5px` stroke in `rgba(221, 169, 203, 0.6)` (Pink Orchid). This adds a subtle atmospheric rim.

4. **Orbit Ring:** Draw a single thin ellipse around the planet (horizontal diameter `~44px`, vertical diameter `~10px`) with a `1px` stroke in `rgba(174, 173, 240, 0.35)` (Periwinkle). Centre it on the planet. This uses `ctx.ellipse()` or a scaled arc.

**Visual centre calculation:**
```
centreX = planet.x + planet.width / 2   // = planet.x + 30
centreY = planet.y + planet.height / 2  // = planet.y + 10
```

All drawing is relative to this centre. The hitbox rectangle is NOT drawn.

### 5.2 Collectible Stars

**Current state:** `20 × 20` gold (`#FFD700`) filled rectangles.

**New design — a glowing 5-pointed star shape:**

The collision hitbox remains a `20 × 20` rectangle (no change to `obj.x`, `obj.y`, `obj.width`, `obj.height`).

Drawing steps (centred on the hitbox centre):

1. **Calculate centre:**
   ```
   cx = obj.x + obj.width / 2
   cy = obj.y + obj.height / 2
   ```

2. **Outer Glow:** Draw a radial gradient circle, radius `16px`:
   - Centre: `rgba(174, 173, 240, 0.4)` (Periwinkle glow).
   - Edge: transparent.

3. **Star Shape (5-pointed):** Use a function `drawStar(cx, cy, outerRadius, innerRadius, points)`:
   - `outerRadius = 11` (slightly larger than half the hitbox for visual pop).
   - `innerRadius = 5`.
   - `points = 5`.
   - The function loops through `points * 2` vertices, alternating between outer and inner radii at evenly spaced angles (starting at `-π/2` so one point faces up).
   - Fill with a **linear gradient** from Periwinkle (`#aeadf0`) at top to Pink Orchid (`#dda9cb`) at bottom — giving a warm golden/starlight appearance within the palette.

4. **Bright Centre Dot:** Draw a small filled circle (radius `2px`) at `(cx, cy)` in white-ish Periwinkle (`rgba(174, 173, 240, 0.9)`) to simulate a bright core.

5. **Distinguishing from background stars:** Collectible stars will be **much larger** (~22px diameter vs background stars at 1–4px), **brighter**, **star-shaped** (not round dots), and will have an obvious glow halo. Background stars are tiny, round, static, and faint. There should be no confusion.

#### Star Drawing Helper Function

```
function drawStarShape(ctx, cx, cy, outerR, innerR, points):
  ctx.beginPath()
  for i = 0 to (points * 2 - 1):
    radius = (i % 2 === 0) ? outerR : innerR
    angle = (i * Math.PI / points) - Math.PI / 2
    x = cx + Math.cos(angle) * radius
    y = cy + Math.sin(angle) * radius
    if i === 0: ctx.moveTo(x, y)
    else: ctx.lineTo(x, y)
  ctx.closePath()
```

### 5.3 Asteroids

**Current state:** `20 × 20` red (`#FF4444`) filled rectangles.

**New design — irregular rocky polygons:**

The collision hitbox remains `20 × 20`. The visual shape will be an irregular polygon inscribed within a slightly larger area, centred on the hitbox centre.

Drawing steps:

1. **Generate a random polygon** for each asteroid at spawn time. Add a `vertices` property to each asteroid object when it is created in `spawnFallingObject()`:
   - Pick `6` to `8` vertices around a circle of radius `12px`.
   - For each vertex, choose a random angle evenly distributed around the circle, then vary the radius by `±3px` (range `9–15px`) to create an irregular, rocky outline.
   - Store the array of `{angle, radius}` pairs (or pre-computed `{x, y}` offsets from centre) on the object.

   ```
   function generateAsteroidVertices(numVertices):
     vertices = []
     for i = 0 to numVertices - 1:
       angle = (i / numVertices) * 2 * Math.PI + random(-0.15, 0.15)
       radius = 12 + random(-3, 3)
       vertices.push({ angle, radius })
     sort vertices by angle (to avoid self-intersecting polygon)
     return vertices
   ```

   Attach this to the asteroid object: `obj.vertices = generateAsteroidVertices(7)`.

2. **Draw the asteroid body:**
   - `ctx.beginPath()`, loop through `obj.vertices`, compute `(cx + cos(angle) * radius, cy + sin(angle) * radius)`, `moveTo` / `lineTo`.
   - `ctx.closePath()`.
   - Fill with a **radial gradient** from `#533a7b` (Indigo Velvet, centre — slightly lighter rocky core) to `#0b2852` (Prussian Blue, edge — dark rocky surface).
   - Stroke with `1.5px` line in `#f7567c` (Bubblegum Pink) to provide a distinct dangerous-looking outline and ensure visibility.

3. **Surface Detail (optional, subtle):**
   - Draw 1–2 small circles (radius `1.5–2.5px`) on the asteroid face in `rgba(11, 40, 82, 0.5)` (dark Prussian Blue) to simulate craters. Position them at hard-coded offsets like `(cx - 3, cy - 2)` and `(cx + 2, cy + 3)`. Keep it subtle.

4. **Danger Glow:**
   - Draw a soft radial glow behind the asteroid: radius `18px`, `rgba(247, 86, 124, 0.15)` (faint Bubblegum Pink), fading to transparent. This gives a subtle warning aura.

### 5.4 Distinguishability Matrix

| Object | Shape | Dominant Colour | Glow Colour | Size (visual) |
|--------|-------|----------------|-------------|----------------|
| Background star | Tiny circle | Periwinkle (faint) | None or very faint | 1–4px |
| Collectible star | 5-pointed star | Periwinkle → Pink Orchid gradient | Periwinkle halo | ~22px |
| Asteroid | Irregular polygon | Indigo Velvet / Prussian Blue | Bubblegum Pink aura | ~24px |
| Player planet | Circle with ring | Periwinkle → Indigo Velvet gradient | Pink Orchid atmosphere | ~36px |

---

## 6. Screen Designs

### 6.1 Start Screen

**Layout (top to bottom, centred horizontally):**

| Y Position | Element | Details |
|------------|---------|---------|
| `CANVAS_HEIGHT / 2 - 80` | Title: **STAR SEEKER** | `bold 44px`, Periwinkle, glow shadow (Pink Orchid, blur 15px), letter-spacing 4px |
| `CANVAS_HEIGHT / 2 - 35` | Tagline: **CHASE THE LIGHT. DODGE THE DARK.** | `14px`, Pink Orchid, letter-spacing 2px |
| `CANVAS_HEIGHT / 2 + 30` | Prompt: **PRESS ANY KEY TO START** | `18px`, Periwinkle, optional pulsing opacity |
| Background | Full cosmic background | `ctx.drawImage(backgroundCanvas, 0, 0)` |

**Optional pulsing prompt:** The "PRESS ANY KEY" text can smoothly oscillate its opacity between `0.4` and `1.0` using a sine wave based on the timestamp:
```
opacity = 0.7 + 0.3 * Math.sin(timestamp / 500)
ctx.globalAlpha = opacity
// draw text
ctx.globalAlpha = 1.0
```

This is a render-only effect in `renderStartScreen()` — no game logic change.

### 6.2 Gameplay HUD

**Layout:**

| Position | Element | Details |
|----------|---------|---------|
| Top-left `(15, 15)` | **SCORE: 0** | `bold 18px`, Periwinkle, `textAlign = "left"`, 1px dark outline |
| Top-right `(CANVAS_WIDTH - 15, 15)` | **ETERNITIES: 7** | `bold 18px`, Pink Orchid, `textAlign = "right"`, 1px dark outline |

**Key change:** Replace `"Lives: " + lives + "/" + MAX_LIVES` with `"ETERNITIES: " + lives`.

- Remove the `"/" + MAX_LIVES` denominator display — show only the current count for a cleaner arcade look.
- Change `ctx.fillStyle` from `#FF4444` to `#dda9cb` (Pink Orchid).
- Change "Lives" to "ETERNITIES".

**Text outline technique:**
```
ctx.strokeStyle = "#0b2852"
ctx.lineWidth = 3
ctx.strokeText(text, x, y)
ctx.fillStyle = "#aeadf0"
ctx.fillText(text, x, y)
```

The background behind the HUD is the cosmic starfield (drawn via `ctx.drawImage(backgroundCanvas, 0, 0)`), so outlines ensure readability.

### 6.3 Game-Over Screen

**Layout (top to bottom, centred):**

| Y Position | Element | Details |
|------------|---------|---------|
| Background | Cosmic background | `ctx.drawImage(backgroundCanvas, 0, 0)` |
| Overlay | Semi-transparent dark overlay | `ctx.fillStyle = "rgba(11, 40, 82, 0.7)"; ctx.fillRect(0, 0, 800, 600)` — softens the background |
| `CANVAS_HEIGHT / 2 - 60` | **GAME OVER** | `bold 46px`, Bubblegum Pink `#f7567c`, glow shadow (Bubblegum Pink, blur 20px) |
| `CANVAS_HEIGHT / 2 + 10` | **FINAL SCORE: {score}** | `22px`, Periwinkle `#aeadf0` |
| `CANVAS_HEIGHT / 2 + 60` | **PRESS ANY KEY TO RESTART** | `16px`, Pink Orchid `#dda9cb` |

The dark overlay creates a "softened nebula" effect over the starfield without adding new art.

---

## 7. Changes by File

### 7.1 `index.html`

**Minimal changes.** The HTML structure is already lean.

| Change | Details |
|--------|---------|
| None required | The canvas, script link, and CSS link are already correct. The `<title>` already says "Star Seeker". No new HTML elements needed since all rendering is on the canvas. |

> The Builder agent should verify the `<title>` is `Star Seeker` and leave the file otherwise untouched.

### 7.2 `style.css`

| Line(s) | Current | New | Rationale |
|---------|---------|-----|-----------|
| L8 | `background: #111;` | `background: #0b2852;` | Page background behind the canvas should match the Prussian Blue palette rather than being generic dark grey. If the canvas doesn't cover the full viewport, the visible page edges will be on-palette. |
| L17 | `background: #000;` | `background: #0b2852;` | Canvas default background before JS renders. Matches the palette. |
| L18 | `border: 2px solid #333;` | `border: 2px solid #533a7b;` | Canvas border uses Indigo Velvet instead of grey. |
| (optional) | — | `border-radius: 8px;` | Softly round the canvas corners for a polished look. |
| (optional) | — | `box-shadow: 0 0 30px rgba(83, 58, 123, 0.4), 0 0 60px rgba(11, 40, 82, 0.6);` | Subtle outer glow around the canvas, reinforcing the cosmic feel. |

No other CSS changes. All game visuals are canvas-rendered.

### 7.3 `script.js`

This is where the bulk of Stage 2 work happens. Below is a **section-by-section** change map.

#### A. New Constants / Variables (add near top)

```
// Colour Palette Constants
const PRUSSIAN_BLUE = "#0b2852";
const INDIGO_VELVET = "#533a7b";
const PERIWINKLE = "#aeadf0";
const PINK_ORCHID = "#dda9cb";
const BUBBLEGUM_PINK = "#f7567c";

// Background buffer
let backgroundCanvas = null;
let backgroundCtx = null;
```

#### B. New Function: `generateBackground()`

Add this function (as described in Section 3). It creates and populates the off-screen background canvas. Call it once at the bottom of the file (at initialisation) and it does NOT need to be called again on restart (reuse the same starfield).

#### C. New Function: `drawStarShape(ctx, cx, cy, outerR, innerR, points)`

A reusable helper for drawing n-pointed star polygons (Section 5.2).

#### D. New Function: `generateAsteroidVertices(numVertices)`

Returns an array of `{angle, radius}` pairs for irregular polygons (Section 5.3). Called inside `spawnFallingObject()` when creating an asteroid.

#### E. Modified Function: `spawnFallingObject()`

- When `type === "asteroid"`, add: `obj.vertices = generateAsteroidVertices(7);`
- No other logic changes. Spawn rates, speeds, and probabilities remain identical.

#### F. New Function: `drawPlanet(ctx, planet)`

Replaces the single `ctx.fillRect(planet.x, planet.y, planet.width, planet.height)` call in `renderGame()`. Draws the planet as described in Section 5.1 (glow → body gradient → rim → orbit ring).

#### G. New Function: `drawCollectibleStar(ctx, obj)`

Replaces the `ctx.fillRect(obj.x, obj.y, obj.width, obj.height)` call for stars in `renderGame()`. Draws the 5-pointed star with glow as described in Section 5.2.

#### H. New Function: `drawAsteroid(ctx, obj)`

Replaces the `ctx.fillRect(obj.x, obj.y, obj.width, obj.height)` call for asteroids in `renderGame()`. Uses `obj.vertices` to draw the irregular polygon as described in Section 5.3.

#### I. Modified Function: `renderGame()`

Current code (lines 268–301) → new structure:

```
function renderGame():
  ctx.clearRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT)

  // 1. Draw pre-rendered cosmic background
  ctx.drawImage(backgroundCanvas, 0, 0)

  // 2. Draw falling objects
  for each obj in fallingObjects:
    if obj.type === "star":
      drawCollectibleStar(ctx, obj)
    else:
      drawAsteroid(ctx, obj)

  // 3. Draw player planet
  drawPlanet(ctx, planet)

  // 4. Draw HUD with outlines
  drawHUD()
```

Note: The player is drawn AFTER falling objects so it appears on top (feels more natural — the planet is in the foreground).

#### J. New Function: `drawHUD()`

Extracted from the bottom of `renderGame()`. Draws:

- `"SCORE: " + score` — top-left, Periwinkle, bold 18px, with dark outline.
- `"ETERNITIES: " + lives` — top-right, Pink Orchid, bold 18px, with dark outline.

Uses the outline technique: `strokeText` in Prussian Blue (lineWidth 3), then `fillText` in the label colour.

#### K. Modified Function: `renderStartScreen()`

Replace the current implementation (lines 234–247) with:

```
function renderStartScreen():
  ctx.drawImage(backgroundCanvas, 0, 0)            // cosmic background

  // Title glow
  ctx.save()
  ctx.shadowColor = PINK_ORCHID
  ctx.shadowBlur = 15
  ctx.fillStyle = PERIWINKLE
  ctx.font = "bold 44px 'Courier New', 'Lucida Console', monospace"
  ctx.textAlign = "center"
  ctx.textBaseline = "middle"
  ctx.fillText("STAR SEEKER", CANVAS_WIDTH / 2, CANVAS_HEIGHT / 2 - 80)
  ctx.restore()

  // Tagline
  ctx.fillStyle = PINK_ORCHID
  ctx.font = "14px 'Courier New', 'Lucida Console', monospace"
  ctx.fillText("CHASE THE LIGHT. DODGE THE DARK.", CANVAS_WIDTH / 2, CANVAS_HEIGHT / 2 - 35)

  // Pulsing prompt
  let opacity = 0.7 + 0.3 * Math.sin(performance.now() / 500)
  ctx.globalAlpha = opacity
  ctx.fillStyle = PERIWINKLE
  ctx.font = "18px 'Courier New', 'Lucida Console', monospace"
  ctx.fillText("PRESS ANY KEY TO START", CANVAS_WIDTH / 2, CANVAS_HEIGHT / 2 + 30)
  ctx.globalAlpha = 1.0
```

#### L. Modified Function: `renderGameOverScreen()`

Replace the current implementation (lines 249–266) with:

```
function renderGameOverScreen():
  ctx.drawImage(backgroundCanvas, 0, 0)            // cosmic background

  // Dark overlay
  ctx.fillStyle = "rgba(11, 40, 82, 0.7)"
  ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT)

  // "GAME OVER" with glow
  ctx.save()
  ctx.shadowColor = BUBBLEGUM_PINK
  ctx.shadowBlur = 20
  ctx.fillStyle = BUBBLEGUM_PINK
  ctx.font = "bold 46px 'Courier New', 'Lucida Console', monospace"
  ctx.textAlign = "center"
  ctx.textBaseline = "middle"
  ctx.fillText("GAME OVER", CANVAS_WIDTH / 2, CANVAS_HEIGHT / 2 - 60)
  ctx.restore()

  // Final score
  ctx.fillStyle = PERIWINKLE
  ctx.font = "22px 'Courier New', 'Lucida Console', monospace"
  ctx.fillText("FINAL SCORE: " + score, CANVAS_WIDTH / 2, CANVAS_HEIGHT / 2 + 10)

  // Restart prompt
  ctx.fillStyle = PINK_ORCHID
  ctx.font = "16px 'Courier New', 'Lucida Console', monospace"
  ctx.fillText("PRESS ANY KEY TO RESTART", CANVAS_WIDTH / 2, CANVAS_HEIGHT / 2 + 60)
```

#### M. Initialisation Change

At the bottom of the file, before `requestAnimationFrame(gameLoop)`, add:

```
generateBackground();
```

#### N. Summary of Lines NOT Changed

The following functions and logic blocks must remain **completely untouched**:

| Code Section | Lines | Reason |
|-------------|-------|--------|
| `isColliding()` | 131–138 | Core collision logic |
| `updatePlanet()` | 141–160 | Movement and clamping logic |
| `updateGame()` | 162–231 | All game update logic: collision handling, miss handling, spawn timing, difficulty ramping |
| `resetGameState()` | 72–87 | Game reset logic (score, lives, spawn state) |
| `startGame()` / `restartGame()` | 89–97 | State transitions |
| All `keydown` / `keyup` / `click` handlers | 35–69 | Input handling |
| `gameLoop()` | 304–326 | Main loop structure, delta time, state branching |
| `planet` object properties | 25–32 | Position, size, speed |
| `MAX_LIVES`, `lives` logic | 11–12 | Starting count = 7 (already correct) |
| Spawn probabilities and speed ranges | 100–128 | 65/35 split, speed values |

---

## 8. Preserving Stage 1 Game Logic

### 8.1 No-Touch Rules

- **Collision detection:** `isColliding()` is axis-aligned bounding box (AABB). Even though objects are now drawn as circles, stars, and polygons, the underlying hitbox rectangles (`x, y, width, height`) remain unchanged. Visual rendering is purely cosmetic — collision math stays rectangular.
- **Scoring:** Stars caught = +10 points. No change.
- **Life/Eternity loss:** Asteroid collision = −1. Star missed (falls off bottom) = −1. No change. Only the *displayed label* changes from "Lives" to "ETERNITIES".
- **Game-over condition:** `lives <= 0` → `gameState = "gameover"`. No change.
- **Starting lives:** `MAX_LIVES = 7`. Already set. No change.
- **Spawn logic:** 65% stars, 35% asteroids. Speeds unchanged. Difficulty ramp (−0.1s per 30s, floor 0.4s) unchanged.
- **Controls:** ArrowLeft / ArrowRight / A / D for movement. Any key to start/restart. Click to start/restart. All unchanged.
- **Canvas size:** `800 × 600`. Unchanged.

### 8.2 Safe Modification Pattern

The Builder agent should:
1. Add new drawing helper functions (`drawPlanet`, `drawCollectibleStar`, `drawAsteroid`, `drawStarShape`, `generateAsteroidVertices`, `generateBackground`, `drawHUD`).
2. Modify the three `render*` functions to call these helpers instead of using `fillRect`.
3. Add `obj.vertices` assignment inside `spawnFallingObject()` for asteroids only.
4. Add colour constants and the background canvas variable at the top.
5. Add `generateBackground()` call before the game loop starts.
6. **Not touch** anything listed in section 7.N above.

---

## 9. Visual Test Checklist

After implementation, open `index.html` directly in a browser (offline, no server) and verify:

### Start Screen
- [ ] The cosmic background displays with visible nebula gradients and many stars of varying sizes.
- [ ] Background is NOT a solid colour.
- [ ] "STAR SEEKER" title appears in Periwinkle with a pink glow, in a monospace/arcade font.
- [ ] Tagline "CHASE THE LIGHT. DODGE THE DARK." appears in Pink Orchid below the title.
- [ ] "PRESS ANY KEY TO START" text pulses gently (opacity oscillation).
- [ ] All text is readable against the background.
- [ ] Pressing any key transitions to gameplay.
- [ ] Clicking the canvas transitions to gameplay.

### Gameplay Screen
- [ ] The cosmic background is visible behind all game objects.
- [ ] The player appears as a rounded planet with gradient shading, a rim highlight, and an orbit ring — NOT a rectangle.
- [ ] The player moves left/right with Arrow keys and A/D.
- [ ] The player cannot move outside the canvas bounds.
- [ ] Falling stars appear as glowing 5-pointed star shapes — NOT rectangles.
- [ ] Falling stars are visually distinct from background decoration stars (larger, brighter, star-shaped vs. tiny dots).
- [ ] Falling asteroids appear as irregular rocky polygons with Bubblegum Pink outlines — NOT rectangles.
- [ ] Asteroids are visually distinct from stars (different shape, different colour scheme).
- [ ] HUD shows "SCORE: 0" (top-left, Periwinkle) — text is readable against the background.
- [ ] HUD shows "ETERNITIES: 7" (top-right, Pink Orchid) — NOT "Lives".
- [ ] Catching a star adds 10 to the score.
- [ ] Colliding with an asteroid reduces ETERNITIES by 1.
- [ ] Missing a star (falls off bottom) reduces ETERNITIES by 1.
- [ ] Missing an asteroid (falls off bottom) has no penalty.
- [ ] When ETERNITIES reaches 0, the game transitions to the game-over screen.
- [ ] No visual element obstructs gameplay or makes objects hard to identify.

### Game-Over Screen
- [ ] The cosmic background is visible, darkened by a semi-transparent Prussian Blue overlay.
- [ ] "GAME OVER" appears in Bubblegum Pink with a glow effect.
- [ ] The final score is displayed in Periwinkle.
- [ ] "PRESS ANY KEY TO RESTART" appears in Pink Orchid.
- [ ] Pressing any key restarts the game correctly (score resets to 0, ETERNITIES to 7).
- [ ] Clicking the canvas restarts the game.

### General / Cross-Cutting
- [ ] All colours used come from the 5-colour palette (or transparency variations thereof). No stray greys, whites, or off-palette colours.
- [ ] The game works fully offline (opened via double-click on `index.html`, no server needed).
- [ ] No external images, fonts, or libraries are loaded (check the Network tab in DevTools — should show only the three project files).
- [ ] Only three project files exist: `index.html`, `style.css`, `script.js`.
- [ ] The canvas border is Indigo Velvet, optionally with rounded corners and a glow.
- [ ] The page background (outside the canvas) is Prussian Blue.
- [ ] The game maintains smooth performance (~60fps) — the background is drawn from a buffer, not recomputed each frame.
- [ ] Resizing the browser window does not break the layout (the canvas stays centred via flexbox).

---

## 10. Definition of Done — Stage 2 Complete

Stage 2: Visual Vibe is **complete** when ALL of the following are true:

1. **Palette enforced:** Every visible colour in the game is derived from the five official colours (`#0b2852`, `#533a7b`, `#aeadf0`, `#dda9cb`, `#f7567c`) or their transparency variants. No off-palette colours remain.

2. **Background is cosmic:** The canvas background is a layered, code-generated starfield with nebula gradients, multiple star layers, and subtle depth — not a solid colour or simple gradient.

3. **Typography is arcade-style:** All text uses a monospace font stack (`Courier New`, `Lucida Console`, `Consolas`, `monospace`), rendered in uppercase, with appropriate glow/shadow effects for titles and outline strokes for HUD readability.

4. **"Eternities" label is active:** The HUD displays `ETERNITIES: n` instead of `Lives: n`. The starting value is 7. All life-loss logic is unchanged.

5. **Player is a planet:** The player is rendered as a circular body with gradient shading, atmospheric glow, and an orbit ring — not a rectangle.

6. **Stars are star-shaped:** Collectible stars are rendered as glowing 5-pointed stars, visually distinct from background decorative stars.

7. **Asteroids are rocky polygons:** Asteroids are rendered as irregular polygons with Bubblegum Pink outlines and a danger glow, visually distinct from stars.

8. **All three screens are themed:** The start screen, gameplay screen, and game-over screen all use the cosmic background, palette colours, and arcade typography consistently.

9. **Game logic is preserved:** All collision rules, scoring (+10 per star), life loss (−1 per asteroid hit or missed star), game-over condition (0 eternities), controls (Arrow/AD keys, any key to start/restart, click to start/restart), spawn rates, difficulty ramping, and canvas dimensions work exactly as they did in Stage 1.

10. **No external dependencies:** The game uses no downloaded images, external fonts, web services, or third-party libraries. It works fully offline from three files.

11. **All checklist items in Section 9 pass.**

**When these conditions are met, Stage 2 is done. Do not proceed to Stage 3, 4, or 5.**

---

*End of Plan 2 — Stage 2: Visual Vibe*
