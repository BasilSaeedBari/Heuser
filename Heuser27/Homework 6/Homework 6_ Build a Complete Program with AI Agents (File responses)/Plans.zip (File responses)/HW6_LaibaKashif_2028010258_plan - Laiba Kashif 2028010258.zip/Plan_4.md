Stage: State and Storage
Architect model: Claude Opus 4.6 (Thinking)
Builder model: Gemini 3.8 Flash (Low) (Also used Claude opus 4.6 accidentally, I realized it by the end and changed it)
Result: I implemented state management and storage for high score and sound preference. I added pause/resume controls, restart functionality, and a reset-saved-data option with confirmation. I tested the features in the browser and confirmed that gameplay, saved preferences, and existing functionality worked as anticipated. Key press for pausing and restarting were also added and so were its visuals in the game to make it easier if played on mobile rather than laptop.



# Plan 4 — State & Storage

## Overview

Add persistent storage (high score, sound preference), formal game-state management (menu → playing → paused → game over), pause/resume controls, clean restart, and a reset-saved-data control. All changes stay within the existing three files.

---

## Files Changed

| File | Changes |
|------|---------|
| `script.js` | All logic: localStorage helpers, game state machine, pause/resume, high score tracking, reset-data control |
| `index.html` | None |
| `style.css` | None |

---

## Feature Details

### 1. localStorage Helper Functions

Create a small storage API at the top of `script.js` to centralise all reads and writes and handle errors in one place.

```
STORAGE_KEY = "starSeeker"
```

**Functions:**

- `saveData(key, value)` — Wraps `localStorage.setItem` in a try/catch. Silently fails on quota errors or SecurityError (private browsing). Stores values under a namespaced key like `starSeeker_highScore`.
- `loadData(key, fallback)` — Wraps `localStorage.getItem` + `JSON.parse` in a try/catch. Returns `fallback` on any error (missing key, corrupted JSON, SecurityError).
- `clearAllSavedData()` — Wraps `localStorage.removeItem` for each known key in a try/catch. Used by the reset control.

**Known keys:** `starSeeker_highScore` (number), `starSeeker_isMuted` (boolean).

**Validation:** `loadData` for high score must verify the result is a finite non-negative number; anything else returns the fallback (0). `loadData` for mute must verify the result is a boolean; anything else returns the fallback (false).

### 2. High-Score Storage

- Add a `highScore` variable, initialised at startup via `loadData("starSeeker_highScore", 0)`.
- On game over, compare `score` to `highScore`. If `score > highScore`, update `highScore` and call `saveData("starSeeker_highScore", highScore)`.
- Display the high score on:
  - **Start screen:** Below the tagline, e.g., `"HIGH SCORE: 0"` using `PINK_ORCHID` colour.
  - **Game-over screen:** Below the final score, e.g., `"HIGH SCORE: 120"`. If the player just set a new high score, briefly indicate it (e.g., `"★ NEW HIGH SCORE ★"`).
  - **HUD during play:** Not required — keep the HUD clean. (Optional: add below score if space allows.)

### 3. Sound Preference Persistence

- On startup, initialise `isMuted` via `loadData("starSeeker_isMuted", false)` instead of hardcoding `false`.
- Every time `isMuted` is toggled (in the keydown handler's `M` branch and in the canvas click mute-button branch), call `saveData("starSeeker_isMuted", isMuted)` immediately after flipping the flag.
- No other changes to the audio system.

### 4. Game State Machine

Expand the current `gameState` variable from three values to four:

| State | Value | Description |
|-------|-------|-------------|
| Menu | `"start"` | Title screen (unchanged name for backward compat) |
| Playing | `"playing"` | Active gameplay |
| Paused | `"paused"` | Gameplay frozen, pause overlay shown |
| Game Over | `"gameover"` | End screen (unchanged) |

**Allowed transitions:**

```
start    → playing    (any key / click)
playing  → paused     (Escape / P key / pause button click)
playing  → gameover   (score < 0 or lives ≤ 0)
paused   → playing    (Escape / P key / resume button click)
paused   → playing    (restart button click → confirm → restartGame)
paused   → start      (menu button click → returnToMenu)
gameover → playing    (any key / click triggers restartGame)
```

### 5. Pause / Resume and In-Game Controls

#### 5a. HUD Control Bar (visible during `"playing"`)

Draw a row of small clickable icon-buttons in the top-right HUD area, right-to-left:

| Button | Position (top-left) | Icon | Action |
|--------|---------------------|------|--------|
| Mute | `(CANVAS_WIDTH - 45, 12)` | Speaker / slash (existing) | Toggle mute |
| Pause | `(CANVAS_WIDTH - 80, 12)` | Two vertical bars `❚❚` | Pause game |

Each is a 24×24 hit-test region, detected in the existing canvas click handler the same way the mute button already works.

#### 5b. Pause Controls

**Keyboard:** `Escape` or `P` key toggles between `"playing"` and `"paused"`.

**When pausing (`"playing"` → `"paused"`):**
- Set `gameState = "paused"`.
- In `gameLoop`, skip `updateGame(deltaTime)` when `gameState === "paused"`. The rAF loop keeps running so the pause overlay renders, but no gameplay simulation occurs — no movement, spawning, collisions, score changes, or eternity changes.
- Clear all pressed keys (`keys` object) to avoid stuck-key issues on resume.

**When resuming (`"paused"` → `"playing"`):**
- Set `gameState = "playing"`.
- **Critical — prevent time-jump:** Set `lastTime = 0` so the next `gameLoop` iteration recomputes `lastTime = timestamp` without a large delta. The existing guard at line 1061–1063 (`if (!lastTime) { lastTime = timestamp; }`) already handles this.
- Clear all pressed keys.

#### 5c. Pause Overlay with Menu Buttons

Add a `renderPauseScreen()` function:
1. Draw the current game frame (call `renderGame()` to show the frozen scene).
2. Draw a semi-transparent overlay (`rgba(11, 40, 82, 0.6)`).
3. Draw `"PAUSED"` title text centred, using the same glow style as the start/game-over titles.
4. Draw three text-label buttons stacked vertically below the title, centred on the canvas:

| Label | Y offset (from centre) | Action |
|-------|------------------------|--------|
| `"▶ RESUME"` | +20 | Resume gameplay |
| `"↺ RESTART"` | +55 | Restart with confirmation (see §5d) |
| `"✦ MENU"` | +90 | Return to start screen (see §5e) |

Each button is drawn as styled text (e.g., `PERIWINKLE`, 18px monospace). Define a hit-test rectangle for each (measure with `ctx.measureText` or use a fixed-width box, e.g., 180×28 centred). Detect clicks in the canvas click handler when `gameState === "paused"`.

5. Draw the mute button (always accessible).

#### 5d. In-Game Restart (with confirmation)

Restart can be triggered from the **pause overlay** (the `"↺ RESTART"` button).

**Confirmation flow** (prevents accidental progress loss):
- Add a variable `restartConfirmActive = false`.
- First click on `"↺ RESTART"`: change the label to `"↺ CONFIRM RESTART?"` in a warning colour (`BUBBLEGUM_PINK`) and set `restartConfirmActive = true`.
- Second click while active: call `restartGame()` — resets score to 0, eternities to 7, preserves `highScore` and `isMuted`, transitions to `"playing"`, resets `lastTime = 0`.
- If the player clicks any other button (Resume, Menu) or presses `Escape`/`P` to resume, reset `restartConfirmActive = false` — the confirmation is cancelled.
- No timeout needed: the confirmation resets whenever the player leaves the paused state or clicks another button.

#### 5e. Return to Menu

Available from the **pause overlay** (the `"✦ MENU"` button).

**Behaviour:**
- Add a `returnToMenu()` function.
- `returnToMenu()` calls `resetGameState()` (resets score, lives, objects, timers) then sets `gameState = "start"`.
- `highScore` and `isMuted` are preserved (same as restart).
- No extra confirmation needed — returning to menu is less destructive than it appears since the high score is safe, and the player already paused intentionally.

#### 5f. `gameLoop` changes

```
if (gameState === "playing") {
    updateGame(deltaTime);
    renderGame();
} else if (gameState === "start") {
    renderStartScreen();
} else if (gameState === "paused") {
    renderPauseScreen();          // ← new
} else if (gameState === "gameover") {
    renderGameOverScreen(deltaTime);
}
```

### 6. Input Handler Updates

Modify the `keydown` listener to respect game states properly:

| Key | `"start"` | `"playing"` | `"paused"` | `"gameover"` |
|-----|-----------|-------------|------------|--------------|
| `M` | Toggle mute + save pref | Toggle mute + save pref | Toggle mute + save pref | Toggle mute + save pref |
| `Escape` / `P` | — | Pause game | Resume game | — |
| Movement keys | — | Set `keys[e.key]` | Ignored | — |
| Any other key | Start game | Set `keys[e.key]` | Ignored (don't resume on random key) | Restart game |

- Move the mute toggle so it works in **all** states (it currently does, verify it remains so).
- Add the `Escape`/`P` handling **before** the per-state switch, returning early after toggling.
- In `"paused"` state, ignore all keys except `M`, `Escape`, and `P` — do **not** treat arbitrary keys as resume triggers.

**Canvas click handler updates:**
- In `"paused"` state: check for pause/play button click (resume) and mute button click. Clicking elsewhere does nothing.
- In `"playing"` state: also check for the new pause button click area.
- Add a check for the **reset-data button** on the start screen (see §7).

### 7. Restart (Clean Reset)

The existing `restartGame()` function already calls `resetGameState()` which resets `score = 0` and `lives = MAX_LIVES`. This is correct.

**Verify and ensure:**
- `restartGame()` does **not** clear `highScore`, `isMuted`, or their localStorage entries.
- `restartGame()` does **not** re-initialise `highScore` from storage (it should keep the in-memory value which may have been updated during the just-finished game).
- `restartGame()` transitions to `"playing"` (already does).
- `resetGameState()` resets `lastTime = 0` to prevent a time-jump on the first frame of the new game.

No structural changes needed — just verify the existing implementation remains correct after adding the new variables.

### 8. Reset Saved Data Control

**UI:** Add a small text label `"[RESET DATA]"` on the **start screen only**, positioned at the bottom-centre of the canvas (e.g., `y = CANVAS_HEIGHT - 30`). Render in `INDIGO_VELVET` or dim `PERIWINKLE` with reduced alpha so it doesn't dominate the screen.

**Interaction — two-click confirmation:**
1. First click on the `[RESET DATA]` region: change the label to `"[CONFIRM RESET?]"` and set a confirmation flag/timer.
2. Second click (within ~3 seconds): call `clearAllSavedData()`, reset `highScore = 0`, and revert the label. Optionally set `isMuted = false` as well since preferences are cleared.
3. If the timer expires without a second click, revert to `"[RESET DATA]"`.

**Implementation:**
- Add variables: `resetConfirmActive = false`, `resetConfirmTimer = 0`.
- In `renderStartScreen()`, draw the appropriate label based on `resetConfirmActive`.
- In the canvas click handler, when `gameState === "start"`, hit-test the reset label area. On first click set `resetConfirmActive = true` and `resetConfirmTimer = 3`. On second click while active, execute the reset.
- Tick `resetConfirmTimer` down using `deltaTime` in the start-screen branch of `gameLoop` (start screen currently doesn't receive deltaTime — pass it, or use `performance.now()` timestamps for the confirm timeout instead).

### 9. Storage Safety (Summary)

All storage safety is handled by the helper functions in §1:
- `saveData`: try/catch around `setItem`, silent failure.
- `loadData`: try/catch around `getItem` + `JSON.parse`, returns fallback.
- Type validation for each key (number for high score, boolean for mute).
- `clearAllSavedData`: try/catch around `removeItem`.
- The game never depends on storage succeeding — `highScore` defaults to 0, `isMuted` defaults to false. If storage is completely unavailable, the game plays normally without persistence.

---

## Integration: How State, Storage, Pause & Restart Work Together

```
┌──────────────────────────────────────────────────────────────────┐
│  Page Load                                                       │
│  1. loadData("highScore", 0) → highScore                         │
│  2. loadData("isMuted", false) → isMuted                         │
│  3. gameState = "start"                                          │
│  4. generateBackground(), start rAF loop                         │
└──────────────┬───────────────────────────────────────────────────┘
               │ any key / click
               ▼
┌──────────────────────────────────────────────────────────────────┐
│  Playing                                                         │
│  • updateGame() runs each frame                                  │
│  • Mute toggle → save pref immediately                           │
│  • Esc / P / Pause icon → pause                                  │
│  • Score < 0 or lives ≤ 0 → game over                            │
└──────┬───────────────────────────────┬───────────────────────────┘
       │ Esc/P/Pause icon              │ score<0 or lives≤0
       ▼                               ▼
┌──────────────────────────────┐   ┌───────────────────────────────┐
│  Paused                      │   │  Game Over                    │
│  • Gameplay frozen           │   │  • Compare score vs highScore │
│  • Esc / P / "RESUME"        │   │  • If new high: save storage  │
│  • "RESTART" → confirm       │   │  • Any key/click              │
│    resets score=0, lives=7   │   │    → restartGame()            │
│  • "MENU" → returnToMenu()   │   │  • Keeps highScore & isMuted  │
│  • M / Mute icon → mute      │   └───────────────────────────────┘
└──────────────────────────────┘
```

---

## Manual Testing Checklist

### High Score Persistence
- [ ] Play a game, get a score > 0, reach game over. High score displays on game-over and start screens.
- [ ] Refresh the page. Start screen still shows the saved high score.
- [ ] Play again and get a lower score. High score does not decrease.
- [ ] Play again and beat the high score. New high score is saved and displayed.
- [ ] Close the browser tab, reopen `index.html`. High score persists.

### Sound Preference Persistence
- [ ] Mute the sound with M key. Refresh the page. Sound is still muted.
- [ ] Unmute. Refresh. Sound is unmuted.
- [ ] Toggle mute by clicking the speaker icon. Refresh. Setting persists.

### Pause / Resume & In-Game Controls
- [ ] During gameplay, press `Escape` or `P`. Game pauses — objects freeze, "PAUSED" overlay appears with visible Resume, Restart, Menu buttons.
- [ ] During pause, score and eternities do not change; no objects spawn or move.
- [ ] Press `Escape` or `P` again. Game resumes without a visible time-jump (objects don't teleport).
- [ ] Click the pause button icon in the HUD during gameplay. Game pauses.
- [ ] Click `"▶ RESUME"` on the pause overlay. Game resumes cleanly.
- [ ] While paused, click `"↺ RESTART"`. Button changes to `"↺ CONFIRM RESTART?"`.
- [ ] Click `"↺ CONFIRM RESTART?"`. Current game resets cleanly (score = 0, eternities = 7), high score and mute pref are preserved, game starts immediately without browser refresh.
- [ ] While paused with restart confirmation active, click `"▶ RESUME"`. Confirmation cancels and game resumes.
- [ ] While paused, click `"✦ MENU"`. Game returns cleanly to start screen, preserving high score and mute pref without browser refresh.
- [ ] While paused, press movement keys. Nothing happens. Resume — no stuck movement.
- [ ] While paused, toggle mute with `M` or the mute icon. Setting updates and persists.
- [ ] While paused, press random keys (e.g., `A`, `Space`). Game does **not** resume.

### Restart & Game Over
- [ ] Reach game over. Press any key or click canvas. New game starts with score = 0, eternities = 7.
- [ ] High score is still displayed correctly (not reset).
- [ ] Mute preference is preserved through restart.

### Reset Saved Data
- [ ] On the start screen, click `[RESET DATA]`. Label changes to `[CONFIRM RESET?]`.
- [ ] Click again within 3 seconds. High score resets to 0 on screen. Sound preference resets to unmuted.
- [ ] Refresh the page. High score is 0. Sound is unmuted.
- [ ] Click `[RESET DATA]`, then wait 3+ seconds without clicking. Label reverts. Data is not cleared.

### Storage Safety
- [ ] Open the game in a private/incognito window. Game loads and plays normally (high score defaults to 0, mute defaults to off). No console errors.
- [ ] Manually corrupt `localStorage` (e.g., set `starSeeker_highScore` to `"abc"` in DevTools). Refresh. High score defaults to 0. No console errors.
- [ ] Delete `starSeeker_highScore` from DevTools. Refresh. High score defaults to 0.
- [ ] Game remains fully playable even if all localStorage operations throw errors.

---

## Completion Criteria

1. **High score** is saved to localStorage on game over and restored on page load. It displays on start and game-over screens.
2. **Mute preference** is saved on toggle and restored on page load.
3. **Four game states** (`start`, `playing`, `paused`, `gameover`) are managed with correct transitions.
4. **Pause/resume** works via `Escape`, `P`, and a visible canvas button. Pausing freezes all gameplay, prevents score/eternity updates, and displays in-game controls (Resume, Restart with confirmation, Menu). Resuming causes no time-jump.
5. **Restart** can be triggered at any time (from in-game pause menu with confirmation or from game over), cleanly resetting score to 0 and eternities to 7 without clearing high score or mute preference and without page reload.
6. **Return to menu** allows returning to the start screen at any time from pause while preserving saved data.
7. **Reset data** control on start screen clears all saved data with two-click confirmation.
8. **Storage errors** are caught silently; the game is fully playable without localStorage.
9. All existing Stage 1–3 functionality, visuals, sounds, and gameplay rules are preserved exactly.
10. No new files, libraries, or internet dependencies. Game works offline via `index.html`.
11. All items on the manual testing checklist pass.
