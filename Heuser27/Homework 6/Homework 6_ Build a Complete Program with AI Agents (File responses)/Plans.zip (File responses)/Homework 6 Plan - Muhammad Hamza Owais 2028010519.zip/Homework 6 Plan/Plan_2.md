Stage: 2. Visuals Effect
Architect model: Gemini 3 Flash
Builder model:Plan Build by Gemini
Result: NO bugs in visuals 
# Implementation Plan: Game Visuals & Styling (`plan_2.md`)

This document details the visual implementation instructions for the AI agent. Use these guidelines, color tokens, and asset requirements to style and render the game canvas and UI components.

## 1. Color Palette Tokens

Integrate the following color scheme across CSS/SCSS and Canvas rendering contexts:

### CSS Variables

```css
:root {
  --soft-apricot: #fcd0a1ff;
  --laser-blue: #2b59c3ff;
  --emerald: #06d6a0ff;
  --oxblood: #960200ff;
  --turf-green: #137547ff;
}
```

### SCSS Variables

```scss
$soft-apricot: #fcd0a1ff;
$laser-blue: #2b59c3ff;
$emerald: #06d6a0ff;
$oxblood: #960200ff;
$turf-green: #137547ff;

// Gradients
$gradient-top: linear-gradient(0deg, #fcd0a1ff, #2b59c3ff, #06d6a0ff, #960200ff, #137547ff);
$gradient-right: linear-gradient(90deg, #fcd0a1ff, #2b59c3ff, #06d6a0ff, #960200ff, #137547ff);
$gradient-bottom: linear-gradient(180deg, #fcd0a1ff, #2b59c3ff, #06d6a0ff, #960200ff, #137547ff);
$gradient-left: linear-gradient(270deg, #fcd0a1ff, #2b59c3ff, #06d6a0ff, #960200ff, #137547ff);
$gradient-radial: radial-gradient(#fcd0a1ff, #2b59c3ff, #06d6a0ff, #960200ff, #137547ff);
```

## 2. Background Scene & Environment Visuals

* **Sky & Sun:**
  * A shining bright sun in the upper portion of the screen using `--soft-apricot` and bright glow effects.
  * Sky styled using soft transitions from `--laser-blue` into lighter atmospheric tints.

* **Ground & Trees:**
  * Open grassy field using `--turf-green`.
  * Lush foliage on trees using `--emerald` and `--turf-green` tones.
  * Visible fresh fruits hanging on the tree branches.

* **Background Easter Egg / Detail:**
  * **Sir Isaac Newton:** Rendered sitting under the main tree on the side.
  * **Mid-air Apple:** An apple floating/falling in mid-air directly above Isaac Newton's head as a static or subtle looping ambient element.

## 3. Game Characters & Interactive Visuals

### Player Character
* **Sprite/Graphic:** Player character rendered with a **basket placed on their head** to catch items.
* **Bounding Box:** Ensure the collision detection aligns with the basket rim at the top of the player model.

### Dropping Collectibles
1. **Fresh Fruits:**
   * Bright, vibrant textures (e.g., apples, oranges, berries).
   * Styled with `--emerald` and warm fruit colors to signify positive points.
2. **Rotten Fruits:**
   * Darkened, damaged, or discolored fruit sprites with subtle fly/swarm particle effects or brown/dark spots (`--oxblood` accents).
   * Signifies negative points or loss of life when caught.

## 4. Game Over Visual Effects & Particle Systems

When the game state changes to `GAME_OVER`, trigger one of two particle celebrations based on the player's final score:

### Condition A: High Score Beaten (`score > highScore`)
* **Effect:** **Firecrackers / Fireworks Explosion System**
* **Visuals:**
  * Multi-colored explosive bursts originating from random points on screen.
  * High-velocity particles with trailing motion blurs and glowing flares.
  * Uses full palette contrast (`--soft-apricot`, `--emerald`, `--laser-blue`).

### Condition B: Standard Completion (`score <= highScore`)
* **Effect:** **Subtle Sparkles / Confetti System**
* **Visuals:**
  * Gentle falling or floating sparkle particles (`--soft-apricot` and `--emerald` twinkles).
  * Calm fade-out animations without grand explosions.

## 5. Summary Checklist for AI Agent Implementation

* [ ] Apply CSS/SCSS variables to the global stylesheet.
* [ ] Draw background with ground (`--turf-green`), sky (`--laser-blue`), sun (`--soft-apricot`), and trees with hanging fruit.
* [ ] Render Isaac Newton with a floating mid-air apple under a tree.
* [ ] Draw the main player sprite with a basket on their head.
* [ ] Implement fresh fruit vs. rotten fruit sprites for drop logic.
* [ ] Build particle emitter engine for:
  * High Score: Firecracker bursts.
  * Regular Score: Gentle sparkles.