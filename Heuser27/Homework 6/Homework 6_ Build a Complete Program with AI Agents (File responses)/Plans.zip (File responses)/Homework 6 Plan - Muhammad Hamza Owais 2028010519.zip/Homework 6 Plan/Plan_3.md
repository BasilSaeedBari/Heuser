Stage: 3. Sensary Feedback
Architect model: Gemini 3 Flash 
Builder model: Plan Build by Gemini
Result: No bugs


# Sensory Feedback & Audio Integration Plan for AI Agent

## Overview
Implement sensory audio feedback and audio control UI to enhance player engagement.

---

## 1. Asset Requirements & Directory Setup
Create a dedicated sound directory (e.g., `assets/sounds/` or `public/audio/`) containing the following audio files:

- **`fruit_collect.mp3`**: Quick, high-pitched "ting" or coin-pickup sound effect.
- **`firecracker.mp3`**: Pop / crackle celebration audio for milestones or high scores.
- **`game_over.mp3`**: Classic retro arcade / Snake game-over descending tone.

---

## 2. Audio Manager Architecture
Implement a central `AudioManager` to handle sound execution, overlap, and state persistence:

- **State Management**: Maintain a global `isMuted` boolean.
- **Persistence**: Save `isMuted` setting in `localStorage` to retain player preferences across sessions.
- **Autoplay Handling**: Initialize the main `AudioContext` (or audio elements) on the user's first interaction (click/keypress) to comply with browser autoplay policies.
- **Overlap Support**: Allow sound effects (e.g., `fruit_collect`) to play rapidly without cutting off previous instances.

---

## 3. UI Controls (Mute Button)
Add a UI element for audio controls:

- Position a toggle button in a persistent corner of the screen (e.g., top-right UI bar).
- Toggle icons dynamically: `🔊` (Unmuted) vs `🔇` (Muted).
- Clicking the toggle flips the `isMuted` state in `AudioManager` and updates the UI state.

---

## 4. Game Loop & Event Triggers

### A. Fruit Collection
- **Trigger Location**: Inside collision detection logic for fruit/item pickup.
- **Action**: Call `AudioManager.play('fruit_collect')`.

### B. Game Over Event
- **Trigger Location**: Inside the collision/defeat state trigger (e.g., snake hits wall or tail).
- **Action**: Call `AudioManager.play('game_over')` immediately before displaying the high-score / reset overlay.

### C. Firecracker Celebration
- **Trigger Location**: When reaching specific milestones, level clear, or acquiring special rewards.
- **Action**: Call `AudioManager.play('firecracker')` (can trigger multiple rapid pops for visual fireworks).

---

## 5. Implementation Checklist for AI Agent
- [ ] Create/map audio file assets.
- [ ] Implement `AudioManager` class or audio helper functions.
- [ ] Render Mute/Unmute UI toggle button with persistent state.
- [ ] Attach sound calls to fruit pickup, game over, and milestone events.
- [ ] Test rapid audio triggers for overlapping sounds.