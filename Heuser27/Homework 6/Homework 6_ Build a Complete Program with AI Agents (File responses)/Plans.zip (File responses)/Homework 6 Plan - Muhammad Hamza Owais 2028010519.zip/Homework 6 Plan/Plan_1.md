Stage: 1. Core Logic
Architect model: Gemini 3 Flash 
Builder model: Plan Build by Gemini
Result: Objects starts falling very fast impossible to catch score increased by 50(Bug)

# Stage 1: Core Logic Architecture Plan

## 1. Overview & Core Objective

The objective of Stage 1 is to construct a fully functional, playable prototype of the Catch Game using pure HTML, CSS, and JavaScript. Visual appearance is secondary at this stage—plain shapes, rectangles, and basic HTML elements are completely acceptable. The focus is strictly on mechanics, user controls, hit detection, scoring rules, and game state transitions.

## 2. File Responsibilities & Setup

The project will consist of three interconnected files created by the Builder model:

1. `index.html`: Contains structural DOM elements including game container/canvas, heads-up display (HUD) for scores and lives, and basic HTML buttons for pause and restart.

2. `style.css`: Minimal positioning rules to center the game board on screen and manage overlay visibility (`display: none` / `display: block`).

3. `script.js`: Contains all engine logic, game loops, event listeners, physics updates, collision routines, and state control functions.

## 3. Game State & Configuration Variables

The JavaScript engine (`script.js`) must define and maintain the following key state parameters:

```
// Screen & Boundary Configurations
const GAME_WIDTH = 800;
const GAME_HEIGHT = 600;

// Player Variables
const PLAYER_WIDTH = 100;
const PLAYER_HEIGHT = 20;
const PLAYER_SPEED = 8;
let playerX = (GAME_WIDTH - PLAYER_WIDTH) / 2;
const playerY = GAME_HEIGHT - PLAYER_HEIGHT - 10; // Fixed Y position

// Game Engine Parameters
let score = 0;
let highScore = 0;
let lives = 3;
let isGameOver = false;
let isPaused = false;
let gameLoopId = null;

// Falling Entities Array
let fallingObjects = [];
let lastSpawnTime = 0;
const spawnInterval = 1000; // Time in milliseconds between object drops

```

## 4. Movement Mechanics & Controls

* **Constraint**: Player moves strictly along the horizontal X-axis. Y-axis position remains permanently static at `playerY`.

* **Keyboard Listeners**:

  * `ArrowLeft` or `A`/`a` key set `moveLeft = true`.

  * `ArrowRight` or `D`/`d` key set `moveRight = true`.

* **Boundary Collisions**:

  * Clamp `playerX` between `0` (left screen boundary) and `GAME_WIDTH - PLAYER_WIDTH` (right screen boundary) to prevent moving off-screen.

## 5. Spawning & Physics Engine

* **Spawning Logic**:

  * Objects spawn at `Y = 0` with a randomized `X` position between `0` and `GAME_WIDTH - OBJECT_SIZE`.

  * Type determination is randomized: `GOOD` item (\~70% probability) vs `BAD` item (\~30% probability).

  * Objects fall downwards at a constant downward velocity (`Y += speed`).

* **Collision Detection Routine (AABB - Axis-Aligned Bounding Box)**:

  * Check intersection between falling object rectangles and player rectangle: \$$\\text{Overlap} = (Obj_X < Player_X + Player_W) \\land (Obj_X + Obj_W > Player_X) \\land (Obj_Y < Player_Y + Player_H) \\land (Obj_Y + Obj