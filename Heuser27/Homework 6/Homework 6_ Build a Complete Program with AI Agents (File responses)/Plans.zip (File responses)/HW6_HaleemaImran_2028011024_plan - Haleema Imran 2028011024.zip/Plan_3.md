Stage: 3 - Sensory Feedback
Architect model: Claude Sonnet 5.5    Builder model: Claude Sonnet 5.5
Result: Glow, sparks, shake, Web Audio sounds and a mute button were written in code; the effects were added in one pass and still need a hands-on playtest to confirm each one.

---

# Plan 3: Sensory Feedback

## Visual reactions
- Lantern lit: scale up to 1.07 plus a colored box-shadow halo and radial glow.
- Hover: brightness boost. Press: scale down to 0.96.
- Particles: 10 small colored sparks fly outward from the lantern center on every flash (CSS animation, removed on animationend, capped at 80 on screen).
- Wrong answer: the board shakes for 0.4 s.
- Button hover/press: color change and slight shrink.

## Sounds (Web Audio API only, no files)
- Each lantern has its own note: 262, 330, 392, 523 Hz (triangle wave, 0.35 s with fast fade in/out to avoid clicks).
- Round cleared: two rising sine tones (523, 659 Hz).
- Game over: two low sawtooth tones (160, 110 Hz).
- UI click: very short square blip.
- AudioContext is created lazily on the first user action (browsers block autoplay) and resumed if suspended.

## Mute
- A Sound on/off button. When muted, no AudioContext is created or used.
- State shown in button text and aria-pressed.

## Accessibility
- `prefers-reduced-motion` disables shake and particles.
- Every important action (flash, correct, wrong, round clear) has both a visual and audio reaction.

## Done when
Every important action gives the player a visible or audible reaction, and mute silences everything.
