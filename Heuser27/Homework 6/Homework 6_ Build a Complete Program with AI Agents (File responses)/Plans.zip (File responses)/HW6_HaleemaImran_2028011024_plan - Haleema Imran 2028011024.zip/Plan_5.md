Stage: 5 - Debugging and Polish
Architect model: Claude Sonnet 5.5    Builder model: Claude Sonnet 5.5
Result: Edge cases were reviewed in the code and five risks were guarded against (listed below); these were found by code review, not by playtesting.

---

# Plan 5: Debugging

## Edge cases to attack
1. Rapid clicking / key mashing during the SHOWING phase.
2. Rapid clicking after the last correct tap (could double-count and skip a round).
3. Pressing Restart while a sequence is mid-playback (old timers firing into the new game).
4. Pausing during playback, then resuming.
5. Switching tabs or minimizing the window during play.
6. Resizing the window while particles are on screen.
7. Corrupted saved data (e.g. localStorage value set to `{"best":"abc"}` or invalid JSON).
8. Holding down a key (auto-repeat) counting as many presses.
9. Pressing Space while a button has focus (double triggering).
10. Muting before the first sound, and unmuting mid-game.
11. Clicking Reset data accidentally.

## Final polish
- Respect prefers-reduced-motion.
- Make sure status text always says what to do next.
- Cap particles so long sessions do not slow down.

## Bug list
These risks were found by reviewing the code (not by playtesting) and each fix is in the final code.
| # | Problem found | How it was fixed |
|---|---|---|
| 1 | Tapping right after the final correct step could register extra input and skip or break the next round. | State is set to "showing" immediately on round completion so extra taps are ignored. |
| 2 | Pressing Restart mid-playback let old timers flash lanterns in the new game. | All timers are stored in one array and cleared in `clearTimers()` on restart, pause, and game over. |
| 3 | Invalid or corrupted saved data crashed loading or showed NaN as best score. | Load wrapped in try/catch and values validated before use; defaults on failure. |
| 4 | Switching tabs left the game running, so the player lost without seeing the sequence. | `visibilitychange` automatically pauses; resume replays the sequence. |
| 5 | Holding a number key counted as repeated presses. | Ignore `keydown` events where `e.repeat` is true. |

## Done when
At least 3 real bugs found, fixed, and listed above.
