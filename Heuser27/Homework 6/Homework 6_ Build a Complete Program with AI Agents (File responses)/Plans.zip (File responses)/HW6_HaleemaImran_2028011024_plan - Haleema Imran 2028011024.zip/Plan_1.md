Stage: 1 - Core Logic
Architect model: Claude Sonnet 5.5    Builder model: Claude Sonnet 5.5
Result: Core rules, controls, scoring and restart were built and syntax-checked; the game loads in Chrome with all four lanterns and buttons showing correctly.

---

# Plan 1: Core Logic (Pattern Memory, "Lantern Echo")

## Goal
A fully playable pattern-memory game with plain visuals. Rules only, no polish.

## Rules
- Four lanterns (amber, teal, rose, violet).
- Each round the game adds ONE new random lantern to the end of a growing sequence, then replays the whole sequence.
- The player repeats the sequence in the same order.
- Correct full repeat: round increases, sequence grows by one.
- Any wrong lantern: game over.

## Controls
- Mouse/touch: click a lantern.
- Keyboard: keys 1, 2, 3, 4 map to the lanterns left-to-right, top-to-bottom.
- Buttons: Start / Restart.

## Scoring
- Score = number of rounds fully cleared. Shown as "Round" in the HUD.
- On game over, show how many rounds were cleared.

## Game flow
1. Menu: status text explains the game, Start button visible.
2. Start: sequence = [], round = 0, then first round begins.
3. SHOWING: lanterns light one by one. Input is ignored.
4. INPUT: player taps. A pointer to the current expected step (inputIndex) advances on each correct tap.
5. When inputIndex equals sequence length, lock input immediately, wait about 1 s, add next step, go to SHOWING.
6. On wrong tap: state = OVER, message shown, Restart available.

## Data structures
- `sequence: number[]` (values 0-3), `inputIndex`, `round`, `state` string.
- Timers stored in an array so they can all be cancelled on restart.

## Implementation notes
- Single state variable; every input handler first checks `state === "input"`.
- Sequence playback speed shrinks slightly with round number (minimum 260 ms per step).
- Lantern flash = temporary CSS class `lit`.

## Done when
Someone can start, play several rounds, lose, and restart. It is ugly but works.
