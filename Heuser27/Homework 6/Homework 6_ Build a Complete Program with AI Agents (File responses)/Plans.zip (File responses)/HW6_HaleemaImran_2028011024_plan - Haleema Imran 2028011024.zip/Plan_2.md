Stage: 2 - Visual Vibe
Architect model: Claude Sonnet 5.5    Builder model: Claude Sonnet 5.5
Result: The lantern theme, palette and layout are drawn with CSS only (no image files); the page renders in Chrome with the night-sky background and four coloured lanterns.

---

# Plan 2: Visual Vibe

## Theme
A quiet night festival: paper lanterns glowing against a deep indigo sky. Calm, warm, slightly nostalgic. Rules from Stage 1 must NOT change.

## Palette
- Night: #141a36 and #1d2547 (background gradient)
- Ink (text): #f1e9d8
- Muted text: #9aa3c7
- Lantern colors: amber #f2a65a, teal #3fb5a5, rose #e0607e, violet #8e7dff
Each lantern's idle color is its hue mixed with night (about 28 percent), so lit state clearly pops.

## Layout
- Single centered column, max width 460 px, works on phones.
- Order top to bottom: title, status line, HUD (Round, Best), 2x2 lantern board, control buttons, hint line.
- Text is center aligned; buttons wrap on narrow screens.

## How everything is drawn with code (no images)
- Lantern body: a button with asymmetric border-radius to make a rounded paper-lantern shape.
- Lantern cap: `::before` rectangle on top. Tassel: `::after` thin bar underneath.
- Glow layer: inner span with radial-gradient, hidden until the `lit` class is added.
- Background: CSS radial-gradient. No SVG or image files needed.

## Typography
- Title and numbers: Georgia (system serif) for a lantern-festival feel.
- Everything else: system-ui. No downloaded fonts.

## Accessibility
- Visible focus outline, aria-labels on lanterns, sufficient contrast for text, status line uses aria-live.

## Done when
It looks like a real themed game and the project folder has zero image files.
