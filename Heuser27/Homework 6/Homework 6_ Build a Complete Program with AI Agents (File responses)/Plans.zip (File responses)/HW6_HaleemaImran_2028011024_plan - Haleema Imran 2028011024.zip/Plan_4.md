Stage: 4 - State & Storage
Architect model: Claude Sonnet 5.5    Builder model: Claude Sonnet 5.5
Result: Best score and sound setting save to localStorage with validation, and pause, game-over and reset-data were added; refresh persistence still needs a hands-on check.

---

# Plan 4: State & Storage

## Data that must be remembered
- `best`: highest round reached (integer).
- `muted`: sound preference (boolean).

## Where it is saved
- `localStorage` under one key, `lanternEcho_v1`, as JSON: `{ "best": 7, "muted": false }`.
- Save happens when a new best is reached and when mute is toggled.

## Loading safely
- Wrap read/parse in try/catch.
- Validate: `best` must be a finite number between 0 and 1,000,000; `muted` must be boolean. Anything else falls back to defaults.
- If localStorage is blocked, the game still runs (save is wrapped in try/catch).

## Game states
- menu: before first start.
- showing: sequence is playing, input locked.
- input: player's turn.
- paused: timers cleared, board dimmed, Resume button.
- over: after a mistake, Restart available.

## State transitions
menu -> showing -> input -> showing (next round) ... -> over -> showing (restart).
Pause is allowed from showing or input. Resuming from showing replays the sequence from the start so the player never misses a step; resuming from input returns to input.

## Pause rules
- Pause button, Space key, and automatic pause when the tab becomes hidden.
- All pending timeouts are cancelled on pause; no state change can happen while paused.

## Reset data
- Button requires two taps within 3 s (no popup). Clears localStorage and resets best and mute to defaults.

## Done when
Refreshing keeps best score and sound setting. Pause and restart work. Reset clears everything.
