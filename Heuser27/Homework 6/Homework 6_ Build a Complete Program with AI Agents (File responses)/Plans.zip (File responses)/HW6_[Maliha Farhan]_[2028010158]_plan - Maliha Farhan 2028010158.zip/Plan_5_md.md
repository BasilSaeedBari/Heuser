﻿Stage: 5. Debugging 
Architect model: C. pattern memory
Builder model: Gemini, claude sonnet
Result: Since the limit in antigravity had been reached i used claude sonnet 5.5 to debug my game also the score kept going to -1 if the user got an answer wrong which i fixed after reading the java script code file 
I found seven bugs, all now fixed in `script.js` and `style.css`. `index.html` needed no changes. I checked `script.js` for syntax errors and confirmed the CSS braces balance, but I haven’t played the game in a browser, so test the pause and quit cases below.

**Bugs found and fixed**

1.  **The round advanced while the game was paused.** If you paused during the ✅/❌ result flash, the next round still started behind the pause screen. The round now waits and moves on when you resume (`pendingAdvance` in `script.js`).
2.  **Cancelling Quit unpaused a game you had paused.** If you were already paused and pressed ✕ then Cancel, the game resumed. It now returns to the pause screen (`quitWasPaused`).
3.  **Undo and Submit worked while paused.** The overlay hid them, but Tab and Enter could still trigger them, so you could submit an answer while paused. Both now check `isPaused` and the current phase.
4.  **The Hard stage card overflowed on narrow phones.** Six colour swatches were wider than the card at about 320px. The swatches are smaller and wrap, and the cards can now shrink (`min-width: 0` on the fieldset and cards).
5.  **The colour swatches had big glow shadows.** They came from the shared `.color-*` classes and looked blurry at 9px. I turned the glow off on them.
6.  **The stage picker had no keyboard navigation.** It declared itself a radio group but every card was a Tab stop. It now works like a radio group: one Tab stop, and the arrow keys move between stages.
7.  **Dead CSS.** The old `.difficulty-picker` and `.high-score-display` rules are removed.

**Smaller change.** The Space-to-pause shortcut now only fires when no button has focus (target is `body` or `html`).


