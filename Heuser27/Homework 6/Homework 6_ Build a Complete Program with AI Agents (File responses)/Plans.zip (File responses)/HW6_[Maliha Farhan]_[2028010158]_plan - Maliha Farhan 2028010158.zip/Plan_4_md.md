﻿Stage: 4. State and storage 
Architect model: C. pattern memory
Builder model: Gemini, claude sonnet
Result: I already gave the prompt of storing the high-score in stage 1 so the high-score gets saved and the pause and play button work accordingly. The only additional prompt I gave was to save the progress if the user had paused the game and the game window got closed the data would still be there and to save three different high-scores for three different levels (easy, medium, hard)
The prompt given to Gemini:
If the user pauses the game and the game window gets closed down then make sure to save the progress also for each stage (easy, medium, hard) store three different high-scores. Make the changes in the plan of these three files accordingly also keep in mind that this game should be playable offline.
The result received from Gemini:
### File 1: `index.html` Updates

-   **Stage Selection Screen:**
    
    -   Add a pre-game menu or selector allowing the user to choose between **Easy**,  **Medium**, and **Hard** difficulty stages before starting a session.
        
-   **Offline Asset Management:**
    
    -   Ensure all audio files (beep sound, disappointing sound, cheerful sound, bubbly click sound) and styling assets are linked locally rather than relying on external CDNs, guaranteeing the game works completely offline.
        
-   **UI Controls & Layout (Retained from previous updates):**
    
    -   Top-left: Timer (with the 3-second beep integration).
        
    -   Top-middle: Counter/Score display.
        
    -   Top-right: Pause/Play button,  **Green** Main Menu button, and **Red** Cross/Quit button.
        

### File 2: `style.css` Updates

-   **Stage Selection Styling:**
    
    -   Design clean, accessible buttons or cards for the Easy, Medium, and Hard difficulty options using the game's core theme colors (`pitch-black`,  `dark-amethyst`,  `salmon`,  `burnt-peach`,  `porcelain`).
        
-   **Multi-Stage High Score Display:**
    
    -   Create dedicated layout spaces in the menu or end-game summary to clearly showcase the high scores separately for Easy, Medium, and Hard modes.
        

### File 3: `script.js` Updates

-   **Progress Persistence on Pause/Close:**
    
    -   Utilize the `beforeunload` event listener and `localStorage` to automatically save the current game state (current round, score, active stage, and remaining time) if the user pauses and closes or refreshes the window.
        
    -   Add a "Resume Game" option on startup if saved progress is detected in `localStorage`.
        
-   **Stage-Specific High Scores:**
    
    -   Restructure `localStorage` data handling to store and retrieve three distinct high scores mapped to their respective stages:  `highScore_easy`,  `highScore_medium`, and `highScore_hard`.
        
-   **Offline Logic & Audio Integration:**
    
    -   Keep all sequence generation, timer logic, score calculations (+1 for correct, 0 for incorrect across 10 rounds), audio triggers (bubbly click for 1s, timer beep for 3s, score-based sounds for 2s), and guessing color separation entirely self-contained for seamless offline play.
 
