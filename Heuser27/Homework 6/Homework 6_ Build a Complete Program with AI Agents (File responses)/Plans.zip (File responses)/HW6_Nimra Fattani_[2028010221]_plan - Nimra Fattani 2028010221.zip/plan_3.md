Stage: Stage 3 — Sensory Feedback & Audio Enhancement
Architect model: Claude Opus 4.6
Builder model: Gemini 3.8 Flash
Result: Implemented procedural Web Audio API sound synthesis, Web Speech API voice announcements, interactive button micro-interactions, canvas particle bursts, and floating score popups. Handled browser audio autoplay restrictions by unlocking AudioContext on the first user interaction, ensuring seamless audio and visual feedback without external assets.

---

# Antigravity: Sensory Feedback & Audio Enhancement Spec (Plan 3 MD)

## 1. Overview & Objectives
Enhance player immersion and game feel for "Antigravity" by integrating dynamic visual particle effects, responsive micro-interactions (hover/press), procedural code-made audio effects (Web Audio API), spoken voice cues for game states, and a global Mute toggle.

---

## 2. Audio Design & Sound Effects (Code-Made / Synthesized)
All audio must be procedurally generated via the Web Audio API to keep assets lightweight and fully self-contained.

*   **Button Press Sound:** 
    *   *Trigger:* On mouse down/click or keyboard activation of any UI button.
    *   *Characteristics:* Short, crisp sine-wave frequency chirp (rising pitch from 400Hz to 800Hz over 50ms) with a gentle volume decay.
*   **Apple Picked (Good) Sound:**
    *   *Trigger:* Successfully catching a positive item (Apple).
    *   *Characteristics:* Cheerful ascending major arpeggio chime (e.g., C5 -> E5 -> G5 -> C6) using bright oscillator tones with a warm reverb tail.
*   **Bomb Caught (Crash) Sound:**
    *   *Trigger:* Colliding with a hazard (Bomb).
    *   *Characteristics:* Deep noise buffer burst (white/pink noise filtered low-pass) combined with a low sub-bass impact drop (150Hz down to 30Hz) and screen shake.
*   **Master Mute Button:**
    *   *Trigger:* Clicking the Mute/Unmute icon in the HUD.
    *   *Characteristics:* Toggles a global audio gain node destination between `1.0` and `0.0`. Updates icon state dynamically (e.g., Speaker Active vs. Speaker Muted).

---

## 3. Voice Lines & Game State Announcements
Integrate speech synthesis or pre-synthesized vocal tones for key game lifecycle moments:

*   **Game Start:** 
    *   *Audio Line:* "Good luck!"
    *   *Style:* Upbeat, energetic synthesized voice with a friendly pitch curve, accompanied by sparkles.
*   **Game Over / Lost:** 
    *   *Audio Line:* "Better luck next time"
    *   *Style:* Softer, sympathetic cadence to cushion the loss without discouraging the player.
*   **Game Paused:** 
    *   *Audio Line:* "Relax player"
    *   *Style:* Calm, soothing tone delivered immediately when pause is triggered, reassuring the user.

---

## 4. Visual Feedback & Particles
*   **Hover & Press States:** Buttons scale up by 5% on hover with a glowing drop shadow, and depress slightly (scale down or shift down 2px) on active press.
*   **Catch Particle Bursts:** 
    *   *Apple Catch:* Burst of green/gold floating sparkles drifting upward.
    *   *Bomb Crash:* Red/orange sparks and smoke puffs bursting outward accompanied by canvas screen shake.
*   **Floating Score Popups:** Floating text labels (e.g., `+100`, `CRASH!`, `COMBO X2`) that spawn at the catch location and fade out as they float upward.
