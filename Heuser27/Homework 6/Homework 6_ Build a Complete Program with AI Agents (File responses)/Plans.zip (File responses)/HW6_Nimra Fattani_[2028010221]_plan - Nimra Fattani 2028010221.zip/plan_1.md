**Stage:** Stage 1 — Core Logic  
**Architect model:** Gemini  
**Builder model:** Gemini  
**Result:** The core game loop, basket movement, and timed multi-object falling mechanics worked smoothly. Continuous timed spawning, balanced drop distribution, dynamic difficulty scaling with accelerated spawn frequency, and responsive collision handling provide consistent, fair arcade gameplay.

---

# A. STAGE 1 ARCHITECT PLAN — Core Logic

## 1. Project overview
- **Project:** Catch Game
- **Stage:** Stage 1 — Core Logic
- **Objective:** Plan a functional browser game in which the player moves a catcher to catch good falling objects and avoid bad ones.

According to Homework 6, Stage 1 must define the rules, controls, scoring or winning conditions, and how the game starts, ends and repeats. The game may look basic at this stage.

## 2. Game rules
The game works as follows:
- Good objects (Apples) and bad objects (Bombs) fall continuously from the top of the game area.
- The player controls a basket near the bottom of the play area.
- **Catching an apple (good object):** Increases score by 1 point.
- **Missing an apple:** Costs 1 life AND decreases score by 1 point (score never drops below zero).
- **Catching a bomb (bad object):** Costs 1 life (score is unaffected).
- **Missing a bomb:** Has no penalty (score and lives remain unchanged).
- The player starts with three lives.
- The game ends when all lives are lost (lives reach zero).
- The final score is displayed after game over.
- The player can restart and play a new round.

*Assumptions:* Apples are good objects and bombs are bad objects. Each apple caught earns one point.

## 3. Controls
| Control | Action |
|---|---|
| Left Arrow / A | Move basket left (speed dynamically scales with falling speed) |
| Right Arrow / D | Move basket right (speed dynamically scales with falling speed) |
| Start button | Begin a new game |
| Restart button | Reset score, lives, and speed, then begin again |
| Pause / Resume | Freeze/unfreeze gameplay and timer without losing game state |

The basket must remain inside the game area. Movement must stop when the game ends. Basket horizontal velocity is dynamically linked to falling object speed so player control stays agile and balanced as difficulty rises.

## 4. Game states
The game uses four states:
- **Ready:** Instructions and the Start button are visible.
- **Playing:** Objects spawn on schedule and fall, the basket moves, and collisions are checked.
- **Paused:** Game loop and spawn timer are frozen; all positions and states are preserved.
- **Game Over:** Gameplay stops, and the final score and Restart button are displayed.

**State transitions:**
1. Ready → Playing when Start is clicked.
2. Playing → Paused when Pause is clicked or 'P' is pressed.
3. Paused → Playing when Resume is clicked or 'P' is pressed.
4. Playing → Game Over when lives reach zero.
5. Game Over → Playing when Restart is clicked.

## 5. Game data and variables
The JavaScript logic maintains:
- `gameState` — current state (`'Ready'`, `'Playing'`, `'Paused'`, `'GameOver'`).
- `score` — current score (clamped at `Math.max(0, score)`).
- `lives` — remaining lives (starts at 3).
- `basket` — position (`basketX`), dimensions, and movement speed.
- `fallingObjects` — list of currently active falling objects on screen (allowing multiple concurrent falling items).
- `objectSpeed` — vertical falling speed of objects in pixels per second.
- `spawnIntervalMs` — active spawn timer interval in milliseconds.
- `spawnTimer` — accumulator / timer tracking when the next object should spawn.
- `processedCount` — count of total objects processed (caught or missed) for difficulty scaling milestones.
- `goodItemRatio` — probability threshold for spawning good objects vs. bad objects (defaults to 0.50).
- `pressedKeys` — movement keys currently held (`left`, `right`).
- `animationFrameId` — active animation loop identifier.
- `lastFrameTime` — previous frame timestamp for delta-time calculation.
- `gameWidth` and `gameHeight` — play-area dimensions (400 × 500).

## 6. Random object generation & Item Distribution
When a new object is created:
1. **Item Distribution & Drop Rate:** Use an equal drop rate / balanced ratio between good and bad items (a strict 50% chance for each type upon generation: `Math.random() < goodItemRatio`, where `goodItemRatio = 0.50`).
2. **Ratio Adjustments:** As difficulty scales across rounds/milestones, the engine allows dynamic adjustments in the item drop ratio if needed (e.g., maintaining a fair 50/50 balance or gradually tuning bad object probability as difficulty ramps up).
3. **Positioning:** Select a randomized horizontal coordinate `x` within playfield boundaries: `Math.random() * (GAME_WIDTH - OBJECT_SIZE)`.
4. **Initialization:** Place it at the top of the game area (`y = 0`) with downward vertical velocity.
5. **Type immutability:** The object's type (`apple` or `bomb`) remains fixed throughout its fall.

## 7. Movement, Spawning & Timing
- **Basket Speed Scaling:** Link and scale the basket's movement speed dynamically to the speed of falling objects. As falling objects speed up with difficulty, basket speed scales proportionally (maintaining a balanced maneuverability ratio of `basketSpeed = objectSpeed * 2.0` or a proportional baseline speed formula), ensuring the player can traverse the playfield comfortably as items fall faster.
- **Timed Spawning Schedule:** New objects spawn on a timed schedule (`spawnIntervalMs`) rather than waiting strictly for the previous object to be completely removed from the screen. This allows multiple items to fall simultaneously, creating active arcade pacing.
- **Main Loop:** Use `requestAnimationFrame()` with elapsed delta-time calculation (`deltaTime`) so movement speed remains consistent across refresh rates.
- **Elapsed Time Capping:** Cap `deltaTime` to `0.1s` (100ms) to prevent large movement jumps when switching tabs or experiencing frame drops.
- **Basket Bounds:** Prevent the basket from crossing the play-area boundaries (`0 <= basketX <= GAME_WIDTH - BASKET_WIDTH`).
- **Object Updates:** Each frame updates every active object's vertical position: `obj.y += objectSpeed * deltaTime`.

## 8. Collision detection, Scoring & Difficulty Progression
The game detects when any falling object overlaps the basket via Axis-Aligned Bounding Box (AABB) intersection:
- **Apple caught:** Score increases by 1 point; spawn visual/audio feedback; remove object.
- **Apple missed (passes bottom):** Score reduced by 1 point (never below 0) AND player loses 1 life; remove object.
- **Bomb caught:** Player loses 1 life (score unaffected); trigger screen shake/crash feedback; remove object.
- **Bomb missed (passes bottom):** No penalty; remove object.
- **Lives reach zero:** Trigger Game Over immediately.
- **Difficulty Progression:**
  - Track processed objects (every object caught or missed).
  - After every milestone (every 3 rounds / milestones of processed objects):
    - Accelerate the spawning frequency by reducing `spawnIntervalMs` (e.g., decreasing interval by 80ms down to a responsive minimum threshold).
    - Increase object falling speed (e.g., +20 px/s to +40 px/s).
    - **Dynamic Basket Speed Scaling:** Simultaneously adjust and scale basket movement speed proportionally alongside falling object speed, ensuring player maneuverability scales with higher difficulty without feeling sluggish.
    - Optionally fine-tune `goodItemRatio` if dynamic ratio adjustment is active.

## 9. Start, Game Over and Restart
- **Starting:** Initialize score to 0, lives to 3, reset speed and spawn interval, clear active objects and particles, center the basket, and start the timed spawning loop.
- **Game Over:** Stop the animation loop, cancel pending spawn timers, clear remaining active falling objects, freeze movement, and display the final score and Restart button.
- **Restarting:** Clear previous game activity, reset all run-specific variables, and start a fresh game without duplicate loops or orphaned timers.

## 10. Error prevention
The implementation prevents:
- Multiple game loops running simultaneously by cancelling previous animation frame IDs.
- Duplicate or overlapping spawn timers.
- Orphaned objects from previous rounds lingering after restart or reset.
- Score or lives dropping below zero via `Math.max(0, val)`.
- The same object triggering multiple collision events using a `processed` flag.
- Basket escaping the play area by clamping position coordinates.
- Stuck keys after browser loses focus by clearing `pressedKeys` on window `blur`.
- Large position leaps on lag spikes or tab switching by capping `deltaTime`.
- Multiple game-over invocations in the same frame.

## 11. Responsibilities of the three files
| File | Responsibility |
|---|---|
| `index.html` | Semantic layout: title, stats HUD, control bar (Pause, Reset, Mute), canvas play area, and state overlays (Ready, Pause, Game Over). |
| `style.css` | Modern Nature Arcade styling, cohesive color palette, responsive card containers, buttons, and HUD typography. |
| `script.js` | Game state machine, scheduled multi-object spawning, balanced item distribution, accelerated difficulty progression, basket motion, collision detection, feedback effects, and procedural rendering. |

The program uses exactly these three files, has no external asset dependencies, and works completely offline.

## 12. Manual testing plan
| Test | Expected result |
|---|---|
| Open HTML directly | Game loads offline without internet or external requests. |
| Start game | Score starts at 0, lives at 3, basket centered. |
| Timed Spawning | Objects spawn continuously on schedule; multiple objects can be on screen simultaneously. |
| Drop Rate & Ratio | Apples and bombs spawn in balanced 50/50 proportion. |
| Catch Apple | Score increases by 1 point with sparkle effect and chime. |
| Catch Bomb | 1 life is lost; screen shakes; explosion particle burst. |
| Miss Apple | 1 life is lost and score decreases by 1 (clamped at 0). |
| Miss Bomb | Bomb falls past bottom with no penalty to score or lives. |
| Difficulty Milestone | After every milestone (every 3 rounds/milestones), spawn frequency accelerates and speed increases. |
| Pause / Resume | Pausing freezes basket, falling objects, and spawn timer; resuming continues smoothly without position jumps. |
| Game Over | When lives reach 0, game stops and final score overlay displays. |
| Restart | Resets all states, clears all objects, and launches a fresh run. |
| Window Blur | Releasing keys while tabbed away does not stick basket movement. |

## 13. Stage 1 completion criteria
Stage 1 is complete when the player can start, move smoothly, experience scheduled continuous spawning of balanced good/bad objects, encounter progressive difficulty scaling via accelerated spawn rates and falling speeds, receive accurate score/life changes for catches and misses, pause/resume reliably, reach Game Over, and restart cleanly.
