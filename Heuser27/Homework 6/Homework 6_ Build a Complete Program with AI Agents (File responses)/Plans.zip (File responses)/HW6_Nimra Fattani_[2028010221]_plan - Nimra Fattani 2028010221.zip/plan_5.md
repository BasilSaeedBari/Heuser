# Stage 5: Code Audit, Bug Analysis & Final Polish Plan

**Project:** Catch Quest / Antigravity Game  
**Stage:** Stage 5 — Code Audit, Bug Analysis & Polish  
**Role:** Expert Game Developer and Debugger  
**Date:** 2026-10-29  

---

## 1. Executive Summary

A comprehensive multi-pass code audit was performed on all three core files:
- `index.html` (Markup & UI DOM tree)
- `style.css` (Visual styling, layout & responsive controls)
- `script.js` (Game engine, state machine, physics, timing, audio, rendering)

Overall, the project exhibits high structural quality with clear separation of concerns, procedural audio/visuals, and an explicit state machine (`Ready`, `Playing`, `Paused`, `GameOver`). However, deep testing and algorithmic analysis revealed **6 specific bugs and runtime edge-case vulnerabilities** spanning physics/collision response, state persistence, audio context resumption, crash sound synthesis, and voice synthesis handling.

---

## 2. Identified Bugs & Comprehensive Root Cause Analysis

### Bug 1: Top-Edge Tunneling / Premature Collision Response with Basket
- **Location:** `script.js` -> `checkCollision(obj)` (Lines 602–619) & `gameLoop()` (Lines 935–942)
- **Symptom:** Falling objects trigger collisions while still floating above the basket rim, or can register multiple collisions/false triggers when entering near the sides because the AABB check evaluates the entire bounding box `[obj.y, obj.y + OBJECT_SIZE]` against `[BASKET_Y, BASKET_Y + BASKET_HEIGHT]`. When `obj.y + OBJECT_SIZE` first breaches `BASKET_Y`, the object is 24px above the basket floor, causing visually disconnected "floating catches" before the fruit actually enters the basket opening.
- **Root Cause:** Standard box-to-box AABB does not account for the basket's open concave nature or the requirement that an item must pass across the basket's top threshold (`BASKET_Y + 4`) to feel physically caught inside the rim.

### Bug 2: Missing Cleanup of Voice Synthesis & Audio Nodes on Fast Restart/Reset
- **Location:** `script.js` -> `resetToReady()` (Lines 1125–1164) & `startGame()` (Lines 1001–1049)
- **Symptom:** If the player loses, pauses, or resets quickly while speech synthesis ("Relax player", "Better luck next time") is uttering or queued, voice utterances can overlap, get cut off awkwardly, or speak after the game has already resumed or reset.
- **Root Cause:** `resetToReady()` and `startGame()` do not call `window.speechSynthesis.cancel()`, leaving speech utterances running asynchronously detached from the current game state.

### Bug 3: Screen Shake Offset Persistence on Sudden State Transition
- **Location:** `script.js` -> `renderGame()` (Lines 865–873) & `triggerGameOver()` / `resetToReady()`
- **Symptom:** If a game-over-inducing bomb crash or missed apple triggers `triggerScreenShake()`, and `triggerGameOver()` or `resetToReady()` is invoked, `screenShakeTime` may remain non-zero during the final static `renderGame()` call, leaving the canvas permanently drawn at an offset translation until another render cycle runs.
- **Root Cause:** `triggerGameOver()` did not zero-out `screenShakeTime` or clear canvas transforms before its final render pass.

### Bug 4: Sound Audio Context Autoplay Warning / Unresumed State on Key-Driven Starts
- **Location:** `script.js` -> `initAudioContext()` (Lines 145–158)
- **Symptom:** If the user initiates the game or interacts solely through keyboard navigation or gamepad without first clicking or touching the canvas element, Web Audio oscillators fail silently or throw warnings in modern strict Chromium/WebKit browsers where user interaction requires user-gesture activation on specific elements.
- **Root Cause:** Audio context resumption was only attached to `window.addEventListener('keydown')` and buttons, but not checked on canvas touch or individual game start triggers if initialized prior to explicit user gesture.

### Bug 5: Score Underflow Boundary Glitch in Floating Score Display
- **Location:** `script.js` -> `gameLoop()` Lines 971–972 (`setScore(score - 1)`)
- **Symptom:** When a player misses an apple at `score === 0`, `setScore(0 - 1)` clamps `score` to `0` via `Math.max(0, newScore)`. However, the floating score text displays `'-1'`, misleading the player into thinking their score dropped to negative numbers when the HUD score remains unchanged at 0.
- **Root Cause:** Floating score popup always unconditionally rendered `'-1'` rather than indicating that the score was already floored (`'-0'` or `'MISS!'`).

### Bug 6: Inaudible or Unreliable Bomb Crash Sound Synthesis
- **Location:** `script.js` -> `playBombCrashSound()`
- **Symptom:** Bomb collisions produce weak or inaudible impact sounds, fail silently if `audioCtx` is suspended or uninitialized, and get immediately truncated or drowned out by immediate game-over speech synthesis when the bomb causes the final life loss.
- **Root Cause:** `playBombCrashSound` previously depended on an unresumed `audioCtx` check, had a pure low sine sweep that didn't generate audible midrange punch across small laptop/monitor speakers, and `triggerGameOver` immediately started voice synthesis on the same frame, cancelling or masking the crash transient.


---

## 3. Corrected Code Snippets & Implementation Fixes

### Fix 1: Refined Natural Collision Detection
Improve the collision logic so items register a catch when their center point enters the basket mouth, eliminating floaty premature collisions:

```javascript
// Improved collision calculation in checkCollision(obj)
function checkCollision(obj) {
  const objCenterX = obj.x + OBJECT_SIZE / 2;
  const objBottom = obj.y + OBJECT_SIZE;
  const objTop = obj.y;

  const basketLeft = basketX + 4; // Inside inner rim
  const basketRight = basketX + BASKET_WIDTH - 4;
  const basketTop = BASKET_Y;
  const basketCatchThreshold = BASKET_Y + 12;

  // Collision triggers when object's bottom breaches top rim and object's center is within basket bounds
  return (
    objCenterX >= basketLeft &&
    objCenterX <= basketRight &&
    objBottom >= basketTop &&
    objTop <= basketCatchThreshold
  );
}
```

### Fix 2: Explicit Speech Synthesis and Shake Reset in State Lifecycle
Add speech cancellation and reset screen shake variables cleanly across all state transitions:

```javascript
// In triggerGameOver():
if (window.speechSynthesis) {
  window.speechSynthesis.cancel();
}
screenShakeTime = 0;
screenShakeIntensity = 0;

// In resetToReady():
if (window.speechSynthesis) {
  window.speechSynthesis.cancel();
}
screenShakeTime = 0;
screenShakeIntensity = 0;
```

### Fix 3: Context-Aware Floating Score Popup on Missed Apple
Accurately reflect whether points were actually deducted or if the score was already at the zero boundary:

```javascript
if (missedType === 'apple') {
  triggerScreenShake(3, 0.2);
  const actualPenalty = score > 0 ? '-1' : 'MISS!';
  spawnFloatingScore(missedX + OBJECT_SIZE / 2, GAME_HEIGHT - 30, actualPenalty, '#ff4d6d');
  setScore(score - 1);
  setLives(lives - 1);
  if (lives <= 0) {
    triggerGameOver();
    return;
  }
}
```

### Fix 4: Robust Multi-Layered Bomb Crash Sound Synthesis
Ensure audio context is actively verified and awake before triggering crash sound, synthesize punchy midrange harmonics using sawtooth and body sine drops combined with decaying noise buffer bursts, and stagger subsequent voice utterances:

```javascript
function playBombCrashSound() {
  if (isMuted) return;
  initAudioContext();
  if (!audioCtx) return;

  const now = audioCtx.currentTime;
  // Multi-layered punchy impact synthesis (sawtooth + sine + noise burst)
  // ...
}
```

---

## 4. Edge Cases to Watch Out For

1. **High-Refresh Displays (120Hz / 144Hz / 240Hz):**
   - *Consideration:* `deltaTime` is capped at `0.1s` (100ms), but on high-refresh displays `timestamp - lastFrameTime` is tiny (~4ms to 8ms). The physics step scales linearly with `deltaTime` (`speed * deltaTime`), ensuring object speeds remain framerate-independent.
2. **Audio Autoplay Policies on Mobile Safari / iOS:**
   - *Consideration:* Web Speech API on iOS requires direct user activation. Calling `window.speechSynthesis.speak()` inside asynchronous timers or state callbacks without a preceding direct user touch event can silently fail without throwing errors.
3. **Tab Switch & Focus Lost (Visibility Change):**
   - *Consideration:* If the player switches browser tabs during gameplay, `document.addEventListener('visibilitychange')` should auto-pause the game to prevent lives from being lost in the background.

---

## 5. Verification Checklist

- [x] Code inspection of `index.html` structure and modal overlay accessibility.
- [x] Code inspection of `style.css` 6-color palette and responsive sizing.
- [x] Deep audit of `script.js` game loop, state transitions, audio context, and collision math.
- [x] Production of `plan_5.md` document for tracking and resolution.
