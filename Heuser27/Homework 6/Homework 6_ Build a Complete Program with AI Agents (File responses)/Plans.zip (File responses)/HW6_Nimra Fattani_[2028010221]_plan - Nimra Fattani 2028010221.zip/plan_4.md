Stage: Stage 4 — State & Storage
Architect model: Claude Opus 4.6
Builder model: Gemini 3.8 Flash
Result: Implemented state-gated game flow (Ready, Playing, Paused, GameOver), safe localStorage persistence for high scores with graceful private-mode fallbacks, and freeze-frame pause/resume handling. Solved the delta-time surge and spawn timer acceleration on resume by resetting `lastFrameTime` and carrying over the fractional spawn delay.

---

# Catch Quest: Stage 4 — State & Storage Specification

## 1. Executive Summary
Stage 4 ensures bulletproof game state management, offline-safe best score persistence using `localStorage`, seamless pause/resume mechanics that freeze gameplay without timer or position jumps, and clean reset cycles that eliminate loop stacking or event listener duplication.

---

## 2. Key Architecture & Features

### A. Game State Machine
The game operates under four explicit mutually-exclusive states:
- **`Ready`**: Initial welcome state showing instructions and how-to-play card. Spawning and physics loops are idle.
- **`Playing`**: Main gameplay loop active. Objects fall, collisions evaluate, scoring occurs, and continuous timed spawning fires.
- **`Paused`**: Complete physics and spawning freeze. `requestAnimationFrame` is cancelled, `setTimeout` for spawning is cleared while preserving elapsed time, and input controls are blocked by a modal overlay.
- **`GameOver`**: Triggers when lives reach `0`. Active loops are stopped, playfield entities cleared, and the session's final score and all-time record are displayed.

### B. Persistent Best-Score Storage
- **Storage Key**: `catch_quest_best_score_v1`
- **Safe Read & Validation**:
  - Validates retrieved data with `parseInt` and `Number.isFinite(parsed) && parsed >= 0`.
  - Wrapped in `try...catch` blocks to seamlessly fall back to an in-memory `0` value if `localStorage` access is blocked (e.g., sandboxed iframes or restrictive private browsing modes).
- **Instant Persistence**:
  - Checked and written immediately when the current score surpasses `bestScore`.
  - Displayed prominently in the top stats deck, on the pause overlay, and on the game over screen.

### C. Seamless Pause & Resume
- Freezes basket movement, falling item velocity, particle effects, and screen shake.
- Calculates remaining interval duration before the next item spawn (`spawnTimerRemainingMs = spawnTimerScheduledDuration - elapsed`), and resumes with this exact remainder to prevent item clustering or sudden drops.
- Resets `lastFrameTime = 0` upon resume, avoiding huge delta-time leaps that could cause objects to clip through the basket.
- Full-screen modal overlay with `backdrop-filter: blur(4px)` and `z-index: 20` prevents accidental canvas clicks.

### D. Leak & Loop Stacking Prevention
- DOM event listeners are registered only once at script evaluation time (no dynamic listener accumulation on restart/resume).
- `startGame()` and `resetToReady()` explicitly cancel any active `animationFrameId` and `spawnTimeoutId`.
- Entity arrays (`fallingObjects`, `particles`, `scorePopups`) are cleared to prevent memory leaks across game sessions.

---

## 3. Verification & Manual Testing Checklist (10 Criteria)

| # | Verification Criterion | Status | How Tested / Verified |
|---|---|---|---|
| **1** | **State Machine Integrity** | PASS | Verified `gameState` is strictly managed across `'Ready'`, `'Playing'`, `'Paused'`, and `'GameOver'`. Loop execution and controls are disabled when not `'Playing'`. |
| **2** | **No Loop Stacking** | PASS | Repeatedly clicked Start, Play Again, and Reset. Verified only one `requestAnimationFrame` and one spawn timer run at any time. |
| **3** | **No Duplicate Event Listeners** | PASS | Event listeners are declared once at the top level. Multiple restarts and pause/resume cycles do not duplicate click or key handlers. |
| **4** | **Best Score Persistence** | PASS | Scored points to establish a record, refreshed the browser, and verified the best score loaded correctly from `localStorage`. |
| **5** | **Safe Storage Fallback** | PASS | Wrapped `localStorage.getItem` and `setItem` in `try...catch`. Invalid keys or restricted storage defaults safely to `0` without breaking the game. |
| **6** | **Immediate Best Score Updates** | PASS | As soon as current score exceeds best score, `bestScore` updates in the UI and writes to `localStorage` without waiting for Game Over. |
| **7** | **Pause Freeze Precision** | PASS | Pressing `P` or the Pause button halts falling items, basket movement, particles, and timers mid-flight at exact coordinates. |
| **8** | **Resume Without Surge / Speedup** | PASS | Resuming from pause resets `lastFrameTime`, preventing delta-time spikes or sudden basket leaps. Spawning resumes with remaining timer offset. |
| **9** | **Pause Overlay Input Block** | PASS | The paused overlay covers the arena with pointer events captured, preventing accidental clicks or key inputs while paused. |
| **10** | **Clean Restart & Score Reset** | PASS | Restarting resets current score to `0`, lives to `3`, and speed to initial base, while strictly preserving the saved best score. |
