Problems: Overlapping sounds create harsh volume distortion, basic synthesizer waves sound screeching, and mute state occasionally desyncs.
Fixes: Use master volume gain control with soft sine waves, apply volume fade-outs on each note, and route every audio function through a global mute check.

Artitect model:Gemini pro

builder model:gemini medium
Stage 4: Sound & Audio Feedback Plan
1. Objective
Enhance the Virtual Pet application by adding dynamic audio feedback using the browser's built-in Web Audio API. Tones and chimes will be synthesized entirely via JavaScript without external audio files, libraries, or network assets.
Preserve all Stage 1 game logic, Stage 2 visual polish, and Stage 3 sensory feedback. Maintain the core five-color palette (Prussian Blue: #102542, Pink Orchid: #e0acd5, Celadon: #96e6b3, Sky Surge: #06bee1, Dark Raspberry: #7e1946).
2. Synthesized Sound System
Implement an internal Web Audio API sound engine that generates soft, pleasant tones using oscillators and gain envelopes.
 * Zero external MP3, WAV, or OGG file dependencies.
 * Handle browser audio context restrictions (initialize audio on first user gesture).
 * Prevent audio distortion, harsh frequencies, or overlapping sound glitches.
3. Action Audio Feedback
Provide unique audio chimes for primary player interactions:
 * Feed: Soft, upward double-tone chime.
 * Play: Cheerful, ascending three-note sequence.
 * Sleep: Calming, descending low-frequency tone.
 * Restart: Short reset sweeps.
 * Cookie & Umbrella: Gentle pop/click tones.
4. Game State & Warning Alerts
 * Stat Warning: Subtle low-tone alert when any stat falls into the danger zone (under 20%).
 * Game Over: Distinct, gentle low sequence signifying the end of the run.
5. Mute Controls
 * Clearly visible Sound On / Sound Off toggle button on the UI.
 * Muting immediately suppresses all synthesized sound nodes.
6. Acceptance Tests
 * All sound effects are generated 100% in code without audio files.
 * Clicking Feed, Play, Sleep, and Restart triggers distinct audio tones.
 * Stat warnings and Game Over trigger appropriate sound alerts.
 * Mute button correctly toggles all sound output.
 * The game remains fully operational if Web Audio is unsupported or blocked.
