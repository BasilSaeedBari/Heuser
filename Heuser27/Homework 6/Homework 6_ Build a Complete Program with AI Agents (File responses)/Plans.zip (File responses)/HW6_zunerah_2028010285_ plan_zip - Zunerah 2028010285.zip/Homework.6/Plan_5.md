


Stage 5: Stages of Life & Evolution
Problems: Sudden stat decay jumps instantly kill low-stat pets, evolving looks jarring without visual feedback, and resetting forgot to revert age back to Baby.
Fixes: Grant minor stat boosts during evolution, add smooth CSS scale transitions with sparkle effects, and explicitly reset age and timers inside the restart function.
artitect model:gemini pro 
builder model:gemini medium


Stage 5: Stages of Life & Evolution Plan
1. Objective
Introduce growth mechanics, dynamic stat decay rates, and visual evolution stages as the pet survives over time.
Preserve all core mechanics, visuals, audio engine, and the five-color palette established in earlier stages.
2. Life Stages & Evolution
Implement 3 distinct evolutionary stages based on elapsed survival time:
 * Baby (0 - 60 seconds): Small sprite size, fast hunger decay.
 * Teen (61 - 180 seconds): Medium sprite size, higher energy demand.
 * Adult (181+ seconds): Full sprite size, balanced stat decay rates.
3. Visual Evolution
 * Dynamic CSS scaling and sprite transformations matching each life stage.
 * Gentle visual evolution transition effect (sparkle burst/bounce) upon evolving.
 * Stage indicator text display in the header or status bar (e.g., "Stage: Baby").
4. Dynamic Stat Decay
 * Adjust decay rates dynamically per stage to scale difficulty smoothly.
 * Game Over resets the pet's age and stage back to Baby.
5. Acceptance Tests
 * Pet starts as a Baby and evolves to Teen and Adult based on survival time.
 * Stat decay rates dynamically adjust according to the active life stage.
 * Visual sprite changes size and appearance upon evolving.
 * Restart resets the pet's age and stage back to Baby cleanly.
 * All Stage 1–4 features (buttons, rain, audio, messages) remain fully functional.