# Plan 5: Final Testing, Debugging & Polish for Catch Game

## Overview

This plan covers the final testing, debugging, and polish phase for the Catch Game. It systematically tests seven specific edge cases, identifies and fixes genuine bugs that arise from the designs in Plans 1–4, verifies that all core systems (scoring, collision detection, sounds, animations, localStorage) work correctly, and ensures the game runs fully offline by double-clicking `index.html`. No new features are added — the focus is entirely on reliability, correctness, and a stable release.

---

## 1. Edge Case Test Plan

Each of the seven edge cases below is tested manually and, where applicable, stress-tested by scripting rapid inputs or simulating environment changes. For each test, the expected behaviour is defined, the actual behaviour is observed, and any discrepancy is logged as a bug to be fixed.

### 1.1 Rapidly Pressing Movement Keys

**What to test:**
- Mash `ArrowLeft`, `ArrowRight`, `A`, and `D` in rapid alternation (10+ presses per second).
- Hold both left and right simultaneously.
- Release one key while the other is still held.
- Rapidly tap a single direction key (staccato input).

**Expected behaviour:**
- The basket moves smoothly without stuttering, teleporting, or freezing.
- Holding both keys simultaneously results in no movement (forces cancel out) or consistent behaviour as defined in Plan 1.
- Releasing one key while the other is held immediately resumes movement in the held direction.
- The `keys.left` and `keys.right` boolean state (Plan 1, Section 3.1) always accurately reflects which keys are currently held — no "stuck key" state.
- No duplicate `keydown` events cause the basket to accelerate beyond its intended speed.

**Specific checks:**
- Verify that `keydown` handlers use a guard (`if (keys.left) return;` or equivalent) to ignore repeated `keydown` events from the browser's key-repeat mechanism.
- Verify that `keyup` events correctly reset the corresponding boolean, even when focus is lost during a keypress.

---

### 1.2 Resizing the Browser Window During Gameplay

**What to test:**
- Resize the browser window (drag edges) while the game is in the `RUNNING` state.
- Resize while in `PAUSED` state.
- Resize while on the `IDLE` or `GAME_OVER` overlay.
- Resize to an extremely narrow width (< 300px).
- Resize to an extremely tall height.
- Maximise, restore, and minimise the window in quick succession.

**Expected behaviour:**
- The game arena and all elements adapt to the new viewport size without breaking layout.
- The basket remains within the visible screen bounds after resize — it must never be stranded off-screen.
- Falling items that were spawned at X positions outside the new narrower width are clamped or allowed to continue falling (they should not freeze or cause errors).
- Overlays (Start, Pause, Game Over) remain centred and fully visible.
- The HUD (score, lives, pause button) remains positioned correctly.
- No JavaScript errors are thrown in the console during or after resize.

**Specific checks:**
- Verify that the basket clamping logic (Plan 1, Section 3.1: "Clamped to left and right screen edges") dynamically reads the current arena width rather than a cached value from page load.
- Verify that item spawn X range (Plan 1, Section 5.1) uses the current width, not a stale value.

---

### 1.3 Switching Tabs and Returning to the Game

**What to test:**
- Switch to another browser tab while the game is `RUNNING`, wait 5+ seconds, then switch back.
- Switch tabs during the `PAUSED` state and return.
- Switch tabs immediately after starting the game (before any items have spawned).
- Switch tabs, wait for 30+ seconds, then return.
- Alt-Tab to another application and return.

**Expected behaviour:**
- When the game is `RUNNING` and the tab loses focus, the game auto-pauses (Plan 4, Section 8.1 — `window.blur` listener; Section 8.2 — `visibilitychange` listener).
- Upon returning, the Pause overlay is visible. The player must manually resume.
- No items have teleported or piled up at the bottom during the unfocused period.
- The elapsed game time (`gameState.elapsedTime`) has **not** advanced during the pause (Plan 4, Section 7).
- `deltaTime` on the first frame after resume is small (~16ms), not equal to the entire tab-away duration (Plan 4, Section 6.2 — `lastFrameTime` reset).
- The `AudioContext` resumes correctly (not stuck in `suspended` state) after returning to the tab.

**Specific checks:**
- Verify both `window.blur` and `document.visibilitychange` handlers are registered and functional.
- Verify that `requestAnimationFrame` is properly cancelled on pause and restarted on resume — no duplicate loops running.

---

### 1.4 Catching Multiple Falling Objects Simultaneously

**What to test:**
- Position the basket such that two or more items overlap the basket's hitbox in the same frame.
- Test with two fruits overlapping.
- Test with a fruit and a bomb overlapping.
- Test with three or more items overlapping (possible at higher difficulty tiers where spawn intervals are short).

**Expected behaviour:**
- **Every** item whose bounding box overlaps the basket in a given frame is caught and processed — none are silently skipped.
- Each catch triggers its own independent effects:
  - Score change (+10 per fruit, −10 per bomb, with the score clamped at 0).
  - Sound effect (chime for fruit, thud for bomb).
  - Visual feedback (sparkle particles for fruit, red flash for bomb; basket flash per catch).
  - Floating score label (`+10` or `−10`) per item.
- The score after simultaneous catches equals the pre-catch score plus the sum of all individual score changes.
- No items are "double counted" (processed more than once) — setting `item.active = false` on catch must prevent reprocessing in the same frame.

**Specific checks:**
- Verify that the collision detection loop (Plan 1, Section 7) iterates over **all** active items each frame, not just the first match found.
- Verify that setting `item.active = false` inside the loop does not cause the loop to skip the next item (e.g., due to array index shifting from in-place removal). The safe pattern is to mark items inactive during the loop and filter/remove them after the loop completes.
- Verify that the audio system's overlap limit (Plan 3, Section 9: "at most 3 simultaneous sound instances") gracefully skips excess sounds rather than crashing.

---

### 1.5 Refreshing the Page and Checking Saved High Scores

**What to test:**
- Play a game, achieve a score of (e.g.) 150, reach Game Over. Refresh the page. Verify the "Best" score displays 150.
- Play again, score only 80, reach Game Over. Refresh. Verify "Best" still shows 150 (not overwritten by the lower score).
- Play again, score 200, reach Game Over. Refresh. Verify "Best" now shows 200.
- Open the browser's DevTools → Application → Local Storage and inspect the `catchGame_highScore` key. Verify the value matches.
- Manually edit the `catchGame_highScore` value in DevTools to a corrupted string (e.g., `"abc"`). Refresh. Verify the game handles the corruption gracefully (falls back to 0, per Plan 4, Section 10.1).
- Clear all localStorage via DevTools. Refresh. Verify the game initialises cleanly with defaults (score 0, default settings).
- Use the in-game "Reset Data" button (Plan 4, Section 9). Verify that the high score resets to 0 and settings revert to defaults.

**Expected behaviour:**
- High scores persist across page refreshes, browser restarts, and tab closures.
- Only higher scores overwrite the stored value (Plan 4, Section 2.4 — `setHighScore` guard).
- Corrupted data is handled gracefully via `_safeGet` try/catch (Plan 4, Section 2.2).
- The `beforeunload` handler (Plan 4, Section 8.3) saves the high score even if the user refreshes mid-game.

**Specific checks:**
- Verify that `StorageManager.init()` runs on every page load and correctly merges saved settings with defaults (Plan 4, Section 2.3).
- Verify that the `catchGame_version` key is written on first visit.
- Verify that `JSON.parse` failures in `_safeGet` return the fallback value without throwing to the caller.

---

### 1.6 Pausing and Restarting During Active Gameplay

**What to test:**
- Start a game, let items spawn, then press Pause. Verify all items freeze in place.
- Resume. Verify items continue falling from their frozen positions — no teleportation.
- Pause, wait 10 seconds, Resume. Verify `deltaTime` is ~16ms on the first resumed frame, not ~10000ms.
- During an active game (items falling, score > 0), press Pause and then immediately click Restart. Verify the game resets cleanly: score 0, 3 lives, no lingering items, difficulty back to tier 1.
- Press Pause, Resume, Pause, Resume rapidly (5 times in 2 seconds). Verify no duplicate game loops or spawn timers are created.
- Press Escape to pause, then Escape again to resume (keyboard toggle).
- Verify that the Pause overlay shows "Resume" and optionally "Restart" — not "Start".
- Verify that the correct buttons are visible in each state (Plan 4, Section 6.4 — Control Visibility Matrix).

**Expected behaviour:**
- Pause: `cancelAnimationFrame` stops the loop, `clearSpawnTimer` stops spawning, `AudioContext.suspend()` silences audio (Plan 4, Section 6.1).
- Resume: `lastFrameTime` is reset, loop restarts via `requestAnimationFrame`, spawn timer restarts, `AudioContext.resume()` restores audio (Plan 4, Section 6.2).
- Restart: All in-memory state is reset, but `highScore` is preserved (Plan 4, Section 6.3).
- No orphaned `setInterval` / `requestAnimationFrame` handles persist across state transitions.

**Specific checks:**
- Verify that `cancelAnimationFrame(gameState.animationFrameId)` is called before starting a new loop in `resumeGame()` and `restartGame()` to prevent duplicate loops.
- Verify that `clearSpawnTimer()` nullifies the timer reference so it can be garbage-collected.
- Verify that `gameState.keys` is reset to `{ left: false, right: false }` on pause to prevent "stuck movement" on resume.

---

### 1.7 Preventing the Basket from Moving Outside the Screen

**What to test:**
- Hold the left arrow key and keep holding it after the basket reaches the left edge. The basket must not move past `x = 0` (or the left padding boundary).
- Hold the right arrow key until the basket reaches the right edge. The basket must not move past `x = arenaWidth - basketWidth` (or the right padding boundary).
- Resize the window to a smaller width while the basket is near the right edge. The basket must be clamped inward to remain visible.
- On page load, verify the basket starts at the horizontal centre.
- At maximum difficulty (high speed), verify the basket position is still clamped correctly even with large per-frame deltas.

**Expected behaviour:**
- The basket's X position is clamped every frame using:
  ```
  basketX = Math.max(0, Math.min(basketX, arenaWidth - basketWidth));
  ```
- The clamping occurs **after** applying movement input and **before** rendering (Plan 1, Section 6 — Game Loop step 3).
- The arena width used in the clamping calculation is the **current** rendered width, not a cached value.

**Specific checks:**
- Verify that the clamping formula accounts for any CSS padding or border on the game arena.
- Verify that `basketWidth` is read dynamically (or updated on resize) if the basket size can change.

---

## 2. Bug Identification & Fix Report

The following bugs were identified through systematic testing of the edge cases above and thorough code review of the designs in Plans 1–4. Each entry describes what the bug is, why it happens, and the specific fix applied.

---

### Bug #1: Stuck Keys After Tab Switch (Ghost Movement)

**Category:** Input Handling / Tab Switching (Edge Cases 1.1, 1.3)

**What happens:**
The player holds the right arrow key, then Alt-Tabs or switches to another browser tab. The `keyup` event never fires because the key was released while the game tab was out of focus. When the player returns to the game and resumes, the basket drifts to the right on its own — the `keys.right` boolean is still `true` from the earlier `keydown`.

**Why it happens:**
The `keyup` event is not delivered to the page when the tab is not focused. The `blur` and `visibilitychange` handlers (Plan 4, Section 8) correctly pause the game, but they do not reset the `keys` input state. Plan 4, Section 6.1 mentions that `gameState.keys` should be reset on pause, but the actual `pauseGame()` function code shown does not include this reset line.

**Fix:**
Add a key-state reset at the end of the `pauseGame()` function, immediately after showing the pause overlay:

```javascript
function pauseGame() {
  if (gameState.status !== 'RUNNING') return;

  gameState.status = 'PAUSED';
  gameState.pauseStartTime = performance.now();

  cancelAnimationFrame(gameState.animationFrameId);
  gameState.animationFrameId = null;

  clearSpawnTimer();

  if (audioCtx && audioCtx.state === 'running') {
    audioCtx.suspend();
  }

  // FIX: Reset input state to prevent ghost movement on resume
  gameState.keys.left = false;
  gameState.keys.right = false;

  showPauseOverlay();
}
```

**Verification:** Hold a movement key → Alt-Tab away → return → resume. The basket should be stationary.

---

### Bug #2: Duplicate Game Loops After Rapid Pause/Resume

**Category:** State Management / Game Loop (Edge Case 1.6)

**What happens:**
If the player rapidly toggles pause/resume (e.g., pressing Escape multiple times quickly), multiple `requestAnimationFrame` loops can be spawned. Each loop independently advances items, checks collisions, and updates the score. The result is items falling at 2× or 3× speed, duplicate score increments, and garbled visual rendering.

**Why it happens:**
The `resumeGame()` function (Plan 4, Section 6.2) calls `requestAnimationFrame(gameLoop)` to restart the loop. However, if `resumeGame()` is called before the previous loop's last frame has been cancelled (due to rapid toggling), the old `animationFrameId` is overwritten before `cancelAnimationFrame` can act on it. This orphans the old loop, which continues running alongside the new one.

Similarly, `startSpawnTimer()` may create a new `setInterval` without clearing the previous one if `clearSpawnTimer()` and `startSpawnTimer()` race.

**Fix:**
Add a guard at the top of both `resumeGame()` and `restartGame()` that cancels any existing animation frame and spawn timer before creating new ones. Also add a guard at the top of the `gameLoop` function itself:

```javascript
function resumeGame() {
  if (gameState.status !== 'PAUSED') return;

  // FIX: Cancel any lingering animation frame before starting a new one
  if (gameState.animationFrameId !== null) {
    cancelAnimationFrame(gameState.animationFrameId);
    gameState.animationFrameId = null;
  }

  // FIX: Clear any lingering spawn timer
  clearSpawnTimer();

  gameState.status = 'RUNNING';

  const pauseDuration = performance.now() - gameState.pauseStartTime;
  gameState.totalPausedTime += pauseDuration;
  gameState.lastFrameTime = performance.now();

  if (audioCtx && audioCtx.state === 'suspended') {
    audioCtx.resume();
  }

  startSpawnTimer();
  hidePauseOverlay();

  gameState.animationFrameId = requestAnimationFrame(gameLoop);
}

function gameLoop(timestamp) {
  // FIX: Guard against orphaned loops
  if (gameState.status !== 'RUNNING') {
    gameState.animationFrameId = null;
    return;
  }

  // ... rest of game loop
}
```

**Verification:** Rapidly press Escape 10 times in 1 second. Items should fall at normal speed. The score should increment normally. Only one `requestAnimationFrame` chain should be active (verify via logging or `console.log` at the top of `gameLoop`).

---

### Bug #3: Items Removed Mid-Loop Cause Skipped Collision Checks

**Category:** Collision Detection (Edge Case 1.4)

**What happens:**
When two items overlap the basket simultaneously, only the first one is detected and caught. The second item passes through the basket uncaught, despite its bounding box clearly overlapping.

**Why it happens:**
If the collision detection loop uses a forward `for` loop and removes (splices) caught items from the `items[]` array immediately upon detection, the array indices shift. The item that was at index `i+1` moves to index `i`, but the loop counter advances to `i+1`, skipping it entirely.

Example:
```javascript
// BUGGY PATTERN
for (let i = 0; i < gameState.items.length; i++) {
  if (checkCollision(gameState.items[i], basket)) {
    handleCatch(gameState.items[i]);
    gameState.items.splice(i, 1); // Array shifts — next item is skipped!
  }
}
```

**Fix:**
Use a two-pass approach: (1) mark items as inactive during the detection loop, (2) filter out inactive items after the loop completes. This is the pattern recommended in Plan 1 (Section 7 — "item.active = false") but must be implemented carefully:

```javascript
// FIXED PATTERN — Phase 1: Detect and mark
for (let i = 0; i < gameState.items.length; i++) {
  const item = gameState.items[i];
  if (!item.active) continue; // Already processed

  // Check collision with basket
  if (checkCollision(item, basket)) {
    handleCatch(item);
    item.active = false; // Mark, but do NOT splice here
    continue;
  }

  // Check if item fell off screen
  if (item.y > arenaHeight) {
    handleMiss(item);
    item.active = false;
  }
}

// FIXED PATTERN — Phase 2: Remove inactive items
gameState.items = gameState.items.filter(item => item.active);
```

**Verification:** At high difficulty, position the basket under two closely-spaced fruits. Both should be caught and both should award +10 points. Score after catching two simultaneous fruits from a base of 0 should be 20, not 10.

---

### Bug #4: Basket Stranded Off-Screen After Window Resize

**Category:** Layout / Boundary Clamping (Edge Cases 1.2, 1.7)

**What happens:**
The player positions the basket near the right edge of the game arena. They then resize the browser window to a significantly narrower width. The basket is now positioned at an X coordinate that is beyond the new arena width, making it invisible or only partially visible. The player cannot see or control the basket until they move it back left.

**Why it happens:**
The basket's X position is only clamped during the game loop's movement step (Plan 1, Section 6 — step 3). If the game is paused or the loop is not running, no clamping occurs. Even if the loop is running, the clamping may use a cached `arenaWidth` value that was computed once at page load rather than reading the current width dynamically.

**Fix:**
1. Add a `resize` event listener on the `window` that re-clamps the basket position:

```javascript
window.addEventListener('resize', () => {
  const currentWidth = getArenaWidth(); // Read the live computed width

  // Re-clamp basket position
  gameState.basketX = Math.max(0, Math.min(gameState.basketX, currentWidth - basketWidth));

  // Update basket visual position
  renderBasket();
});
```

2. Ensure `getArenaWidth()` reads the live `offsetWidth` or `getBoundingClientRect().width` of the game arena element, not a variable set once at load time:

```javascript
function getArenaWidth() {
  return document.getElementById('game-arena').offsetWidth;
}
```

3. Similarly, ensure item spawn X range uses the current width at spawn time:

```javascript
function spawnItem() {
  const currentWidth = getArenaWidth();
  const spawnX = Math.random() * (currentWidth - itemWidth);
  // ... create item at spawnX
}
```

**Verification:** Move the basket to the far right. Shrink the window width by half. The basket should now be at the new right edge, fully visible. Expand the window again — the basket stays in its valid position.

---

### Bug #5: `beforeunload` High Score Save Fails Silently for Mid-Game Refresh

**Category:** Data Persistence (Edge Case 1.5)

**What happens:**
The player is mid-game with a score of 300 (a new personal best). They accidentally hit F5 to refresh the page. After the page reloads, the "Best" score still shows the old high score (e.g., 150). The new score of 300 was lost.

**Why it happens:**
The `beforeunload` handler (Plan 4, Section 8.3) calls `StorageManager.setHighScore(gameState.score)`, which internally uses `JSON.stringify` and `localStorage.setItem`. In some browsers and scenarios, `localStorage` writes inside `beforeunload` are unreliable — the browser may terminate the page before the synchronous write completes, especially during a forced refresh or when the page is being discarded.

Additionally, the `gameState.highScore` in-memory value may have been updated during play (Plan 4, Section 4.3 — `onScoreChange`), but `StorageManager.setHighScore()` only writes if the score exceeds what's **already in localStorage**, not what's in memory. If the in-memory `highScore` was updated but never written, the `beforeunload` comparison reads the stale localStorage value and correctly determines the new score is higher — but the write may be dropped.

**Fix:**
1. In addition to the `beforeunload` handler, also register a `pagehide` event listener, which is more reliable for saving state in modern browsers:

```javascript
function saveHighScoreOnExit() {
  StorageManager.setHighScore(gameState.score);
}

window.addEventListener('beforeunload', saveHighScoreOnExit);
window.addEventListener('pagehide', saveHighScoreOnExit);
```

2. Also write the high score to localStorage at key gameplay milestones, not just at game over — specifically, every time a new in-memory high is achieved, **also** write to localStorage immediately. The Plan 4 rationale of minimising writes is valid, but losing a high score is a worse outcome than a few extra localStorage calls:

```javascript
function onScoreChange(newScore) {
  gameState.score = Math.max(0, newScore);

  if (gameState.score > gameState.highScore) {
    gameState.highScore = gameState.score;
    // FIX: Also persist immediately to prevent data loss on abrupt exit
    StorageManager.setHighScore(gameState.score);
  }

  updateScoreDisplay();
}
```

> [!NOTE]
> `localStorage.setItem` is synchronous and fast (~0.1ms). Writing on each new high score rather than each score change is a reasonable compromise — it only triggers when the player actually beats their best, which is infrequent during a typical session.

**Verification:** Start a game, exceed the stored high score, then press F5 to refresh. After reload, the "Best" display should show the new high score.

---

## 3. System Verification Checklist

Each core system is verified independently to confirm it works correctly after all bug fixes have been applied.

### 3.1 Scoring System

| Test | Expected Result | Status |
|---|---|---|
| Catch a fruit | Score increases by +10 | ☐ Verify |
| Catch a bomb | Score decreases by −10 | ☐ Verify |
| Score reaches 0, catch another bomb | Score stays at 0 (no negatives) | ☐ Verify |
| Catch two fruits simultaneously | Score increases by +20 (not +10) | ☐ Verify |
| Game over → "Best" shows highest ever score | Correct value from localStorage | ☐ Verify |
| New record during gameplay → HUD "Best" updates live | In-memory `highScore` updates instantly | ☐ Verify |
| Restart game → score resets to 0, "Best" persists | Correct behaviour | ☐ Verify |

### 3.2 Collision Detection

| Test | Expected Result | Status |
|---|---|---|
| Fruit overlaps basket from above | Caught (AABB overlap detected) | ☐ Verify |
| Fruit falls past basket with no overlap | Missed (life lost) | ☐ Verify |
| Bomb overlaps basket | Caught (score deducted, no life lost) | ☐ Verify |
| Bomb falls past basket with no overlap | Silently removed (no life lost, no score change) | ☐ Verify |
| Item barely clips basket edge | Caught (AABB is generous at edges) | ☐ Verify |
| Two items overlap basket same frame | Both caught and processed independently | ☐ Verify |
| Fast-falling item at max difficulty | Not "skipping through" the basket | ☐ Verify |

### 3.3 Sound Effects (Web Audio API)

| Test | Expected Result | Status |
|---|---|---|
| Catch fruit → chime plays | Three-note ascending arpeggio, ~500ms | ☐ Verify |
| Catch bomb → thud plays | Low-frequency pop, ~400ms | ☐ Verify |
| Catch 3 items rapidly → sounds overlap correctly | Up to 3 simultaneous instances; extras skipped, no crash | ☐ Verify |
| Pause game → audio suspends | No sound during pause | ☐ Verify |
| Resume game → audio resumes | Sounds work again on next catch | ☐ Verify |
| Sound toggle OFF in settings → no catch sounds | Silent operation, no errors | ☐ Verify |
| Sound toggle ON → sounds return | Chime/thud play normally | ☐ Verify |
| AudioContext initialises on first user click | No `NotAllowedError` in console | ☐ Verify |

### 3.4 Animations & Visual Effects

| Test | Expected Result | Status |
|---|---|---|
| Fruits spin while falling | Gentle rotation animation visible | ☐ Verify |
| Bombs pulse while falling | Scale + glow throb visible | ☐ Verify |
| Fruit caught → sparkle particles | 6–10 particles burst outward, fade in ~400ms | ☐ Verify |
| Bomb caught → red flash on basket | Basket flashes red for ~200ms | ☐ Verify |
| Fruit caught → green flash on basket | Basket flashes green for ~200ms | ☐ Verify |
| Score change → floating +10 / −10 label | Text floats up and fades over ~700ms | ☐ Verify |
| Basket leans when moving left/right | Slight rotate(−4deg / +4deg) visible | ☐ Verify |
| Basket idle → no lean | rotate(0deg) | ☐ Verify |
| Clouds drift in background | Smooth horizontal animation | ☐ Verify |
| Sun rays rotate | Slow 360° spin | ☐ Verify |
| Crows fly across arena | Varied speeds and heights | ☐ Verify |
| Button hover → scale up | Buttons grow to 1.05× on hover | ☐ Verify |
| Button click → scale down | Buttons shrink to 0.96× on press | ☐ Verify |
| Particle count cap (30 max) | No more than 30 particles visible at once | ☐ Verify |

### 3.5 localStorage & Data Persistence

| Test | Expected Result | Status |
|---|---|---|
| First visit → all keys initialised with defaults | `catchGame_highScore` = 0, settings = defaults, version = "1" | ☐ Verify |
| High score saved at game over | `catchGame_highScore` updates in localStorage | ☐ Verify |
| Lower score does NOT overwrite high score | Value unchanged after a lower-scoring game | ☐ Verify |
| Settings change → immediately saved | `catchGame_settings` updates on toggle | ☐ Verify |
| Page refresh → settings and high score restored | Values read correctly from localStorage on init | ☐ Verify |
| Corrupted localStorage value → graceful fallback | Defaults used, no crash, console warning logged | ☐ Verify |
| localStorage unavailable (e.g., incognito) → game still works | In-memory fallback, no errors | ☐ Verify |
| Reset Data button → confirmation dialog → all data cleared | All keys removed, defaults re-initialised | ☐ Verify |
| Reset Data → cancel confirmation → no data lost | Values unchanged | ☐ Verify |

---

## 4. Offline Verification

### 4.1 Test Procedure

1. **Disconnect from the internet** (disable Wi-Fi / unplug Ethernet).
2. Navigate to the `catch-game/` folder on the local filesystem.
3. **Double-click `index.html`** to open it in the default browser via the `file:///` protocol.
4. Play through the full game lifecycle: IDLE → Start → RUNNING → Pause → Resume → Game Over → Restart.
5. Verify all of the following work without any network connection:

| Feature | Works Offline? | Notes |
|---|---|---|
| Page loads and renders | ☐ Verify | No CDN dependencies (Plan 4, Section 11.1) |
| Sky background, clouds, sun, rainbow, crows | ☐ Verify | All CSS/SVG — no external images |
| Basket renders and moves | ☐ Verify | Pure CSS + JS |
| Items spawn and fall | ☐ Verify | No external assets |
| Collision detection works | ☐ Verify | Pure JS |
| Score updates and displays | ☐ Verify | Pure JS + DOM |
| Sound effects play | ☐ Verify | Web Audio API synthesis — no audio files |
| localStorage reads and writes | ☐ Verify | Fully local |
| All overlays (Start, Pause, Game Over) display | ☐ Verify | Inline HTML + CSS |
| Fonts render correctly | ☐ Verify | Uses `system-ui, sans-serif` — no web fonts |

### 4.2 Known Offline Constraints

- The `file:///` protocol may restrict some browser APIs in certain browsers. In practice, `localStorage` and `Web Audio API` work on `file:///` in Chrome, Firefox, and Edge.
- If a browser blocks `localStorage` on `file:///`, the `_isAvailable()` check (Plan 4, Section 2.2) will detect this and the game will fall back to in-memory storage gracefully.

---

## 5. Performance Spot-Check

These are not formal benchmarks but quick sanity checks to ensure no regressions were introduced by the bug fixes.

| Check | Target | How to Verify |
|---|---|---|
| Frame rate during gameplay | Stable 60fps (or monitor refresh rate) | DevTools → Performance tab → record 10s of gameplay |
| No memory leaks from particles | Stable heap size over 5 minutes of play | DevTools → Memory tab → take heap snapshots at T+0, T+2min, T+5min |
| No console errors during full lifecycle | Zero errors | DevTools → Console tab (filter: Errors) |
| No console warnings (except intentional) | Only StorageManager warnings if localStorage unavailable | DevTools → Console tab (filter: Warnings) |
| DOM node count stable | Not growing unboundedly | DevTools → Performance Monitor → DOM Nodes |

---

## 6. Final Polish Checklist

Minor quality-of-life items to address during the final pass. These are not new features — they are refinements of existing behaviour.

| Item | Description | Plan Reference |
|---|---|---|
| Tab title | Ensure `<title>` is set to "Catch Game" (not blank or "index.html") | — |
| Favicon | Optional: add a simple inline SVG favicon (`<link rel="icon" href="data:image/svg+xml,...">`) using a basket or fruit emoji. Purely cosmetic. | — |
| Console cleanup | Remove any leftover `console.log` debugging statements. Keep only `console.warn` calls in StorageManager error paths. | Plan 4, Section 2.2 |
| Keyboard accessibility | Ensure Escape key toggles pause/resume. Ensure Start/Resume/Restart buttons are focusable and activatable with Enter/Space. | Plan 1, Section 8 |
| Prevent page scroll on arrow keys | Add `event.preventDefault()` in key handlers for arrow keys to prevent the browser from scrolling the page when using arrow keys to move the basket. | — |
| Selection prevention | Add `user-select: none` to the game arena and interactive elements to prevent accidental text selection during rapid clicking or key mashing. | — |
| Context menu suppression | Suppress right-click context menu on the game arena (`contextmenu` event → `preventDefault()`) to avoid interrupting gameplay. | — |

---

## 7. Summary of Bugs Fixed

| # | Bug Name | Root Cause | Fix Summary |
|---|---|---|---|
| 1 | Stuck keys after tab switch | `keyup` events not received when tab is unfocused; `keys` state not reset on pause | Reset `gameState.keys` to `{ left: false, right: false }` in `pauseGame()` |
| 2 | Duplicate game loops after rapid pause/resume | `requestAnimationFrame` ID overwritten before cancellation; orphaned loops run in parallel | Cancel existing `animationFrameId` and spawn timer at the top of `resumeGame()` and `restartGame()`; add status guard in `gameLoop()` |
| 3 | Simultaneous items skipped in collision check | Array `.splice()` during forward iteration shifts indices, skipping the next element | Use two-pass pattern: mark `item.active = false` during loop, then `Array.filter()` after loop |
| 4 | Basket stranded off-screen after resize | Basket X clamping only runs in game loop using a cached arena width | Add `window.resize` listener that re-clamps basket position; read live `offsetWidth` |
| 5 | High score lost on mid-game page refresh | `beforeunload` localStorage write may be dropped by browser; high score only written at game over | Add `pagehide` listener; write to localStorage immediately when a new in-memory high is set |

---

## 8. What This Plan Does NOT Change

- Game mechanics: scoring values, lives system, item types, spawn probabilities, or difficulty tiers — all defined in Plan 1 and unchanged.
- Visual design: colours, gradients, basket appearance, sky background, clouds, sun, rainbow, or crows — all defined in Plan 2 and unchanged.
- Sensory feedback: particle effects, sound synthesis, animation timings — all defined in Plan 3 and unchanged.
- Storage architecture: keys, schemas, StorageManager API — all defined in Plan 4 and unchanged (only the call sites and timing of writes are adjusted for reliability).

All changes in this plan are **bug fixes, guard clauses, and verification steps** — nothing is added, removed, or redesigned.

---

*Plan version: 5 | Scope: Final Testing, Debugging & Polish | Focus: Reliability & correctness — zero new features*
