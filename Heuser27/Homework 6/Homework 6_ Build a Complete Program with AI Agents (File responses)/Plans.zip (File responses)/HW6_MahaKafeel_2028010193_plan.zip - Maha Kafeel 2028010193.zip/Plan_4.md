# Plan 4: State Management & Data Storage for Catch Game

## Overview

This plan covers the complete design and implementation of state management and persistent data storage for the Catch Game. It addresses saving high scores and settings via `localStorage`, displaying current and best scores, implementing pause/resume/restart controls without losing progress, preserving data across page refreshes and reopens, and providing a reset-data button to clear all saved data. The game is designed to work fully offline. No existing game mechanics or visual design are altered.

---

## 1. Storage Architecture

### 1.1 Storage Medium

All persistent data is stored exclusively in the browser's `localStorage` API. This provides:

- **Persistence** across page refreshes, browser restarts, and system reboots.
- **Synchronous** read/write — no async complexity needed.
- **Offline-first** by design — `localStorage` has zero network dependency.
- **~5MB capacity** per origin — far more than this game will ever need.

> [!NOTE]
> `localStorage` stores only strings. All data must be serialized to JSON before writing and parsed back when reading.

### 1.2 Storage Keys

All game data is stored under namespaced keys to avoid collisions with other applications on the same origin.

| Key | Type | Description |
|---|---|---|
| `catchGame_highScore` | `number` (stored as string) | The player's all-time best score |
| `catchGame_settings` | `JSON string` | Player-configurable settings object |
| `catchGame_version` | `string` | Schema version for future migration |

### 1.3 Data Schemas

#### High Score

```json
{
  "key": "catchGame_highScore",
  "value": "540"
}
```

A single numeric value stored as a string. Default: `"0"`.

#### Settings Object

```json
{
  "key": "catchGame_settings",
  "value": "{\"soundEnabled\":true,\"musicEnabled\":true,\"volume\":0.7}"
}
```

| Setting Field | Type | Default | Description |
|---|---|---|---|
| `soundEnabled` | `boolean` | `true` | Toggle sound effects on/off |
| `musicEnabled` | `boolean` | `true` | Toggle background music on/off |
| `volume` | `number` | `0.7` | Master volume level (0.0 – 1.0) |

> [!TIP]
> Keep the settings object flat (no nesting) for simplicity. If new settings are added in the future, they can be merged with defaults during the load phase so older saved data isn't broken.

#### Schema Version

```json
{
  "key": "catchGame_version",
  "value": "1"
}
```

A simple integer version string. Used to detect and handle storage schema changes in future updates.

---

## 2. Storage Manager Module

A dedicated `StorageManager` module encapsulates all `localStorage` interactions, providing a clean API and centralized error handling.

### 2.1 Module Interface

```javascript
const StorageManager = {
  KEYS: {
    HIGH_SCORE: 'catchGame_highScore',
    SETTINGS: 'catchGame_settings',
    VERSION: 'catchGame_version',
  },

  DEFAULTS: {
    highScore: 0,
    settings: {
      soundEnabled: true,
      musicEnabled: true,
      volume: 0.7,
    },
    version: '1',
  },

  // Initialize storage with defaults if empty
  init(),

  // High score operations
  getHighScore(),
  setHighScore(score),

  // Settings operations
  getSettings(),
  saveSetting(key, value),
  saveSettings(settingsObj),

  // Reset everything
  clearAll(),

  // Internal safety utilities
  _safeGet(key, fallback),
  _safeSet(key, value),
  _isAvailable(),
};
```

### 2.2 Safety & Error Handling

Every `localStorage` operation must be wrapped in `try/catch` blocks. Browsers can throw exceptions when:

- Storage is full (`QuotaExceededError`)
- The user is in private/incognito mode (some older browsers block `localStorage`)
- Storage has been disabled by browser settings or enterprise policies
- The stored data is corrupted or has been manually edited

#### Availability Check

```javascript
_isAvailable() {
  try {
    const testKey = '__catchGame_test__';
    localStorage.setItem(testKey, '1');
    localStorage.removeItem(testKey);
    return true;
  } catch (e) {
    return false;
  }
}
```

> [!WARNING]
> If `localStorage` is unavailable, the game must still function normally — it simply won't persist high scores or settings between sessions. All features degrade gracefully: in-memory defaults are used, and save operations become no-ops.

#### Safe Getter

```javascript
_safeGet(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    if (raw === null) return fallback;
    return JSON.parse(raw);
  } catch (e) {
    console.warn(`[StorageManager] Failed to read "${key}":`, e);
    return fallback;
  }
}
```

#### Safe Setter

```javascript
_safeSet(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
    return true;
  } catch (e) {
    console.warn(`[StorageManager] Failed to write "${key}":`, e);
    return false;
  }
}
```

### 2.3 Initialization Logic

Called once when the game script loads, before the first frame or user interaction:

```javascript
init() {
  if (!this._isAvailable()) {
    console.warn('[StorageManager] localStorage not available. Using in-memory defaults.');
    this._memoryFallback = true;
    this._memoryStore = {
      highScore: this.DEFAULTS.highScore,
      settings: { ...this.DEFAULTS.settings },
    };
    return;
  }

  // Set version if missing (first-ever visit)
  if (localStorage.getItem(this.KEYS.VERSION) === null) {
    this._safeSet(this.KEYS.VERSION, this.DEFAULTS.version);
  }

  // Set high score if missing
  if (localStorage.getItem(this.KEYS.HIGH_SCORE) === null) {
    this._safeSet(this.KEYS.HIGH_SCORE, this.DEFAULTS.highScore);
  }

  // Set settings if missing; if present, merge with defaults to handle new fields
  const savedSettings = this._safeGet(this.KEYS.SETTINGS, null);
  if (savedSettings === null) {
    this._safeSet(this.KEYS.SETTINGS, this.DEFAULTS.settings);
  } else {
    // Merge: defaults provide any new keys; saved values override existing keys
    const merged = { ...this.DEFAULTS.settings, ...savedSettings };
    this._safeSet(this.KEYS.SETTINGS, merged);
  }
}
```

### 2.4 High Score Methods

```javascript
getHighScore() {
  if (this._memoryFallback) return this._memoryStore.highScore;
  return this._safeGet(this.KEYS.HIGH_SCORE, this.DEFAULTS.highScore);
}

setHighScore(score) {
  // Only update if the new score is actually higher
  const current = this.getHighScore();
  if (score > current) {
    if (this._memoryFallback) {
      this._memoryStore.highScore = score;
    } else {
      this._safeSet(this.KEYS.HIGH_SCORE, score);
    }
    return true; // A new record was set
  }
  return false; // Not a new record
}
```

### 2.5 Settings Methods

```javascript
getSettings() {
  if (this._memoryFallback) return { ...this._memoryStore.settings };
  return this._safeGet(this.KEYS.SETTINGS, { ...this.DEFAULTS.settings });
}

saveSetting(key, value) {
  const settings = this.getSettings();
  settings[key] = value;
  this.saveSettings(settings);
}

saveSettings(settingsObj) {
  if (this._memoryFallback) {
    this._memoryStore.settings = { ...settingsObj };
  } else {
    this._safeSet(this.KEYS.SETTINGS, settingsObj);
  }
}
```

### 2.6 Clear All Method

```javascript
clearAll() {
  if (this._memoryFallback) {
    this._memoryStore.highScore = this.DEFAULTS.highScore;
    this._memoryStore.settings = { ...this.DEFAULTS.settings };
    return;
  }

  try {
    localStorage.removeItem(this.KEYS.HIGH_SCORE);
    localStorage.removeItem(this.KEYS.SETTINGS);
    localStorage.removeItem(this.KEYS.VERSION);
  } catch (e) {
    console.warn('[StorageManager] Failed to clear data:', e);
  }

  // Re-initialize with defaults
  this.init();
}
```

---

## 3. In-Memory Game State

The in-memory game state is the single source of truth during an active session. `localStorage` is only read at startup and written at specific checkpoints (game over, settings change, high score update).

### 3.1 State Object Structure

```javascript
const gameState = {
  // --- Core gameplay state (reset every game) ---
  status: 'IDLE',         // 'IDLE' | 'RUNNING' | 'PAUSED' | 'GAME_OVER'
  score: 0,               // Current score this game
  lives: 3,               // Remaining lives
  elapsedTime: 0,         // Milliseconds since game start (paused time excluded)
  items: [],              // Active falling items array
  basketX: 0,             // Basket horizontal position

  // --- Timing state ---
  lastFrameTime: 0,       // Timestamp of last rAF callback
  pauseStartTime: 0,      // Timestamp when pause began (for elapsed time correction)
  totalPausedTime: 0,     // Cumulative ms spent paused this game session
  spawnTimer: null,        // Reference to the active spawn interval/timer
  animationFrameId: null,  // Reference to the active rAF ID

  // --- Persistent references (loaded from storage at init) ---
  highScore: 0,           // Best score ever (loaded from localStorage)
  settings: {},           // Settings object (loaded from localStorage)

  // --- Input state ---
  keys: {
    left: false,
    right: false,
  },
};
```

### 3.2 State Flow Diagram

```mermaid
stateDiagram-v2
    [*] --> IDLE : Page loads / StorageManager.init()

    IDLE --> RUNNING : Start clicked
    note right of IDLE : Load highScore & settings\nfrom localStorage

    RUNNING --> PAUSED : Pause clicked / window.blur
    note right of RUNNING : Game loop active\nScore updating live

    PAUSED --> RUNNING : Resume clicked
    note right of PAUSED : Loop halted\nAll timers frozen\nProgress preserved

    RUNNING --> GAME_OVER : Lives === 0
    note right of GAME_OVER : Check & save highScore\nShow final score + best

    GAME_OVER --> RUNNING : Restart clicked
    note left of GAME_OVER : Reset in-memory state\nDo NOT reset highScore
```

---

## 4. Score Display System

### 4.1 HUD Elements

The HUD must display two score values at all times during gameplay:

| Element | Label | Position | Update Frequency |
|---|---|---|---|
| Current Score | `Score: 240` | Top-left of game area | Every frame (on score change) |
| Best Score | `Best: 540` | Below current score or top-right | On game start, on new record |

#### HTML Markup

```html
<div id="hud">
  <div id="hud-left">
    <div id="current-score">Score: 0</div>
    <div id="best-score">Best: 0</div>
  </div>
  <div id="hud-right">
    <div id="lives">❤️ ❤️ ❤️</div>
  </div>
</div>
```

### 4.2 Score Update Logic

```javascript
function updateScoreDisplay() {
  document.getElementById('current-score').textContent = `Score: ${gameState.score}`;
  document.getElementById('best-score').textContent = `Best: ${gameState.highScore}`;
}
```

### 4.3 High Score Check & Persistence

The high score is checked and potentially saved at **two** points:

1. **During gameplay** — each time the score increases, compare against `gameState.highScore` and update the in-memory best if exceeded. This ensures the HUD "Best" display is always current, even mid-game. Do **not** write to `localStorage` on every score change (unnecessary I/O).

2. **At game over** — call `StorageManager.setHighScore(gameState.score)` once. This writes to `localStorage` only if the current score beats the stored record.

```javascript
function onScoreChange(newScore) {
  gameState.score = Math.max(0, newScore); // Floor at 0

  // Live update of best score in memory (not localStorage)
  if (gameState.score > gameState.highScore) {
    gameState.highScore = gameState.score;
  }

  updateScoreDisplay();
}

function onGameOver() {
  gameState.status = 'GAME_OVER';
  cancelAnimationFrame(gameState.animationFrameId);
  clearSpawnTimer();

  // Persist high score to localStorage (only writes if new record)
  const isNewRecord = StorageManager.setHighScore(gameState.score);

  showGameOverOverlay(gameState.score, gameState.highScore, isNewRecord);
}
```

### 4.4 New Record Indicator

When a new high score is achieved, the game-over overlay should display a "🏆 New Record!" badge. This is a purely visual addition — no change to game mechanics.

---

## 5. Settings Persistence

### 5.1 When to Save Settings

Settings are saved to `localStorage` **immediately** when changed by the user, not on an interval or at game over. This ensures that if the user adjusts sound and then closes the tab, the preference is preserved.

```javascript
function onSettingChanged(key, value) {
  gameState.settings[key] = value;
  StorageManager.saveSetting(key, value);
  applySettings(); // Apply the change to the live game
}
```

### 5.2 When to Load Settings

Settings are loaded from `localStorage` once during initialization and cached in `gameState.settings`:

```javascript
function initializeGame() {
  StorageManager.init();
  gameState.highScore = StorageManager.getHighScore();
  gameState.settings = StorageManager.getSettings();
  applySettings();
  updateScoreDisplay();
}
```

### 5.3 Applying Settings at Runtime

```javascript
function applySettings() {
  const s = gameState.settings;

  // Audio
  if (typeof setMasterVolume === 'function') {
    setMasterVolume(s.volume);
  }

  // Sound effects toggle
  gameState.soundMuted = !s.soundEnabled;

  // Music toggle
  if (s.musicEnabled) {
    resumeBackgroundMusic();
  } else {
    pauseBackgroundMusic();
  }
}
```

### 5.4 Settings UI

A small settings icon (⚙️) accessible from the IDLE, PAUSED, and GAME_OVER states opens a settings panel or modal. The settings panel contains:

| Control | Type | Bound Setting |
|---|---|---|
| Sound Effects | Toggle switch | `soundEnabled` |
| Music | Toggle switch | `musicEnabled` |
| Volume | Range slider (0 – 100%) | `volume` |

> [!IMPORTANT]
> The settings panel must **not** be accessible during the RUNNING state to avoid unintended pauses or distraction. If the player needs to change settings mid-game, they must pause first.

---

## 6. Pause, Resume & Restart Controls

### 6.1 Pause

**Triggered by:** Pause button click, `Escape` key press, or `window.blur` event.

**Actions performed:**

```javascript
function pauseGame() {
  if (gameState.status !== 'RUNNING') return; // Guard: only pause if running

  gameState.status = 'PAUSED';
  gameState.pauseStartTime = performance.now();

  // 1. Stop the game loop
  cancelAnimationFrame(gameState.animationFrameId);
  gameState.animationFrameId = null;

  // 2. Stop the spawn timer
  clearSpawnTimer();

  // 3. Freeze audio context (if using Web Audio API)
  if (audioCtx && audioCtx.state === 'running') {
    audioCtx.suspend();
  }

  // 4. Show pause overlay
  showPauseOverlay();
}
```

**What is preserved during pause:**

| Data | Preserved? | Notes |
|---|---|---|
| `gameState.score` | ✅ Yes | Untouched |
| `gameState.lives` | ✅ Yes | Untouched |
| `gameState.items[]` | ✅ Yes | All items frozen at current Y positions |
| `gameState.basketX` | ✅ Yes | Basket stays in place |
| `gameState.elapsedTime` | ✅ Yes | Paused time is excluded via tracking |
| `gameState.keys` | ✅ Reset | Both keys set to `false` to prevent stuck input |
| Difficulty tier | ✅ Yes | Derived from `elapsedTime`, which doesn't advance |

### 6.2 Resume

**Triggered by:** Resume button click or `Escape` key press (toggling back from paused).

**Actions performed:**

```javascript
function resumeGame() {
  if (gameState.status !== 'PAUSED') return; // Guard: only resume if paused

  gameState.status = 'RUNNING';

  // 1. Account for paused duration
  const pauseDuration = performance.now() - gameState.pauseStartTime;
  gameState.totalPausedTime += pauseDuration;

  // 2. Reset the frame timestamp so deltaTime doesn't include pause time
  gameState.lastFrameTime = performance.now();

  // 3. Resume audio context
  if (audioCtx && audioCtx.state === 'suspended') {
    audioCtx.resume();
  }

  // 4. Restart spawn timer (continuing from current difficulty tier)
  startSpawnTimer();

  // 5. Hide pause overlay
  hidePauseOverlay();

  // 6. Restart game loop
  gameState.animationFrameId = requestAnimationFrame(gameLoop);
}
```

> [!IMPORTANT]
> The critical detail is resetting `lastFrameTime` to `performance.now()` before resuming the loop. Without this, the first frame after unpause would calculate a massive `deltaTime` equal to the entire pause duration, causing all items to teleport downward.

### 6.3 Restart

**Triggered by:** Restart button on the Game Over screen.

**Actions performed:**

```javascript
function restartGame() {
  // 1. Cancel any lingering timers or animation frames
  cancelAnimationFrame(gameState.animationFrameId);
  clearSpawnTimer();

  // 2. Reset all in-memory gameplay state
  gameState.score = 0;
  gameState.lives = 3;
  gameState.elapsedTime = 0;
  gameState.totalPausedTime = 0;
  gameState.pauseStartTime = 0;
  gameState.items = [];
  gameState.basketX = getCanvasCenterX();
  gameState.keys = { left: false, right: false };
  gameState.lastFrameTime = performance.now();

  // 3. DO NOT reset highScore — it persists across games
  // gameState.highScore remains unchanged

  // 4. DO NOT reset settings — they persist across games
  // gameState.settings remains unchanged

  // 5. Reset difficulty to initial tier
  // (Difficulty is derived from elapsedTime, which is now 0)

  // 6. Update HUD
  updateScoreDisplay();
  updateLivesDisplay();

  // 7. Transition to RUNNING
  gameState.status = 'RUNNING';
  hideAllOverlays();

  // 8. Start fresh spawn timer and game loop
  startSpawnTimer();
  gameState.animationFrameId = requestAnimationFrame(gameLoop);
}
```

### 6.4 Control Visibility Matrix

| Control / Button | IDLE | RUNNING | PAUSED | GAME_OVER |
|---|---|---|---|---|
| Start | ✅ Visible | ❌ Hidden | ❌ Hidden | ❌ Hidden |
| Pause | ❌ Hidden | ✅ Visible | ❌ Hidden | ❌ Hidden |
| Resume | ❌ Hidden | ❌ Hidden | ✅ Visible | ❌ Hidden |
| Restart | ❌ Hidden | ❌ Hidden | ❌ Hidden | ✅ Visible |
| Settings ⚙️ | ✅ Visible | ❌ Hidden | ✅ Visible | ✅ Visible |
| Reset Data 🗑️ | ✅ Visible | ❌ Hidden | ✅ Visible | ✅ Visible |

---

## 7. Elapsed Time Tracking (Pause-Aware)

Accurate elapsed time is essential because the difficulty system (Plan 1, Section 5.2) is driven by it. Paused time must be excluded.

### 7.1 Approach

Rather than using a wall-clock timer, the game accumulates elapsed time from `deltaTime` each frame:

```javascript
function gameLoop(timestamp) {
  if (gameState.status !== 'RUNNING') return;

  const deltaTime = timestamp - gameState.lastFrameTime;
  gameState.lastFrameTime = timestamp;

  // Only accumulate time while RUNNING (paused frames never reach here)
  gameState.elapsedTime += deltaTime;

  // ... rest of game loop (movement, collision, spawning, drawing)

  gameState.animationFrameId = requestAnimationFrame(gameLoop);
}
```

### 7.2 Why This Works

- `gameLoop` only runs when `status === 'RUNNING'`.
- When pausing, `cancelAnimationFrame` stops the loop entirely.
- When resuming, `lastFrameTime` is reset to `performance.now()`, so the first post-resume `deltaTime` is tiny (~16ms), not the full pause duration.
- `elapsedTime` therefore only counts active gameplay time.

---

## 8. Page Lifecycle Handling

### 8.1 Window Blur (Tab Switch / Alt-Tab)

```javascript
window.addEventListener('blur', () => {
  if (gameState.status === 'RUNNING') {
    pauseGame();
  }
});
```

This prevents the game from running unattended in a background tab, which would cause items to pile up and the game to become unresponsive on return.

### 8.2 Visibility Change (Tab Hidden)

```javascript
document.addEventListener('visibilitychange', () => {
  if (document.hidden && gameState.status === 'RUNNING') {
    pauseGame();
  }
});
```

A secondary check using the Page Visibility API, which is more reliable than `blur` in some scenarios (e.g., when the user switches to a different desktop workspace).

### 8.3 Before Unload (Page Close / Refresh)

```javascript
window.addEventListener('beforeunload', () => {
  // Ensure the latest high score is persisted
  StorageManager.setHighScore(gameState.score);
});
```

This catches the case where the user closes the tab mid-game without reaching game over. The current score is checked against the stored high score and saved if it's higher.

> [!NOTE]
> Settings are already saved immediately on change (Section 5.1), so no additional save is needed here for settings.

---

## 9. Reset Data Button

### 9.1 Purpose

Provides the player with a way to completely erase all saved data (high score and settings), restoring the game to a "first visit" state.

### 9.2 Placement

The reset data button is placed in the settings panel or as a small, unobtrusive link/button on the start screen and pause overlay. It should be visually distinct from gameplay controls to prevent accidental clicks (e.g., smaller, muted color, positioned away from primary actions).

### 9.3 Confirmation Flow

Because this action is destructive and irreversible, a confirmation step is required:

```mermaid
flowchart LR
    A["🗑️ Reset Data\nbutton clicked"] --> B{"Confirm?\n\"This will erase your\nhigh score and settings.\nAre you sure?\""}
    B -- Yes --> C["StorageManager.clearAll()"]
    C --> D["Update in-memory state\nto defaults"]
    D --> E["Refresh HUD display"]
    E --> F["Show brief confirmation\n\"Data cleared! ✓\""]
    B -- No --> G["Dismiss — no action taken"]
```

### 9.4 Implementation

```javascript
function onResetDataClicked() {
  const confirmed = confirm(
    'This will erase your high score and all saved settings.\n\nAre you sure?'
  );

  if (!confirmed) return;

  // 1. Clear all localStorage data and re-initialize with defaults
  StorageManager.clearAll();

  // 2. Update in-memory state
  gameState.highScore = StorageManager.getHighScore(); // Now returns 0
  gameState.settings = StorageManager.getSettings();   // Now returns defaults
  applySettings();

  // 3. Refresh displays
  updateScoreDisplay();

  // 4. Brief visual confirmation
  showToast('Data cleared! ✓', 2000);
}
```

### 9.5 What Gets Reset

| Data | Reset? | New Value |
|---|---|---|
| High Score | ✅ Yes | `0` |
| Settings (sound, music, volume) | ✅ Yes | Defaults (`true`, `true`, `0.7`) |
| Schema Version | ✅ Yes | Re-initialized to `"1"` |
| Current Game Score | ❌ No | Unaffected (only relevant if mid-game) |
| Current Lives | ❌ No | Unaffected |
| Current Game State (IDLE/RUNNING/etc.) | ❌ No | Unaffected |

> [!CAUTION]
> The reset button clears the high score permanently. The confirmation dialog is the only safeguard. There is no "undo" after confirming.

---

## 10. Data Integrity & Validation

### 10.1 Input Validation on Load

When reading from `localStorage`, all values must be validated before use. Users or browser extensions could have tampered with stored data.

```javascript
function validateHighScore(value) {
  const num = Number(value);
  if (!Number.isFinite(num) || num < 0) return 0;
  return Math.floor(num); // Ensure integer
}

function validateSettings(obj) {
  const defaults = StorageManager.DEFAULTS.settings;

  if (typeof obj !== 'object' || obj === null) return { ...defaults };

  return {
    soundEnabled: typeof obj.soundEnabled === 'boolean' ? obj.soundEnabled : defaults.soundEnabled,
    musicEnabled: typeof obj.musicEnabled === 'boolean' ? obj.musicEnabled : defaults.musicEnabled,
    volume: typeof obj.volume === 'number' && obj.volume >= 0 && obj.volume <= 1
      ? obj.volume
      : defaults.volume,
  };
}
```

### 10.2 Corruption Recovery

If parsing stored JSON fails (e.g., `JSON.parse` throws), the `_safeGet` method already falls back to defaults. The corrupted key is effectively ignored, and on the next write, valid data overwrites it.

### 10.3 Version Migration

The `catchGame_version` key enables future-proofing:

```javascript
function migrateIfNeeded() {
  const storedVersion = StorageManager._safeGet(
    StorageManager.KEYS.VERSION,
    StorageManager.DEFAULTS.version
  );

  if (storedVersion === '1') {
    // Current version — no migration needed
    return;
  }

  // Future: handle version '2', '3', etc.
  // Example: if (storedVersion === '1') { migrateV1toV2(); }
}
```

---

## 11. Offline Compatibility

### 11.1 Zero Network Dependency

The game has **no** network calls of any kind:

- No CDN-hosted libraries (all code is local)
- No analytics or tracking scripts
- No remote API calls for leaderboards
- No font or asset downloads at runtime (all assets are embedded or bundled)

### 11.2 localStorage Is Offline-Native

`localStorage` operates entirely within the browser's local storage engine. It does not require any network connection to read or write. Data persists until explicitly cleared by the user, the game's reset function, or the browser's "Clear Site Data" action.

### 11.3 Service Worker (Optional Future Enhancement)

For a fully installable PWA experience in the future, a service worker could be added to cache the HTML, CSS, and JS files. This is **not** part of the current plan but is noted here as a natural extension. The storage layer designed in this plan is already compatible with a PWA setup.

---

## 12. Complete Initialization & Lifecycle Sequence

```mermaid
sequenceDiagram
    participant Page as Page Load
    participant SM as StorageManager
    participant LS as localStorage
    participant GS as gameState
    participant HUD as HUD Display

    Page->>SM: init()
    SM->>LS: Check availability
    LS-->>SM: Available ✓
    SM->>LS: Read highScore
    LS-->>SM: "540" (or null → default 0)
    SM->>LS: Read settings
    LS-->>SM: JSON string (or null → defaults)
    SM->>SM: Validate & merge with defaults
    SM-->>Page: Ready

    Page->>GS: Set highScore = 540
    Page->>GS: Set settings = {sound: true, ...}
    Page->>HUD: Display "Score: 0" and "Best: 540"
    Page->>Page: Show IDLE screen

    Note over Page: Player clicks Start
    Page->>GS: status = 'RUNNING'
    Note over Page: ... gameplay ...

    Note over Page: Player catches fruit
    Page->>GS: score += 10
    Page->>HUD: Update "Score: 10"
    alt New best during play
        Page->>GS: highScore = 10
        Page->>HUD: Update "Best: 10"
    end

    Note over Page: Lives reach 0
    Page->>GS: status = 'GAME_OVER'
    Page->>SM: setHighScore(finalScore)
    SM->>LS: Write if new record
    Page->>HUD: Show Game Over overlay

    Note over Page: Player clicks Restart
    Page->>GS: Reset score, lives, items, time
    Page->>GS: highScore stays at 540
    Page->>HUD: "Score: 0", "Best: 540"
    Page->>GS: status = 'RUNNING'
```

---

## 13. Summary of Write Points to localStorage

To minimize I/O and avoid performance issues, `localStorage` writes happen only at specific, infrequent moments:

| Event | What Is Written | Key |
|---|---|---|
| Game over | High score (if new record) | `catchGame_highScore` |
| Setting changed by user | Updated settings object | `catchGame_settings` |
| Page unload (beforeunload) | High score (if new record) | `catchGame_highScore` |
| Reset data button confirmed | All keys removed, then defaults written | All keys |
| First-ever page load | Default values for all keys | All keys |

> [!TIP]
> Never write to `localStorage` on every frame or every score change. Batch writes to meaningful checkpoints as listed above.

---

## 14. What This Plan Does NOT Change

- Game loop mechanics (spawning, collision, movement) — Plan 1.
- Visual design, layout, colors, or CSS styles — Plan 2 (if applicable).
- Sensory feedback (particles, sounds, animations) — Plan 3.
- Scoring rules, lives system, or difficulty scaling — Plan 1.
- Item types, probabilities, or speeds — Plan 1.

All additions in this plan are purely data-management and control-flow enhancements layered on top of the existing architecture.

---

*Plan version: 4 | Scope: State Management & Data Storage | Storage: localStorage (offline-first, zero network dependency)*
