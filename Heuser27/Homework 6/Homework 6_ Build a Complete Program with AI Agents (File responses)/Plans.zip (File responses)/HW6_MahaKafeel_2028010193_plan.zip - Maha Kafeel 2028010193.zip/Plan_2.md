# 🧺 Catch Game — Visual Design Plan
**Theme: Colourful, Cheerful Cartoon Sky**
*Using CSS shapes, gradients, emojis & inline SVG only. Zero external assets.*

---

## 1. Design Token Overhaul

Replace the current `:root` variables with a vivid cartoon palette:

```css
:root {
  /* Sky Gradient */
  --sky-top:    #5BC8FF;   /* bright cerulean */
  --sky-mid:    #87DFFF;   /* lighter midpoint */
  --sky-bottom: #C8F0FF;   /* pale horizon haze */

  /* HUD */
  --hud-bg:     rgba(255, 240, 100, 0.92); /* sunny yellow strip */
  --hud-text:   #5B2D00;                   /* warm dark brown  */
  --hud-border: #FFAA00;

  /* Accent & Interaction */
  --accent-color: #FF6B35;   /* tangerine orange */
  --accent-hover: #E55A25;
  --danger-color: #FF3B30;
  --success-color: #34C759;

  /* Overlay & Cards */
  --overlay-bg:  rgba(10, 60, 120, 0.65); /* deep sky blue dim */
  --card-bg:     rgba(255, 255, 255, 0.97);
  --card-border: #FFD700;
}
```

---

## 2. Sky Background

The `.game-arena` becomes the full sky canvas.

```css
.game-arena {
  background:
    /* 3-stop gradient sky */
    linear-gradient(
      to bottom,
      var(--sky-top)    0%,
      var(--sky-mid)   50%,
      var(--sky-bottom) 100%
    );
  border-radius: 16px;
  border: 3px solid #FFD700;   /* golden cartoon outline */
  box-shadow:
    0 0 0 5px #FF9500,          /* orange outer ring */
    0 24px 60px rgba(0,0,0,0.5);
}
```

> [!NOTE]  
> The sky gradient darkens slightly at the top (deeper blue = higher altitude) and lightens toward the horizon—giving a natural cartoon-sky look without any images.

---

## 3. Background Scenery Layer (z-index: 1)

A single `<div id="sky-bg" class="sky-bg">` inserted as the **first child** of `.game-arena`. It is `position: absolute; inset: 0; pointer-events: none; z-index: 1` and holds three kinds of inline SVG decoration.

### 3a. White Puffy Clouds

Each cloud is a cluster of overlapping CSS `border-radius: 50%` ellipses — no SVG needed:

```html
<div class="cloud cloud-1"></div>
<div class="cloud cloud-2"></div>
<div class="cloud cloud-3"></div>
```

```css
.cloud {
  position: absolute;
  background: white;
  border-radius: 50%;
  opacity: 0.88;
  filter: drop-shadow(0 4px 8px rgba(0,0,0,0.08));
}

/* Each cloud is built as a pseudo-element sandwich */
.cloud::before,
.cloud::after {
  content: '';
  position: absolute;
  background: white;
  border-radius: 50%;
}

/* Cloud 1 — large, upper-left */
.cloud-1 {
  width: 110px; height: 44px;
  top: 80px; left: 20px;
  animation: drift 18s linear infinite;
}
.cloud-1::before { width:70px; height:60px; top:-34px; left:14px; }
.cloud-1::after  { width:50px; height:46px; top:-22px; left:54px; }

/* Cloud 2 — medium, upper-right */
.cloud-2 {
  width: 90px; height: 36px;
  top: 140px; right: 30px;
  animation: drift 24s linear infinite reverse;
}
.cloud-2::before { width:55px; height:48px; top:-28px; left:10px; }
.cloud-2::after  { width:40px; height:38px; top:-18px; left:40px; }

/* Cloud 3 — small, mid-left */
.cloud-3 {
  width: 70px; height: 28px;
  top: 300px; left: -10px;
  animation: drift 30s linear infinite;
}
.cloud-3::before { width:44px; height:38px; top:-22px; left:8px; }
.cloud-3::after  { width:34px; height:30px; top:-14px; left:32px; }

@keyframes drift {
  from { transform: translateX(-20px); }
  to   { transform: translateX(30px); }
}
```

### 3b. Sun

One inline SVG positioned top-right corner:

```html
<svg class="deco-sun" viewBox="0 0 80 80" xmlns="http://www.w3.org/2000/svg">
  <!-- Animated rotating rays ring -->
  <g class="sun-rays" transform-origin="40 40">
    <line x1="40" y1="4"  x2="40" y2="14" stroke="#FFD700" stroke-width="4" stroke-linecap="round"/>
    <!-- repeat 7 more rays rotated 45° each -->
    <line x1="69" y1="11" x2="62" y2="18" stroke="#FFD700" stroke-width="4" stroke-linecap="round"/>
    <line x1="76" y1="40" x2="66" y2="40" stroke="#FFD700" stroke-width="4" stroke-linecap="round"/>
    <line x1="69" y1="69" x2="62" y2="62" stroke="#FFD700" stroke-width="4" stroke-linecap="round"/>
    <line x1="40" y1="76" x2="40" y2="66" stroke="#FFD700" stroke-width="4" stroke-linecap="round"/>
    <line x1="11" y1="69" x2="18" y2="62" stroke="#FFD700" stroke-width="4" stroke-linecap="round"/>
    <line x1="4"  y1="40" x2="14" y2="40" stroke="#FFD700" stroke-width="4" stroke-linecap="round"/>
    <line x1="11" y1="11" x2="18" y2="18" stroke="#FFD700" stroke-width="4" stroke-linecap="round"/>
  </g>
  <!-- Main disc -->
  <circle cx="40" cy="40" r="22" fill="#FFDD00" stroke="#FFA500" stroke-width="2"/>
  <!-- Cute face -->
  <circle cx="34" cy="37" r="2.5" fill="#A0522D"/>
  <circle cx="46" cy="37" r="2.5" fill="#A0522D"/>
  <path d="M33 44 Q40 50 47 44" stroke="#A0522D" stroke-width="2" fill="none" stroke-linecap="round"/>
</svg>
```

```css
.deco-sun {
  position: absolute;
  width: 70px; height: 70px;
  top: 60px; right: 24px;
}
.sun-rays {
  animation: spin-slow 12s linear infinite;
  transform-origin: 40px 40px;
}
@keyframes spin-slow {
  to { transform: rotate(360deg); }
}
```

### 3c. Rainbow

One short inline SVG arc, semi-transparent, placed mid-arena:

```html
<svg class="deco-rainbow" viewBox="0 0 200 110" xmlns="http://www.w3.org/2000/svg">
  <!-- 7 concentric arcs for ROYGBIV -->
  <path d="M10,110 A90,90 0 0,1 190,110" stroke="#FF0000" stroke-width="10" fill="none" opacity="0.7"/>
  <path d="M18,110 A82,82 0 0,1 182,110" stroke="#FF7F00" stroke-width="10" fill="none" opacity="0.7"/>
  <path d="M26,110 A74,74 0 0,1 174,110" stroke="#FFFF00" stroke-width="10" fill="none" opacity="0.7"/>
  <path d="M34,110 A66,66 0 0,1 166,110" stroke="#00BB00" stroke-width="10" fill="none" opacity="0.7"/>
  <path d="M42,110 A58,58 0 0,1 158,110" stroke="#0000FF" stroke-width="10" fill="none" opacity="0.7"/>
  <path d="M50,110 A50,50 0 0,1 150,110" stroke="#4B0082" stroke-width="10" fill="none" opacity="0.7"/>
  <path d="M58,110 A42,42 0 0,1 142,110" stroke="#8B00FF" stroke-width="10" fill="none" opacity="0.7"/>
</svg>
```

```css
.deco-rainbow {
  position: absolute;
  width: 200px; height: 110px;
  left: 50%; transform: translateX(-50%);
  bottom: 160px;    /* above the basket zone */
  opacity: 0.45;
  pointer-events: none;
}
```

### 3d. Crow Silhouettes

Small SVG crows (simple M-curve wings) fly across the arena using a CSS keyframe:

```html
<!-- 3 crows at different heights & speeds -->
<svg class="crow crow-1" viewBox="0 0 36 16" xmlns="http://www.w3.org/2000/svg">
  <path d="M18,8 Q10,0 0,4 Q10,6 18,8 Q26,6 36,4 Q26,0 18,8Z" fill="#1a1a2e"/>
</svg>
<svg class="crow crow-2" viewBox="0 0 28 12" xmlns="http://www.w3.org/2000/svg">
  <path d="M14,6 Q7,0 0,3 Q7,5 14,6 Q21,5 28,3 Q21,0 14,6Z" fill="#1a1a2e"/>
</svg>
<svg class="crow crow-3" viewBox="0 0 22 10" xmlns="http://www.w3.org/2000/svg">
  <path d="M11,5 Q6,0 0,2 Q6,4 11,5 Q16,4 22,2 Q16,0 11,5Z" fill="#1a1a2e"/>
</svg>
```

```css
.crow {
  position: absolute;
  opacity: 0.55;
  pointer-events: none;
}
.crow-1 { width:36px; top:170px; animation: flyAcross 14s linear infinite; }
.crow-2 { width:24px; top:230px; animation: flyAcross 20s linear infinite 5s; }
.crow-3 { width:18px; top:380px; animation: flyAcross 10s linear infinite 2s; }

@keyframes flyAcross {
  from { left: -50px; }
  to   { left: 530px; }
}
```

> [!TIP]
> The three crows have different sizes and delays, creating a natural parallax depth impression.

---

## 4. HUD Redesign

The HUD becomes a vibrant, bubbly yellow strip:

```css
.hud {
  background: linear-gradient(to right, #FFD700, #FFAA00);
  border-bottom: 3px solid #FF8C00;
  box-shadow: 0 3px 10px rgba(0,0,0,0.2);
  font-family: system-ui, sans-serif;
  font-weight: 900;
  font-size: 15px;
  color: #5B2D00;
  letter-spacing: 0.5px;
}

/* Score badge — pill-shaped coloured box */
.hud-score {
  background: #FF6B35;
  color: white;
  padding: 3px 10px;
  border-radius: 20px;
  font-size: 14px;
  box-shadow: 0 2px 6px rgba(255,107,53,0.5);
}

.hud-high-score {
  background: #A855F7;  /* purple */
  color: white;
  padding: 3px 10px;
  border-radius: 20px;
  font-size: 14px;
  box-shadow: 0 2px 6px rgba(168,85,247,0.5);
}

/* Pause button — round bubbly */
.hud-btn {
  background: white;
  border: 2px solid #FF8C00;
  border-radius: 50%;
  width: 32px; height: 32px;
  font-size: 14px;
  box-shadow: 0 2px 6px rgba(0,0,0,0.15);
  transition: transform 0.1s, box-shadow 0.1s;
}
.hud-btn:hover  { transform: scale(1.1); }
.hud-btn:active { transform: scale(0.9); }
```

---

## 5. Basket Redesign

Replace the flat brown rectangle with a **cartoon wicker basket** built from CSS layers and the existing 🧺 emoji:

```css
.basket {
  /* Wicker gradient — warm woven look */
  background: repeating-linear-gradient(
    45deg,
    #C17F24 0px 4px,
    #E8A83E 4px 8px
  );
  border: 3px solid #8B4513;
  border-radius: 8px 8px 20px 20px;  /* wider bottom → bucket shape */
  box-shadow:
    0 6px 12px rgba(0,0,0,0.3),
    inset 0 2px 6px rgba(255,255,255,0.25);
  transition: transform 0.08s ease;  /* subtle lean when moving */
}

/* Top rim — a rounded bar */
.basket::before {
  content: '';
  position: absolute;
  top: -6px; left: -4px; right: -4px;
  height: 8px;
  background: linear-gradient(to right, #A0522D, #D2691E, #A0522D);
  border-radius: 4px;
  border: 2px solid #6B3A2A;
  box-shadow: 0 2px 4px rgba(0,0,0,0.2);
}

/* Basket gloss shine */
.basket::after {
  content: '';
  position: absolute;
  inset: 0;
  background: linear-gradient(to bottom, rgba(255,255,255,0.18) 0%, transparent 60%);
  border-radius: inherit;
}

/* Catch-good flash → green glow */
.basket.hit-good {
  box-shadow: 0 0 24px #34C759, 0 0 8px #34C759, 0 6px 12px rgba(0,0,0,0.3);
  border-color: #22A848;
}

/* Catch-bad flash → red glow */
.basket.hit-bad {
  box-shadow: 0 0 24px #FF3B30, 0 0 8px #FF3B30, 0 6px 12px rgba(0,0,0,0.3);
  border-color: #CC1F1A;
}
```

**Movement lean effect** — added in JS when keys are held:
```js
// On basket move LEFT  → basketEl.style.transform = `translateX(${basketX}px) rotate(-4deg)`;
// On basket move RIGHT → basketEl.style.transform = `translateX(${basketX}px) rotate(4deg)`;
// On basket idle       → basketEl.style.transform = `translateX(${basketX}px) rotate(0deg)`;
```

> [!NOTE]  
> The 🧺 `.basket-art` emoji inside the basket is kept as-is; it blends perfectly with the wicker CSS background and acts as the visual centrepiece.

---

## 6. Falling Items

### Fruit items (🍎 🍊 🍓 🍉 🍋 🍇 🍒)

Each fruit element gets a **slow spin + subtle shadow**:

```css
.falling-item {
  font-size: 30px;
  filter: drop-shadow(0 4px 6px rgba(0,0,0,0.25));
  animation: fruitSpin 2s linear infinite;
  will-change: transform, top;
}

@keyframes fruitSpin {
  from { transform: rotate(0deg); }
  to   { transform: rotate(360deg); }
}
```

### Bomb items (💣)

Bombs get a **throb / pulse** animation to signal danger:

```css
.falling-item.type-bomb {
  animation: bombPulse 0.6s ease-in-out infinite alternate;
}

@keyframes bombPulse {
  from { filter: drop-shadow(0 0 4px rgba(255,60,0,0.4)); transform: scale(1);   }
  to   { filter: drop-shadow(0 0 12px rgba(255,60,0,0.9)); transform: scale(1.12); }
}
```

> [!IMPORTANT]  
> The `type-bomb` class must be added in `spawnItem()` in script.js when `isBomb` is true, keeping all logic unchanged.

---

## 7. Overlay Cards — Start, Pause, Game Over

All overlays share the same vivid backdrop, but each card has a unique accent.

### Shared overlay backdrop
```css
.overlay {
  background: radial-gradient(ellipse at center,
    rgba(10, 60, 130, 0.72) 0%,
    rgba(5,  30,  80, 0.85) 100%
  );
  backdrop-filter: blur(6px);
}
```

### Shared `.overlay-card`
```css
.overlay-card {
  background: white;
  border-radius: 20px;
  border: 4px solid #FFD700;
  box-shadow: 0 0 0 7px rgba(255,215,0,0.25),
              0 20px 50px rgba(0,0,0,0.4);
  padding: 28px 24px;
}
```

### Start Screen
| Element | Style |
|---|---|
| `h1.game-title` | Rainbow gradient text via `background-clip: text` — red→orange→yellow |
| `.tagline` | `color: #64748b`, italic |
| `.instructions-box` | Soft sky-blue background `#EBF5FF`, rounded, left-border accent `4px solid #5BC8FF` |
| `kbd` | Styled as mini sky-blue pills |
| `#btn-start` | Orange gradient button, bouncing `@keyframes bounce` on first render |

```css
.game-title {
  font-size: 28px;
  background: linear-gradient(90deg, #FF4500, #FF8C00, #FFD700);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  text-shadow: none;
}

.btn-primary {
  background: linear-gradient(to bottom, #FF8C00, #FF6B35);
  color: white;
  border-radius: 12px;
  font-size: 16px;
  letter-spacing: 0.5px;
  box-shadow: 0 6px 0 #C0421A, 0 8px 20px rgba(255,107,53,0.4);
  transition: transform 0.1s, box-shadow 0.1s;
}
.btn-primary:active {
  transform: translateY(4px);
  box-shadow: 0 2px 0 #C0421A, 0 4px 10px rgba(255,107,53,0.3);
}
```

### Pause Screen
| Element | Style |
|---|---|
| `h2` | 🌤️ icon + "Game Paused" in deep blue |
| `.overlay-card` border | Changed to `#5BC8FF` (sky blue) |
| `#btn-resume` | Green gradient `#34C759 → #28A745` |
| `#btn-restart-pause` | Warm grey, subdued |

### Game Over Screen
| Element | Style |
|---|---|
| `h2` | 💥 emoji + red gradient text |
| `.overlay-card` border | Changed to `#FF3B30` (red) |
| `.stats-panel` | `background: #FFF8E7` warm cream; border `#FFD700` |
| `#high-score-banner` | Gold shimmer via `@keyframes shimmer` background animation |
| `#btn-restart` | Purple gradient `#A855F7 → #7C3AED` to stand out from Start screen orange |

```css
/* New High Score golden shimmer */
.high-score-banner {
  background: linear-gradient(90deg, #FFF176, #FFD700, #FFA000, #FFD700, #FFF176);
  background-size: 200% auto;
  animation: shimmer 2s linear infinite;
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  font-size: 15px; font-weight: 900;
}
@keyframes shimmer {
  to { background-position: 200% center; }
}
```

---

## 8. Animation Summary

| Element | Animation | Duration | CSS keyword |
|---|---|---|---|
| Clouds drifting | Side-to-side translateX | 18–30s | `drift` |
| Sun rays | Full 360° rotation | 12s | `spin-slow` |
| Crow flight | Left → right across arena | 10–20s | `flyAcross` |
| Fruit falling | 360° spin during fall | 2s | `fruitSpin` |
| Bomb pulsing | Scale + glow throb | 0.6s alt | `bombPulse` |
| Basket lean | CSS rotate on move | instant JS | inline `transform` |
| Basket hit flash | Color + glow swap | 160ms JS | `.hit-good/.hit-bad` |
| Start button | Gentle bounce | 1s × 3 | `bounce` (once) |
| High-score banner | Gold gradient shimmer | 2s loop | `shimmer` |

> [!TIP]
> All animations use `will-change: transform` or `will-change: filter` on the elements that actually change — this avoids layout thrash and keeps the frame rate smooth on mobile.

---

## 9. HTML Changes Required

Only two additions to index.html:

1. **Insert the sky-bg div** as the first child inside `#game-arena`:
   ```html
   <div class="sky-bg" aria-hidden="true">
     <!-- clouds, sun, rainbow, crows SVGs go here -->
   </div>
   ```

2. **Keep all existing IDs/classes intact.** The design is purely additive — no existing game logic elements are removed.

---

## 10. JS Changes Required

Only **two minimal additions** to script.js — no logic changes:

1. **Add `type-bomb` class** to bomb elements in `spawnItem()`:
   ```js
   if (isBomb) itemEl.classList.add('type-bomb');
   ```

2. **Basket lean on movement** in `renderBasket()`:
   ```js
   function renderBasket() {
     let angle = 0;
     if (keysHeld.left  && !keysHeld.right) angle = -4;
     if (keysHeld.right && !keysHeld.left)  angle =  4;
     basketEl.style.transform = `translateX(${basketX}px) rotate(${angle}deg)`;
   }
   ```

---

## 11. File Change Scope

```mermaid
flowchart TD
    A["index.html"] -->|"Add sky-bg div with SVG scenery"| B["No structural changes to game markup"]
    C["style.css"] -->|"Full visual redesign — same class names"| D["All existing selectors updated/extended"]
    E["script.js"] -->|"2 tiny additions only"| F["Game logic 100% unchanged"]

    style A fill:#EBF5FF,stroke:#5BC8FF
    style C fill:#FFF8E7,stroke:#FFD700
    style E fill:#F0FFF4,stroke:#34C759
```

> [!IMPORTANT]
> The game's collision detection, scoring, lives, difficulty ramp, localStorage, pause/resume and all event listeners in script.js remain completely **untouched**.
