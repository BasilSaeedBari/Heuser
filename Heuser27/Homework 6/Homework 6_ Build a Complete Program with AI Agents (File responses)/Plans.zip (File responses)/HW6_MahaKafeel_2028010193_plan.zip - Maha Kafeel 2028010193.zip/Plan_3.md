# Plan 3: Sensory Feedback for Catch Game

## Overview

This plan covers the design and implementation of sensory feedback for the Catch Game. All effects are intentionally lightweight: smooth but not distracting animations, subtle audio cues generated entirely via the Web Audio API (no external files), and responsive UI interactions. Game rules remain unchanged.

---

## 1. Smooth Falling Animations for Fruits and Bombs

### Goal
Make every falling item feel physically natural and satisfying to track.

### Approach

- **Easing**: Apply a gentle ease-in curve to simulate gravity acceleration. Items start slightly slower and gradually speed up as they fall.
- **CSS / Canvas Animation**: Use `requestAnimationFrame` for frame-perfect updates. Each item's Y position is updated with an incrementally increasing delta (simulating acceleration), capped at a terminal velocity.
- **Rotation**: Add a subtle, slow rotation to each falling item (e.g., ±0.5 to ±2 degrees per frame, randomly assigned at spawn). Fruits rotate gently; bombs rotate slightly faster for visual distinction.
- **Slight Wobble**: Apply a very small sinusoidal X-axis drift (amplitude ≤ 5px) on a per-item basis using a unique phase offset. This prevents items from looking rigidly linear.
- **Spawn Fade-In**: Items fade from 0 to full opacity over the first 10–15 frames of their fall, so they appear to "materialize" from the top rather than popping in abruptly.

### Parameters (Tunable)
| Property | Fruits | Bombs |
|---|---|---|
| Initial speed | 1.5–2.5 px/frame | 2.0–3.5 px/frame |
| Acceleration | +0.03–0.06 px/frame² | +0.05–0.08 px/frame² |
| Rotation range | ±0.5–1 deg/frame | ±1–2 deg/frame |
| Wobble amplitude | ≤ 4px | ≤ 2px |
| Fade-in duration | 12 frames | 10 frames |

---

## 2. Sparkle Effect When a Fruit / Positive Item Is Caught

### Goal
Give the player an immediate, pleasing visual reward when they successfully catch a good item.

### Approach

- **Particle Burst**: On catch, spawn 6–10 small circular or star-shaped particles at the item's last position (near the basket/catcher).
- **Behavior**:
  - Each particle shoots outward in a randomly chosen direction (uniform spread over 360°).
  - Particles travel 20–50px from the origin.
  - Fade from full opacity to 0 over 350–500ms.
  - Scale down from 100% to 0% simultaneously (shrink as they fade).
- **Colors**: Match the item's color palette (e.g., golden/yellow for coins, red/green for fruits). Use 2–3 color variants per catch event for variety.
- **Implementation**: Use a lightweight canvas overlay or absolutely-positioned DOM elements with CSS transitions. Particles are removed from the DOM / canvas after their animation completes.

### Visual Specs
| Property | Value |
|---|---|
| Particle count | 6–10 per catch |
| Particle size | 4–8px diameter |
| Travel distance | 20–50px |
| Lifetime | 350–500ms |
| Animation | Fade-out + scale-down |

---

## 3. Bomb Catch: Pop / Blast Sound

### Goal
Deliver a quick, clearly negative audio cue when a bomb is caught — noticeable but not startling.

### Web Audio API Implementation

```javascript
function playBombSound(audioCtx) {
  // Low-frequency thump/pop
  const bufferSize = audioCtx.sampleRate * 0.4; // 0.4 seconds
  const buffer = audioCtx.createBuffer(1, bufferSize, audioCtx.sampleRate);
  const data = buffer.getChannelData(0);

  for (let i = 0; i < bufferSize; i++) {
    // White noise decaying exponentially
    data[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / bufferSize, 3);
  }

  const source = audioCtx.createBufferSource();
  source.buffer = buffer;

  // Low-pass filter to give it a "thud" quality
  const filter = audioCtx.createBiquadFilter();
  filter.type = 'lowpass';
  filter.frequency.value = 300;

  // Gain envelope
  const gainNode = audioCtx.createGain();
  gainNode.gain.setValueAtTime(0.6, audioCtx.currentTime);
  gainNode.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.4);

  source.connect(filter);
  filter.connect(gainNode);
  gainNode.connect(audioCtx.destination);
  source.start();
}
```

**Character**: A short, dull "thud-pop" — like a muffled firecracker. Decays in under 400ms. Volume kept at 60% max gain.

---

## 4. Good Item Caught: Sparkle / Chime Sound

### Goal
A light, pleasant audio reward for every successful fruit/positive-item catch.

### Web Audio API Implementation

```javascript
function playChimeSound(audioCtx) {
  const notes = [523.25, 659.25, 783.99]; // C5, E5, G5 — a major chord arpeggio
  const now = audioCtx.currentTime;

  notes.forEach((freq, i) => {
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(freq, now + i * 0.07); // slight arpeggio stagger

    gain.gain.setValueAtTime(0, now + i * 0.07);
    gain.gain.linearRampToValueAtTime(0.18, now + i * 0.07 + 0.02); // quick attack
    gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.07 + 0.35); // decay

    osc.connect(gain);
    gain.connect(audioCtx.destination);
    osc.start(now + i * 0.07);
    osc.stop(now + i * 0.07 + 0.4);
  });
}
```

**Character**: A soft three-note ascending chime (C–E–G major arpeggio), each note staggered by 70ms, total duration ~500ms. Max gain per note: 0.18 (quiet and pleasant).

---

## 5. Visual Score Animation (Points Added / Deducted)

### Goal
Reinforce score changes with a small, readable pop-up number that floats and fades.

### Approach

- **Trigger**: Fire on every score update event (whether positive or negative).
- **Display**:
  - Render `+N` in green (or the item's accent color) for gains.
  - Render `-N` in red for deductions (bomb catch, missed item if penalized).
- **Animation**:
  1. Appear instantly at the catch position (above the basket/catcher, or at item's last Y).
  2. Float upward ~30–40px over 700ms.
  3. Fade from 100% to 0% opacity over the same 700ms.
  4. Scale from 100% to 120% then back to 90% (subtle "pop" feel).
- **Typography**: Bold, slightly larger than the game's base font (e.g., 18–22px). Slight text shadow for readability on any background.
- **Implementation**: Create a temporary DOM element with inline styles or use a canvas draw call. Remove element after animation completes.

### Timing
| Phase | Duration |
|---|---|
| Appear | Instant |
| Float up | 700ms (ease-out) |
| Fade | 700ms (ease-out, simultaneous with float) |
| Total lifetime | 700ms |

---

## 6. Button Hover and Click Responses

### Goal
Make the UI feel polished and responsive without being distracting.

### Hover State
- **Scale**: Buttons scale to `1.05` on hover (CSS `transform: scale(1.05)`).
- **Transition**: `transition: transform 150ms ease, background-color 150ms ease`.
- **Color Shift**: Lighten or brighten the button's background color by ~10–15% on hover.
- **Cursor**: Always `cursor: pointer`.

### Active / Click State
- **Scale Down**: On `mousedown` / `:active`, scale to `0.96` for a brief "press" feel.
- **Duration**: 100ms, then springs back to `1.05` (hover) or `1.0` (blur).
- **Optional Audio**: A very soft, brief tick sound (optional, off by default).

### CSS Snippet
```css
.game-button {
  transition: transform 150ms ease, background-color 150ms ease, box-shadow 150ms ease;
  cursor: pointer;
}

.game-button:hover {
  transform: scale(1.05);
  background-color: /* 10-15% lighter variant */;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
}

.game-button:active {
  transform: scale(0.96);
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.1);
}
```

---

## 7. Visual Feedback When the Player Catches an Item

### Goal
Give the player immediate confirmation that the catcher/basket registered a catch.

### Approach

- **Basket Flash**: For ~200ms after a catch, briefly flash the basket/catcher sprite or element:
  - **Good catch**: Flash white or the item's color (opacity pulse: 0% → 60% → 0%).
  - **Bad catch (bomb)**: Flash red (opacity pulse: 0% → 70% → 0%).
- **Catch Ripple**: Emit a single expanding ring from the catch point:
  - Starts at the item's size, expands to ~1.5× that diameter.
  - Fades from ~40% opacity to 0% over 300ms.
  - Rendered on the canvas overlay or as a CSS `border-radius: 50%` div.
- **Basket Scale Pulse**: The catcher briefly scales to `1.08` on catch, then returns to `1.0` over 180ms — a subtle "squish" response indicating contact.

### Timings
| Effect | Duration |
|---|---|
| Basket flash | 200ms |
| Catch ripple | 300ms |
| Basket scale pulse | 180ms |

---

## 8. AudioContext Initialization Strategy

> [!IMPORTANT]
> Browsers require a user gesture before creating or resuming an `AudioContext`. Initialize the `AudioContext` on the first user interaction (e.g., clicking "Start Game") and reuse a single shared instance throughout the session.

```javascript
let audioCtx = null;

function initAudio() {
  if (!audioCtx) {
    audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  }
  if (audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
  return audioCtx;
}

// Call on game start button click:
startButton.addEventListener('click', () => {
  initAudio();
  startGame();
});
```

---

## 9. Performance Guidelines

- **No external files**: All audio is synthesized at runtime via the Web Audio API.
- **Particle pooling**: Reuse particle DOM elements or canvas draw calls rather than creating new ones every frame.
- **Throttling**: Cap simultaneous active particles at 30 total across all effects.
- **Audio overlap**: Allow at most 3 simultaneous sound instances; skip a new sound trigger if 3 are already playing.
- **CSS animations over JS**: Prefer CSS transitions/keyframes for button states and simple effects; reserve canvas or JS-driven animation for game-layer effects.
- **No `setInterval` for animations**: Use `requestAnimationFrame` exclusively for all animated effects.

---

## 10. Summary Table

| Feature | Method | Duration / Intensity |
|---|---|---|
| Fruit/bomb fall animation | `requestAnimationFrame` + easing | Continuous, subtle |
| Fruit sparkle particles | Canvas/DOM particles | 350–500ms, 6–10 particles |
| Bomb blast sound | Web Audio API (noise + lowpass) | ~400ms, 60% gain |
| Good catch chime | Web Audio API (sine oscillators) | ~500ms, 18% gain |
| Score float animation | Floating DOM label | 700ms, ease-out |
| Button hover/click | CSS transform + transition | 150ms hover, 100ms press |
| Basket catch flash | Opacity pulse | 200ms |
| Catch ripple | Expanding ring | 300ms |
| Basket scale pulse | CSS/JS scale | 180ms |

---

## 11. What This Plan Does NOT Change

- Game loop logic (spawn rate, difficulty scaling, lives/health system).
- Scoring rules (points awarded or deducted per item type).
- Item types, their weights, or their probabilities.
- Win/lose conditions.
- Existing UI layout or screen flow.

All feedback described in this plan is purely additive and cosmetic.

---

*Plan version: 3 | Scope: Sensory Feedback Only | Audio: Web Audio API (no external files)*
