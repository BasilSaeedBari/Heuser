# 🎮 Catch Game — Implementation Plan

> [!NOTE]
> This plan covers core game logic only. No code is written at this stage.

---

## 1. Project Structure

```
catch-game/
├── index.html      # Game canvas, UI overlays, button markup
├── style.css       # Layout, basket, item animations, overlays
└── game.js         # All game logic
```

---

## 2. Game States

The game operates in one of four distinct states at any time:

```mermaid
stateDiagram-v2
    [*] --> IDLE : Page loads
    IDLE --> RUNNING : Start button clicked
    RUNNING --> PAUSED : Pause button clicked
    PAUSED --> RUNNING : Resume button clicked
    RUNNING --> GAME_OVER : Lives reach 0
    GAME_OVER --> RUNNING : Restart button clicked
```

| State | Description |
|---|---|
| `IDLE` | Start screen visible, no entities active |
| `RUNNING` | Game loop active, items spawning, input accepted |
| `PAUSED` | Game loop halted, all entities frozen, overlay shown |
| `GAME_OVER` | Loop stopped, final score shown, restart offered |

---

## 3. Core Entities

### 3.1 Basket (Player)

| Property | Value |
|---|---|
| Width | ~100px |
| Height | ~40px |
| Start Position | Bottom-center of screen |
| Movement | Horizontal only (no vertical movement) |
| Speed | Fixed pixels-per-frame (e.g. 6px/frame) |
| Bounds | Clamped to left and right screen edges |

**Input Handling:**
- Keydown events register `ArrowLeft` / `A` and `ArrowRight` / `D`
- A boolean state object tracks which keys are currently held (`keys.left`, `keys.right`)
- Position is updated each frame based on held keys, not on individual key events (smooth movement)

---

### 3.2 Falling Items

Each item is an independent object with these properties:

| Property | Description |
|---|---|
| `type` | `"fruit"` or `"bomb"` |
| `emoji` | A single emoji character (see lists below) |
| `x` | Random spawn X within screen bounds |
| `y` | Starts just above the visible screen (`-40px`) |
| `speed` | Pixels dropped per frame (see difficulty scaling) |
| `width/height` | Uniform hitbox size (~50×50px) |
| `active` | Boolean — set to `false` to remove from pool |

**Fruit / Positive Item Pool:**
🍎 🍊 🍋 🍇 🍓 🍒 🌟 💎 🍉

**Bomb Pool:**
💣

---

## 4. Game Rules & Scoring

### 4.1 Scoring

| Event | Score Change |
|---|---|
| Catch a fruit/positive item | **+10** |
| Catch a bomb | **−10** |
| Miss a fruit (exits screen) | **0** (no penalty) |
| Score floor | **0** (score cannot go negative) |

### 4.2 Lives System

- Player starts with **3 lives** (displayed as ❤️ icons)
- A life is lost **only** when a fruit/positive item reaches the bottom without being caught
- Bombs that reach the bottom are **silently removed** (no life lost, no score change)
- When lives reach **0** → transition to `GAME_OVER`

> [!IMPORTANT]
> Catching a bomb deducts score but does **not** deduct a life. Only missed fruits cost lives.

---

## 5. Spawning System

### 5.1 Spawn Timing

- A **spawn timer** fires on a configurable interval (e.g. every 1200ms initially)
- Each spawn event creates **one item**
- Item type is chosen randomly: **80% chance fruit**, **20% chance bomb**
- X position is chosen randomly within `[padding, screenWidth - padding - itemWidth]`

### 5.2 Difficulty Scaling

Difficulty increases over time to keep the game engaging:

| Time Elapsed | Spawn Interval | Item Fall Speed |
|---|---|---|
| 0–30s | 1200ms | 2.5 px/frame |
| 30–60s | 900ms | 3.5 px/frame |
| 60–90s | 700ms | 4.5 px/frame |
| 90s+ | 500ms | 6.0 px/frame |

- Thresholds are checked each time a new item spawns
- Speed and interval update **gradually** (never jumps abruptly mid-item)

> [!TIP]
> Tie difficulty to `elapsedTime` (ms since game start) rather than score, so a player losing points doesn't slow the game down.

---

## 6. Game Loop

The game loop uses `requestAnimationFrame` for smooth, frame-rate-aware rendering.

**Each frame, in order:**

```
1. Calculate deltaTime (ms since last frame)
2. Update elapsed game time
3. Read held keys → move basket (clamp to bounds)
4. For each active item:
   a. Increase item.y by item.speed
   b. Check collision with basket → handle catch event
   c. If item.y > screenHeight → handle miss event
   d. If item.active === false → remove from active array
5. Update score and lives UI
6. Check game-over condition (lives === 0)
7. Clear canvas / update DOM positions
8. Draw all entities at updated positions
9. Request next frame (if state === RUNNING)
```

---

## 7. Collision Detection

**Method:** Axis-Aligned Bounding Box (AABB) — simple rectangle overlap test.

For a catch to register, **all four** conditions must be true simultaneously:

```
item.right  > basket.left
item.left   < basket.right
item.bottom > basket.top
item.top    < basket.bottom
```

Where:
- `item.right = item.x + item.width`
- `item.bottom = item.y + item.height`
- `basket.right = basket.x + basket.width`
- `basket.bottom = basket.y + basket.height`

> [!NOTE]
> The basket's hitbox can be made slightly **narrower** than its visual width (e.g. 80% of visual) to make the game feel fair — edge catches won't feel like misses.

**On collision:**
- `item.active = false` (remove from loop)
- Apply score change (`+10` or `−10`, clamped at 0)
- Trigger a brief visual feedback effect (flash or emoji burst)

---

## 8. UI Components

### 8.1 HUD (always visible during play)

- **Score** — top-left: `Score: 240`
- **Lives** — top-right: `❤️ ❤️ ❤️`
- **Pause Button** — top-center or corner

### 8.2 Overlays (full-screen, centered)

| Overlay | Contents |
|---|---|
| **Start Screen** | Game title, instructions summary, **Start** button |
| **Pause Screen** | "Paused" label, **Resume** button |
| **Game Over Screen** | "Game Over!", final score, **Restart** button |

Overlays use a semi-transparent dark backdrop over the game area.

### 8.3 Buttons & Controls Summary

| Button | Visible In State | Action |
|---|---|---|
| Start | IDLE | → RUNNING |
| Pause | RUNNING | → PAUSED |
| Resume | PAUSED | → RUNNING |
| Restart | GAME_OVER | Reset all state → RUNNING |

---

## 9. Visual Feedback (No Animation Library Needed)

| Event | Effect |
|---|---|
| Fruit caught | Brief green flash on basket |
| Bomb caught | Brief red flash on basket |
| Life lost | Heart icon dims/disappears with a shake |
| Score update | Score element pulses (CSS class toggled momentarily) |

All effects are purely CSS class-based (`classList.add` → `setTimeout` → `classList.remove`).

---

## 10. Reset & Restart Logic

On **Restart**, the following are fully reset:

- Score → `0`
- Lives → `3`
- Elapsed time → `0`
- Basket position → center-bottom
- All active items → cleared from array
- Spawn timer → cleared and restarted
- Difficulty → back to initial tier
- Game state → `RUNNING`

---

## 11. Edge Cases & Guard Conditions

| Scenario | Handling |
|---|---|
| Score drops below 0 | Clamp to `0` |
| Multiple keys held simultaneously | Allow diagonal-ish movement (last-key-wins OR both handled) |
| Window loses focus | Auto-pause (listen to `window.blur`) |
| Item spawns partially off-screen | Clamp spawn X to safe range |
| Very fast items skipping basket | Use item height for collision, not just center point |
| Restart mid-game | Fully clear all timeouts and animation frames before reinitializing |

---

## 12. Implementation Order (Suggested)

```mermaid
flowchart LR
    A["1. HTML skeleton\n& CSS layout"] --> B["2. Basket rendering\n& keyboard movement"]
    B --> C["3. Item spawning\n& falling loop"]
    C --> D["4. Collision detection\n& scoring"]
    D --> E["5. Lives system\n& game-over"]
    E --> F["6. Start/Pause/Restart\nstate machine"]
    F --> G["7. Difficulty scaling"]
    G --> H["8. Visual feedback\n& polish"]
```
