# Stage 3 — Architect Plan: Sensory Feedback & Audio Synthesis

**Stage:** Sensory Feedback  
**Architect model:** Claude Sonnet 3.7  
**Builder model:** Antigravity (Gemini 3.8 Flash)  
**Result:** Implemented and verified via automated test suite and manual browser testing.

---

## 1. Stage 3 Overview & Objectives

Stage 3 enriches the user experience by delivering immediate, tactile sensory feedback for every interaction. It introduces synchronized CSS micro-animations, code-generated floating Unicode particles, custom Web Audio API sound synthesis, and an accessible Mute/Unmute control toggle.

---

## 2. Sensory Feedback Matrix

| Action / Event | Visual Motion (CSS) | Particle FX (DOM) | Web Audio API Synthesis |
|----------------|---------------------|-------------------|-------------------------|
| **Feed Click** | Rapid open/close chewing mouth cycle (`.anim-chew`) | Floating `🍖`, `✨`, `😋`, `💖` particles rise & fade | 4-step bite tone sweep (480Hz → 800Hz sine waves) |
| **Play Click** | Bouncy hop, side-tilt spin, & stretch (`.anim-play-bounce`) | Floating `⚽`, `🎾`, `🎵`, `⭐`, `🎉` particles | Ascending 4-note arpeggio (C5 → E5 → G5 → C6 triangle wave) |
| **Sleep Click** | Gentle breathing scale motion (`.anim-breathe`) | Floating `💤`, `🌙`, `✨` lavender particles | Soothing dual-tone lullaby (392Hz G4 with smooth decay) |
| **Play Blocked** | Horizontal shake on Play button (`.anim-shake`) | None | Low warning blip (180Hz square wave) |
| **Game Over** | Screen camera shake + Overlay fade-in | None | Melancholic descending cadence (G4 → F4 → D4 → A3 sawtooth) |
| **Restart** | Overlay collapse + posture reset | Reset sparkle burst | Uplifting ascending chime sweep (220Hz → 880Hz) |

---

## 3. Code-Generated Particle System

```javascript
function spawnParticles(symbols) {
  if (!particleContainer) return;
  symbols.forEach((sym) => {
    const p = document.createElement("span");
    p.className = "particle";
    p.textContent = sym;
    p.style.left = `${50 + (Math.random() * 40 - 20)}%`;
    p.style.top = `${50 + (Math.random() * 20 - 10)}%`;
    p.style.color = Math.random() > 0.5 ? "#FF2A85" : "#00F0FF";
    p.style.fontSize = `${20 + Math.random() * 10}px`;
    p.style.setProperty("--dx", `${(Math.random() - 0.5) * 80}px`);
    p.style.setProperty("--dy", `-${50 + Math.random() * 50}px`);
    
    particleContainer.appendChild(p);
    setTimeout(() => p.remove(), 1100);
  });
}
```

---

## 4. Web Audio API Architecture

1. **Autoplay Compliance**: `AudioContext` initializes on the first user click event (`getAudioContext()`) and resumes automatically if suspended.
2. **Master Mute Control**: `soundMuted` boolean flag toggles sound output. Clicking `#btn-sound` switches UI state between `🔊 Sound: ON` and `🔇 Sound: OFF`.
3. **Zero External Files**: All audio is synthesized purely in code using standard `OscillatorNode` and `GainNode` primitives.

---

## 5. Verification Checklist

- [x] Feed triggers chewing mouth animation and munching audio.
- [x] Play triggers bouncy jump animation, particles, and melodic arpeggio.
- [x] Sleep triggers breathing motion, closed eyes, and soothing chord.
- [x] Mute button toggles audio state correctly across reloads.
- [x] Zero external media dependencies; 100% offline compliant.
