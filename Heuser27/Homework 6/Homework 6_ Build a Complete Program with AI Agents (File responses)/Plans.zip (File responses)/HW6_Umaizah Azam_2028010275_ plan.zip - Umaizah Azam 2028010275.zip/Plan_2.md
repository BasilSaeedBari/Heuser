# Stage 2 — Architect Plan: Visual Vibe (Dark Slate Navy Glassmorphism)

**Stage:** Visual Vibe  
**Architect model:** Claude Opus 4.6 (Thinking)  
**Builder model:** Antigravity (Gemini 3.8 Flash)  
**Result:** Implemented and verified via automated test suite and manual browser testing.

---

## 1. Stage 2 Overview and Visual Goals

Stage 2 elevates the Virtual Pet UI from a plain functional wireframe into a visually captivating, modern arcade interface for **Kitty**. It resolves all background framing issues by introducing an obsidian dark slate-navy canvas (`#0F172A`) paired with glassmorphism card surfaces, glowing hot-pink accents (`#FF2A85`), cyan highlights (`#00F0FF`), and a enlarged, expressive SVG character model.

### Key Visual Objectives
1. **Enlarged Vector Character**: Render Kitty as a high-resolution, responsive SVG character scaled to `220px × 220px` with radial gradient fills (`#FF72BE` → `#C71585`), blush cheeks, and dynamic facial expression states.
2. **Glassmorphism Aesthetic**: Deep slate navy background with subtle backdrop blurring (`backdrop-filter: blur(16px)`), ambient pink/purple radial background glows, and crisp semi-transparent borders.
3. **Color-Coded Stat Indicators**: Dynamic stat bar fills utilizing gradient highlights (Pink for Hunger, Cyan for Happiness, Purple for Energy).
4. **Distinct Action Button Design**: Hot pink for Feed, vibrant cyan for Play, deep purple for Sleep, each with glowing box shadows and tactile hover/press states.
5. **Full Overlay Modal**: Game Over modal positioned over the pet card with dark backdrop blur, skull icon, and survival stats.

---

## 2. Color Tokens & Design Language

```css
:root {
  --bg-page-top: #0F172A;
  --bg-page-bottom: #090D16;
  --bg-card: rgba(30, 41, 59, 0.75);
  --bg-card-border: rgba(255, 79, 163, 0.25);
  
  --pink-primary: #FF2A85;
  --pink-light: #FF6BB5;
  --pink-glow: rgba(255, 42, 133, 0.45);
  
  --cyan-primary: #00F0FF;
  --purple-primary: #A855F7;
  --purple-glow: rgba(168, 85, 247, 0.35);

  --text-white: #F8FAFC;
  --text-subtle: #94A3B8;

  --btn-feed-bg: linear-gradient(135deg, #FF2A85 0%, #E11D48 100%);
  --btn-play-bg: linear-gradient(135deg, #00F0FF 0%, #0284C7 100%);
  --btn-sleep-bg: linear-gradient(135deg, #A855F7 0%, #6D28D9 100%);

  --radius-lg: 24px;
  --radius-md: 16px;
  --radius-sm: 12px;
}
```

---

## 3. Inline SVG Anatomy & Facial Expressions (Kitty)

Kitty is constructed using an inline SVG element (`viewBox="0 0 200 200"`) allowing CSS/JS manipulation of individual sub-groups without external image assets:

| Component | SVG Elements | ID / Class | Behavioral Styling |
|-----------|--------------|------------|-------------------|
| **Ears** | `<ellipse>` (x2) | `.pet-body-part` | Uses `#petGradient` fill |
| **Body** | `<ellipse>` | `.pet-body-part` | Main body shape (`rx=72, ry=62`) |
| **Cheeks** | `<circle>` (x2) | `.pet-cheek` | Blush cheeks using `#cheekGradient` |
| **Normal Eyes** | `<g>` (x2) | `#pet-left-eye`, `#pet-right-eye` | Sclera + Pupil + Catchlight highlight |
| **Sleep Eyes** | `<g>` | `#pet-sleeping-eyes` | Dual closed arc paths (`M 64 110 Q 76 96 88 110`) |
| **X-Eyes** | `<g>` | `#pet-left-x`, `#pet-right-x` | Crossed line geometry shown on Game Over |
| **Mouth** | `<path>` | `#pet-mouth` | Dynamic path string updated by JS expression state |

### Expression Mapping Table
| Mood State | Avg Stat Tier | Body Filter / Class | Mouth Path (`d`) | Eye Display |
|------------|---------------|--------------------|------------------|-------------|
| **Thriving** | 70 – 100 | `.mood-thriving` | `M 80 138 Q 100 158 120 138` (Big Smile) | Normal Eyes |
| **Okay** | 40 – 69 | `.mood-okay` | `M 85 135 Q 100 148 115 135` (Gentle Smile) | Normal Eyes |
| **Warning** | 15 – 39 | `.mood-warning` | `M 85 138 L 115 138` (Flat Neutral) | Normal Eyes |
| **Critical** | 0 – 14 | `.mood-critical` | `M 80 145 Q 100 132 120 145` (Frown) | Normal Eyes + Tremble |
| **Sleeping** | Active Nap | `.mood-okay` | `M 88 136 Q 100 144 112 136` (Peaceful) | Closed Arcs (`#pet-sleeping-eyes`) |
| **Dead** | Game Over | `.mood-dead` | `M 80 140 Q 87 136 94 140...` (Wobbly) | X-Eyes (`#pet-left-x`, `#pet-right-x`) |

---

## 4. Verification & Testing Summary

- [x] Unwanted light backgrounds removed; page renders dark slate navy (`#0F172A`).
- [x] Kitty SVG rendered large (`220px`), perfectly centered with drop shadows.
- [x] All 5 facial expressions and sleeping/dead states function seamlessly.
- [x] Glassmorphism card framing applied with responsive layout scaling across mobile/desktop.
