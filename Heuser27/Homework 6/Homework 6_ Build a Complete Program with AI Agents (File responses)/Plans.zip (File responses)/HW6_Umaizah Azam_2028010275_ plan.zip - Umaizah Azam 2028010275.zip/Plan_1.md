# Stage 1 — Architect Plan: Virtual Pet Core Logic (Kitty)

**Stage:** Core Logic  
**Architect model:** Claude Opus 4.6 (Thinking)  
**Builder model:** Antigravity (Gemini 3.8 Flash)  
**Result:** Implemented and verified via automated test suite and manual testing.

---

## 1. Game Overview and Core System Architecture

The Virtual Pet application is a single-player, browser-based interactive micro-game where the user manages the well-being of a digital pet named **Kitty**. The core logic revolves around three numeric stats — **Hunger**, **Happiness**, and **Energy** — that continually decay over time. The player must issue strategic action commands (**Feed**, **Play**, **Sleep**) to keep Kitty's stats in safe operating ranges. If any stat drops to zero and stays at zero for two consecutive game ticks, Kitty "runs away" and the game transitions to a terminal Game Over state.

The application is strictly built as a **three-file local package**:
- `index.html`: Semantic markup, game frame layout, SVG DOM tree, accessible control structures.
- `style.css`: Visual hierarchy, glassmorphism dark navy theme, layout rules, state animations, responsive breakpoints.
- `script.js`: State machine, game loop timers, event handlers, Web Audio API synthesis, `localStorage` persistence.

The game is offline-first, requiring no web server, no external CDNs, and zero third-party libraries.

---

## 2. Core Game Rules & Clamping Mechanics

| # | Rule Specification |
|---|-------------------|
| R1 | The pet is explicitly named **Kitty** across all UI elements, status text, aria-labels, and storage state. |
| R2 | Kitty possesses three core stats: **Hunger**, **Happiness**, and **Energy**. |
| R3 | Each stat is an integer strictly bounded within the range **[0, 100]**. |
| R4 | **Clamping Rule**: All stat modifications pass through `Math.max(0, Math.min(100, newValue))` to prevent underflow or overflow. |
| R5 | Stats decay automatically at fixed intervals during active gameplay (RUNNING state). |
| R6 | The player can trigger three primary actions: **Feed**, **Play**, and **Sleep**. |
| R7 | Each action enforces an independent **cooldown timer** preventing rapid execution spam. |
| R8 | **Losing Condition (Two-Tick Rule)**: If any individual stat reaches `0` and remains at `0` for **two consecutive 3-second game ticks**, Kitty runs away and GAME_OVER is triggered. |
| R9 | **Survival Timer**: An internal counter tracks active survival time in seconds, formatted as `MM:SS`. |
| R10 | **Restart Mechanics**: The player can restart from RUNNING or GAME_OVER, resetting stats to initial defaults (`50/50/50`) and clearing all active intervals. |

---

## 3. Numeric Stat Specifications & Decay Model

| Stat Name | Min Value | Max Value | Default Initial | Decay Rate (per 3s tick) | Critical Threshold |
|-----------|-----------|-----------|-----------------|--------------------------|--------------------|
| **Hunger** | 0 | 100 | 50 | −3 | 0 (Starving) |
| **Happiness** | 0 | 100 | 50 | −2 | 0 (Miserable) |
| **Energy** | 0 | 100 | 50 | −1 | 0 (Exhausted) |

### Interpretation
- **Hunger = 100**: Fully fed and satisfied. `0`: Starving.
- **Happiness = 100**: Ecstatic / thriving. `0`: Extremely sad/bored.
- **Energy = 100**: Fully rested. `0`: Completely exhausted.

---

## 4. Player Command Actions & Cooldown Contract

### 4.1 Feed Command
- **Primary Effect**: Hunger **+20** (clamped to 100).
- **Side Effects**: Wakes Kitty if sleeping (`isSleeping = false`). Resets `zeroTickCounts.hunger = 0`.
- **Precondition**: Cooldown inactive (`cooldownActive.feed === false`) and `gameState === "running"`.
- **Cooldown Duration**: **3 seconds**.
- **Action Feedback**: `"🍖 Yum! Kitty eats happily."`

### 4.2 Play Command
- **Primary Effect**: Happiness **+15** (clamped to 100).
- **Side Effects**: Energy **−10**, Hunger **−5**. Wakes Kitty if sleeping. Resets zero-tick counters for affected stats raised above 0.
- **Precondition**: Energy ≥ 10 **AND** Cooldown inactive (`cooldownActive.play === false`).
- **Energy Block Guard**: If Energy < 10, action is blocked. Shows feedback: `"😴 Kitty is too tired to play!"` and triggers button shake animation without activating cooldown.
- **Cooldown Duration**: **4 seconds**.
- **Action Feedback**: `"🎾 Kitty jumps and plays happily!"`

### 4.3 Sleep Command
- **Primary Effect**: Energy **+25** (clamped to 100).
- **Side Effects**: Hunger **−5**. Activates sleeping state (`isSleeping = true`) for 2.5 seconds, changing eyes to closed arcs (`⌒ ⌒`).
- **Precondition**: Cooldown inactive (`cooldownActive.sleep === false`).
- **Cooldown Duration**: **5 seconds**.
- **Action Feedback**: `"💤 Zzz… Kitty takes a cozy nap."`

---

## 5. State Machine & Execution Flow

```
                     ┌──────────────┐
                     │   LOAD /     │
                     │  RESET DATA  │
                     └──────┬───────┘
                            │
                            ▼
                     ┌──────────────┐
                     │  IDLE STATE  │
                     │  (Start Btn) │
                     └──────┬───────┘
                            │  click Start /
                            │  auto-load saved
                            ▼
                     ┌──────────────┐
  ┌─────────────────►│ RUNNING STATE│◄─────────────────┐
  │                  │  (Game Loop) │                  │
  │                  └──────┬───────┘                  │
  │                         │                          │
  │ click Restart           │ 2 consecutive ticks      │ click Restart
  │                         │ at stat = 0              │
  │                         ▼                          │
  │                  ┌──────────────┐                  │
  └──────────────────┤  GAME OVER   ├──────────────────┘
                     │ (Modal / X's)│
                     └──────────────┘
```

---

## 6. Implementation Verification Checklist

- [x] Pet is strictly named **Kitty** across HTML, CSS, JS, and local storage.
- [x] Three files in root directory: `index.html`, `style.css`, `script.js`.
- [x] Clamping function enforces `[0, 100]` bounds on all stat operations.
- [x] Game loop ticks every 3000ms, applying `-3` Hunger, `-2` Happiness, `-1` Energy.
- [x] Two-tick rule correctly triggers GAME_OVER after 2 consecutive 0-stat ticks.
- [x] Action cooldowns enforce 3s (Feed), 4s (Play), and 5s (Sleep) delays.
- [x] Play command properly guarded when Energy < 10.
- [x] Full state machine transitions verified (IDLE → RUNNING → GAME_OVER → RUNNING).
