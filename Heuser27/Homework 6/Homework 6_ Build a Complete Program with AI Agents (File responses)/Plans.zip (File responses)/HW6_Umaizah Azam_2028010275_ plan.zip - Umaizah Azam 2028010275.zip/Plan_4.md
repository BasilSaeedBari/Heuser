# Stage 4 — Architect Plan: State Management & Persistence

**Stage:** State & Persistence  
**Architect model:** Gemini 1.5 Pro  
**Builder model:** Antigravity (Gemini 3.8 Flash)  
**Result:** Implemented and verified via automated test suite and manual testing.

---

## 1. Stage 4 Overview and Requirements

Stage 4 introduces local storage state persistence to Kitty Virtual Pet. Players can close or refresh their browser tab without losing Kitty's survival stats, elapsed game time, or preferred audio configuration.

### Key Objectives
1. **Local Storage Integration**: Save game state automatically to `localStorage` under key `virtual_pet_save_v1`.
2. **Auto-Load Sequence**: Restore saved stats, elapsed seconds, and audio mute settings upon page initialization.
3. **Reset Data Functionality**: Provide an explicit **"🧹 Reset Data"** button to allow players to wipe saved progress and restart fresh.
4. **Data Validation & Recovery**: Sanitize and clamp all parsed values from `localStorage` to prevent corrupted state crashes.

---

## 2. Storage Data Schema & Serialization

```json
{
  "stats": {
    "hunger": 75,
    "happiness": 60,
    "energy": 80
  },
  "elapsedSeconds": 142,
  "soundMuted": false
}
```

### Persistence Triggers
- **Auto-Save**: Triggered on every game tick (3s), action execution (Feed/Play/Sleep), timer tick (1s), audio mute toggle, and game-over transition.
- **Auto-Load**: Invoked on page load (`loadGameData()`).
- **Data Reset**: Triggered via `#btn-reset-data` click (`resetStoredData()`).

---

## 3. Sanitization & Fallback Logic

```javascript
function loadGameData() {
  try {
    const rawData = localStorage.getItem("virtual_pet_save_v1");
    if (!rawData) return;
    const parsed = JSON.parse(rawData);
    if (parsed && typeof parsed === "object") {
      if (parsed.stats && typeof parsed.stats === "object") {
        if (typeof parsed.stats.hunger === "number") stats.hunger = clamp(parsed.stats.hunger, 0, 100);
        if (typeof parsed.stats.happiness === "number") stats.happiness = clamp(parsed.stats.happiness, 0, 100);
        if (typeof parsed.stats.energy === "number") stats.energy = clamp(parsed.stats.energy, 0, 100);
      }
      if (typeof parsed.elapsedSeconds === "number" && parsed.elapsedSeconds >= 0) {
        elapsedSeconds = parsed.elapsedSeconds;
      }
      if (typeof parsed.soundMuted === "boolean") {
        soundMuted = parsed.soundMuted;
      }
    }
  } catch (err) {
    localStorage.removeItem("virtual_pet_save_v1");
  }
}
```

---

## 4. Verification Summary

- [x] Game state auto-saves during active gameplay.
- [x] Page reload successfully restores stats, survival time, and audio mute state.
- [x] Reset Data button clears local storage and restores default starting state.
