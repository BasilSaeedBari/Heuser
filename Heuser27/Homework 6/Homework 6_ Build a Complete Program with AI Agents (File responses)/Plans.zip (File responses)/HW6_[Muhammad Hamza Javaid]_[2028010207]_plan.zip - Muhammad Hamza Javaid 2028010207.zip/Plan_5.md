
Stage: (5. Debugging) 
Architect model: (Claude Opus 4.6 (Thinking)) Builder model: (Gemini 3.8 Flash - Low) 
Result: (Fixed all personally identified bugs perfectly, List of Bugs: 
cursor not visible, which makes it difficult to locate pause button.
Only center of the balls are caught while touching the edges make them go through the catcher.
In paused state the game goes back to the menu after the page is refreshed.
Cant move catcher on mobile screen, make it so pointers make it move not just cursor.
refreshing the page makes the previous score of the game disappear.)
# 🐛 Ball Catcher — Debugging & Polish Plan

> **Companion to:** `PLAN.md` (core logic), `Plan_2.md` (visual vibe), `Plan_3.md` (sensory feedback), `Plan_4.md` (state & storage)
> **Purpose:** This document addresses five specific bugs/UX issues and provides exact fix specifications. Apply this **on top of** all four previous plans — each fix section references and **overrides** the relevant section of a prior plan.
> **Files affected:** `index.html`, `style.css`, `game.js` (same 3 files).

---

## Bug Index

| # | Issue | Root Cause | Fix Section |
|---|-------|-----------|-------------|
| 1 | Cursor invisible during gameplay — hard to find pause button | `cursor: none` on body during `.playing` | §1 — Custom voxel cursor |
| 2 | Balls pass through basket edges — only dead-centre catches register | Collision uses ball centre point only, ignores radius | §2 — Radius-aware collision |
| 3 | Refreshing during pause returns to menu | `gameState` not persisted to localStorage | §3 — Persist game session |
| 4 | Catcher doesn't move on mobile / touch screens | Only `mousemove` is listened — no touch events | §4 — Pointer event support |
| 5 | Last score disappears after page refresh | `lastScore` not saved to localStorage | §5 — Persist last score |

---

## 1. Custom Voxel Cursor

### 1.1 Problem

Plan_2.md §3.2 sets `cursor: none` on `<body>` when the `.playing` class is active. This makes it impossible to visually locate and click the pause button at the top-right corner because the user can't see where their pointer is.

### 1.2 Solution

Replace the hidden cursor with a **custom pixelated voxel-themed cursor** that is visible at all times during gameplay. The cursor is drawn on the canvas, not via CSS `cursor: url(...)`, so it stays consistent with the voxel art style.

### 1.3 CSS Changes

**Remove** the `cursor: none` rule from `.playing`. Instead, use a small transparent 1×1 cursor so the native cursor doesn't compete with the custom one:

```css
.playing {
  cursor: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAC0lEQVQI12NgAAIABQABNjN9GQAAAAlwSFlzAAAWJQAAFiUBSVIk8AAAAA0lEQVQI12P4//8/AwAI/AL+hc2rNAAAAABJRU5ErkJggg==') 0 0, none;
}
```

> This is a 1×1 transparent PNG as a data URI — fully offline, no external files. The native arrow disappears, but the browser still tracks position. Our custom cursor renders on canvas instead.

### 1.4 Cursor Tracking Variable

Store the current pointer position in a global object that updates on **every** pointer event (not just during gameplay):

```js
const cursorPos = { x: 0, y: 0, visible: false };

// Updated via pointer events (see §4 for the full listener)
function onPointerMove(e) {
  cursorPos.x = e.clientX;
  cursorPos.y = e.clientY;
  cursorPos.visible = true;

  // Basket follows cursor (only during playing state)
  if (gameState === GameState.PLAYING) {
    basket.x = clamp(e.clientX, BASKET_WIDTH / 2, canvas.width - BASKET_WIDTH / 2);
  }
}

// Hide custom cursor when pointer leaves the window
function onPointerLeave() {
  cursorPos.visible = false;
}
```

### 1.5 Drawing the Custom Cursor (Canvas)

Draw the cursor in `render()` — **after** everything else, so it's always on top. Only draw when `gameState === GameState.PLAYING` or `gameState === GameState.PAUSED`.

**Voxel crosshair design (pixel art):**

```
        ██
        ██
    ██      ██
        ██
        ██
```

A small plus-sign made of pixel blocks, with a hollow centre for precision.

```js
function drawVoxelCursor(x, y) {
  if (!cursorPos.visible) return;

  const px = 3;   // pixel block size
  const color = '--royal-gold value';            // bright and always visible
  const shadow = 'rgba(0, 0, 0, 0.5)';

  // Crosshair pixel pattern — centred on (x, y)
  // Each entry: [offsetX, offsetY] in pixel-block units from centre
  const pattern = [
    // Vertical arm (top)
    [0, -3], [0, -2],
    // Vertical arm (bottom)
    [0, 2], [0, 3],
    // Horizontal arm (left)
    [-3, 0], [-2, 0],
    // Horizontal arm (right)
    [2, 0], [3, 0],
    // Centre dot (single pixel — aim point)
    [0, 0]
  ];

  // Draw shadow layer
  ctx.fillStyle = shadow;
  pattern.forEach(([ox, oy]) => {
    ctx.fillRect(x + ox * px + 1, y + oy * px + 1, px, px);
  });

  // Draw main layer
  ctx.fillStyle = color;
  pattern.forEach(([ox, oy]) => {
    ctx.fillRect(x + ox * px, y + oy * px, px, px);
  });
}
```

### 1.6 Render Integration

In the `render()` function, at the very end (after all game elements):

```js
// Draw custom voxel cursor (during gameplay and pause)
if (gameState === GameState.PLAYING || gameState === GameState.PAUSED) {
  drawVoxelCursor(cursorPos.x, cursorPos.y);
}
```

### 1.7 Pause Button Hover Awareness

Since the cursor is now visible, the user can see it hovering over the pause button. No further changes needed — the CSS `:hover` styles from Plan_4.md already handle button hover feedback.

> **Override note:** This fix **replaces** Plan_2.md §3.2's instruction to hide the cursor and draw a "crosshair or dot at `(basket.x, basket.y - 30)`". The cursor now follows the actual pointer position, not the basket.

---

## 2. Radius-Aware Ball Collision

### 2.1 Problem

PLAN.md §4.6.1 uses the ball's **centre point** `(ball.x, ball.y)` for collision checks against the basket rectangle. This means if the edge of a ball touches the basket but the centre hasn't reached it yet, the ball passes through. The player sees the ball touching the basket but not being caught — frustrating and unfair.

### 2.2 Solution

Replace the point-vs-rectangle check with a proper **circle-vs-rectangle** collision test that accounts for the ball's full radius.

### 2.3 Old Collision Code (REPLACE THIS)

```js
// ❌ OLD — point check only
if (ball.y + ball.radius >= basket.y &&
    ball.x >= basket.x - basket.width / 2 &&
    ball.x <= basket.x + basket.width / 2) {
  // caught
}
```

### 2.4 New Collision Code

```js
function isBallCaughtByBasket(ball, basket) {
  // Find the closest point on the basket rectangle to the ball's centre
  const basketLeft   = basket.x - basket.width / 2;
  const basketRight  = basket.x + basket.width / 2;
  const basketTop    = basket.y;
  const basketBottom = basket.y + basket.height;

  // Clamp ball centre to basket bounds to find nearest point on rect
  const closestX = clamp(ball.x, basketLeft, basketRight);
  const closestY = clamp(ball.y, basketTop, basketBottom);

  // Calculate distance from ball centre to closest point
  const dx = ball.x - closestX;
  const dy = ball.y - closestY;
  const distanceSquared = dx * dx + dy * dy;

  // Collision if distance is less than ball radius
  return distanceSquared <= ball.radius * ball.radius;
}

// Utility (if not already defined)
function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}
```

### 2.5 Usage in Update Loop

Replace the old collision block in `update()`:

```js
for (let i = balls.length - 1; i >= 0; i--) {
  const ball = balls[i];

  if (isBallCaughtByBasket(ball, basket)) {
    if (ball.isBad) {
      // ... trigger game over sequence ...
      return;
    } else {
      // ... increment score, spawn particles, notification, sound ...
      balls.splice(i, 1);
    }
  }
}
```

### 2.6 Why This Works

The circle-vs-AABB (axis-aligned bounding box) algorithm handles all edge cases:

| Scenario | Old (broken) | New (fixed) |
|----------|-------------|-------------|
| Ball centre directly above basket | ✅ Caught | ✅ Caught |
| Ball grazes basket's left edge | ❌ Missed | ✅ Caught |
| Ball grazes basket's right edge | ❌ Missed | ✅ Caught |
| Ball clips basket's corner diagonally | ❌ Missed | ✅ Caught |
| Ball is fully above basket (no contact) | ✅ Missed | ✅ Missed |

> **Override note:** This fix **replaces** PLAN.md §4.6.1's collision detection section entirely.

---

## 3. Persist Game Session Across Refresh (Pause Survival)

### 3.1 Problem

Plan_4.md §2.4 explicitly states: *"On page refresh, the game always returns to the menu state."* This means if the player pauses and accidentally refreshes, they lose their in-progress game.

### 3.2 Solution

Save enough session data to localStorage so that a paused game can be **fully restored** after a page refresh.

### 3.3 Updated localStorage Schema

**Add** a new field to the save data (extends Plan_4.md §1.2):

```js
const DEFAULT_SAVE_DATA = {
  highScore: 0,
  totalGamesPlayed: 0,
  totalPointsScored: 0,
  isMuted: false,
  lastScore: null,              // ← added (see §5)
  pausedSession: null           // ← added (this fix)
};
```

The `pausedSession` field is either `null` (no paused game) or an object:

```js
pausedSession: {
  score: 120,
  balls: [
    { x: 200, y: 300, radius: 15, speed: 3, color: "#00c49a", isBad: false },
    { x: 500, y: 100, radius: 15, speed: 3.5, color: "#000000", isBad: true },
    // ...
  ],
  basket: { x: 400, y: 550, width: 120, height: 20 },
  currentSpawnInterval: 45,
  currentBadChance: 0.24,
  spawnTimer: 12
}
```

### 3.4 When to Save the Paused Session

**Save on pause:**

```js
function pauseGame() {
  if (gameState !== GameState.PLAYING) return;

  gameState = GameState.PAUSED;

  // ... (existing UI changes from Plan_4.md §5.3) ...

  // Persist session so it survives refresh
  saveData.pausedSession = {
    score: score,
    balls: balls.map(b => ({ ...b })),    // shallow clone each ball
    basket: { ...basket },
    currentSpawnInterval: currentSpawnInterval,
    currentBadChance: currentBadChance,
    spawnTimer: spawnTimer
  };
  writeSaveData(saveData);

  playButtonSound();
}
```

**Clear on resume, quit, or game over:**

```js
function resumeGame() {
  if (gameState !== GameState.PAUSED) return;

  gameState = GameState.PLAYING;

  // ... (existing UI changes) ...

  // Clear saved session — game is live again
  saveData.pausedSession = null;
  writeSaveData(saveData);

  playButtonSound();
}

function quitToMenu() {
  // ... (existing logic from Plan_4.md §5.5) ...

  // Clear saved session
  saveData.pausedSession = null;
  writeSaveData(saveData);
}

function gameOver() {
  // ... (existing logic from Plan_4.md §5.6) ...

  // Clear saved session
  saveData.pausedSession = null;
  writeSaveData(saveData);
}
```

### 3.5 Restore on Page Load

Update `init()` to detect and restore a saved paused session:

```js
function init() {
  // ... (existing setup: canvas, events, etc.) ...

  saveData = loadSaveData();
  isMuted = saveData.isMuted;
  updateMuteButtons();
  updateMenuStats();

  // Check for a saved paused session
  if (saveData.pausedSession) {
    restorePausedSession(saveData.pausedSession);
  } else {
    gameState = GameState.MENU;
    menuOverlay.classList.remove('hidden');
  }

  requestAnimationFrame(gameLoop);
}

function restorePausedSession(session) {
  // Restore game variables
  score = session.score;
  balls = session.balls.map(b => ({ ...b }));
  basket = { ...session.basket };
  currentSpawnInterval = session.currentSpawnInterval;
  currentBadChance = session.currentBadChance;
  spawnTimer = session.spawnTimer;

  // Clear particle arrays (cosmetic — don't need to persist these)
  trailParticles = [];
  popParticles = [];
  scoreNotifications = [];

  // Set UI to paused state
  gameState = GameState.PAUSED;
  scoreDisplay.textContent = `Score: ${score}`;
  scoreDisplay.classList.remove('hidden');
  pauseOverlay.classList.remove('hidden');
  menuOverlay.classList.add('hidden');
  pauseBtn.classList.add('hidden');   // hidden because pause overlay is showing

  // Restore last score display if available
  if (saveData.lastScore !== null) {
    lastScoreDisplay.textContent = `LAST SCORE: ${saveData.lastScore}`;
    lastScoreDisplay.classList.remove('hidden');
  }
}
```

### 3.6 What Is NOT Saved (Intentional)

| Data | Saved? | Reason |
|------|--------|--------|
| Ball positions & velocities | ✅ Yes | Core gameplay state |
| Basket position | ✅ Yes | Needed to render the paused frame |
| Score | ✅ Yes | Critical |
| Difficulty params | ✅ Yes | Must resume at same difficulty |
| Trail particles | ❌ No | Purely cosmetic, regenerate naturally |
| Pop particles | ❌ No | Transient — would have faded by now anyway |
| Score notifications | ❌ No | Transient floating text |

> **Override note:** This fix **overrides** Plan_4.md §2.4's statement that game state is not persisted. The paused state now survives refresh.

---

## 4. Touch & Pointer Support (Mobile Fix)

### 4.1 Problem

PLAN.md §4.4 only attaches a `mousemove` listener to track the basket. This doesn't fire on touch devices — the basket is stuck in place on mobile.

### 4.2 Solution

Replace all `mouse*` event listeners with **Pointer Events** (`pointermove`, `pointerdown`, `pointerup`). Pointer Events are a unified API that handles mouse, touch, and stylus input in a single listener.

### 4.3 Event Listener Changes

**Remove these (from PLAN.md §4.4 and Plan_4.md):**
```js
// ❌ Remove all mouse-specific listeners
canvas.addEventListener('mousemove', ...);
```

**Replace with:**
```js
// ✅ Pointer events — works on mouse, touch, and stylus
canvas.addEventListener('pointermove', onPointerMove);
canvas.addEventListener('pointerdown', onPointerDown);
canvas.addEventListener('pointerleave', onPointerLeave);

// Prevent default touch behaviours (scroll, zoom) on the canvas
canvas.addEventListener('touchstart', (e) => e.preventDefault(), { passive: false });
canvas.addEventListener('touchmove', (e) => e.preventDefault(), { passive: false });
```

### 4.4 Pointer Event Handlers

```js
function onPointerMove(e) {
  e.preventDefault();

  cursorPos.x = e.clientX;
  cursorPos.y = e.clientY;
  cursorPos.visible = true;

  if (gameState === GameState.PLAYING) {
    basket.x = clamp(e.clientX, BASKET_WIDTH / 2, canvas.width - BASKET_WIDTH / 2);
  }
}

function onPointerDown(e) {
  e.preventDefault();

  // On touch devices, also update position on first touch
  // (pointermove may not fire until the finger moves)
  cursorPos.x = e.clientX;
  cursorPos.y = e.clientY;
  cursorPos.visible = true;

  if (gameState === GameState.PLAYING) {
    basket.x = clamp(e.clientX, BASKET_WIDTH / 2, canvas.width - BASKET_WIDTH / 2);
  }
}

function onPointerLeave() {
  cursorPos.visible = false;
}
```

### 4.5 Touch-Action CSS

Prevent browser-level touch gestures (pull-to-refresh, pinch-to-zoom) from interfering with gameplay:

```css
#gameCanvas {
  touch-action: none;      /* disable all browser touch gestures on the canvas */
}

/* Also prevent overscroll on the whole page during gameplay */
body.playing {
  overscroll-behavior: none;
  touch-action: none;
}
```

### 4.6 Mobile Pause Button Sizing

The pause button needs to be large enough for finger taps (minimum 44×44px touch target per WCAG):

```css
#pauseBtn {
  /* ... existing styles from Plan_4.md §4.3 ... */
  min-width: 48px;
  min-height: 48px;
  padding: 12px 16px;
}
```

### 4.7 Custom Cursor on Touch

The custom voxel cursor (§1) should **not** render on touch devices — fingers already indicate position and a floating crosshair would be distracting:

```js
let isTouch = false;

canvas.addEventListener('pointerdown', (e) => {
  if (e.pointerType === 'touch') {
    isTouch = true;
  }
});

canvas.addEventListener('pointermove', (e) => {
  if (e.pointerType === 'mouse') {
    isTouch = false;
  }
});

// In render(), update the cursor draw call:
if ((gameState === GameState.PLAYING || gameState === GameState.PAUSED) && !isTouch) {
  drawVoxelCursor(cursorPos.x, cursorPos.y);
}
```

> **Override note:** This fix **replaces** PLAN.md §4.4's `mousemove` listener and adds all touch/pointer handling.

---

## 5. Persist Last Score Across Refresh

### 5.1 Problem

Plan_3.md §7 and Plan_4.md §5.6 set `lastScoreDisplay.textContent` in `gameOver()`, but this is only in-memory DOM manipulation. When the page refreshes, the DOM resets and the last score disappears. The user sees "LAST SCORE" vanish even though their high score persists.

### 5.2 Solution

Save `lastScore` to the localStorage save data alongside the other persistent fields.

### 5.3 Updated localStorage Schema

Already included in §3.3 above — the `lastScore` field:

```js
const DEFAULT_SAVE_DATA = {
  highScore: 0,
  totalGamesPlayed: 0,
  totalPointsScored: 0,
  isMuted: false,
  lastScore: null,        // null = no game played yet; number = most recent final score
  pausedSession: null
};
```

### 5.4 Save Last Score on Game Over

Update `gameOver()` and `quitToMenu()`:

```js
function gameOver() {
  const finalScore = score;

  // Update persistent stats
  saveData.totalGamesPlayed++;
  saveData.totalPointsScored += finalScore;
  saveData.lastScore = finalScore;          // ← NEW
  if (finalScore > saveData.highScore) {
    saveData.highScore = finalScore;
  }
  saveData.pausedSession = null;
  writeSaveData(saveData);                  // single write

  // Update menu displays
  lastScoreDisplay.textContent = `LAST SCORE: ${finalScore}`;
  lastScoreDisplay.classList.remove('hidden');
  updateMenuStats();

  // ... (rest of game over — state transition, cleanup) ...
}

function quitToMenu() {
  const finalScore = score;

  saveData.totalGamesPlayed++;
  saveData.totalPointsScored += finalScore;
  saveData.lastScore = finalScore;          // ← NEW
  if (finalScore > saveData.highScore) {
    saveData.highScore = finalScore;
  }
  saveData.pausedSession = null;
  writeSaveData(saveData);

  lastScoreDisplay.textContent = `LAST SCORE: ${finalScore}`;
  lastScoreDisplay.classList.remove('hidden');
  updateMenuStats();

  // ... (rest of quit flow) ...
}
```

### 5.5 Restore Last Score on Page Load

Update `init()` — after loading save data:

```js
function init() {
  // ... (existing setup) ...

  saveData = loadSaveData();

  // Restore last score display
  if (saveData.lastScore !== null) {
    lastScoreDisplay.textContent = `LAST SCORE: ${saveData.lastScore}`;
    lastScoreDisplay.classList.remove('hidden');
  } else {
    lastScoreDisplay.classList.add('hidden');
  }

  updateMenuStats();

  // ... (rest of init) ...
}
```

### 5.6 Reset Clears Last Score

Update `confirmReset()` (from Plan_4.md §7.3):

```js
function confirmReset() {
  saveData = { ...DEFAULT_SAVE_DATA };    // lastScore resets to null
  writeSaveData(saveData);

  isMuted = false;
  updateMuteButtons();

  lastScoreDisplay.classList.add('hidden');   // hide since no game played
  updateMenuStats();

  resetModal.classList.add('hidden');
  playButtonSound();
}
```

---

## 6. Final localStorage Shape (Complete)

After all five plans, the complete save data schema is:

```js
{
  highScore: 350,                // Plan_4.md — highest single-game score
  totalGamesPlayed: 14,          // Plan_4.md — cumulative game count
  totalPointsScored: 2840,       // Plan_4.md — cumulative points across all games
  isMuted: false,                // Plan_4.md — sound preference
  lastScore: 120,                // Plan_5.md §5 — most recent game's final score
  pausedSession: {               // Plan_5.md §3 — null when no game paused
    score: 85,
    balls: [ /* ... */ ],
    basket: { x: 400, y: 550, width: 120, height: 20 },
    currentSpawnInterval: 45,
    currentBadChance: 0.24,
    spawnTimer: 12
  }
}
```

---

## 7. Debugging & Polish Checklist

### §1 — Custom Cursor
- [ ] Native cursor is replaced with a 1×1 transparent PNG during gameplay (not `cursor: none`).
- [ ] A **voxel crosshair** is drawn on the canvas at the pointer position during `playing` and `paused` states.
- [ ] Crosshair is rendered in `--royal-gold` with a pixel shadow for visibility.
- [ ] Crosshair is drawn **last** in the render pipeline (always on top).
- [ ] Crosshair hides when the pointer leaves the window.
- [ ] Crosshair does **not** render on touch devices (finger is the indicator).

### §2 — Collision Fix
- [ ] Collision uses **circle-vs-rectangle** (distance from ball centre to nearest point on basket rect ≤ ball radius).
- [ ] Balls touching the basket's left edge are caught.
- [ ] Balls touching the basket's right edge are caught.
- [ ] Balls clipping the basket's corners diagonally are caught.
- [ ] Balls not touching the basket at all are correctly missed.

### §3 — Pause Persistence
- [ ] Pausing saves full session state (`score`, `balls`, `basket`, `difficulty params`) to localStorage.
- [ ] Refreshing the page during pause **restores the paused game** — not the menu.
- [ ] Resuming clears the saved session from localStorage.
- [ ] Game over clears the saved session from localStorage.
- [ ] Quitting to menu clears the saved session from localStorage.
- [ ] Cosmetic particles (trails, pops, notifications) are **not** saved — they regenerate.

### §4 — Mobile / Touch Support
- [ ] `pointermove` replaces `mousemove` for basket tracking.
- [ ] `pointerdown` also updates basket position (handles first-touch without move).
- [ ] `touch-action: none` on canvas prevents scroll/zoom interference.
- [ ] `touchstart` and `touchmove` have `preventDefault()` to block browser gestures.
- [ ] Pause button meets minimum 48×48px touch target size.
- [ ] Custom cursor is suppressed for `pointerType === 'touch'`.

### §5 — Last Score Persistence
- [ ] `lastScore` is saved to localStorage on game over and quit.
- [ ] `lastScore` is restored and displayed on page load (if not null).
- [ ] `lastScore` is cleared (set to null, display hidden) on data reset.
- [ ] First visit shows no last score (hidden until first game completes).

---

*End of Debugging & Polish Plan*
