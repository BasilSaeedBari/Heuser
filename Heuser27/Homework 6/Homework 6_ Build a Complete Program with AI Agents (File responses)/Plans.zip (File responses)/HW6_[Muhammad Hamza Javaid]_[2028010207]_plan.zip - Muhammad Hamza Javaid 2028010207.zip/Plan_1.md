
Stage: (1. Core Logic) 
Architect model: (Claude Opus 4.6 (Thinking)) Builder model: (Gemini 3.8 Flash - Low) 
Result: (laid out the foundations of the game. Was too bland and basic looking, fixed later in visual vibe.)
# 🎮 Ball Catcher — Offline Browser Game Plan

> **Target Output:** 3 files — `index.html`, `style.css`, `game.js`
> **Tech Stack:** Vanilla HTML5 / CSS3 / JavaScript (no libraries, fully offline)
> **Canvas:** Use an HTML5 `<canvas>` element for all game rendering.

---

## 1. File Structure & Responsibilities

| File | Role |
|------|------|
| `index.html` | Page skeleton, canvas element, menu overlay, links CSS & JS |
| `style.css` | All styling — page layout, menu overlay, buttons, typography |
| `game.js` | Entire game engine — state machine, rendering, physics, scoring, localStorage |

---

## 2. HTML — `index.html`

### 2.1 Document Setup
- Standard HTML5 boilerplate (`<!DOCTYPE html>`, `<html lang="en">`).
- `<meta charset="UTF-8">` and `<meta name="viewport" content="width=device-width, initial-scale=1.0">`.
- Page `<title>`: **"Ball Catcher"**.
- Link `style.css` in `<head>`.
- Load `game.js` with `defer` at the end of `<body>`.

### 2.2 Body Elements (in order)

1. **`<canvas id="gameCanvas">`** — The full game area. No fixed width/height attributes; size is set by JS on load/resize to fill the viewport.

2. **`<div id="menuOverlay">`** — Centered overlay shown on top of the canvas.
   - `<h1>` — Game title: **"Ball Catcher"**.
   - `<p id="highScoreDisplay">` — Text: `High Score: 0` (updated dynamically).
   - `<button id="startBtn">` — Text: **"Start Game"**.

3. **`<div id="scoreDisplay">`** — In-game HUD element (top-left corner), hidden when on the menu.
   - Text content: `Score: 0` (updated dynamically).

---

## 3. CSS — `style.css`

### 3.1 Global Reset & Page
- `*` — `margin: 0; padding: 0; box-sizing: border-box;`
- `html, body` — `width: 100%; height: 100%; overflow: hidden;` background colour: dark navy (`#1a1a2e`) or similar dark tone.
- `cursor: none;` on the body **only while the game is active** (use a `.playing` class toggled by JS).

### 3.2 Canvas
- `#gameCanvas` — `display: block; width: 100%; height: 100%;` positioned absolutely filling the viewport.

### 3.3 Menu Overlay (`#menuOverlay`)
- Position: `fixed`, full viewport, `display: flex; flex-direction: column; align-items: center; justify-content: center;`
- Semi-transparent dark backdrop: `background: rgba(0, 0, 0, 0.75);`
- `z-index: 10` (above canvas).
- Hidden class: `.hidden { display: none; }` — toggled by JS.
- **Title `<h1>`**: large, white, slight text-shadow glow.
- **High score `<p>`**: white, smaller font, margin below title.
- **Start button**:
  - Large, pill-shaped (generous `border-radius`).
  - Bright accent colour (e.g., `#00e676` green).
  - White bold text, padding `15px 50px`.
  - Hover state: lighter shade + subtle scale transform.
  - `cursor: pointer`.

### 3.4 Score HUD (`#scoreDisplay`)
- Position: `fixed; top: 20px; left: 20px;`
- White text, semi-bold, font-size ~24px.
- `z-index: 5`.
- Hidden class `.hidden` shared with menu.

### 3.5 Utility
- `.hidden` — `display: none !important;`

---

## 4. JavaScript — `game.js`

> All logic lives in this single file. Use an IIFE or a top-level scope with `"use strict";`.

---

### 4.1 Constants & Configuration

```
BASKET_WIDTH        = 120          (pixels)
BASKET_HEIGHT       = 20           (pixels)
BASKET_COLOR        = "#4fc3f7"    (light blue)
BASKET_Y_OFFSET     = 50           (pixels from bottom of canvas)

BALL_RADIUS         = 15           (pixels)
GOOD_BALL_COLORS    = ["#ff5252", "#ffeb3b", "#69f0ae", "#e040fb", "#40c4ff"]
BAD_BALL_COLOR      = "#000000"    (black — must be visually distinct)

BALL_BASE_SPEED     = 2            (pixels/frame at score 0)
BALL_MAX_SPEED      = 10           (upper cap)

INITIAL_SPAWN_INTERVAL = 60       (frames between spawns at score 0)
MIN_SPAWN_INTERVAL     = 10       (fastest spawn rate cap)
BAD_BALL_CHANCE_BASE   = 0.15     (15 % at score 0)
BAD_BALL_CHANCE_MAX    = 0.45     (45 % cap)

SCORE_PER_GOOD_CATCH   = 10
DIFFICULTY_STEP        = 50       (every 50 points, difficulty ramps)

LOCAL_STORAGE_KEY      = "ballCatcherHighScore"
```

> These are **tuning knobs** — the implementer may adjust exact values, but the plan defines the parameters that must exist.

---

### 4.2 Game State Machine

The game has **two states**, managed by a variable `gameState`:

| State | Description |
|-------|-------------|
| `"menu"` | Menu overlay visible. Canvas shows a static or animated background (optional). Game loop may still run for ambient animation but no gameplay. |
| `"playing"` | Menu hidden, balls spawn, basket follows cursor, scoring active. |

**Transitions:**
- `menu → playing` : User clicks **Start** button.
- `playing → menu` : Player catches a **bad ball** (game over).

---

### 4.3 Data Structures

#### Basket Object
```
basket = {
  x: <canvas center>,   // centre x, updated by mouse
  y: <canvas.height - BASKET_Y_OFFSET>,
  width: BASKET_WIDTH,
  height: BASKET_HEIGHT
}
```

#### Ball Object (each instance)
```
{
  x: <random across canvas width>,
  y: 0 - BALL_RADIUS,          // starts just above viewport
  radius: BALL_RADIUS,
  speed: <calculated from difficulty>,
  color: <picked from GOOD_BALL_COLORS or BAD_BALL_COLOR>,
  isBad: <boolean>
}
```

#### Active Collections
- `balls` — Array of currently active ball objects.

#### Scalars
- `score` — Current session score (integer, starts at 0).
- `highScore` — Loaded from localStorage on init.
- `spawnTimer` — Frame counter until next ball spawn.
- `currentSpawnInterval` — Dynamically recalculated each difficulty step.
- `currentBadChance` — Dynamically recalculated each difficulty step.

---

### 4.4 Initialisation (`init()`)

1. Cache DOM references: `canvas`, `ctx`, `menuOverlay`, `startBtn`, `highScoreDisplay`, `scoreDisplay`.
2. Set `canvas.width` and `canvas.height` to `window.innerWidth` / `window.innerHeight`.
3. Listen for `window.resize` → update canvas size and clamp basket position.
4. Load `highScore` from `localStorage` (default `0` if absent). Update `highScoreDisplay` text.
5. Attach event listeners:
   - `startBtn.click` → `startGame()`.
   - `mousemove` on canvas → update `basket.x` to `event.clientX` (clamped so basket stays fully on-screen).
6. Set `gameState = "menu"` and show menu overlay.
7. Start the main loop: `requestAnimationFrame(gameLoop)`.

---

### 4.5 Start Game (`startGame()`)

1. Reset `score = 0`. Update score HUD text.
2. Clear `balls` array.
3. Reset `spawnTimer = 0`.
4. Recalculate difficulty params for score 0.
5. Hide menu overlay (add `.hidden`), show score HUD (remove `.hidden`).
6. Add `.playing` class to `<body>` (hides cursor).
7. Set `gameState = "playing"`.

---

### 4.6 Main Game Loop (`gameLoop(timestamp)`)

Called every frame via `requestAnimationFrame`.

```
function gameLoop() {
    update();
    render();
    requestAnimationFrame(gameLoop);
}
```

#### 4.6.1 `update()`

Only run gameplay logic if `gameState === "playing"`:

1. **Spawn logic:**
   - Decrement `spawnTimer`.
   - When `spawnTimer <= 0`:
     - Determine if the new ball is bad: `Math.random() < currentBadChance`.
     - Pick colour accordingly.
     - Calculate speed: `BALL_BASE_SPEED + (score / DIFFICULTY_STEP) * 0.5` (capped at `BALL_MAX_SPEED`).
     - Push new ball object into `balls` array with random `x` (within canvas bounds minus radius).
     - Reset `spawnTimer = currentSpawnInterval`.

2. **Move balls:**
   - For each ball: `ball.y += ball.speed`.

3. **Collision detection (basket catch):**
   - For each ball, check if:
     - `ball.y + ball.radius >= basket.y` **AND**
     - `ball.x >= basket.x - basket.width / 2` **AND**
     - `ball.x <= basket.x + basket.width / 2`
   - If caught:
     - **Good ball:** increment `score += SCORE_PER_GOOD_CATCH`, update score HUD, recalculate difficulty.
     - **Bad ball:** trigger `gameOver()`. Return immediately.
   - Remove caught ball from array.

4. **Off-screen cleanup:**
   - Remove any ball whose `y - radius > canvas.height` (fell past the bottom without being caught — no penalty for missing good balls).

5. **Difficulty recalculation** (call whenever score changes):
   - `currentSpawnInterval = max(MIN_SPAWN_INTERVAL, INITIAL_SPAWN_INTERVAL - (score / DIFFICULTY_STEP) * 5)`
   - `currentBadChance = min(BAD_BALL_CHANCE_MAX, BAD_BALL_CHANCE_BASE + (score / DIFFICULTY_STEP) * 0.03)`

#### 4.6.2 `render()`

1. **Clear canvas** — fill with background colour or `clearRect`.
2. **Draw balls:**
   - For each ball: filled circle (`arc`) at `(ball.x, ball.y)` with `ball.radius`.
   - Use `ball.color` as fill.
   - **Bad balls** additionally get:
     - A slightly larger radius or a white/red outline (`strokeStyle`) to make them extra distinct from the dark background.
     - Optionally a small "☠" or "✕" symbol drawn in white at the centre.
3. **Draw basket:**
   - Filled rounded rectangle centred at `(basket.x, basket.y)`.
   - Colour: `BASKET_COLOR`.
   - Optional: slight gradient or border for visual polish.
4. **Draw cursor indicator** (since native cursor is hidden during play):
   - Small crosshair or dot at `(basket.x, basket.y - 30)` so the player can track position.

---

### 4.7 Game Over (`gameOver()`)

1. Set `gameState = "menu"`.
2. If `score > highScore`:
   - `highScore = score`.
   - Save to `localStorage.setItem(LOCAL_STORAGE_KEY, highScore)`.
3. Update `highScoreDisplay` text to reflect current `highScore`.
4. Show menu overlay (remove `.hidden`), hide score HUD (add `.hidden`).
5. Remove `.playing` class from `<body>` (restores cursor).
6. Clear `balls` array (stop rendering leftover balls).

---

### 4.8 Edge Cases & Polish

| Concern | Handling |
|---------|----------|
| **Canvas resize** | `window.resize` listener recalculates `canvas.width/height`, re-clamps basket y-position, and repositions any balls still in-frame proportionally. |
| **Ball spawn position** | Ensure `x` is at least `BALL_RADIUS` from both edges so balls are fully visible. |
| **Basket clamping** | `basket.x` is clamped between `BASKET_WIDTH/2` and `canvas.width - BASKET_WIDTH/2`. |
| **localStorage unavailable** | Wrap in try/catch; fall back to in-memory high score only. |
| **First visit** | If no high score in storage, display `High Score: 0`. |
| **Tab hidden** | `requestAnimationFrame` naturally pauses when the tab is not visible — no extra handling needed. |

---

## 5. Difficulty Scaling Summary

| Score Range | Spawn Interval (frames) | Bad Ball Chance | Ball Speed (px/frame) |
|-------------|------------------------|-----------------|-----------------------|
| 0 – 49 | 60 | 15% | 2.0 |
| 50 – 99 | 55 | 18% | 2.5 |
| 100 – 149 | 50 | 21% | 3.0 |
| 150 – 199 | 45 | 24% | 3.5 |
| 200 – 249 | 40 | 27% | 4.0 |
| 300+ | 35 → 10 (cap) | 30 → 45% (cap) | 4.5 → 10 (cap) |

> Values are illustrative. The formulas in §4.6.1 / §4.6.2 govern exact behaviour.

---

## 6. Visual Reference (ASCII Wireframe)

```
┌──────────────────────────────────────────────┐
│  Score: 120                                  │  ← HUD (top-left, visible during play)
│                                              │
│          ● (red)                             │
│                      ● (BLACK — bad!)        │
│    ● (green)                                 │
│                 ● (yellow)                   │
│                                              │
│                                              │
│                                              │
│              ┌──────────┐                    │  ← Basket (follows cursor X)
│              └──────────┘                    │
└──────────────────────────────────────────────┘

┌──────────────────────────────────────────────┐
│                                              │
│            ┌─────────────────┐               │
│            │   BALL CATCHER  │               │  ← Menu overlay
│            │                 │               │
│            │ High Score: 120 │               │
│            │                 │               │
│            │  [ START GAME ] │               │
│            └─────────────────┘               │
│                                              │
└──────────────────────────────────────────────┘
```

---

## 7. Implementation Checklist

Use this checklist to verify completeness:

- [ ] `index.html` contains canvas, menu overlay, and score HUD elements.
- [ ] `style.css` styles the page, menu, button, and HUD as described.
- [ ] Canvas fills the full viewport and resizes dynamically.
- [ ] Menu displays game title, high score, and a start button.
- [ ] Clicking "Start Game" hides the menu and begins gameplay.
- [ ] Basket renders at the bottom and tracks the mouse X position.
- [ ] Good balls (multiple bright colours) fall from random X positions at the top.
- [ ] Bad balls are coloured **black** and are visually distinct (outline/symbol).
- [ ] Catching a good ball adds to the score.
- [ ] Catching a bad ball triggers game over.
- [ ] Score HUD updates in real time during play.
- [ ] Difficulty increases as score rises (more balls, faster, higher bad-ball ratio).
- [ ] Game over returns to the menu.
- [ ] High score is saved to `localStorage` and persists across sessions.
- [ ] High score on menu updates after each game if beaten.
- [ ] Game is fully offline — no external resources, CDNs, or network calls.

---

*End of Plan*
