
Stage: (4. State & Storage) 
Architect model: (Claude Opus 4.6 (Thinking)) Builder model: (Gemini 3.8 Flash - Low) 
Result: (Made the appropiate required data to be saved to be stored which displayed each time the game was reopened. Added the paused state of the game. Noticed that the last score didnt save, fixed later in debugging.)
# 💾 Ball Catcher — State & Storage Plan

> **Companion to:** `PLAN.md` (core logic), `Plan_2.md` (visual vibe), `Plan_3.md` (sensory feedback)
> **Purpose:** This document specifies all persistent data, game state management, pause/resume flow, and UI controls for mute and data reset. Apply this **on top of** all three previous plans.
> **Files affected:** `index.html`, `style.css`, `game.js` (same 3 files — no new files).

---

## 1. localStorage Schema

All persistent data is stored in `localStorage` under a single JSON key to keep things clean and atomic.

### 1.1 Storage Key

```js
const STORAGE_KEY = "ballCatcherSaveData";
```

### 1.2 Data Shape

```js
// Default save data (used on first visit or after reset)
const DEFAULT_SAVE_DATA = {
  highScore: 0,
  totalGamesPlayed: 0,
  totalPointsScored: 0,
  isMuted: false
};
```

| Field | Type | Description | Persists across refresh? |
|-------|------|-------------|--------------------------|
| `highScore` | `number` | Highest score achieved in any single game session | ✅ Yes |
| `totalGamesPlayed` | `number` | Cumulative count of completed games (incremented on every game over) | ✅ Yes |
| `totalPointsScored` | `number` | Sum of final scores from every game ever played | ✅ Yes |
| `isMuted` | `boolean` | Whether sound effects are muted | ✅ Yes |

### 1.3 Read / Write Helpers

```js
function loadSaveData() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      // Merge with defaults to handle missing fields (forward compatibility)
      return { ...DEFAULT_SAVE_DATA, ...parsed };
    }
  } catch (e) {
    console.warn("Failed to load save data:", e);
  }
  return { ...DEFAULT_SAVE_DATA };
}

function writeSaveData(data) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch (e) {
    console.warn("Failed to save data:", e);
  }
}
```

> **Important:** Always merge loaded data with `DEFAULT_SAVE_DATA` using spread so that any newly added fields in future updates receive their default values instead of being `undefined`.

### 1.4 In-Memory Mirror

On page load, call `loadSaveData()` and store the result in a module-level variable:

```js
let saveData = loadSaveData();
```

All game logic reads from and writes to `saveData`. The `writeSaveData(saveData)` function is called **only at specific save points** (not every frame) — see §5.

---

## 2. Game State Machine (Updated)

The original plan (PLAN.md) defined two states (`menu`, `playing`) and Plan_2.md added a third (`disintegrating`). This plan adds a fourth: **`paused`**.

### 2.1 State Enum

```js
const GameState = {
  MENU:           "menu",
  PLAYING:        "playing",
  PAUSED:         "paused",
  DISINTEGRATING: "disintegrating"
};

let gameState = GameState.MENU;
```

### 2.2 State Transition Diagram

```mermaid
stateDiagram-v2
    [*] --> Menu
    Menu --> Playing : Click "Start Game"
    Playing --> Paused : Click "Pause" or press Escape
    Paused --> Playing : Click "Continue" or press Escape
    Paused --> Menu : Click "Quit to Menu" (optional)
    Playing --> Disintegrating : Catch bad ball
    Disintegrating --> Menu : Animation complete (~2s)
```

### 2.3 State Behaviour Summary

| State | Game Loop Runs? | Balls Move? | Basket Follows Cursor? | HUD Visible? | Menu Visible? | Pause Button Visible? |
|-------|----------------|-------------|----------------------|--------------|--------------|----------------------|
| `menu` | Yes (ambient bg) | No (menu balls only) | No | No | Yes | No |
| `playing` | Yes | Yes | Yes | Yes | No | Yes |
| `paused` | Yes (frozen frame) | **No** | **No** | Yes (dimmed) | No | No (pause overlay shown instead) |
| `disintegrating` | Yes (animation) | No (frozen) | No | Yes | No | No |

### 2.4 Saving Current State

The current `gameState` is **NOT** saved to localStorage. Here's why and what happens instead:

> On page refresh, the game always returns to the **menu** state. There is no need to resume a paused or in-progress game after refresh — the game round is too short to warrant session restoration.

However, the **score of the in-progress game is lost on refresh** (this is intentional and standard for arcade-style games). Only cumulative stats persist.

---

## 3. New HTML Elements

### 3.1 Updated Menu Overlay (`#menuOverlay`)

Add the new stat displays and the reset-data button:

```html
<div id="menuOverlay">
  <div id="menuPanel">
    <h1>BALL CATCHER</h1>

    <div id="menuStats">
      <p id="highScoreDisplay">HIGH SCORE: 0</p>
      <p id="lastScoreDisplay" class="hidden">LAST SCORE: 0</p>
      <hr class="pixel-divider">
      <p id="totalGamesDisplay">GAMES PLAYED: 0</p>
      <p id="totalPointsDisplay">TOTAL POINTS: 0</p>
    </div>

    <button id="startBtn">START GAME</button>

    <div id="menuFooterButtons">
      <button id="resetDataBtn">RESET DATA</button>
      <button id="muteBtn">🔊 SOUND: ON</button>
    </div>
  </div>
</div>
```

### 3.2 Pause Button (In-Game HUD)

```html
<button id="pauseBtn" class="hidden">❚❚</button>
```

- Positioned at **top-right** of the screen during gameplay.
- Hidden when not in `playing` state.

### 3.3 Pause Overlay

```html
<div id="pauseOverlay" class="hidden">
  <div id="pausePanel">
    <h2>PAUSED</h2>
    <button id="continueBtn">CONTINUE</button>
    <button id="quitBtn">QUIT TO MENU</button>
    <button id="pauseMuteBtn">🔊 SOUND: ON</button>
  </div>
</div>
```

- Displayed on top of the frozen game canvas when `gameState === "paused"`.
- Contains continue, quit, and mute buttons.

### 3.4 Reset Confirmation Modal

```html
<div id="resetModal" class="hidden">
  <div id="resetPanel">
    <p>ERASE ALL DATA?</p>
    <p class="reset-warning">THIS CANNOT BE UNDONE</p>
    <div id="resetModalButtons">
      <button id="resetConfirmBtn">YES, RESET</button>
      <button id="resetCancelBtn">CANCEL</button>
    </div>
  </div>
</div>
```

- Shown only when the user clicks "RESET DATA" — requires explicit confirmation.

---

## 4. CSS — New Element Styles

### 4.1 Menu Stats Section

```css
#menuStats {
  text-align: center;
  margin: 20px 0;
}

#menuStats p {
  font-family: 'PixelFont', monospace;
  font-size: 13px;
  color: var(--fresh-sky);
  text-shadow: 2px 2px 0px rgba(0, 0, 0, 0.5);
  margin: 8px 0;
  font-weight: bold;
}

#highScoreDisplay {
  font-size: 15px;
  color: var(--royal-gold);   /* high score gets gold treatment */
}

.pixel-divider {
  border: none;
  border-top: 2px dashed var(--fresh-sky);
  opacity: 0.3;
  margin: 14px 20px;
}

#totalGamesDisplay,
#totalPointsDisplay {
  font-size: 11px;
  opacity: 0.75;
}
```

### 4.2 Menu Footer Buttons (Reset & Mute)

```css
#menuFooterButtons {
  display: flex;
  justify-content: center;
  gap: 12px;
  margin-top: 24px;
}

#resetDataBtn,
#muteBtn,
#pauseMuteBtn {
  font-family: 'PixelFont', monospace;
  font-size: 10px;
  text-transform: uppercase;
  color: var(--fresh-sky);
  background: transparent;
  border: 2px solid var(--fresh-sky);
  border-radius: 0;                     /* sharp voxel edges */
  padding: 8px 16px;
  cursor: pointer;

  box-shadow: 2px 2px 0px rgba(0, 0, 0, 0.4);
  transform: translateY(0);
  transition: transform 0.05s, box-shadow 0.05s;
}

#resetDataBtn:hover,
#muteBtn:hover,
#pauseMuteBtn:hover {
  color: var(--royal-gold);
  border-color: var(--royal-gold);
}

#resetDataBtn:active,
#muteBtn:active,
#pauseMuteBtn:active {
  transform: translateY(2px);
  box-shadow: 0px 0px 0px rgba(0, 0, 0, 0.4);
}

/* Muted state styling */
#muteBtn.muted,
#pauseMuteBtn.muted {
  color: var(--blazing-flame);
  border-color: var(--blazing-flame);
  opacity: 0.6;
}
```

### 4.3 Pause Button (In-Game)

```css
#pauseBtn {
  position: fixed;
  top: 16px;
  right: 16px;
  z-index: 5;

  font-family: 'PixelFont', monospace;
  font-size: 18px;
  color: var(--royal-gold);
  background: rgba(27, 73, 101, 0.6);
  border: 2px solid var(--royal-gold);
  border-radius: 0;
  padding: 8px 14px;
  cursor: pointer;

  box-shadow: 3px 3px 0px rgba(0, 0, 0, 0.5);
  transform: translateY(0);
  transition: transform 0.05s, box-shadow 0.05s;
}

#pauseBtn:hover {
  color: var(--blazing-flame);
  border-color: var(--blazing-flame);
}

#pauseBtn:active {
  transform: translateY(3px);
  box-shadow: 0px 0px 0px rgba(0, 0, 0, 0.5);
}
```

### 4.4 Pause Overlay

```css
#pauseOverlay {
  position: fixed;
  top: 0; left: 0; right: 0; bottom: 0;
  background: rgba(27, 73, 101, 0.80);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 15;
}

#pausePanel {
  text-align: center;
  background: rgba(27, 73, 101, 0.95);
  border: 4px solid var(--fresh-sky);
  box-shadow: 4px 4px 0px rgba(0, 0, 0, 0.5),
              8px 8px 0px rgba(0, 0, 0, 0.3);
  padding: 40px 50px;
}

#pausePanel h2 {
  font-family: 'PixelFont', monospace;
  font-size: 28px;
  color: var(--royal-gold);
  text-shadow: 3px 3px 0px rgba(0, 0, 0, 0.7);
  margin-bottom: 30px;
  letter-spacing: 4px;
}

#continueBtn {
  /* Same style as #startBtn from Plan_2 — mint green, sharp edges, press effect */
  font-family: 'PixelFont', monospace;
  font-size: 16px;
  text-transform: uppercase;
  color: var(--yale-blue);
  background: var(--mint-leaf);
  border: 3px solid var(--yale-blue);
  border-radius: 0;
  padding: 14px 40px;
  cursor: pointer;
  box-shadow: 3px 3px 0px rgba(0, 0, 0, 0.5);
  transform: translateY(0);
  transition: transform 0.05s, box-shadow 0.05s;
  display: block;
  margin: 0 auto 16px auto;
}

#continueBtn:hover {
  background: var(--royal-gold);
}

#continueBtn:active {
  transform: translateY(3px);
  box-shadow: 0px 0px 0px rgba(0, 0, 0, 0.5);
}

#quitBtn {
  font-family: 'PixelFont', monospace;
  font-size: 11px;
  text-transform: uppercase;
  color: var(--blazing-flame);
  background: transparent;
  border: 2px solid var(--blazing-flame);
  border-radius: 0;
  padding: 8px 20px;
  cursor: pointer;
  box-shadow: 2px 2px 0px rgba(0, 0, 0, 0.4);
  transform: translateY(0);
  transition: transform 0.05s, box-shadow 0.05s;
  display: block;
  margin: 0 auto 16px auto;
}

#quitBtn:hover {
  background: rgba(255, 63, 0, 0.15);
}

#quitBtn:active {
  transform: translateY(2px);
  box-shadow: 0px 0px 0px rgba(0, 0, 0, 0.4);
}
```

### 4.5 Reset Confirmation Modal

```css
#resetModal {
  position: fixed;
  top: 0; left: 0; right: 0; bottom: 0;
  background: rgba(0, 0, 0, 0.85);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 20;     /* above everything else */
}

#resetPanel {
  text-align: center;
  background: rgba(27, 73, 101, 0.95);
  border: 4px solid var(--blazing-flame);
  box-shadow: 4px 4px 0px rgba(0, 0, 0, 0.5);
  padding: 30px 40px;
}

#resetPanel p {
  font-family: 'PixelFont', monospace;
  font-size: 14px;
  color: var(--royal-gold);
  text-shadow: 2px 2px 0px rgba(0, 0, 0, 0.7);
  margin-bottom: 8px;
}

.reset-warning {
  font-size: 10px !important;
  color: var(--blazing-flame) !important;
  margin-bottom: 20px !important;
}

#resetModalButtons {
  display: flex;
  justify-content: center;
  gap: 16px;
}

#resetConfirmBtn {
  font-family: 'PixelFont', monospace;
  font-size: 12px;
  color: var(--yale-blue);
  background: var(--blazing-flame);
  border: 2px solid var(--yale-blue);
  border-radius: 0;
  padding: 10px 24px;
  cursor: pointer;
  box-shadow: 2px 2px 0px rgba(0, 0, 0, 0.5);
  transform: translateY(0);
  transition: transform 0.05s, box-shadow 0.05s;
}

#resetConfirmBtn:active {
  transform: translateY(2px);
  box-shadow: 0px 0px 0px rgba(0, 0, 0, 0.5);
}

#resetCancelBtn {
  font-family: 'PixelFont', monospace;
  font-size: 12px;
  color: var(--fresh-sky);
  background: transparent;
  border: 2px solid var(--fresh-sky);
  border-radius: 0;
  padding: 10px 24px;
  cursor: pointer;
  box-shadow: 2px 2px 0px rgba(0, 0, 0, 0.5);
  transform: translateY(0);
  transition: transform 0.05s, box-shadow 0.05s;
}

#resetCancelBtn:active {
  transform: translateY(2px);
  box-shadow: 0px 0px 0px rgba(0, 0, 0, 0.5);
}
```

---

## 5. JavaScript — State & Storage Logic

### 5.1 Initialisation (updated `init()`)

```js
function init() {
  // ... (existing canvas setup, event listeners from PLAN.md) ...

  // Load persistent data
  saveData = loadSaveData();

  // Apply mute state
  isMuted = saveData.isMuted;
  updateMuteButtons();

  // Update menu displays
  updateMenuStats();

  // Attach new event listeners
  pauseBtn.addEventListener('click', pauseGame);
  continueBtn.addEventListener('click', resumeGame);
  quitBtn.addEventListener('click', quitToMenu);
  resetDataBtn.addEventListener('click', showResetModal);
  resetConfirmBtn.addEventListener('click', confirmReset);
  resetCancelBtn.addEventListener('click', hideResetModal);
  muteBtn.addEventListener('click', toggleMute);
  pauseMuteBtn.addEventListener('click', toggleMute);

  // Keyboard shortcut for pause
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      if (gameState === GameState.PLAYING) {
        pauseGame();
      } else if (gameState === GameState.PAUSED) {
        resumeGame();
      }
    }
  });

  gameState = GameState.MENU;
  requestAnimationFrame(gameLoop);
}
```

### 5.2 Update Menu Stats

```js
function updateMenuStats() {
  highScoreDisplay.textContent  = `HIGH SCORE: ${saveData.highScore}`;
  totalGamesDisplay.textContent = `GAMES PLAYED: ${saveData.totalGamesPlayed}`;
  totalPointsDisplay.textContent = `TOTAL POINTS: ${saveData.totalPointsScored}`;
}
```

Called:
- On `init()`
- On `gameOver()` (after updating save data)
- On `confirmReset()` (after clearing data)

### 5.3 Pause Game

```js
function pauseGame() {
  if (gameState !== GameState.PLAYING) return;

  gameState = GameState.PAUSED;

  // Show pause overlay
  pauseOverlay.classList.remove('hidden');
  // Hide pause button (replaced by the pause overlay)
  pauseBtn.classList.add('hidden');
  // Restore cursor (hidden during gameplay)
  document.body.classList.remove('playing');

  playButtonSound();   // respects mute (see §6)
}
```

### 5.4 Resume Game

```js
function resumeGame() {
  if (gameState !== GameState.PAUSED) return;

  gameState = GameState.PLAYING;

  // Hide pause overlay
  pauseOverlay.classList.add('hidden');
  // Show pause button again
  pauseBtn.classList.remove('hidden');
  // Hide cursor again
  document.body.classList.add('playing');

  playButtonSound();   // respects mute
}
```

### 5.5 Quit to Menu (from Pause)

```js
function quitToMenu() {
  if (gameState !== GameState.PAUSED) return;

  // The player chose to leave — treat it as a game over
  // but WITHOUT the disintegration animation (they quit voluntarily)

  const finalScore = score;

  // Update persistent stats
  saveData.totalGamesPlayed++;
  saveData.totalPointsScored += finalScore;
  if (finalScore > saveData.highScore) {
    saveData.highScore = finalScore;
  }
  writeSaveData(saveData);

  // Update menu displays
  lastScoreDisplay.textContent = `LAST SCORE: ${finalScore}`;
  lastScoreDisplay.classList.remove('hidden');
  updateMenuStats();

  // Transition to menu
  gameState = GameState.MENU;
  pauseOverlay.classList.add('hidden');
  pauseBtn.classList.add('hidden');
  scoreDisplay.classList.add('hidden');
  menuOverlay.classList.remove('hidden');
  document.body.classList.remove('playing');

  // Clean up game objects
  balls.length = 0;
  trailParticles.length = 0;
  popParticles.length = 0;
  scoreNotifications.length = 0;

  playButtonSound();
}
```

### 5.6 Game Over (updated from PLAN.md)

```js
function gameOver() {
  // Called after disintegration animation completes

  const finalScore = score;

  // Update persistent stats
  saveData.totalGamesPlayed++;
  saveData.totalPointsScored += finalScore;
  if (finalScore > saveData.highScore) {
    saveData.highScore = finalScore;
  }
  writeSaveData(saveData);        // SAVE POINT

  // Update menu displays
  lastScoreDisplay.textContent = `LAST SCORE: ${finalScore}`;
  lastScoreDisplay.classList.remove('hidden');
  updateMenuStats();

  // Transition to menu
  gameState = GameState.MENU;
  pauseBtn.classList.add('hidden');
  scoreDisplay.classList.add('hidden');
  menuOverlay.classList.remove('hidden');
  document.body.classList.remove('playing');

  // Clean up
  balls.length = 0;
  trailParticles.length = 0;
  popParticles.length = 0;
  scoreNotifications.length = 0;
  disintegrationParticles.length = 0;
}
```

### 5.7 Game Loop Update (Pause-Aware)

```js
function update() {
  if (gameState === GameState.PLAYING) {
    // ... all normal gameplay logic (spawn, move, collide, difficulty) ...
  }
  else if (gameState === GameState.DISINTEGRATING) {
    // ... only disintegration particle updates ...
  }
  else if (gameState === GameState.PAUSED) {
    // DO NOTHING — freeze everything in place
    // The last rendered frame stays on screen
  }
  else if (gameState === GameState.MENU) {
    // ... ambient menu ball animation only ...
  }
}
```

---

## 6. Mute System

### 6.1 State Variable

```js
let isMuted = false;    // initialised from saveData.isMuted in init()
```

### 6.2 Toggle Function

```js
function toggleMute() {
  isMuted = !isMuted;
  saveData.isMuted = isMuted;
  writeSaveData(saveData);      // persist immediately
  updateMuteButtons();

  // Play a tiny blip to confirm unmute (only if turning sound ON)
  if (!isMuted) {
    playButtonSound();
  }
}
```

### 6.3 Update Mute Button Visuals

```js
function updateMuteButtons() {
  const label = isMuted ? '🔇 SOUND: OFF' : '🔊 SOUND: ON';

  muteBtn.textContent = label;
  pauseMuteBtn.textContent = label;

  muteBtn.classList.toggle('muted', isMuted);
  pauseMuteBtn.classList.toggle('muted', isMuted);
}
```

> Both the menu mute button and the pause-menu mute button stay synchronised.

### 6.4 Sound Gate

**Every sound function** must check the mute flag before playing:

```js
function playCollectSound() {
  if (isMuted) return;          // ← add this guard to ALL sound functions
  // ... existing Web Audio code ...
}

function playDeathHitSound() {
  if (isMuted) return;
  // ...
}

function playGameOverMelody() {
  if (isMuted) return;
  // ...
}

function playStartSound() {
  if (isMuted) return;
  // ...
}

function playButtonSound() {
  if (isMuted) return;
  // ...
}
```

> **Vibration is NOT affected by mute.** Haptic feedback always fires regardless of the sound setting — it's a separate sensory channel. (The user can disable vibration at the OS level if they wish.)

---

## 7. Reset Data

### 7.1 Show Confirmation Modal

```js
function showResetModal() {
  resetModal.classList.remove('hidden');
  playButtonSound();
}
```

### 7.2 Cancel Reset

```js
function hideResetModal() {
  resetModal.classList.add('hidden');
  playButtonSound();
}
```

### 7.3 Confirm Reset

```js
function confirmReset() {
  // Wipe all persistent data
  saveData = { ...DEFAULT_SAVE_DATA };
  writeSaveData(saveData);

  // Reset in-memory mute state
  isMuted = false;
  updateMuteButtons();

  // Clear last score display
  lastScoreDisplay.classList.add('hidden');

  // Update menu
  updateMenuStats();

  // Close modal
  resetModal.classList.add('hidden');

  playButtonSound();
}
```

> **What gets reset:**
> - High score → 0
> - Total games played → 0
> - Total points scored → 0
> - Mute preference → OFF
> - Last score display → hidden

---

## 8. Save Points (When Data is Written)

Data is written to localStorage **only** at these moments — not continuously:

| Trigger | What's Saved |
|---------|-------------|
| `gameOver()` | `highScore`, `totalGamesPlayed`, `totalPointsScored` |
| `quitToMenu()` | `highScore`, `totalGamesPlayed`, `totalPointsScored` |
| `toggleMute()` | `isMuted` |
| `confirmReset()` | Full reset to defaults |

> This minimises localStorage writes for performance and avoids unnecessary I/O during gameplay.

---

## 9. Element Visibility Per State

| Element | Menu | Playing | Paused | Disintegrating |
|---------|------|---------|--------|----------------|
| `#menuOverlay` | ✅ Visible | ❌ Hidden | ❌ Hidden | ❌ Hidden |
| `#scoreDisplay` | ❌ Hidden | ✅ Visible | ✅ Visible (dimmed) | ✅ Visible |
| `#pauseBtn` | ❌ Hidden | ✅ Visible | ❌ Hidden | ❌ Hidden |
| `#pauseOverlay` | ❌ Hidden | ❌ Hidden | ✅ Visible | ❌ Hidden |
| `#resetModal` | Conditionally | ❌ | ❌ | ❌ |
| Body cursor | Normal | Hidden | Normal | Normal |

---

## 10. Keyboard Shortcuts

| Key | Context | Action |
|-----|---------|--------|
| `Escape` | While `playing` | Pause the game |
| `Escape` | While `paused` | Resume the game |
| `Escape` | While `menu` + reset modal open | Close the reset modal |

---

## 11. Menu Layout (Updated Wireframe)

```
┌──────────────────────────────────────┐
│  (ambient falling balls behind)      │
│                                      │
│       ╔════════════════════╗         │
│       ║   BALL  CATCHER    ║         │
│       ╠════════════════════╣         │
│       ║                    ║         │
│       ║  HIGH SCORE: 350   ║  ← gold text
│       ║  LAST SCORE: 120   ║  ← sky-blue text (hidden until 1st game)
│       ║  ─ ─ ─ ─ ─ ─ ─ ─  ║  ← dashed pixel divider
│       ║  GAMES PLAYED: 14  ║  ← dimmer stats
│       ║  TOTAL POINTS: 2840║         │
│       ║                    ║         │
│       ║  ┌──────────────┐  ║         │
│       ║  │  START GAME  │  ║  ← primary button (mint-leaf)
│       ║  └──────────────┘  ║         │
│       ║                    ║         │
│       ║  [RESET DATA]  [🔊]║  ← small footer buttons
│       ╚════════════════════╝         │
│                                      │
└──────────────────────────────────────┘
```

---

## 12. Pause Overlay Wireframe

```
┌──────────────────────────────────────┐
│  Score: 120  (dimmed, still visible) │
│                                      │
│  ┄┄┄┄┄┄┄ frozen game frame ┄┄┄┄┄┄┄  │
│                                      │
│       ╔════════════════════╗         │
│       ║                    ║         │
│       ║      PAUSED        ║  ← gold text
│       ║                    ║         │
│       ║  ┌──────────────┐  ║         │
│       ║  │   CONTINUE   │  ║  ← primary button (mint-leaf)
│       ║  └──────────────┘  ║         │
│       ║  ┌──────────────┐  ║         │
│       ║  │ QUIT TO MENU │  ║  ← secondary button (blazing-flame outline)
│       ║  └──────────────┘  ║         │
│       ║       [🔊 SOUND]   ║  ← mute toggle
│       ║                    ║         │
│       ╚════════════════════╝         │
│                                      │
└──────────────────────────────────────┘
```

---

## 13. Full State & Storage Checklist

### Persistence
- [ ] All persistent data stored in localStorage under a single JSON key (`ballCatcherSaveData`).
- [ ] `highScore` is saved and displayed on the menu.
- [ ] `totalGamesPlayed` is incremented on each game over and quit, saved, and displayed on the menu.
- [ ] `totalPointsScored` accumulates across all games, saved, and displayed on the menu.
- [ ] `isMuted` preference persists across page refreshes.
- [ ] Data loads correctly on page load with fallback defaults.
- [ ] Data survives page refresh (verified via localStorage).

### Pause System
- [ ] Pause button (❚❚) visible during gameplay, positioned top-right.
- [ ] Clicking pause button or pressing `Escape` pauses the game.
- [ ] Paused state freezes all balls, basket, and spawning.
- [ ] Pause overlay shows **CONTINUE**, **QUIT TO MENU**, and **mute toggle**.
- [ ] Continue button or `Escape` resumes gameplay seamlessly.
- [ ] Quit to Menu saves the current score to stats and returns to menu.
- [ ] Pause button hidden in all states except `playing`.

### Mute System
- [ ] Mute button on the menu AND in the pause overlay.
- [ ] Both buttons stay synchronised (same label and visual state).
- [ ] When muted: all sound functions are silenced.
- [ ] When muted: vibration still works (independent of mute).
- [ ] Mute preference saved to localStorage immediately on toggle.
- [ ] Mute state restored on page load.
- [ ] Visual distinction: muted buttons show `🔇 SOUND: OFF` in blazing-flame colour with reduced opacity.

### Reset Data
- [ ] "RESET DATA" button on the menu.
- [ ] Clicking it shows a confirmation modal: "ERASE ALL DATA? THIS CANNOT BE UNDONE".
- [ ] Confirm erases all localStorage data and resets all displays to zero.
- [ ] Cancel closes the modal with no changes.
- [ ] `Escape` key also closes the reset modal.
- [ ] After reset, mute is also turned off.

### Buttons
- [ ] All new buttons follow the voxel theme: sharp edges, hard pixel shadows, press-down effect on `:active`.
- [ ] All new buttons play the button blip sound (respecting mute).

---

*End of State & Storage Plan*
