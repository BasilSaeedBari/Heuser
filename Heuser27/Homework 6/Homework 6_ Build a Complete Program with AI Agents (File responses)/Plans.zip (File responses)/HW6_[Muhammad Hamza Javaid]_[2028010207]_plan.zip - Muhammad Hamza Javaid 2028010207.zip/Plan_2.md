
Stage: (2. Visual Vibe) 
Architect model: (Claude Opus 4.6 (Thinking)) Builder model: (Gemini 3.8 Flash - Low) 
Result: (Gave the game a proper theme that looked really nice. The blocky aspects were delivered near perfectly. The text seemed quite small and unreadable, fixed later in sensory feedback.)
# 🎨 Ball Catcher — Visual & Vibe Plan (Voxel Arts Theme)

> **Companion to:** `PLAN.md` (core logic)
> **Purpose:** This document specifies every visual element, animation, effect, and styling detail. The implementer should apply this plan **on top of** the core logic plan.
> **Files affected:** `index.html`, `style.css`, `game.js` (same 3 files — no new files).

---

## 1. Colour Palette (Single Source of Truth)

Define these as CSS custom properties on `:root` in `style.css`. **All colours in the project must reference these variables — no hard-coded hex values elsewhere.**

```css
:root {
  --yale-blue:      #1b4965;
  --fresh-sky:      #00a7e1;
  --mint-leaf:      #00c49a;
  --royal-gold:     #f8e16c;
  --blazing-flame:  #ff3f00;
}
```

### Colour Assignments

| Element | Colour Variable | Notes |
|---------|----------------|-------|
| Page / canvas background | `--yale-blue` | Deep dark base for the voxel world |
| Basket | `--fresh-sky` | Bright and easy to track |
| Good ball colour pool | `--fresh-sky`, `--mint-leaf`, `--royal-gold`, `--blazing-flame` | Randomly pick one per ball |
| Bad balls | `#000000` (black) | Retains black per core plan; gets a pulsing `--blazing-flame` outline (see §5.3) |
| Menu background | `--yale-blue` at ~85% opacity | Semi-transparent dark overlay |
| Menu title text | `--royal-gold` | Bold, warm, eye-catching |
| High score / last score text | `--fresh-sky` | Cool contrast against gold title |
| Start button — default | Background: `--mint-leaf`, text: `--yale-blue` | |
| Start button — hover | Background: `--royal-gold`, text: `--yale-blue` | |
| Start button — active/pressed | Background: darkened `--mint-leaf`, shifted down (see §4.4) | |
| Score HUD text | `--royal-gold` | Stands out on dark canvas |
| Particle trail (basket) | `--fresh-sky` at fading opacity | |
| Catch pop particles (good ball) | Same colour as the caught ball | |
| Disintegration pixels (bad ball catch) | `--fresh-sky` (basket colour) | Basket shatters into its own colour |

---

## 2. Typography — Pixelated Font

### 2.1 Font Choice

Use **"Press Start 2P"** from Google Fonts. Since the game must be **fully offline**, the font must be **embedded**:

**Recommended approach — base64 embed:**
1. Download the `.woff2` file for "Press Start 2P" from Google Fonts.
2. Convert to a base64 data URI.
3. Embed it via a `@font-face` rule directly in `style.css`:

```css
@font-face {
  font-family: 'PixelFont';
  src: url('data:font/woff2;base64,...') format('woff2');
  /* OR link to a local file: src: url('./PressStart2P.woff2') format('woff2'); */
}
```

**Acceptable alternative — system fallback stack:**
If embedding is too complex, use this CSS-only fallback that still looks pixelated:
```css
font-family: 'Courier New', 'Lucida Console', monospace;
letter-spacing: 1px;
/* Apply CSS: font-smooth: never; -webkit-font-smoothing: none; */
```

> The implementer should prefer the embedded approach. If they choose the fallback, anti-aliasing must be disabled on all game text so it retains a blocky pixel look.

### 2.2 Font Usage

| Element | Size | Weight | Transform |
|---------|------|--------|-----------|
| Menu title (`<h1>`) | 32px – 40px | Normal (pixel fonts are naturally bold) | `text-transform: uppercase` |
| High score display | 14px – 16px | Normal | None |
| Last score display | 14px – 16px | Normal | None |
| Start button text | 16px – 18px | Normal | `text-transform: uppercase` |
| Score HUD (in-game) | 16px | Normal | None |
| Canvas-drawn text (if any) | Set `ctx.font` to the same pixel font at appropriate pt size | — | — |

---

## 3. Voxel Art Rendering Style

> **"Voxel Art"** = blocky, cube-like, pixel-art-inspired 3D. Everything should look like it's built from small cubes/blocks, with visible edges and depth.

### 3.1 Balls — Voxel Style

**Do NOT draw smooth circles.** Instead, draw each ball as a **pixelated square or diamond shape** that reads as a chunky voxel sphere:

**Method — stepped pixel block:**
Draw each ball as a stack of filled rectangles (like a sprite):
```
    ████
  ████████
  ████████
████████████
████████████
████████████
  ████████
  ████████
    ████
```

Implementation approach:
- Define a small 2D array pattern (e.g., 6×6 grid of 0s and 1s) representing the ball's pixel mask.
- Scale each cell to `pixelSize` (e.g., `BALL_RADIUS / 3`).
- Draw filled squares (`fillRect`) for each `1` in the mask.
- Use a slightly lighter shade on the top-left cells and a slightly darker shade on the bottom-right cells to create a **3D cube illusion**.

### 3.2 Basket — Voxel Style

Draw the basket as a **blocky tray** made of pixel blocks:
- The main body is a row of filled squares (like a Tetris piece lying flat).
- Add a **3D depth effect**:
  - Draw the top face in `--fresh-sky`.
  - Draw a 2–3 px strip on the bottom edge in a **darker shade** of `--fresh-sky` (simulating the side of a 3D block).
  - Draw a 1–2 px strip on the right edge in a **slightly darker shade** (right-side shadow).
- The basket should look like a small shelf or platform made of cubes.

### 3.3 Canvas Background — Voxel World Feel

Render a subtle **pixel grid** on the canvas background to reinforce the voxel theme:
- Draw faint grid lines (1px, `rgba(255,255,255,0.03)`) every 20–30 px across the entire canvas.
- OR draw a repeating pattern of tiny squares with very slight colour variation (`--yale-blue` ± 3–5% lightness).
- Keep it very subtle — it should not distract from gameplay.

---

## 4. Menu Overlay — Voxel Theme

### 4.1 Layout (update from PLAN.md)

The menu overlay now displays **three text items** (not two):

```
┌──────────────────────────────────────┐
│                                      │
│         ╔══════════════════╗         │
│         ║   BALL CATCHER   ║  ← Gold voxel title
│         ╠══════════════════╣         │
│         ║                  ║         │
│         ║  High Score: 120 ║  ← Fresh-sky text
│         ║  Last Score: 85  ║  ← Fresh-sky text (dimmer)
│         ║                  ║         │
│         ║  ┌────────────┐  ║         │
│         ║  │ START GAME │  ║  ← Mint-leaf button, sharp corners
│         ║  └────────────┘  ║         │
│         ╚══════════════════╝         │
│                                      │
└──────────────────────────────────────┘
```

### 4.2 HTML Addition

Add this element inside `#menuOverlay`, between the high score and the button:
```html
<p id="lastScoreDisplay" class="hidden">Last Score: 0</p>
```
- **Hidden on first load** (no game has been played yet).
- After the first game over, remove `.hidden` and update with the session's final score.

### 4.3 Menu Container Styling

The inner content area (the panel holding title, scores, button) should look like a **voxel panel / block**:
- `background: rgba(27, 73, 101, 0.92)` (yale-blue, near-opaque).
- **No border-radius** — sharp 90° corners everywhere (voxel = blocky).
- A **thick pixel border**: `border: 4px solid var(--fresh-sky);`
- **3D block shadow** — not a soft CSS `box-shadow`, but a **hard offset shadow** to mimic depth:
  ```css
  box-shadow:
    4px 4px 0px var(--yale-blue),
    8px 8px 0px rgba(0, 0, 0, 0.4);
  ```
- Padding: `40px 50px`.

### 4.4 Buttons — Sharp Edges + Press Effect

All buttons (`#startBtn` and any future ones):

```css
#startBtn {
  font-family: 'PixelFont', monospace;
  font-size: 16px;
  text-transform: uppercase;
  color: var(--yale-blue);
  background: var(--mint-leaf);
  border: 3px solid var(--yale-blue);
  border-radius: 0;                    /* SHARP EDGES — no rounding */
  padding: 14px 40px;
  cursor: pointer;
  position: relative;

  /* 3D raised effect */
  box-shadow:
    3px 3px 0px rgba(0, 0, 0, 0.5);
  transform: translateY(0);
  transition: transform 0.05s, box-shadow 0.05s;
}

#startBtn:hover {
  background: var(--royal-gold);
}

/* PRESSED STATE — button physically moves down */
#startBtn:active {
  transform: translateY(3px);
  box-shadow: 0px 0px 0px rgba(0, 0, 0, 0.5);   /* shadow disappears as button "sinks" */
}
```

> The button must feel like pressing a physical pixel button — it drops down by exactly the shadow offset, and the shadow collapses to zero. This creates a satisfying tactile illusion.

---

## 5. In-Game Visual Effects (JavaScript Canvas)

### 5.1 Basket Pixel Trail (Sliding Effect)

When the basket moves, it should leave behind a trail of small pixel squares that fade out:

**Data structure:**
```js
trailParticles = [];   // Array of { x, y, size, alpha, decay }
```

**On each frame (in `update()`):**
1. If `basket.x` has changed from the previous frame:
   - Emit 2–4 new trail particles at the basket's current position:
     ```js
     {
       x: basket.x + randomOffset(-basket.width/2, basket.width/2),
       y: basket.y + randomOffset(0, basket.height),
       size: randomInt(3, 6),       // small pixel blocks
       alpha: 0.7,                  // starting opacity
       decay: randomFloat(0.02, 0.05)  // how fast it fades
     }
     ```
2. For all existing trail particles:
   - `particle.alpha -= particle.decay`
   - Remove particle if `alpha <= 0`.

**On each frame (in `render()`, drawn BEFORE the basket):**
- For each trail particle:
  ```js
  ctx.fillStyle = `rgba(0, 167, 225, ${particle.alpha})`;  // --fresh-sky with fading alpha
  ctx.fillRect(particle.x, particle.y, particle.size, particle.size);  // square pixels, not circles
  ```

> The trail should look like tiny pixel cubes dissolving behind the basket as it slides.

### 5.2 Good Ball Catch — Pop Animation

When a good ball is caught, it should **pop** into a burst of small pixel particles:

**On catch (inside collision handler):**
1. Do NOT simply remove the ball. Instead, spawn 8–15 **pop particles** at the ball's last position:
   ```js
   {
     x: ball.x,
     y: ball.y,
     vx: randomFloat(-3, 3),        // random velocity X
     vy: randomFloat(-5, -1),       // upward burst
     size: randomInt(3, 6),
     color: ball.color,             // same colour as the caught ball
     alpha: 1.0,
     decay: randomFloat(0.03, 0.06),
     gravity: 0.15                  // particles arc downward
   }
   ```
2. Add these to a `popParticles` array.

**On each frame:**
- Update each pop particle:
  - `p.x += p.vx`
  - `p.vy += p.gravity`
  - `p.y += p.vy`
  - `p.alpha -= p.decay`
  - Remove if `alpha <= 0`.
- Render each as a filled square (`fillRect`) with the particle's colour and alpha.

> The effect: the ball shatters into a small firework of same-coloured pixel blocks.

### 5.3 Bad Ball Visual Distinction

Bad balls are black (`#000000`) but need extra distinction on the dark background:

1. **Pulsing outline:**
   - Draw a `strokeRect` (or stroke around the pixel pattern) in `--blazing-flame` (`#ff3f00`).
   - The stroke opacity oscillates using a sine wave: `alpha = 0.5 + 0.5 * Math.sin(frameCount * 0.1)`.
   - This creates a sinister red pulsing glow around the black ball.

2. **Skull / cross mark:**
   - Draw a small **pixel "X"** or **cross** in white or `--blazing-flame` on the centre of the bad ball.
   - Use `fillRect` calls to draw a 2-pixel-wide X across the ball's body.

### 5.4 Bad Ball Catch — Basket Disintegration

> This is the **game over animation**. When a bad ball is caught, the basket does NOT simply disappear. It **shatters into pixels**.

**Implementation:**

1. **On bad ball catch:**
   - Set a flag: `isDisintegrating = true`.
   - Set `gameState = "disintegrating"` (new temporary sub-state — gameplay stops, but the loop continues to animate the death effect).
   - Calculate the basket's pixel grid:
     - Divide the basket rectangle into a grid of small blocks (e.g., 6×3 grid of `~20px × ~7px` cells).
     - For each cell, create a disintegration particle:
       ```js
       {
         x: cellX,
         y: cellY,
         width: cellWidth,
         height: cellHeight,
         vx: randomFloat(-4, 4),
         vy: randomFloat(-6, 2),
         rotation: 0,
         rotationSpeed: randomFloat(-0.2, 0.2),
         gravity: 0.2,
         alpha: 1.0,
         decay: randomFloat(0.008, 0.02),
         color: '--fresh-sky value'   // basket colour
       }
       ```
   - Store these in a `disintegrationParticles` array.
   - **Also** spawn the bad ball's pop particles (as in §5.2, but in `--blazing-flame`).

2. **During `"disintegrating"` state (each frame):**
   - Do NOT update normal game logic (no spawning, no movement).
   - Update all disintegration particles:
     - `p.x += p.vx`
     - `p.vy += p.gravity`
     - `p.y += p.vy`
     - `p.rotation += p.rotationSpeed`
     - `p.alpha -= p.decay`
   - Render each particle as a rotated filled rectangle (use `ctx.save()`, `ctx.translate()`, `ctx.rotate()`, `ctx.fillRect()`, `ctx.restore()`).
   - The basket itself is **no longer drawn** — only its shattered pieces.
   - When **all** disintegration particles have `alpha <= 0` (fully faded), **OR** after a maximum of ~2 seconds (120 frames):
     - Transition to `"menu"` state.
     - Call the standard `gameOver()` flow (save score, show menu, etc.).

> The effect: the basket explodes into tumbling, falling, fading pixel shards — then the menu fades in.

---

## 6. 3D / Shadow Effects on All Elements

Every drawn element should have a subtle **hard-edged pixel shadow** to create depth. This is NOT a soft blur shadow — it's a **solid offset copy** drawn behind the main shape.

### 6.1 Method (Canvas)

For any element (ball, basket), before drawing the main shape:
1. Set `ctx.fillStyle` to `rgba(0, 0, 0, 0.3)`.
2. Draw the same shape offset by `(+3px, +3px)`.
3. Then draw the actual element on top in its real colour.

```js
// Example: drawing a voxel ball with shadow
function drawVoxelBall(ball) {
  // Shadow layer
  ctx.fillStyle = 'rgba(0, 0, 0, 0.3)';
  drawPixelPattern(ball.x + 3, ball.y + 3, ball.radius, BALL_PIXEL_MASK);

  // Main layer (slightly lighter top-left for 3D cube feel)
  ctx.fillStyle = ball.color;
  drawPixelPattern(ball.x, ball.y, ball.radius, BALL_PIXEL_MASK);

  // Highlight — top-left pixels drawn 10-15% lighter
  ctx.fillStyle = lighten(ball.color, 0.15);
  drawPixelPatternPartial(ball.x, ball.y, ball.radius, BALL_PIXEL_MASK, 'top-left');
}
```

### 6.2 CSS Shadows (Menu Elements)

For HTML elements (menu panel, buttons, score HUD), use **hard box-shadows** (no blur):
```css
box-shadow: 4px 4px 0px rgba(0, 0, 0, 0.5);
```

### 6.3 Text Shadows (Canvas & CSS)

For all text, apply a 2px hard offset shadow:
```css
text-shadow: 2px 2px 0px rgba(0, 0, 0, 0.5);
```
On canvas:
```js
// Draw shadow text first
ctx.fillStyle = 'rgba(0,0,0,0.5)';
ctx.fillText(text, x + 2, y + 2);
// Draw main text
ctx.fillStyle = actualColor;
ctx.fillText(text, x, y);
```

---

## 7. Score HUD Styling (In-Game)

The `#scoreDisplay` element should match the voxel theme:

```css
#scoreDisplay {
  position: fixed;
  top: 16px;
  left: 16px;
  font-family: 'PixelFont', monospace;
  font-size: 16px;
  color: var(--royal-gold);
  text-shadow: 2px 2px 0px rgba(0, 0, 0, 0.6);
  z-index: 5;
  /* Optional: pixel border box */
  background: rgba(27, 73, 101, 0.6);
  border: 2px solid var(--royal-gold);
  padding: 8px 14px;
  border-radius: 0;   /* sharp */
}
```

---

## 8. Game State Diagram (Updated)

The disintegration animation introduces a brief intermediate state:

```mermaid
stateDiagram-v2
    [*] --> Menu
    Menu --> Playing : Click "Start Game"
    Playing --> Disintegrating : Catch bad ball
    Disintegrating --> Menu : Animation complete (~2s)

    state Playing {
        [*] --> SpawnBalls
        SpawnBalls --> MoveBalls
        MoveBalls --> CheckCollisions
        CheckCollisions --> UpdateDifficulty : Good catch
        CheckCollisions --> SpawnBalls
    }

    state Menu {
        [*] --> ShowTitle
        ShowTitle --> ShowHighScore
        ShowHighScore --> ShowLastScore
        ShowLastScore --> ShowStartButton
    }
```

---

## 9. Menu — Last Score Display (Small Addition)

### 9.1 Behaviour

| Scenario | High Score Text | Last Score Text | Last Score Visible? |
|----------|----------------|-----------------|---------------------|
| First page load (no games played) | `HIGH SCORE: 0` (or stored value) | — | **Hidden** |
| After first game over (score 85) | `HIGH SCORE: 85` | `LAST SCORE: 85` | **Visible** |
| After second game (score 40, didn't beat high) | `HIGH SCORE: 85` | `LAST SCORE: 40` | **Visible** |
| After third game (score 200, new high!) | `HIGH SCORE: 200` | `LAST SCORE: 200` | **Visible** |

### 9.2 Implementation

In `gameOver()`:
```js
function gameOver() {
  const finalScore = score;

  // Update high score
  if (finalScore > highScore) {
    highScore = finalScore;
    try { localStorage.setItem(LOCAL_STORAGE_KEY, highScore); } catch(e) {}
  }

  // Update menu displays
  highScoreDisplay.textContent = `HIGH SCORE: ${highScore}`;
  lastScoreDisplay.textContent = `LAST SCORE: ${finalScore}`;
  lastScoreDisplay.classList.remove('hidden');   // always show after first game

  // ... rest of game over flow (show menu, etc.)
}
```

### 9.3 Styling

```css
#lastScoreDisplay {
  font-family: 'PixelFont', monospace;
  font-size: 14px;
  color: var(--fresh-sky);
  opacity: 0.7;                         /* slightly dimmer than high score */
  text-shadow: 2px 2px 0px rgba(0, 0, 0, 0.5);
  margin-top: 6px;
}
```

---

## 10. Full Visual Checklist

- [ ] All colours use the 5-colour palette via CSS variables.
- [ ] A pixelated/blocky font is used for ALL text (menu, HUD, canvas).
- [ ] Balls are drawn as **pixel block patterns**, not smooth circles.
- [ ] Basket is drawn as a **blocky 3D platform** with depth shading.
- [ ] Canvas background has a subtle pixel grid.
- [ ] Menu panel has sharp corners, pixel border, and hard offset shadow.
- [ ] Start button has sharp corners, 3D raised shadow, and **physically presses down** on click.
- [ ] Good balls **pop** into same-coloured pixel particles when caught.
- [ ] Bad balls are black with a **pulsing red outline** and a pixel **X** mark.
- [ ] Basket leaves a **fading pixel trail** when moved.
- [ ] Catching a bad ball triggers a **basket disintegration** animation (~2 seconds) before returning to menu.
- [ ] All elements (balls, basket, text) have a **hard 3px offset shadow** for depth.
- [ ] Menu shows **HIGH SCORE** (persisted) and **LAST SCORE** (current session, hidden until first game).
- [ ] No soft/blurred shadows anywhere — all shadows are hard-edged pixel-style.
- [ ] No rounded corners anywhere — all rectangles have `border-radius: 0`.
- [ ] The entire game works offline with no external resource fetches.

---

*End of Visual Plan*
