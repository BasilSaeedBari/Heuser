
Stage: (3. Sensory Feedback) 
Architect model: (Claude Opus 4.6 (Thinking)) Builder model: (Gemini 3.8 Flash - Low) 
Result: (Gave the game the appropriate sound effects, gave a gameplay a nice feel to it as the noises sound addicting.)
# 🔊 Ball Catcher — Sensory Feedback & Polish Plan

> **Companion to:** `PLAN.md` (core logic), `Plan_2.md` (visual vibe)
> **Purpose:** This document specifies all audio cues, haptic feedback (vibration), and additional visual polish. Apply this **on top of** both previous plans.
> **Files affected:** `index.html`, `style.css`, `game.js` (same 3 files — no new files).
> **Offline requirement:** All sounds must be generated programmatically using the **Web Audio API** — no external audio files.

---

## 1. Audio Engine Setup

### 1.1 AudioContext Initialisation

Create a single shared `AudioContext` instance. Browsers require user interaction before audio can play, so initialise it on the first user click.

```js
let audioCtx = null;

function ensureAudioContext() {
  if (!audioCtx) {
    audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  }
  if (audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
  return audioCtx;
}
```

- Call `ensureAudioContext()` at the start of every sound-playing function.
- Also call it inside the **Start button click handler** to guarantee unlock on first interaction.

### 1.2 Utility — Tone Generator

All sounds are built from combinations of **oscillators**, **gain envelopes**, and **noise bursts**. Define a reusable helper:

```js
function playTone({ frequency, type, duration, volume, rampDown, delay }) {
  const ctx = ensureAudioContext();
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();

  osc.type = type || 'square';           // 'square' and 'triangle' = pixel/chiptune feel
  osc.frequency.setValueAtTime(frequency, ctx.currentTime + (delay || 0));
  gain.gain.setValueAtTime(volume || 0.3, ctx.currentTime + (delay || 0));

  if (rampDown !== false) {
    gain.gain.exponentialRampToValueAtTime(
      0.001,
      ctx.currentTime + (delay || 0) + duration
    );
  }

  osc.connect(gain);
  gain.connect(ctx.destination);
  osc.start(ctx.currentTime + (delay || 0));
  osc.stop(ctx.currentTime + (delay || 0) + duration);
}
```

> All sound designs below are described as sequences of `playTone` calls. The implementer may fine-tune frequencies and timings, but the **character** of each sound must match the description.

---

## 2. Sound Effects — Definitions

### 2.1 Good Ball Collect Sound 🟢

> **Character:** Short, bright, cheerful chiptune "ping" — like picking up a coin in a retro game.

**Recipe:**
```js
function playCollectSound() {
  // Two quick ascending square-wave notes
  playTone({ frequency: 587,  type: 'square', duration: 0.07, volume: 0.25, delay: 0 });
  playTone({ frequency: 784,  type: 'square', duration: 0.10, volume: 0.25, delay: 0.06 });
}
```

- Two notes: D5 → G5 in quick succession.
- Total duration: ~160ms.
- Waveform: **square** (classic 8-bit feel).

### 2.2 Bad Ball Catch — Immediate Hit Sound 💀

> **Character:** Harsh, dissonant buzz/crunch — like taking damage in an NES game.

**Recipe:**
```js
function playDeathHitSound() {
  // Low harsh buzz
  playTone({ frequency: 120, type: 'sawtooth', duration: 0.15, volume: 0.35, delay: 0 });
  // Dissonant high stab
  playTone({ frequency: 250, type: 'square',   duration: 0.12, volume: 0.30, delay: 0.02 });
  // Noise crunch — use a very low frequency square oscillator for a "buzz" texture
  playTone({ frequency: 80,  type: 'square',   duration: 0.20, volume: 0.25, delay: 0.05 });
}
```

- Plays the **instant** the bad ball is caught (start of disintegration).
- Total duration: ~250ms.
- Waveform: **sawtooth + square** mix for harshness.

### 2.3 Game Over Melody — Nintendo-Style Dying Tune 🎵

> **Character:** The classic descending "wah wah wah wahhh" failure jingle — sad, slow, descending notes. Think Mario death or Zelda game-over.

**Recipe:**
```js
function playGameOverMelody() {
  // Descending minor melody — triangle wave for softer, sadder tone
  const notes = [
    { freq: 494, delay: 0,    dur: 0.25 },   // B4
    { freq: 466, delay: 0.28, dur: 0.25 },   // Bb4
    { freq: 440, delay: 0.56, dur: 0.25 },   // A4
    { freq: 349, delay: 0.84, dur: 0.5  },   // F4 (held longer — final sad note)
  ];

  notes.forEach(n => {
    playTone({
      frequency: n.freq,
      type: 'triangle',
      duration: n.dur,
      volume: 0.3,
      delay: n.delay
    });
  });
}
```

- Starts playing **after** the death hit sound, during the disintegration animation.
- Trigger timing: ~300ms after the bad ball catch (after the hit sound finishes).
- Total duration: ~1.35 seconds.
- Waveform: **triangle** (softer, more melancholic than square).

### 2.4 Game Start Melody — Nintendo-Style Initiation 🎮

> **Character:** Bright, energetic, ascending jingle — like selecting "Start" on an NES title screen. Uplifting and quick.

**Recipe:**
```js
function playStartSound() {
  // Ascending major arpeggio — square wave for punchy retro feel
  const notes = [
    { freq: 523, delay: 0,    dur: 0.10 },   // C5
    { freq: 659, delay: 0.10, dur: 0.10 },   // E5
    { freq: 784, delay: 0.20, dur: 0.10 },   // G5
    { freq: 1047,delay: 0.30, dur: 0.25 },   // C6 (held — triumphant top note)
  ];

  notes.forEach(n => {
    playTone({
      frequency: n.freq,
      type: 'square',
      duration: n.dur,
      volume: 0.25,
      delay: n.delay
    });
  });
}
```

- Plays when the **Start Game** button is clicked.
- Total duration: ~550ms.
- Game begins immediately alongside (or right after) this jingle — no need to wait for it to finish.

### 2.5 Button Press Sound (Generic UI) 🔘

> **Character:** Very short, snappy "click" / "blip" — like selecting a menu option in a retro game.

**Recipe:**
```js
function playButtonSound() {
  playTone({ frequency: 660, type: 'square', duration: 0.05, volume: 0.20 });
}
```

- Single short note, E5, 50ms.
- Plays on **mousedown** for any interactive button.
- For the Start button specifically, `playStartSound()` plays **instead** (not in addition to) this generic sound.

---

## 3. Sound Trigger Map

| Game Event | Sound Function | Timing |
|------------|---------------|--------|
| Good ball caught | `playCollectSound()` | Immediately on collision detection |
| Bad ball caught | `playDeathHitSound()` | Immediately on collision detection |
| Disintegration begins | `playGameOverMelody()` | ~300ms after bad ball catch (use `setTimeout`) |
| Start button clicked | `playStartSound()` | On click, before game state transition |
| Any other button mousedown | `playButtonSound()` | On `mousedown` event |

---

## 4. Haptic Feedback (Vibration API)

Use the **Vibration API** (`navigator.vibrate()`) for tactile feedback. This works on mobile browsers and some desktop environments. Always wrap in a capability check.

```js
function vibrate(pattern) {
  if (navigator.vibrate) {
    navigator.vibrate(pattern);
  }
}
```

### 4.1 Vibration Patterns

| Event | Vibrate Call | Description |
|-------|-------------|-------------|
| Good ball caught | `vibrate(50)` | Single short pulse — 50ms. Subtle confirmation. |
| Bad ball caught | `vibrate([100, 50, 200])` | Buzz-pause-BUZZ. 100ms hit, 50ms gap, 200ms long rumble. Feels alarming. |

### 4.2 Trigger Timing

- **Good catch:** Call `vibrate(50)` at the same moment as `playCollectSound()`.
- **Bad catch:** Call `vibrate([100, 50, 200])` at the same moment as `playDeathHitSound()`.

> Vibration is a progressive enhancement — the game must work perfectly without it. No errors if the API is unavailable.

---

## 5. Sensory Event Integration (Updated Game Flow)

### 5.1 Good Ball Catch — Full Sequence

```
Frame N:  Collision detected
          ├── playCollectSound()          🔊 Ping!
          ├── vibrate(50)                 📳 Short buzz
          ├── Spawn pop particles         💥 Visual burst (per Plan_2 §5.2)
          ├── Spawn "+10" floating text   ✨ Score notification (see §7)
          ├── score += SCORE_PER_GOOD_CATCH
          └── Update score HUD
```

### 5.2 Bad Ball Catch — Full Sequence

```
Frame N:  Collision detected
          ├── playDeathHitSound()         🔊 Harsh buzz!
          ├── vibrate([100, 50, 200])     📳 Alarming rumble
          ├── gameState = "disintegrating"
          ├── Spawn disintegration particles  💥 Basket shatters (per Plan_2 §5.4)
          ├── Spawn bad ball pop particles     💥 Ball explodes too
          └── setTimeout(playGameOverMelody, 300)  🎵 Sad jingle after 300ms

Frame N + ~120 (2s later):
          ├── gameOver()                  📊 Save scores, show menu
          └── Stop all particle systems
```

### 5.3 Start Game — Full Sequence

```
User clicks "Start Game":
          ├── playStartSound()            🎵 Ascending jingle
          ├── ensureAudioContext()         🔧 Unlock audio on first click
          └── startGame()                 🎮 Begin gameplay
```

---

## 6. Additional Visual Effect — Bold Text

> **All text across the game must be bold and highly readable.**

### 6.1 CSS Text (Menu, HUD)

Add `font-weight: bold` to the base font rule. Since pixel fonts like "Press Start 2P" don't have a true bold variant, **increase visibility through these combined techniques:**

```css
/* Global pixel text base */
h1, p, button, #scoreDisplay, #highScoreDisplay, #lastScoreDisplay {
  font-family: 'PixelFont', monospace;
  font-weight: bold;
  -webkit-text-stroke: 0.5px currentColor;   /* thickens pixel font glyphs slightly */
  text-shadow: 2px 2px 0px rgba(0, 0, 0, 0.7);  /* hard shadow for depth + readability */
}
```

### 6.2 Canvas-Drawn Text

When drawing text on the canvas (score notifications, any debug text):

```js
ctx.font = 'bold 16px PixelFont, monospace';
// Double-draw technique for extra boldness:
// 1. Shadow
ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
ctx.fillText(text, x + 2, y + 2);
// 2. Main text
ctx.fillStyle = color;
ctx.fillText(text, x, y);
// 3. Second pass slightly offset for pseudo-bold thickening
ctx.fillText(text, x + 1, y);
```

### 6.3 Menu Title Specifically

The game title `"BALL CATCHER"` should be extra prominent:

```css
#menuOverlay h1 {
  font-size: 36px;
  color: var(--royal-gold);
  text-shadow:
    3px 3px 0px rgba(0, 0, 0, 0.8),     /* depth shadow */
    0 0 10px rgba(248, 225, 108, 0.3);   /* subtle warm glow */
  letter-spacing: 4px;
}
```

---

## 7. Additional Visual Effect — "+N" Score Notification

When a good ball is caught, a floating **"+10"** text should appear at the catch point and drift upward while fading out.

### 7.1 Data Structure

```js
scoreNotifications = [];   // Array of active floating score texts

// Each entry:
{
  x: <ball's x position at catch>,
  y: <ball's y position at catch>,
  text: "+10",               // or "+20" etc. if scoring changes
  alpha: 1.0,
  vy: -1.5,                  // drifts upward
  life: 60,                  // frames to live (1 second at 60fps)
  color: ball.color           // same colour as the caught ball for visual harmony
}
```

### 7.2 Update Logic (each frame)

```js
for (let i = scoreNotifications.length - 1; i >= 0; i--) {
  const n = scoreNotifications[i];
  n.y += n.vy;
  n.life--;
  n.alpha = Math.max(0, n.life / 60);   // linear fade tied to remaining life

  if (n.life <= 0) {
    scoreNotifications.splice(i, 1);
  }
}
```

### 7.3 Render Logic

```js
scoreNotifications.forEach(n => {
  ctx.save();
  ctx.globalAlpha = n.alpha;
  ctx.font = 'bold 14px PixelFont, monospace';

  // Shadow
  ctx.fillStyle = 'rgba(0, 0, 0, 0.6)';
  ctx.fillText(n.text, n.x + 2, n.y + 2);

  // Main text
  ctx.fillStyle = n.color;
  ctx.fillText(n.text, n.x, n.y);

  ctx.restore();
});
```

### 7.4 Spawn Trigger

Inside the good-ball collision handler, **after** incrementing the score:

```js
scoreNotifications.push({
  x: ball.x,
  y: ball.y,
  text: `+${SCORE_PER_GOOD_CATCH}`,
  alpha: 1.0,
  vy: -1.5,
  life: 60,
  color: ball.color
});
```

> The notification appears right where the ball was caught, in the ball's own colour, floats upward, and fades away over ~1 second.

---

## 8. Additional Visual Effect — Menu Background Decoration

> The menu screen should not be a blank overlay. Add **decorative falling balls and a static basket** in the background to hint at the gameplay.

### 8.1 Behaviour

When `gameState === "menu"`:
- The canvas behind the semi-transparent menu overlay shows an **ambient animation**:
  - Several balls (using the good-ball colour palette) **slowly drift downward** across the canvas.
  - A **static basket** sits at the bottom-centre, purely decorative (does not move).
  - Balls that fall past the bottom respawn at the top with a new random X and colour.
  - No collision detection, no scoring — purely cosmetic.

### 8.2 Implementation

```js
const menuBalls = [];         // Separate array from gameplay balls
const MENU_BALL_COUNT = 8;    // Enough to fill the background without cluttering

function initMenuBalls() {
  menuBalls.length = 0;
  for (let i = 0; i < MENU_BALL_COUNT; i++) {
    menuBalls.push(createMenuBall(randomY = true));
    // randomY = true means spawn at a random Y (not just the top)
    // so the screen is pre-filled on load, not empty
  }
}

function createMenuBall(randomY) {
  return {
    x: randomInt(BALL_RADIUS, canvas.width - BALL_RADIUS),
    y: randomY
      ? randomInt(-BALL_RADIUS, canvas.height)
      : -BALL_RADIUS,
    radius: BALL_RADIUS,
    speed: randomFloat(0.5, 1.5),        // slow, gentle drift
    color: GOOD_BALL_COLORS[randomInt(0, GOOD_BALL_COLORS.length - 1)],
    isBad: false                          // no black balls in menu — keep it inviting
  };
}
```

### 8.3 Menu Render (in `render()`)

When `gameState === "menu"` or `gameState === "disintegrating"`:

```js
// 1. Clear canvas with background colour
// 2. Draw subtle grid (per Plan_2 §3.3)
// 3. Update & draw menu balls (slow fall, wrap to top)
menuBalls.forEach(ball => {
  ball.y += ball.speed;
  if (ball.y - ball.radius > canvas.height) {
    Object.assign(ball, createMenuBall(false));  // respawn at top
  }
  drawVoxelBall(ball);  // same voxel drawing function as gameplay balls
});
// 4. Draw static decorative basket at bottom-centre
drawBasket({ x: canvas.width / 2, y: canvas.height - BASKET_Y_OFFSET, width: BASKET_WIDTH, height: BASKET_HEIGHT });
```

> The effect: the menu feels alive and thematic. The player immediately understands the game concept before pressing Start.

### 8.4 Menu Overlay Opacity

To ensure the decorative background is visible, the menu overlay's backdrop opacity should be adjusted:

```css
#menuOverlay {
  background: rgba(27, 73, 101, 0.70);   /* 70% — lets the animated balls show through */
}
```

---

## 9. Full Sensory Checklist

### Audio
- [ ] Web Audio API `AudioContext` is created and unlocked on first user interaction.
- [ ] **Collect sound**: Short ascending 2-note square-wave ping on good ball catch.
- [ ] **Death hit sound**: Harsh low sawtooth + square buzz on bad ball catch.
- [ ] **Game over melody**: Descending 4-note triangle-wave sad jingle, plays ~300ms after death hit.
- [ ] **Start jingle**: Ascending 4-note square-wave major arpeggio on Start button click.
- [ ] **Button blip**: Single short square-wave note on generic button press.
- [ ] All sounds use **square** or **triangle** waveforms (chiptune/pixel aesthetic).
- [ ] No external audio files — everything is synthesised via Web Audio API.

### Haptic
- [ ] **Good catch**: `navigator.vibrate(50)` — short pulse.
- [ ] **Bad catch**: `navigator.vibrate([100, 50, 200])` — alarming pattern.
- [ ] Vibration is wrapped in a capability check — no errors if unsupported.

### Visual Polish (Additions from this plan)
- [ ] All text is **bold** with `-webkit-text-stroke` and hard text-shadows for maximum readability.
- [ ] **"+N" floating score notification** appears at catch point, drifts up, fades over ~1 second.
- [ ] Notification uses the **caught ball's colour** for visual harmony.
- [ ] Menu background shows **ambient falling balls** (8 slow-drifting colourful balls) and a **static basket**.
- [ ] Menu overlay is 70% opacity so background decoration is visible.
- [ ] Menu title has extra large font, letter-spacing, and warm glow shadow.
- [ ] All sensory feedback is **synchronised** — sound, vibration, and visual effects trigger on the same frame.

---

*End of Sensory Plan*
