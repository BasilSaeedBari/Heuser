# 🌿 Visual Vibe — Implementation Plan
**Capybara Virtual Pet · Stage: Visual Vibe**
**Architect:** Claude Sonnet 4.6 · **Builder:** Claude Sonnet 4.6

---

## Overview

This plan details every visual and structural change required to bring the capybara game's aesthetic to the "early-2000s preppy scrapbook" vision. All changes are made to the existing [`index.html`](file:///Users/macbook/Desktop/index.html), [`style.css`](file:///Users/macbook/Desktop/style.css), and [`script.js`](file:///Users/macbook/Desktop/script.js). No new files or external assets are introduced.

> [!IMPORTANT]
> All gameplay logic (pet, feed, wave, restart, scene unlock, save/load) is preserved exactly. Only visual presentation changes.

---

## 1 · Typography

| What | Change |
|---|---|
| Font import | Replace `Nunito + Fredoka One` with `Fredoka One` as the primary display font + keep `Nunito` as fallback |
| `--primary-font` | `'Fredoka One', 'Nunito', system-ui` |
| `.preppy-text` | Increase `letter-spacing` to `0.04em`, keep thick white + dark caramel shadow stack |
| Dialogue text | Font size ↑ to `1rem`, weight stays `800`, white with `#5C1A00` outline |

**Why Fredoka One:** Thick, chunky, perfectly rounded, early-2000s retro. Already imported.

---

## 2 · Background System

### 2a. Radial warm vignette — keep structure, refine values
Current: white edges → warm lemon centre. Enhance to:
- Bond 0: pure white, almost sterile. No warmth at all.
- Bond 25+: faint cream aureole at centre (`#FFFDE7`)
- Bond 40+: honey gold centre bleeding out (`#FFF9C4`)
- Bond 60+: golden warm centre (`#FFEE58`)
- Bond 100: deep amber warmth (`#FFD54F`)

```css
/* Updated bond-level background values */
.scene-bond-0   { --bg-warm-centre: #FFFFFF; --bg-mid: #FFFFFF; }
.scene-bond-25  { --bg-warm-centre: #FFFDE7; --bg-mid: #FFFFFF; }
.scene-bond-40  { --bg-warm-centre: #FFF9C4; --bg-mid: #FFFDE7; }
.scene-bond-60  { --bg-warm-centre: #FFEE58; --bg-mid: #FFF9C4; }
.scene-bond-100 { --bg-warm-centre: #FFD54F; --bg-mid: #FFE566; }
```

The radial gradient will use two custom properties: `--bg-warm-centre` (innermost) and a mid-stop.

### 2b. Camera zoom effect

Add a CSS transform on `.viewport` keyed to bond level classes:
```
bond-0:  scale(0.78) — distant view
bond-25: scale(0.85)
bond-50: scale(0.93)
bond-75: scale(1.0)
bond-100: scale(1.08) — intimate close-up
```
Apply `transform-origin: center 60%` so zoom centres on the capybara, not the top of the frame. Use `transition: transform 2.5s ease`.

---

## 3 · Dialogue Box

- **Colour:** Change from pink (`#FFB7C5`) → warm yellow (`#FFD700`)
- **Border:** `3px solid #E6A800`
- **Glow:** `box-shadow: 0 0 0 3px #FFFFFF, 0 0 20px 8px rgba(255,215,0,0.6), 0 2px 8px rgba(0,0,0,0.15)` — always glowing gold
- **Text colour:** `#FFFFFF` with `#5C2A00` shadow (darker brown for contrast on yellow bg)
- **Font:** `Fredoka One`, size `1rem`
- **Tail pointer:** Keep right-pointing, update border-left-color to `#FFD700`

---

## 4 · Small Rounded Yellow Rectangle ("name tag" near capybara)

Add a new `<div class="capy-nametag">Capy</div>` inside `.capybara-wrapper`, positioned below and slightly right of the capybara. Style:
- Yellow rounded rectangle (`background: #FFD700`, `border-radius: 10px`)
- White preppy text, 0.7rem
- Slight shadow
- Always visible

---

## 5 · Main Scene SVG Improvements

### 5a. Cabbage Sandwich (complete SVG rebuild inside dock)

Replace the current CSS-only sandwich with an inline SVG (60×48px viewBox) showing:
- **Bottom bun:** Rounded rectangle, warm tan gradient (`#DEB887 → #C8A060`), sesame dots
- **Lettuce layer:** Ruffled green path, multiple overlapping curves (`#66BB6A`, `#43A047`)
- **Tomato slice:** Red ellipse with highlight
- **Cheese slice:** Yellow-orange trapezoid (`#FFB300`) peeking out the side
- **Top bun:** Rounded dome with shine highlight + sesame dots
- Overall: visually layered, mouth-watering

### 5b. Toy Doll (replaces dog bowl)

Replace `.dog-bowl` CSS element with a small inline SVG toy doll (40×56px):
- Round head (pale peach), dot eyes, tiny smile
- Dress/body (pink or yellow triangle shape)
- Stubby arms
- Yarn-like hair loops
- Cute + simple, clearly recognisable

### 5c. Sun on main scene

The existing `.sun-or-hotspring` with CSS rays is good but position it in the scene background layer. At bond-0 it's invisible; it fades in at bond-25. Keep existing spin animation, slightly enlarge to `72px`.

### 5d. Construction Hat

Already exists. Ensure it's properly clickable (keep existing toggle logic). Visually refine with slightly thicker brim, more saturated yellow.

---

## 6 · Bottom Frills / Tablecloth Decoration

**This is the most complex visual element.** Replace the CSS `.grass-ground` bottom element logic to coexist with a new `<div class="tablecloth-frills">` layer.

### Implementation: Inline SVG tablecloth

A `<div class="tablecloth-frills">` absolutely positioned at the bottom, `height: 22-25% of viewport`, `width: 100%`, `z-index: 3`.

Inside it, an `<svg>` with `width="100%" height="100%" preserveAspectRatio="xMidYMid slice"` containing:

```
Layer 1 (top edge): Intricate zigzag border with small diamond points, pale yellow (#FFF9C4)
Layer 2 (fabric body): Warm golden fill (#FFE566) with:
  - Repeating floral SVG pattern (rose-inspired petals arranged in grid)
  - Lace-like `<path>` tracery overlay (thin stroked lines forming botanical lattice)
  - Golden ornamental borders at top edge
Layer 3 (bottom hem): Deeper gold rectangle (#FFD700) with scalloped points
```

#### Floral pattern (SVG `<pattern>` element):
```xml
<pattern id="tablecloth-pattern" x="0" y="0" width="60" height="60" patternUnits="userSpaceOnUse">
  <!-- Rose motif: 5 petals around centre -->
  <!-- Leaves -->
  <!-- Lace diamond overlay -->
</pattern>
```

The tablecloth sits behind the capybara and feed dock but above the background. Grass ground strip will be a narrower element layered on top.

---

## 7 · Vines & Flowers Redesign

### 7a. Vine stems — organic/messy

Replace the straight CSS `::before` pseudo-element vine stem with organic SVG paths. Two `<svg>` elements (`.foliage-left` and `.foliage-right`) each containing:
- A `<path>` with cubic bezier curves that meander and curl, not straight
- Multiple `<path>` branches forking off the main stem
- Stroke: `#2E7D32` to `#66BB6A`, `stroke-width: 4-6px`, `stroke-linecap: round`
- `fill: none`

The SVGs already exist as CSS positioned divs — replace their `::before` pseudo with actual inline SVG content via HTML.

### 7b. Vine flowers — rose-inspired

Replace generic `.vine-flower` circles with mini SVG roses:
```xml
<svg class="vine-rose" viewBox="0 0 20 20">
  <!-- 5 petals (ellipses rotated around centre) -->
  <!-- Inner petals slightly darker -->
  <!-- Sepals (green points) -->
</svg>
```

Colours: mix of `#E91E63` (crimson rose), `#FF7043` (coral), `#AB47BC` (violet), `#FFF176` (cream), `#EF5350` (red).

### 7c. Vines draping over dialogue box

Add a `.vine-drape` div absolutely positioned, `z-index: 31` (above dialogue box at z-30). Contains SVG paths representing hanging vine tendrils. Positioned at top-left of the game container, curves sweep to drape over the dialogue box region. Visible at bond ≥ 55.

---

## 8 · Wave / Goodbye Button Redesign

### 8a. Remove restart button

- Remove `<button id="restart-btn">` from HTML
- Remove its event listener in JS (keep the restart modal + `confirmResetBtn` logic — still accessible via goodbye modal)
- Remove `.restart-btn` CSS

### 8b. Wave button redesign

Replace plain `.wave-btn` with an ornate sign:

```html
<div class="wave-sign-wrapper" id="wave-btn-wrapper">
  <!-- Tablecloth pattern border (mini version of bottom frills) -->
  <div class="wave-sign-border"></div>
  <button id="wave-btn" class="wave-sign-btn preppy-text" title="Wave goodbye to capybara">
    <svg class="wave-icon" ...><!-- hand wave SVG --></svg>
    <span>It's time to say goodbye.</span>
  </button>
</div>
```

Style:
- Yellow rectangular sign: `background: #FFD700`, rounded corners
- Intricate border using `border-image` or SVG pattern (mini tablecloth motif)
- Text: "It's time to say goodbye." in preppy font, white
- Wave icon: 👋 or custom SVG hand

---

## 9 · Second Scene (Scene 2)

### 9a. Dreamy white background

When `.scene-2` active:
- Override background to pure white radial (`#FFFFFF → #F8F8FF`)
- Clouds: brighter, more prominent, slightly larger
- Orchids: already exist — refine petals to look more realistic (layered SVG)
- Egret: already exists — improve to have neck arch, beak, wing detail via CSS

### 9b. Scene badge text

Change "Scene 2: Hot Springs ♨️" → "Scene 2: Clouds & Orchids ☁️" (more fitting to dreamy aesthetic).

---

## 10 · Hover Tooltips (Optional)

Add `title` attributes + CSS custom tooltips:

```html
<!-- Bonding bar hover -->
<div class="stat-card" data-tooltip="Feeding and petting grows your bond with Capy.">

<!-- Salad item -->
<div id="salad-item" ... data-tooltip="Drag onto Capy to feed — builds bond!">

<!-- Wave button -->
<button id="wave-btn" ... data-tooltip="Say goodbye and end the journey.">
```

CSS tooltip:
```css
[data-tooltip]:hover::after {
  content: attr(data-tooltip);
  position: absolute;
  /* styled bubble */
}
```

---

## 11 · Implementation Sequence

The changes will be applied in this order to minimize risk of breakage:

1. **Typography** — `style.css` only, no logic change
2. **Dialogue box colour** — `style.css` only
3. **Nametag element** — add HTML div, add CSS
4. **Cabbage sandwich SVG** — replace HTML inside `.cabbage-sandwich`, update CSS
5. **Toy doll SVG** — replace `.dog-bowl` HTML div, update CSS
6. **Bottom tablecloth frills** — add HTML `<div class="tablecloth-frills">` SVG, add CSS
7. **Vine/flower SVG overhaul** — replace foliage HTML content + CSS
8. **Vine drape over dialogue** — add HTML element, CSS
9. **Background camera zoom** — `style.css` only
10. **Wave button redesign** — HTML + CSS
11. **Remove restart button** — HTML + JS + CSS
12. **Scene 2 refinements** — CSS only
13. **Hover tooltips** — HTML + CSS

---

## 12 · Files Changed Summary

| File | Type of Change |
|---|---|
| [`index.html`](file:///Users/macbook/Desktop/index.html) | Sandwich SVG, doll SVG, nametag div, tablecloth div, vine SVG content, wave sign wrapper, drape vine div |
| [`style.css`](file:///Users/macbook/Desktop/style.css) | Typography, colours, zoom, tablecloth, vine/flower, dialogue, wave sign, hover tooltips, scene-2 |
| [`script.js`](file:///Users/macbook/Desktop/script.js) | Remove restart button event listener (1 line) |

> [!NOTE]
> Functionality preserved: pet, feed, wave/goodbye, restart-via-modal, save/load, scene unlock, head posture, construction hat toggle, drag-and-drop.

> [!TIP]
> The tablecloth bottom frills SVG pattern is the most time-intensive element. It should be built as a self-contained SVG `<defs><pattern>` block for easy tweaking.

---

## 13 · Risk & Mitigations

| Risk | Mitigation |
|---|---|
| SVG sandwich too small to read | Use `viewBox` with generous coordinate space, scale via CSS `width/height` |
| Tablecloth SVG pattern performance | Use `<pattern>` with `patternUnits="userSpaceOnUse"` — renders statically, no animation |
| Vine drape z-index conflict with dialogue | Vine drape: `z-index: 31`, pointer-events: none — dialogue still interactive |
| Restart button removal breaking JS | Remove the single `restartBtn.addEventListener` line in `initEventListeners()` |
| Camera zoom cutting off dialogue box | Zoom applied to `.viewport` inner content only, not `.top-bar` or `.game-footer` |
