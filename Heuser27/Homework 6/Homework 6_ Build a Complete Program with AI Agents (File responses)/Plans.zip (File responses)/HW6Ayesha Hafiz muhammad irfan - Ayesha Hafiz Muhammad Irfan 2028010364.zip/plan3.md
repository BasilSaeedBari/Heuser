# Plan 3 — Sensory Feedback System

> **Scope:** CSS animations, JavaScript event-driven feedback, and Web Audio API synthesized sounds for the Capybara Virtual Pet. Zero external audio files or libraries.
Stage:sensrs Architect model: Claude  opus 4.6 (Thinking) Builder model: (pending)
---

## Architecture Overview

```mermaid
flowchart TD
    A["User Interaction"] --> B{"Event Type"}
    B --> C["🐾 Petting"]
    B --> D["🥬 Feeding"]
    B --> E["📓 Scrapbook"]
    B --> F["💬 Dialogue"]
    B --> G["📊 Progress"]
    B --> H["👋 Goodbye"]

    C --> C1["CSS: squish → bounce-back"]
    C --> C2["SVG: floating heart particle"]
    C --> C3["Audio: soft 'boop' + purr"]

    D --> D1["CSS: salad translates toward capy"]
    D --> D2["CSS: happy wiggle reaction"]
    D --> D3["Audio: crunch + satisfied hum"]

    E --> E1["CSS: white notebook overlay fades in"]
    E --> E2["JS: spawn angled capy stickers"]
    E --> E3["CSS: stickers scatter-in, then fade out"]
    E --> E4["Audio: paper rustle + stamp sounds"]

    F --> F1["JS: eye blinks 2–3 times"]
    F --> F2["CSS: dialogue fades on touch"]
    F --> F3["Audio: soft 'pip' per blink"]

    G --> G1["CSS: vine scaleY grows"]
    G --> G2["CSS: cloud drift keyframes"]
    G --> G3["CSS: flower opacity bloom"]
    G --> G4["Audio: ambient nature loop"]

    H --> H1["CSS: gentle opacity fade-out"]
    H --> H2["JS: final farewell message"]
    H --> H3["Audio: lullaby chord → silence"]
    H --> H4["JS: stopAllAudio()"]
```

---

## §1 — Audio Engine (`CapyAudio`)

A singleton class wrapping the Web Audio API. All sounds are procedurally synthesized — no external files.

| Sound | Technique | Trigger |
|---|---|---|
| **Boop** (pet) | Short sine oscillator 440→520 Hz, fast decay envelope | `handlePet()` |
| **Purr** (pet) | Low filtered noise (80 Hz), 600 ms sustain | `handlePet()` after boop |
| **Crunch** (feed) | White noise burst through bandpass 2 kHz, 80 ms | `handleFeed()` |
| **Happy hum** (feed) | Triangle wave chord (C4+E4+G4), 400 ms swell | After crunch |
| **Paper rustle** (scrapbook) | Filtered noise sweep 1→4 kHz, 200 ms | Scrapbook open |
| **Stamp** (scrapbook) | Click — square wave 120 Hz, 30 ms | Each sticker lands |
| **Pip** (blink) | Tiny sine 880 Hz, 50 ms, very quiet | Each eye blink |
| **Ambience** | Brown noise + sine LFO for wind, looping | Game init |
| **Crickets** | Rapid sine chirps 4–5 kHz, randomized timing | Game init (layered) |
| **Lullaby chord** (goodbye) | Soft pad: triangle waves C4+E4+G4+C5, 3 s fade | `handleWave()` |
| **Vine grow** | Rising sine sweep 200→800 Hz, 1.5 s | Bond threshold cross |
| **Flower bloom** | Gentle bell: sine 1200 Hz × decaying AM | Flower appears |

### Audio lifecycle

```
initGame() → CapyAudio.init() → starts ambience + crickets (quiet)
handleWave() confirmed → CapyAudio.playLullaby() → CapyAudio.stopAll() 
                          (fade all nodes to 0 over 3 s, then disconnect)
```

> [!IMPORTANT]
> `AudioContext` is created on the **first user gesture** (click/touch anywhere) to comply with browser autoplay policy. A one-time `'click'` listener on `document` calls `CapyAudio.init()`.

---

## §2 — Petting Feedback

### 2a. Squish + Bounce-back (CSS)

Replace the existing `petBounce` keyframes with a two-phase squish animation:

```css
@keyframes petSquishBounce {
  0%   { transform: scale(1, 1); }
  20%  { transform: scale(1.08, 0.92) translateY(4px); }   /* squish down */
  50%  { transform: scale(0.95, 1.07) translateY(-8px); }  /* bounce up */
  75%  { transform: scale(1.02, 0.98) translateY(2px); }   /* settle */
  100% { transform: scale(1, 1) translateY(0); }
}
```

Duration: **500 ms**, easing: `cubic-bezier(0.34, 1.56, 0.64, 1)`.

### 2b. Floating Heart (already exists — enhance)

- Current: emoji `❤️` / `✨` spawned in SVG layer.
- **Enhancement:** Add gentle horizontal sway via CSS `floatUpSway` keyframe with `translateX(±15px)` oscillation during rise. Increase lifetime to 1.4 s. Add random size variation (0.8–1.2×).

### 2c. Audio

- `CapyAudio.playBoop()` on pet start.
- `CapyAudio.playPurr()` 150 ms later.

---

## §3 — Feeding Feedback

### 3a. Salad Flies to Capybara (CSS + JS)

On drop/feed trigger:

1. JS calculates vector from salad's current position to capybara's mouth (`cx≈245, cy≈130` in SVG space → screen coords).
2. Applies CSS class `salad-flying` with custom properties `--fly-x`, `--fly-y`.
3. Keyframe `saladFlyToCapy` translates + scales down to 0 over 400 ms.
4. On `animationend`, hide salad, trigger chomp reaction, then reset salad after 1.6 s.

```css
@keyframes saladFlyToCapy {
  0%   { transform: translate(0, 0) scale(1) rotate(0deg); opacity: 1; }
  70%  { transform: translate(var(--fly-x), var(--fly-y)) scale(0.5) rotate(-20deg); opacity: 0.9; }
  100% { transform: translate(var(--fly-x), var(--fly-y)) scale(0) rotate(-30deg); opacity: 0; }
}
```

### 3b. Happy Reaction (CSS)

After salad arrives, capybara plays `happyWiggle`:

```css
@keyframes happyWiggle {
  0%, 100% { transform: rotate(0deg); }
  20%      { transform: rotate(-4deg) scale(1.03); }
  40%      { transform: rotate(3deg) scale(1.05); }
  60%      { transform: rotate(-2deg) scale(1.03); }
  80%      { transform: rotate(1deg); }
}
```

Plus happy-squint eyes and extra heart burst (2–3 hearts).

### 3c. Audio

- `CapyAudio.playCrunch()` when salad hits.
- `CapyAudio.playHappyHum()` 200 ms later.

---

## §4 — Scrapbook Overlay

### 4a. Trigger

New function `showScrapbook()` called when bonding crosses **50%** for the first time (one-shot event, tracked via `state.scrapbookShown`).

### 4b. White Notebook Background

A full-screen overlay (`#scrapbook-overlay`) with:
- Background: `#FFFEF9` (off-white notebook paper).
- Subtle ruled lines via repeating-linear-gradient (faint blue, 28px spacing).
- Red margin line at left 60px.
- Spiral binding dots along the left edge.
- Fade-in over 400 ms.

### 4c. Capybara Stickers

JS spawns 8–12 `<div class="capy-sticker">` elements, each containing a small clone of the capybara SVG head (simplified). Each sticker:
- Random position (10–90% x, 10–85% y).
- Random rotation (−25° to +25°).
- Random scale (0.7–1.3).
- CSS animation `stickerSlap`: scales from 1.5→1.0 with a slight bounce, like being slapped onto paper.
- Staggered by `animation-delay: i * 120ms`.

### 4d. Disappearance

After all stickers land (~1.8 s), hold for 1.5 s, then fade entire overlay out over 800 ms. Remove overlay DOM on `transitionend`.

### 4e. Audio

- `CapyAudio.playPaperRustle()` on overlay open.
- `CapyAudio.playStamp()` per sticker land (staggered).

---

## §5 — Dialogue Blink + Fade

### 5a. Blink on Appear

When `showDialogue()` is called, the capybara's eye blinks 2–3 times:

```js
function blinkSequence(count = 2 + Math.round(Math.random())) {
  let i = 0;
  const interval = setInterval(() => {
    eyeBall.setAttribute('ry', '0.5');    // squish eye shut
    eyeSparkle.style.opacity = '0';
    CapyAudio.playPip();
    setTimeout(() => {
      eyeBall.setAttribute('ry', '4');    // reopen
      eyeSparkle.style.opacity = '1';
    }, 120);
    if (++i >= count) clearInterval(interval);
  }, 300);
}
```

### 5b. Fade on Touch

Add a click/touch listener on `#dialogue-container`:
- On touch, add class `dialogue-fading` (CSS: `opacity 0` over 500 ms, slight `translateY(-6px)`).
- After transition, call `hideDialogue()`.
- Audio: quiet `playPip()`.

---

## §6 — Progress Feedback

### 6a. Growing Vines

Already implemented via `.foliage` CSS (scaleY 0→1 at bonding ≥ 40). **Enhance:**
- Add `vineGrow` keyframe with slight overshoot bounce.
- Play `CapyAudio.playVineGrow()` sound when the class is first applied.

### 6b. Drifting Clouds

Already have `cloud-drift` keyframe. **Enhance:**
- Add a third cloud (`.cloud-3`) positioned at `top: 5%; right: 15%` with a 35 s drift cycle.
- Clouds subtly change opacity between 0.6 and 0.95 via added `cloud-breathe` keyframe.

### 6c. Gradually Appearing Flowers

Already have vine-flower opacity transition. **Enhance:**
- Add `flowerBloom` keyframe: scale 0→1.1→1 with slight rotation.
- Each flower gets staggered `animation-delay` (0, 0.4 s, 0.8 s, etc.).
- Play `CapyAudio.playFlowerBloom()` on first appearance.

---

## §7 — Goodbye Sequence

### 7a. Gentle Fade-out

When goodbye is confirmed:

1. `CapyAudio.playLullaby()` — soft sustained chord.
2. `#game-container` receives class `goodbye-fading`:
   ```css
   .goodbye-fading {
     animation: gentleFadeOut 3s ease-out forwards;
   }
   @keyframes gentleFadeOut {
     0%   { opacity: 1; filter: brightness(1); }
     60%  { opacity: 0.7; filter: brightness(1.1) saturate(0.8); }
     100% { opacity: 0.15; filter: brightness(1.2) saturate(0.3) blur(2px); }
   }
   ```
3. At 2.5 s, show `#farewell-message` centered in viewport:
   > *"Goodbye"*
4. At 4 s, `CapyAudio.stopAll()` — all audio nodes faded to 0 and disconnected.
5. At 5 s, show goodbye modal with restart option.

### 7b. Audio Shutdown

```js
stopAll() {
  // Fade master gain to 0 over 2s
  this.masterGain.gain.linearRampToValueAtTime(0, this.ctx.currentTime + 2);
  // After 2.5s, suspend context
  setTimeout(() => this.ctx.suspend(), 2500);
}
```

---

## §8 — Ambient Soundscape

### 8a. Gentle Ambience

- **Brown noise** generated via `AudioBuffer` with lowpass filter at 200 Hz.
- Volume: very quiet (gain 0.04).
- Starts on first user gesture, loops indefinitely.

### 8b. Crickets

- Timer-based chirps: every 2–5 s (randomized), play a burst of 3–6 rapid sine pings at 4200–5000 Hz.
- Each ping: 40 ms, gain 0.015.
- Layered on top of ambience.
- Both stop on goodbye.

---

## §9 — Implementation Checklist

| # | Task | File | Status |
|---|---|---|---|
| 1 | `CapyAudio` class — all synthesis methods | `script.js` | ⬜ |
| 2 | Squish-bounce keyframe replacement | `style.css` | ⬜ |
| 3 | Enhanced floating heart sway | `style.css` | ⬜ |
| 4 | Salad fly-to-capy animation + JS | `style.css` + `script.js` | ⬜ |
| 5 | Happy wiggle reaction | `style.css` | ⬜ |
| 6 | Scrapbook overlay HTML | `index.html` | ⬜ |
| 7 | Scrapbook JS logic + stickers | `script.js` | ⬜ |
| 8 | Scrapbook CSS animations | `style.css` | ⬜ |
| 9 | Dialogue blink sequence JS | `script.js` | ⬜ |
| 10 | Dialogue fade-on-touch CSS + JS | `style.css` + `script.js` | ⬜ |
| 11 | Third cloud + cloud-breathe | `index.html` + `style.css` | ⬜ |
| 12 | Flower bloom keyframe + stagger | `style.css` | ⬜ |
| 13 | Vine grow sound trigger | `script.js` | ⬜ |
| 14 | Goodbye fade-out + farewell msg | All three files | ⬜ |
| 15 | Ambient + crickets audio loop | `script.js` | ⬜ |
| 16 | `stopAllAudio()` on goodbye | `script.js` | ⬜ |

---

## §10 — File Change Summary

| File | Lines Added (est.) | Nature |
|---|---|---|
| `script.js` | ~280 | CapyAudio class, blink logic, scrapbook, salad fly, goodbye sequence |
| `style.css` | ~140 | New keyframes, scrapbook overlay, dialogue fade, flower bloom, cloud-3 |
| `index.html` | ~25 | Scrapbook overlay div, cloud-3, farewell message div |
