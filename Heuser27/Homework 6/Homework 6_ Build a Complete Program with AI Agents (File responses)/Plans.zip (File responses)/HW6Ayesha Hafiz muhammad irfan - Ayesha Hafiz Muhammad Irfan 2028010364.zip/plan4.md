# 🌿 Plan 4 — Persistence & Goodbye Hardening
Stage: state and storae **
**Architect:** Claude Sonnet 4.6 · **Builder:** Claude Sonnet 4.6
## Goal
Ensure all four persistence requirements hold for the Capybara Virtual Pet:
1. Refreshing does **not** erase progress
2. Closing and reopening **restores** the game correctly
3. Scene transitions **restore** correctly on reload
4. The **goodbye ending** works and acts like a full reset

---

## Diagnosis

### What was already working ✅
| Requirement | Mechanism | Status |
|---|---|---|
| Refresh preserves stats | `saveGame()` called on every pet & feed | ✅ |
| Close/reopen loads stats | `loadGame()` on `initGame()` | ✅ |
| Scene 2 persists | `state.scene` saved in `saveGame()` | ✅ |
| Scene 2 CSS restores | `updateUI()` applies `scene-2` / `scene-bond-X` classes | ✅ |
| Orchids / egret / foliage visual | Pure CSS via `scene-bond-X` selector — no JS needed | ✅ |
| Goodbye → Restart journey clears state | `executeRestart()` → `clearSaveData()` | ✅ |
| Modal / overlay cleanup on restart | `goodbye-fading`, `farewellMessage` removed in `handleGoodbyeRestart()` | ✅ |

### Bugs Fixed in Plan 4

#### Bug 1 — Milestone flags not derived from loaded bonding
**File:** [`script.js`](file:///Users/macbook/Desktop/script.js)  
**Lines:** [`loadGame()` — 571–600](file:///Users/macbook/Desktop/script.js#L571-L600)

`vinesGrownSoundPlayed` and `flowersSoundPlayed` defaulted to `false` on every page load. Although the `checkBondingMilestones()` threshold logic (using `prevBonding < threshold`) prevented most double-fires, this wasn't safe by design — it relied on the bonding never being exactly on the threshold boundary after load.

**Fix:** After restoring `state.bonding` from localStorage, derive both flags:
```js
if (state.bonding >= 40) state.vinesGrownSoundPlayed = true;
if (state.bonding >= 55) state.flowersSoundPlayed = true;
```
This guarantees that vine grow and flower bloom sounds never re-fire on thresholds already crossed in a previous session.

---

#### Bug 2 — Restart doesn't persist the clean state
**File:** [`script.js`](file:///Users/macbook/Desktop/script.js)  
**Lines:** [`executeRestart()` — 1079–1107](file:///Users/macbook/Desktop/script.js#L1079-L1107)

After `executeRestart()`, `clearSaveData()` removed the localStorage key but `saveGame()` was never called with the fresh defaults. If the player triggered Goodbye → Restart, then immediately closed the tab (before any further interaction), the next session would load with no save data and use hardcoded defaults — which happened to be the same values, but only by coincidence.

**Fix:** Call `saveGame()` immediately after `clearSaveData()` in `executeRestart()`:
```js
clearSaveData();
saveGame(); // persist the clean-slate so a re-open matches the restart
```

---

## State Persistence Map

```mermaid
flowchart TD
    A["User Action\n(pet / feed)"] --> B["saveGame()"]
    B --> C["localStorage: capybara_pet_data"]
    C --> D["happiness, bonding, scene,\nlastDialogueIndex, scrapbookShown"]

    E["Page Load / Refresh"] --> F["loadGame()"]
    F --> G["Restore from localStorage"]
    G --> H["Derive milestone flags\nfrom bonding level"]
    H --> I["updateUI() — applies\nscene-bond-X, scene-1/2 classes"]

    J["Goodbye → Restart"] --> K["executeRestart()"]
    K --> L["Reset state to defaults\nhappiness=30, bonding=0, scene=1"]
    L --> M["clearSaveData()"]
    M --> N["saveGame() — persists clean slate"]
    N --> O["updateUI() — fresh render"]
```

---

## Scene Transition Restore Flow

When `scene=2` is saved:
1. `loadGame()` sets `state.scene = 2`
2. `updateUI()` removes `scene-1`, adds `scene-2`
3. `sceneBadgeEl` updated to "Scene 2: Clouds & Orchids ☁️"
4. `yuzuAccessory` `.hidden` removed (yuzu on capy's head shown)
5. All orchids / egret / advanced foliage show via CSS `scene-bond-X` selectors

> [!NOTE]
> The transition overlay animation only plays once during `triggerSceneUnlock()` — it does **not** replay on reload. Scene 2 is silently restored, which is the correct UX.

---

## Goodbye Ending State Machine

```mermaid
sequenceDiagram
    participant U as User
    participant G as Game JS
    participant A as Audio
    participant DOM as DOM

    U->>G: clicks Wave btn
    G->>G: state = GOODBYE
    G->>A: playLullaby()
    G->>DOM: add goodbye-fading class
    Note over G: 2.5s delay
    G->>DOM: show farewellMessage
    Note over G: 4s delay
    G->>A: stopAll()
    Note over G: 5s delay
    G->>DOM: show goodbyeModal

    alt "Stay with Capybara"
        U->>DOM: click Stay btn
        DOM->>G: handleGoodbyeStay()
        G->>DOM: hide modal + farewell + remove fading
        G->>A: resumeAll()
        G->>G: state = IDLE
    else "Restart Journey"
        U->>DOM: click Restart btn
        DOM->>G: handleGoodbyeRestart()
        G->>DOM: hide modal + farewell + remove fading
        G->>G: executeRestart()
        G->>G: reset all state to defaults
        G->>G: clearSaveData() + saveGame()
        G->>A: resumeAll()
        G->>G: state = IDLE
        G->>DOM: updateUI() — fresh scene 1
    end
```

---

## Files Changed

| File | Lines Changed | Description |
|---|---|---|
| [`script.js`](file:///Users/macbook/Desktop/script.js) | `loadGame()` +5 lines | Derive milestone flags from loaded bonding |
| [`script.js`](file:///Users/macbook/Desktop/script.js) | `executeRestart()` +1 line | Save clean state after reset |
