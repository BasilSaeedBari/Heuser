# 🌿 Capybara Virtual Pet — Core Logic

**Stage:** Core Logic
**Architect model:** Claude Sonnet 4.6 (Thinking)
**Builder model:** *(pending)*

---

## 1. Game States

The game exists in exactly one state at a time.

| State | Description |
|---|---|
| `IDLE` | Default. Capybara is present, waiting for interaction. |
| `BEING_PET` | Player has tapped the capybara. Dialogue fires, bonding ticks. |
| `BEING_FED` | Salad has been dragged onto the capybara. Feed sequence runs. |
| `SCENE_UNLOCK` | Bonding threshold reached. Transition to scene 2 begins. |
| `GOODBYE` | Wave button pressed. Goodbye ending triggers. |
| `GAME_OVER_RESTART` | Restart confirmed. All progress resets. |

> [!NOTE]
> `BEING_PET` and `BEING_FED` are mutually exclusive. If a feed drag begins while dialogue is mid-display, the dialogue is dismissed and feed takes priority.

---

## 2. Stats Tracked

### 2a. Happiness
- Range: `0–100`
- Starts at: `30` *(slightly sad)*
- Increases from petting and feeding.
- Does not decrease unless explicitly extended later.
- Governs head posture (see §6).

### 2b. Bonding Progress
- Range: `0–100`
- Starts at: `0`
- Acts as the primary unlock currency.
- Increased by petting and feeding (feeding gives more).
- Never decreases.

---

## 3. Controls & Interactions

### 3a. Tap to Pet
- **Trigger:** Player taps the capybara sprite.
- **Effect:**
  - Happiness `+5`
  - Bonding `+3`
  - A random dialogue line is selected and displayed.
  - Dialogue must not repeat the last shown line (see §4).
- **Cooldown:** None — but the state must return to `IDLE` before another tap registers.

### 3b. Drag Salad to Feed
- **Trigger:** Player drags the salad item and releases it over the capybara's hit area.
- **Effect:**
  - Happiness `+10`
  - Bonding `+8`
  - A short "nom" or feeding acknowledgement plays (non-dialogue, no repeat rule applied).
- **Constraint:** Salad must be dragged from its fixed position. It snaps back after the interaction resolves.

### 3c. Wave Button
- **Trigger:** Player presses the wave button (always visible).
- **Effect:** Transitions immediately to `GOODBYE` state.
- **Constraint:** Disabled during active `BEING_FED` or `BEING_PET` state resolution. Re-enables at `IDLE`.

### 3d. Restart
- **Trigger:** Player confirms restart prompt.
- **Effect:**
  - Happiness reset to `30`
  - Bonding reset to `0`
  - Dialogue history cleared
  - Current scene reset to scene 1
  - Saved data wiped
- **Requires:** Explicit confirmation (two-step: prompt → confirm).

---

## 4. Dialogue System

- A pool of dialogue lines is defined (minimum 8 lines recommended).
- On each pet, one line is selected **at random**.
- **No-consecutive-repeat rule:** The index of the last shown line is stored. The random selection re-rolls until a different index is chosen.
  - If the pool has only 1 line, the rule is waived.
- Dialogue is displayed for a fixed duration, then dismissed. State returns to `IDLE`.
- Dialogue pool does not change with bonding level (can be extended later).

---

## 5. Progress Rules & Scene Unlock

### Unlock Threshold
- Scene 2 unlocks when **Bonding ≥ 70**.
- The transition fires once and is permanent (does not revert if happiness drops).

### Unlock Sequence
1. Bonding reaches `70`.
2. State switches to `SCENE_UNLOCK`.
3. A brief transition moment occurs (no visuals defined here).
4. Scene 2 becomes the active scene.
5. Progress is saved immediately.

### Scene 2 Behaviour
- Same controls apply (tap, feed, wave).
- Bonding and happiness carry over.
- Wave button in scene 2 triggers the same `GOODBYE` ending.

---

## 6. Head Posture — Bonding Mapping

Head position is a **derived value** computed from current bonding. It is not stored separately.

| Bonding Range | Head State |
|---|---|
| `0–20` | Fully lowered *(starts here)* |
| `21–40` | Slightly raised |
| `41–60` | Midpoint — neutral |
| `61–80` | Mostly lifted |
| `81–100` | Fully upright |

- Transitions between head states are **gradual and subtle**.
- Head state updates after every interaction that changes bonding.
- Head state is read-only logic; no manual override.

---

## 7. Ending Conditions

### 7a. Goodbye Ending
- **Triggered by:** Wave button.
- **Condition:** No bonding threshold required — available at any time.
- **Sequence:**
  1. State → `GOODBYE`
  2. Capybara performs goodbye acknowledgement.
  3. Final screen shown.
  4. Options: *Restart* or *Stay* (returns to `IDLE` in current scene).

### 7b. Scene 2 Reached *(soft ending / continuation)*
- Reaching scene 2 is a milestone, not a hard ending.
- The game continues in scene 2 until the goodbye ending is triggered.

---

## 8. Save & Persist

### What Is Saved
| Key | Value |
|---|---|
| `happiness` | Current happiness value |
| `bonding` | Current bonding value |
| `scene` | `1` or `2` |
| `lastDialogueIndex` | Index of last shown dialogue line |

### Save Triggers
- After every interaction that changes a stat.
- Immediately upon scene unlock.
- Immediately upon restart (clears save).

### Load Behaviour
- On game launch, saved data is loaded if present.
- If no save exists, game starts fresh with defaults.
- Corrupted or missing keys fall back to defaults individually.

---

## 9. Interaction Priority (Conflict Resolution)

If multiple inputs could fire simultaneously:

1. **Feed** takes highest priority.
2. **Pet** takes second priority.
3. **Wave** is locked out during active state resolution.
4. **Restart** is only accessible from a menu, never accidentally triggerable.

---

## 10. State Transition Summary

```
IDLE
 ├─ tap capybara      → BEING_PET   → IDLE
 ├─ drag salad onto   → BEING_FED   → IDLE
 ├─ wave button       → GOODBYE     → IDLE (stay) or GAME_OVER_RESTART
 └─ bonding ≥ 70     → SCENE_UNLOCK → IDLE (scene 2)

GAME_OVER_RESTART    → IDLE (scene 1, stats reset)
```
