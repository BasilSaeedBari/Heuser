

# Plan 5: Capybara Virtual Pet Changes
Claude Sonnet 5.5,
Based on `index.html`, `style.css` and `script.js`. Nothing has been changed yet.

## 1. Remove text and emojis

- **Emojis:** strip them from the stat labels, modals, transition card, feed popup, scrapbook sticker text and the dock's sun icon. The floating hearts are emoji too, so redraw them as small pixel-style hearts in SVG. Capy still reacts when petted.
- **Head posture and state text:** delete the footer line ("State: IDLE • Head Posture…"). The head still moves, it just isn't announced.
- **Scene change:** delete the "Scene 1/2" badge and the "Scene 2 Unlocked!" overlay. The background and decorations shift quietly with no message.

## 2. Pixel Operator font everywhere

- Pixel Operator isn't on Google Fonts, so the font file needs to be placed in the project folder (check the licence on its download page). Load it with `@font-face` and drop the Fredoka and Nunito links.
- Replace the hard-coded Fredoka references (dialogue, tooltips). Buttons and SVG text don't inherit fonts by default, so they need explicit rules too.
- Use sizes in multiples of 16px so the pixels stay sharp.

## 3. Dialogue on the frill

- Remove the floating yellow speech box and its tail. The line of dialogue is written directly onto the yellow frill, in the lower area left of the Treats dock.
- Use dark text, or white with an outline, whichever reads better on the lace pattern.
- The hanging vine tendrils are currently attached to the old box, so move them to drape from the frill's top edge.
- The scene scales with bonding, so keep the text from shrinking too small at low bond.

## 4. Frill cleanup

Assumption: "bottom of rectangle looks weird" means the darker gold hem band along the bottom of the frill. Remove that band and its line. If something else was meant, such as the Treats dock, this needs to be confirmed.

## 5. Realistic flowers

Everything stays pure SVG/CSS, with no image files.

- **Yellow roses:** layered spiral petals with gradients from pale to deep gold, darker petal edges and soft shadows. They replace the pink, purple and red vine roses.
- **Orchids (the star):** moth orchids with wide upper petals, spotted lips and arching stems carrying several blooms, in white, yellow and soft pink. They are larger and more numerous than now.
- Build each flower once and reuse it, so the page stays light.

## 6. Messier, more detailed vines

- Generate the vines in code with a fixed random seed: wobbly main stems, side branches, curling tendrils and a few drooping strands.
- Vary leaf size and shade, add veins, and make some leaves yellowing.
- Left and right vines are different, not mirrored.
- Vines cross the top corners and trail along the frill, with a gentle sway.

## 7. Fallen leaves and fuller background

- Scatter many leaves in autumn colours (yellow, amber, brown, some green) across the ground and frill, with varied sizes and rotations.
- Keep them out of the dialogue area so text stays readable.
- **Open decision:** should leaves, roses and orchids build up as bonding grows (keeps the "sterile to warm" arc), or be present from the start? Suggested: build up.

## 8. Bug fixes

- **Salad not reappearing:** the salad is only reset by the feeding timer, and restart cancels that timer without resetting it. Reproduce it first. The fix is a single `resetSalad()` that clears every leftover class and inline style, called after feeding, on "Stay with Capybara" and on restart.
- **Blurred goodbye and reset text:** there are two causes.
  - The goodbye modal and "Goodbye" text sit inside the container that fades to 15% opacity and blurs, so they inherit it. Apply the fade to a separate layer behind them instead.
  - The button text carries the dark outline shadow, which smears it. Give the buttons clean text with no outline.

## Open questions

- The original message ended at "add d", so part of it appears to have been cut off. What was being added?
- Leaves, roses and orchids: build up with bonding, or present from the start?
