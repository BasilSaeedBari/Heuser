Stage: Debugging & Bug List
Architect model: GPT-4o High-Reasoning
Builder model: GPT-4o-mini
Result: Inspected edge cases such as rapid clicking causing negative stat bounds or stuck audio context policies.

**Bug List:**
1. **AudioContext Browser Block:** Browsers block audio until user interaction. *Fix:* Initialized the Web Audio API context lazily upon the first click action handler.
2. **Stat Overflow / Underflow:** Rapid button mashing pushed stats past 100 or below 0. *Fix:* Implemented strict clamping using `Math.min(100, ...)` and `Math.max(0, ...)`.
3. **Infinite Stat Drain during Sleep:** Stats continued draining rapidly while the pet was sleeping. *Fix:* Adjusted interval loop logic to regenerate energy and halt hunger depletion when `isSleeping` is true.