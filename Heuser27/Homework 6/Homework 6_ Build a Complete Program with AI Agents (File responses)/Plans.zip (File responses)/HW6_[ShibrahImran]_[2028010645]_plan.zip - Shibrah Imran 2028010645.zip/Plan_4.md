# 🗂️ Ocean Catch — Stage 4: State & Storage Plan

**Stage:** State and Storage
**Architect Model:** (Claude Sonnet) **Builder Model:** Gemini Flash
**Result:** (Tested localStorage persistence (bestScore, isMuted, active game state snapshot), page reloads, pause toggles (P / Escape), and the "Reset Data" button.Added nullish coalescing and safe try/catch fallbacks around localStorage reads/writes.)

---

## 📋 What Must Be Remembered

| Data | Type | When Saved | When Loaded | Reset On |
|------|------|------------|-------------|----------|
| `bestScore` | `number` | Every time score exceeds it | Page load (before first frame) | Never (intentional only via "Clear Data") |
| `isMuted` | `boolean` | Every time the user toggles mute | Page load | Never |
| `fallSpeed` | `number` | Every frame while PLAYING | On **Continue** after pause | Full reset |
| `spawnInterval` | `number` | Every frame while PLAYING | On **Continue** after pause | Full reset |
| `score` | `number` | Every frame while PLAYING | On **Continue** after pause | Full reset |
| `lives` | `number` | Every frame while PLAYING | On **Continue** after pause | Full reset |
| `speedTimer` | `number` | Every frame while PLAYING | On **Continue** after pause | Full reset |
| `nextMilestoneIndex` | `number` | Every frame while PLAYING | On **Continue** after pause | Full reset |

> [!NOTE]
> `items[]`, `particles[]`, `scorePopups[]`, `bubbles[]`, and `seabedPlants[]` are **not** persisted — they are transient visual state that is too large and unnecessary to save. On resume after a true page refresh mid-game, the game restores score/lives/speed and starts with a clean item set.

---

## 🗄️ Where It Is Saved — `localStorage`

All persistence uses the **Web Storage API (`localStorage`)** — no server, no cookies, no files.  
Works offline, survives page refresh, and is scoped to the same origin.

### Storage Key Schema

```js
const STORAGE_KEY = "oceanCatch_v1"; // version prefix — bump if schema changes

// Everything in one JSON blob
const schema = {
  bestScore: 0,       // all-time high score
  isMuted: false,     // audio preference
  savedGame: null     // null when no game in progress, object when paused mid-game
};

// savedGame shape (only written when PAUSED):
const savedGameSchema = {
  score: 0,
  lives: 3,
  fallSpeed: 3,
  spawnInterval: 80,
  speedTimer: 0,
  spawnTimer: 0,
  nextMilestoneIndex: 0,
  comboStreak: 0
};
```

### Helper Functions (add to `script.js`)

```js
// ── Storage Helpers ──────────────────────────────────────────────────────────

function loadStorage() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : { bestScore: 0, isMuted: false, savedGame: null };
  } catch (e) {
    return { bestScore: 0, isMuted: false, savedGame: null }; // graceful fallback
  }
}

function saveStorage(patch) {
  try {
    const current = loadStorage();
    localStorage.setItem(STORAGE_KEY, JSON.stringify({ ...current, ...patch }));
  } catch (e) {} // quota errors silently ignored
}

function clearSavedGame() {
  saveStorage({ savedGame: null });
}
```

---

## 🔄 Game State Machine

The game currently has 3 states. Stage 4 adds a 4th: **`PAUSED`**.

```mermaid
stateDiagram-v2
    [*] --> START : page load
    START --> PLAYING : click DIVE IN
    PLAYING --> PAUSED : press P / Escape / click ⏸
    PAUSED --> PLAYING : click CONTINUE / press P
    PAUSED --> START : click MAIN MENU
    PLAYING --> GAMEOVER : lives reach 0
    GAMEOVER --> PLAYING : click RESTART (full reset)
    GAMEOVER --> START : click MAIN MENU
```

### State Variable

```js
// Extends existing:  "START" | "PLAYING" | "GAMEOVER"
// New value added:
let gameState = "START"; // | "PLAYING" | "PAUSED" | "GAMEOVER"
```

---

## ⏸️ PAUSE State — Full Specification

### How to Trigger Pause
| Input | Action |
|-------|--------|
| `P` key | Toggle pause while PLAYING |
| `Escape` key | Pause (not unpause — avoids accidental resume) |
| Click **⏸ PAUSE** button on HUD | Toggle pause |

### What Happens on Pause
1. `gameState` → `"PAUSED"`
2. `update()` stops running (game loop still ticks for the overlay animation)
3. Bubbles and background keep animating (`updatePassiveEffects()` still runs)
4. The in-progress game state is **saved to `localStorage`** immediately

```js
function pauseGame() {
  if (gameState !== "PLAYING") return;
  gameState = "PAUSED";
  saveStorage({
    savedGame: {
      score,
      lives,
      fallSpeed,
      spawnInterval,
      speedTimer,
      spawnTimer,
      nextMilestoneIndex,
      comboStreak
    }
  });
}
```

### What Happens on Resume
1. `gameState` → `"PLAYING"`
2. `clearSavedGame()` — mid-game snapshot cleared (we're live again)
3. `hitPauseFrames` reset to 0

```js
function resumeGame() {
  if (gameState !== "PAUSED") return;
  gameState = "PLAYING";
  hitPauseFrames = 0;
  clearSavedGame();
}
```

---

## 🔃 Reset Button — Full Specification

### Where It Appears
| Screen | Button Label | Behaviour |
|--------|-------------|-----------|
| PAUSE overlay | **🔄 RESTART** | Full game reset → `"PLAYING"` |
| PAUSE overlay | **🏠 MAIN MENU** | Full game reset → `"START"` |
| GAME OVER screen | **🔄 DIVE AGAIN** | Full game reset → `"PLAYING"` (already exists) |
| GAME OVER screen | **🏠 MAIN MENU** | Full game reset → `"START"` (new button) |

### Updated `resetGame()` — Only Add `clearSavedGame()`

```js
function resetGame() {
  score = 0;
  lives = 3;
  items = [];
  particles.length = 0;
  scorePopups.length = 0;
  spawnTimer = 0;
  spawnInterval = 80;
  fallSpeed = 3;
  speedTimer = 0;
  player.x = (canvas.width - player.width) / 2;
  playerGlowTimer = 0;
  dangerVignetteTimer = 0;

  // Sensory feedback resets (Stage 3 — unchanged)
  comboStreak = 0;
  comboDisplayTimer = 0;
  hitPauseFrames = 0;
  netSquash = 1.0;
  netSquashTimer = 0;
  nextMilestoneIndex = 0;
  milestoneBanner = null;
  lastLifePulseTimer = 0;
  slowMotionFactor = 1.0;
  slowMotionTimer = 0;
  gameOverPending = false;
  shakeIntensity = 0;

  // ── NEW Stage 4 ──
  clearSavedGame();  // ← only new line
}
```

> [!IMPORTANT]
> `bestScore` is **never** reset by `resetGame()`. It only gets updated when `score > bestScore` during play, and it persists in `localStorage` indefinitely.

---

## 📂 Page Load — Restore on Refresh

Add this block **once at startup**, before `gameLoop()` is called:

```js
// ── Stage 4: Startup — Load Persistent State ─────────────────────────────────
(function initStorage() {
  const data = loadStorage();

  // 1. Always restore high score and mute preference
  bestScore = data.bestScore ?? 0;
  isMuted   = data.isMuted   ?? false;

  // 2. If a mid-game save exists, offer "CONTINUE" on the START screen
  if (data.savedGame) {
    hasSavedGame = true; // flag that shows the CONTINUE button
  }
})();
```

### New flag
```js
let hasSavedGame = false; // true when localStorage has a paused mid-game snapshot
```

### "CONTINUE" on the START Screen

When `hasSavedGame === true`, the START screen shows a second button:

```
[ 🌊 DIVE IN ]        ← new fresh game
[ ▶ CONTINUE ]        ← resume from where you left off
```

Clicking **CONTINUE**:

```js
function continueGame() {
  const data = loadStorage();
  if (!data.savedGame) return;
  const s = data.savedGame;

  // Restore in-progress state
  score              = s.score;
  lives              = s.lives;
  fallSpeed          = s.fallSpeed;
  spawnInterval      = s.spawnInterval;
  speedTimer         = s.speedTimer;
  spawnTimer         = s.spawnTimer;
  nextMilestoneIndex = s.nextMilestoneIndex;
  comboStreak        = s.comboStreak ?? 0;

  // Items are gone — that's fine, they'll spawn fresh
  items = [];

  gameState    = "PLAYING";
  hasSavedGame = false;
  clearSavedGame(); // consumed — remove snapshot
}
```

---

## 🖥️ PAUSE Screen Design

Drawn by a new `drawPauseScreen()` function, called from `draw()` when `gameState === "PAUSED"`:

```
[Live ocean background + bubbles still animate]
[Semi-transparent dark overlay — rgba(0, 10, 25, 0.78)]

        ⏸  PAUSED               ← #87CEEB, bold 30px, glow

   Score so far:  240            ← #FFBF00, 20px
   Best Score:    310            ← #87CEEB, 16px
   Lives left:  ❤️ ❤️            ← hearts

   [ ▶  CONTINUE ]              ← Azure button, resumes game
   [ 🔄  RESTART  ]             ← Resets fully, starts new game
   [ 🏠  MAIN MENU ]            ← Resets fully, goes to START
```

**Button regions (canvas 480 wide):**

| Button | x range | y range |
|--------|---------|---------|
| CONTINUE | 180 → 300 | 330 → 370 |
| RESTART | 180 → 300 | 385 → 420 |
| MAIN MENU | 180 → 300 | 435 → 470 |

---

## 🏆 High Score — Save on Every Catch

The existing update already does `if (score > bestScore) bestScore = score;`.  
Stage 4 adds **one line** after that:

```js
if (score > bestScore) {
  bestScore = score;
  saveStorage({ bestScore }); // ← persist immediately
}
```

---

## 📡 `localStorage` Save Triggers Summary

| Trigger | What is Written |
|---------|----------------|
| Score beats `bestScore` during play | `bestScore` |
| User toggles mute (`M` key / mute button) | `isMuted` |
| `pauseGame()` called | Full `savedGame` snapshot |
| `resumeGame()` called | `savedGame: null` |
| `resetGame()` called | `savedGame: null` |
| `continueGame()` called | `savedGame: null` |
| Page loads | Read-only (no write) |

---

## 🧩 Implementation Layer Map

```
script.js (additions only — no existing lines deleted)
  │
  ├── STORAGE_KEY constant
  ├── loadStorage()
  ├── saveStorage(patch)
  ├── clearSavedGame()
  │
  ├── hasSavedGame flag
  ├── continueGame()
  ├── pauseGame()
  ├── resumeGame()
  │
  ├── initStorage()  ← IIFE at bottom, before gameLoop()
  │
  ├── resetGame()    ← +1 line: clearSavedGame()
  ├── update()       ← bestScore save: +1 line
  │
  ├── keydown handler
  │     └── 'P' / 'Escape' → pauseGame() / resumeGame()
  │
  ├── canvas click handler
  │     ├── PAUSED state: CONTINUE / RESTART / MAIN MENU buttons
  │     ├── START state:  CONTINUE button (if hasSavedGame)
  │     └── GAMEOVER state: MAIN MENU button (new)
  │
  ├── draw()
  │     └── case "PAUSED": drawPauseScreen()
  │
  └── drawPauseScreen()   ← NEW visual function
        ├── drawBackground() + drawBubbles() + drawSeabed()   (reuses existing)
        └── overlay + score display + 3 buttons
```

---

## ✅ Stage 4 "Done When" Checklist

- [ ] `localStorage` key `oceanCatch_v1` present after first play
- [ ] `bestScore` survives a full browser refresh
- [ ] Mute preference (`isMuted`) survives a full browser refresh
- [ ] Pressing `P` or `Escape` during play freezes items and shows PAUSE screen
- [ ] Pressing `P` again (or clicking CONTINUE) resumes from exact score/lives/speed
- [ ] PAUSE screen shows current score, best score, and lives remaining
- [ ] Closing and reopening the tab while paused shows a **CONTINUE** button on START
- [ ] Clicking CONTINUE restores score, lives, speed — items spawn fresh
- [ ] Clicking RESTART on PAUSE screen resets fully and starts a new game
- [ ] Clicking MAIN MENU on PAUSE/GAMEOVER goes to START screen (clean state)
- [ ] `bestScore` is **never** reset by RESTART or MAIN MENU
- [ ] Game still runs offline by double-clicking `index.html` (no network needed)
- [ ] Zero new external files — all in existing `script.js`

---

## ⚠️ Edge Cases to Handle

> [!WARNING]
> **`localStorage` quota exceeded** — wrap every `localStorage.setItem` in a `try/catch`. On failure, silently skip — the game still works, just without persistence.

> [!WARNING]
> **Pausing on the last life** — `gameOverPending` may be `true` when the user hits `P`. Block `pauseGame()` if `gameOverPending === true` or `lives <= 0`.

> [!WARNING]
> **`gameState` during hit pause** — `hitPauseFrames > 0` doesn't mean PAUSED. Only the `gameState === "PAUSED"` branch triggers the pause screen.

> [!NOTE]
> **Multiple tabs** — if the player has two tabs open, the last one to write `savedGame` wins. This is acceptable for a single-player homework game.

---

## 🔧 New Variables Added (`script.js` top section)

```js
// ── Stage 4: State & Storage ──────────────────────────────────────────────────
const STORAGE_KEY = "oceanCatch_v1";
let hasSavedGame  = false;   // true when a paused mid-game save exists in localStorage
```

No existing variables are removed or renamed.

---

*Plan authored by Claude Sonnet 4.6 (Thinking) · November 2026*  
*Context: HW6_Game — Stages 1–3 complete (`script.js` 1262 lines). Stage 4 adds ~80 lines.*  
*Ready to hand to the Builder model for Stage 4 implementation.*
