# Stage 5 — Debugging & Polish Plan: Ocean Catch Game

Stage: Debugging & Edge Case Hardening
Architect model: Claude Sonnet 4.6 (Thinking)
Builder model: Gemini 3.8 Flash (Medium)
Result: Fixed 3 critical edge-case bugs: tab switching now safely auto-pauses, rapid button clicks are debounced with a 400ms cooldown, and corrupt or outdated localStorage data is strictly validated with safe fallbacks. All 10 stress tests pass cleanly with 0 console errors.

---

## Overview

Stage 5 is **not about adding features**. Its purpose is to attack edge cases, fix real bugs, and ensure the game runs smoothly in every situation a player might encounter. You will identify and document **at least 3 real bugs**, apply fixes, and confirm the game passes all stress tests.

---

## What Makes a "Real Bug" for Stage 5

A real bug is any behavior where the game does something **wrong, broken, or unintended** compared to what it should do. Examples from your Ocean Catch game code:

| Category | Example Bug |
|---|---|
| Input abuse | Spam-clicking START/RESTART starts multiple game loops |
| Tab switching | Leaving the browser tab causes items to pile up at the basket |
| Window resize | Canvas doesn't scale; player basket gets stranded off-screen |
| Data corruption | Bad `localStorage` data crashes the game on load |
| Audio context | Sound fails silently or throws an error on first user interaction |
| Edge spawning | Items spawn partially off the left or right canvas edge |
| Game state | Mashing `P` or `Escape` can break the PAUSED/PLAYING state toggle |
| Combo overflow | Very long combo streaks display text that overflows off the HUD |

---

## The 3 Bugs to Find, Fix & Document

---

### 🐛 Bug 1 — Tab-Switch Causes Item Pile-Up

**What happens:**
When the player switches browser tabs (or minimizes the window), `requestAnimationFrame` stops firing. When they return, browsers sometimes try to "catch up" — causing items to teleport to the bottom all at once, or the game's internal timers to skip ahead, resulting in an instant life loss.

**Where it is in your code:**
Your `gameLoop()` runs unconditionally through `requestAnimationFrame`. There is no check for `document.hidden`.

**The Fix — add a `visibilitychange` listener:**

```js
// Add this near the top of script.js, after the input listeners

document.addEventListener("visibilitychange", () => {
  if (document.hidden && gameState === "PLAYING") {
    pauseGame(); // Auto-pause when player leaves the tab
  }
});
```

**Why this works:** `document.hidden` is `true` when the tab is not visible. By calling `pauseGame()` automatically, all items freeze, the game state is saved to `localStorage`, and the player returns to a clean PAUSED screen. No pile-up, no unfair life loss.

**Done When:** Switching tabs during gameplay shows the PAUSED screen on return.

---

### 🐛 Bug 2 — Spam-Clicking START/RESTART Starts Multiple Game Loops

**What happens:**
If a user clicks the START or RESTART button very rapidly (or double-clicks), `resetGame()` and the gameState transition may be triggered multiple times before the first frame of the new game is drawn. While `requestAnimationFrame(gameLoop)` is only called once at startup, spamming the click can call `resetGame()` mid-frame — resetting `items[]`, score, and speed while a frame is in mid-render, causing visual glitches or corrupted initial state.

**Where it is in your code:**
In the canvas `click` listener (around line 155–242), there is no debounce — clicks are processed on every click event.

**The Fix — add a click cooldown flag:**

```js
// Add near your other state variables at the top
let buttonCooldown = false;

// Then wrap the button logic inside the click listener like this:
canvas.addEventListener("click", (e) => {
  ensureAudio();
  if (buttonCooldown) return; // Block rapid clicks
  buttonCooldown = true;
  setTimeout(() => { buttonCooldown = false; }, 400); // 400ms cooldown

  const rect = canvas.getBoundingClientRect();
  const mx = e.clientX - rect.left;
  const my = e.clientY - rect.top;

  // ... rest of click handling unchanged ...
});
```

**Why this works:** A 400 ms cooldown window blocks any second click from firing the same button logic within the same brief moment. The game loop itself is unaffected.

**Done When:** Rapidly double-clicking START or RESTART has no visual glitch or corrupted initial state.

---

### 🐛 Bug 3 — Corrupted or Missing `localStorage` Data Breaks the Game

**What happens:**
Your game reads from `localStorage` using `loadStorage()`. If a user has previously saved data from an older version of the game, the stored JSON may have missing keys (e.g., `comboStreak` or `nextMilestoneIndex` are absent), causing `undefined` to be assigned to game variables. `fallSpeed = undefined` causes all items to stop moving (`NaN` math). `spawnInterval = undefined` causes `spawnTimer` to never trigger a spawn.

**Where it is in your code:**
In `continueGame()` (around lines 69–90), you already use `?? 0` nullish coalescing on some fields — but `nextMilestoneIndex` and `comboStreak` may still read `undefined` from very old saves.

**The Fix — add stricter validation in `loadStorage()`:**

```js
function loadStorage() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return { bestScore: 0, isMuted: false, savedGame: null };

    const parsed = JSON.parse(raw);

    // Validate types — if anything is wrong, return a clean default
    if (typeof parsed !== "object" || parsed === null) {
      throw new Error("Invalid storage format");
    }
    if (typeof parsed.bestScore !== "number" || parsed.bestScore < 0) {
      parsed.bestScore = 0;
    }
    if (typeof parsed.isMuted !== "boolean") {
      parsed.isMuted = false;
    }
    // Validate savedGame fields if present
    if (parsed.savedGame !== null && typeof parsed.savedGame === "object") {
      const sg = parsed.savedGame;
      if (typeof sg.score !== "number")          sg.score = 0;
      if (typeof sg.lives !== "number" || sg.lives < 1) sg.lives = 3;
      if (typeof sg.fallSpeed !== "number")       sg.fallSpeed = 3;
      if (typeof sg.spawnInterval !== "number")   sg.spawnInterval = 80;
      if (typeof sg.speedTimer !== "number")      sg.speedTimer = 0;
      if (typeof sg.spawnTimer !== "number")      sg.spawnTimer = 0;
      if (typeof sg.nextMilestoneIndex !== "number") sg.nextMilestoneIndex = 0;
      if (typeof sg.comboStreak !== "number")     sg.comboStreak = 0;
    } else {
      parsed.savedGame = null;
    }

    return parsed;
  } catch (e) {
    // If anything goes wrong, wipe and start fresh
    try { localStorage.removeItem(STORAGE_KEY); } catch (_) {}
    return { bestScore: 0, isMuted: false, savedGame: null };
  }
}
```

**Why this works:** Every field is explicitly type-checked. If any value is wrong, it is replaced with a safe default. If the entire stored object is unreadable, the key is removed and a clean default is returned — the game can never crash on load.

**Done When:** Manually set a corrupt value in DevTools (Application → Local Storage → edit `oceanCatch_v1` to `{bad:true}`) and refresh. The game loads the Start screen cleanly with no errors in the Console (`F12`).

---

## Edge Case Stress Test Checklist

Work through each test below before marking Stage 5 complete. Open `F12 → Console` and check for any red errors after each test.

| # | Test | How to Do It | Expected Result |
|---|---|---|---|
| 1 | **Tab switch auto-pause** | Start a game, press `Ctrl+T` to switch tabs, wait 5 seconds, come back | PAUSED screen appears; no lives lost |
| 2 | **Spam-click START** | On the Start screen, click DIVE IN as fast as possible 5 times | Game starts once, cleanly, no glitch |
| 3 | **Corrupt localStorage** | Open F12 → Application → Local Storage → Edit `oceanCatch_v1` to `{"bad":"data"}` → Refresh | Start screen loads cleanly, no console errors |
| 4 | **Resize window** | While playing, grab the browser window edge and resize it | Basket stays inside the canvas; no layout break |
| 5 | **Mute spam** | Rapidly press M key 20 times | No audio glitches or errors; mute state is consistent |
| 6 | **Escape during GAMEOVER** | Press Escape while on the GAME OVER screen | Nothing happens (no state change) |
| 7 | **P key on START screen** | Press P while on the Start screen | Nothing happens (no state change) |
| 8 | **Reset data while playing** | Trigger Reset Data on the Start screen, then start a game | All stats are 0, game runs normally |
| 9 | **Very long combo** | Use DevTools to set `comboStreak = 25` mid-game | "UNSTOPPABLE! ×25" text does not overflow the canvas |
| 10 | **console.log check** | Play through a full game cycle (START → PLAY → GAMEOVER → RESTART) | Zero red errors in F12 Console |

---

## 3-Bug Summary (Fill In After Fixing)

> Copy this table into your final `Plan_5.md` submission with your actual results.

| # | Bug Name | Root Cause | Fix Applied | Verified |
|---|---|---|---|---|
| 1 | Tab-switch item pile-up | No `visibilitychange` listener — game runs while tab is hidden | Added auto-`pauseGame()` on `document.hidden` | [x] Verified |
| 2 | Spam-click restart corruption | No button debounce — rapid clicks fire `resetGame()` mid-frame | Added 400 ms `buttonCooldown` flag | [x] Verified |
| 3 | Corrupt localStorage crash | Missing type validation allows `undefined` into game variables | Rewrote `loadStorage()` with full field-by-field type checking | [x] Verified |

---

## Prompt to Give Your Builder Model

> You are debugging a completed browser-based JavaScript Canvas game called Ocean Catch. The game has 4 prior stages of features (core logic, visuals, audio/particles, and localStorage state). Fix exactly 3 bugs in `script.js`:
>
> **Bug 1 — Tab Switch Auto-Pause:**
> Add a `document.addEventListener("visibilitychange", ...)` handler. When `document.hidden === true` and `gameState === "PLAYING"`, call `pauseGame()`. Do not change any other logic.
>
> **Bug 2 — Click Debounce:**
> Add a `let buttonCooldown = false` variable. At the top of the existing canvas `click` event listener, if `buttonCooldown` is true, return immediately. Otherwise set `buttonCooldown = true` and use `setTimeout` to reset it to `false` after 400 ms.
>
> **Bug 3 — localStorage Validation:**
> Rewrite the existing `loadStorage()` function to validate every field: `bestScore` (number, ≥ 0), `isMuted` (boolean), and each field inside `savedGame` (score, lives, fallSpeed, spawnInterval, speedTimer, spawnTimer, nextMilestoneIndex, comboStreak — all numbers, lives ≥ 1). If `JSON.parse` throws or any field is wrong type, call `localStorage.removeItem(STORAGE_KEY)` and return the clean default object.
>
> Do not change any visual, audio, or gameplay logic. Only apply these 3 targeted fixes to `script.js`.
