# Stage 3 — Sensory Feedback Plan: Ocean Catch Game

Stage: Sensory Feedback  
Architect model: Claude Sonnet 4.6 (Thinking)  
Builder model: ( Gemini Flash)  
Result: (Tested Web Audio API oscillator synthesis, browser audio autoplay restrictions, screen shake translation bounds, hit-pause frames, and mute toggle.Fixed audio unlock: Ensured audioCtx.resume() triggers on first user interaction so sounds never fail silently.)

---

## Overview

Stage 3 layers **sensory and game-feel feedback** on top of the fully working Stage 2 ocean-themed game. The goal is to make every player action feel satisfying, punishing, or dramatic through:

1. **Audio feedback** — synthesized sound effects using the Web Audio API (no audio files)
2. **Screen shake** — camera-shake effect on bad catches and game over
3. **Combo / streak system** — visual and audio reward for catching items in a row
4. **Hit-pause / frame freeze** — 2–4 frame freeze on collision for weight and impact
5. **Player net squash & stretch** — brief shape distortion on catch
6. **Score milestone fanfare** — visual + audio burst at score milestones (50, 100, 200…)
7. **Last-life warning pulse** — HUD and screen throb when only 1 life remains
8. **Game Over slow-motion** — brief speed ramp-down before state switches

> [!IMPORTANT]
> **Core logic is NOT changed.** All collision detection, AABB bounds, `update()` function, scoring (+10 / -1 life), speed scaling, spawn intervals, and game states remain byte-for-byte identical. All additions are either new variables, new functions, or new draw/audio hooks called from existing event points.

> [!NOTE]
> **No audio files.** All sounds are synthesized at runtime using the **Web Audio API** (`AudioContext`, `OscillatorNode`, `GainNode`). The game remains fully offline.

---

## Files Changed

| File | What Changes |
|------|-------------|
| `index.html` | No changes required |
| `style.css` | No changes required |
| `script.js` | Add audio engine, feedback variables, and new draw/update hooks |

---

## 1. Web Audio Engine (No Audio Files)

All sounds are procedurally synthesized. Create the `AudioContext` once on first user interaction to comply with browser autoplay policy.

### Setup Pattern

```js
let audioCtx = null;

function ensureAudio() {
  if (!audioCtx) {
    audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  }
}
```

### Sound Recipes (all via OscillatorNode + GainNode)

#### `playGoodCatch()`  — bright sparkle tone
```js
function playGoodCatch() {
  ensureAudio();
  const osc  = audioCtx.createOscillator();
  const gain = audioCtx.createGain();
  osc.connect(gain);
  gain.connect(audioCtx.destination);

  osc.type = "sine";
  osc.frequency.setValueAtTime(660, audioCtx.currentTime);
  osc.frequency.exponentialRampToValueAtTime(880, audioCtx.currentTime + 0.08);
  gain.gain.setValueAtTime(0.25, audioCtx.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.25);

  osc.start();
  osc.stop(audioCtx.currentTime + 0.25);
}
```

#### `playBadCatch()` — low thud + distortion
```js
function playBadCatch() {
  ensureAudio();
  const osc  = audioCtx.createOscillator();
  const gain = audioCtx.createGain();
  osc.connect(gain);
  gain.connect(audioCtx.destination);

  osc.type = "sawtooth";
  osc.frequency.setValueAtTime(180, audioCtx.currentTime);
  osc.frequency.exponentialRampToValueAtTime(60, audioCtx.currentTime + 0.18);
  gain.gain.setValueAtTime(0.4, audioCtx.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.3);

  osc.start();
  osc.stop(audioCtx.currentTime + 0.3);
}
```

#### `playComboSound(streak)` — escalating harmonic chime
```js
function playComboSound(streak) {
  ensureAudio();
  const baseFreq = 440 + (streak - 2) * 110; // escalates per combo level
  [1, 1.25, 1.5].forEach((mult, i) => {
    const osc  = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.connect(gain);
    gain.connect(audioCtx.destination);
    osc.type = "triangle";
    osc.frequency.value = baseFreq * mult;
    gain.gain.setValueAtTime(0, audioCtx.currentTime + i * 0.07);
    gain.gain.linearRampToValueAtTime(0.2, audioCtx.currentTime + i * 0.07 + 0.03);
    gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + i * 0.07 + 0.25);
    osc.start(audioCtx.currentTime + i * 0.07);
    osc.stop(audioCtx.currentTime + i * 0.07 + 0.3);
  });
}
```

#### `playMilestoneFanfare()` — triumphant ascending arpeggio
```js
function playMilestoneFanfare() {
  ensureAudio();
  const notes = [523, 659, 784, 1047]; // C5, E5, G5, C6
  notes.forEach((freq, i) => {
    const osc  = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.connect(gain);
    gain.connect(audioCtx.destination);
    osc.type = "sine";
    osc.frequency.value = freq;
    gain.gain.setValueAtTime(0.3, audioCtx.currentTime + i * 0.1);
    gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + i * 0.1 + 0.35);
    osc.start(audioCtx.currentTime + i * 0.1);
    osc.stop(audioCtx.currentTime + i * 0.1 + 0.4);
  });
}
```

#### `playGameOver()` — descending whale-song droop
```js
function playGameOver() {
  ensureAudio();
  const osc  = audioCtx.createOscillator();
  const gain = audioCtx.createGain();
  osc.connect(gain);
  gain.connect(audioCtx.destination);
  osc.type = "sine";
  osc.frequency.setValueAtTime(440, audioCtx.currentTime);
  osc.frequency.exponentialRampToValueAtTime(100, audioCtx.currentTime + 1.2);
  gain.gain.setValueAtTime(0.3, audioCtx.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 1.5);
  osc.start();
  osc.stop(audioCtx.currentTime + 1.5);
}
```

#### `playLastLifeWarning()` — single low heartbeat pulse
```js
function playLastLifeWarning() {
  ensureAudio();
  [0, 0.18].forEach(delay => {
    const osc  = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.connect(gain);
    gain.connect(audioCtx.destination);
    osc.type = "sine";
    osc.frequency.value = 80;
    gain.gain.setValueAtTime(0.35, audioCtx.currentTime + delay);
    gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + delay + 0.15);
    osc.start(audioCtx.currentTime + delay);
    osc.stop(audioCtx.currentTime + delay + 0.2);
  });
}
```

---

## 2. Screen Shake System

A camera-shake effect is applied by offsetting the entire canvas's `ctx.translate()` by a decaying random amount.

### New Variables
```js
let shakeIntensity = 0;    // pixels of max shake offset this frame
let shakeDecay     = 0.85; // multiplier per frame (0.85 = fast fade)
```

### Integration in `draw()`
```js
function draw() {
  ctx.save();

  // Apply screen shake
  if (shakeIntensity > 0.5) {
    const sx = (Math.random() * 2 - 1) * shakeIntensity;
    const sy = (Math.random() * 2 - 1) * shakeIntensity;
    ctx.translate(sx, sy);
    shakeIntensity *= shakeDecay;
  } else {
    shakeIntensity = 0;
  }

  // ... existing draw calls (drawBackground, drawBubbles, etc.)

  ctx.restore();
}
```

### Shake Triggers
| Event | `shakeIntensity` Value |
|-------|------------------------|
| Bad catch | `10` |
| Last life remaining | `6` |
| Game Over | `18` |

---

## 3. Combo / Streak System

Consecutive good catches without a bad catch increment a combo counter. The combo resets on any bad catch.

### New Variables
```js
let comboStreak     = 0;    // current consecutive good catches
let comboDisplayTimer = 0;  // how many frames to show combo label
```

### New Logic — Add to Collision Block in `update()`
```js
// Inside the good-catch branch (after score += 10):
comboStreak++;
comboDisplayTimer = 90;  // show for 90 frames (~1.5 seconds)
if (comboStreak >= 2) {
  playComboSound(comboStreak);
  spawnComboText(comboStreak, centerX, centerY);
}

// Inside the bad-catch branch (after lives -= 1):
comboStreak = 0;
comboDisplayTimer = 0;
```

### Combo Display (`drawComboHUD()`)
- Rendered below the HUD bar when `comboStreak >= 2 && comboDisplayTimer > 0`
- Text: `"🔥 x3 COMBO!"` etc.
- Color scale:
  - x2: `#FFBF00` (amber)
  - x3: `#66FF00` (neon green)
  - x4: `#FF0090` (hot pink)
  - x5+: `#DA70D6` (orchid) with glow shadow
- Font: `bold 20px 'Segoe UI'`
- Alpha fades over last 30 frames of `comboDisplayTimer`

### Combo Floating Text (via existing `scorePopups` array)
```js
function spawnComboText(streak, x, y) {
  const labels = ["", "", "NICE! ×2", "GREAT! ×3", "AMAZING! ×4", "LEGENDARY! ×5"];
  const label  = labels[Math.min(streak, 5)] || `UNSTOPPABLE! ×${streak}`;
  scorePopups.push({ x, y: y - 20, text: label, life: 55, color: comboColor(streak) });
}
```

---

## 4. Hit-Pause (Frame Freeze)

A 2–4 frame freeze on catch makes impacts feel weighty. Achieved by skipping `update()` calls for N frames.

### New Variables
```js
let hitPauseFrames = 0;   // number of frames to freeze game logic
```

### Integration in `gameLoop()`
```js
function gameLoop() {
  if (hitPauseFrames > 0) {
    hitPauseFrames--;
    draw();  // still render (screen shake, particles continue)
  } else {
    update();
    draw();
  }
  requestAnimationFrame(gameLoop);
}
```

### Hit-Pause Triggers
| Event | `hitPauseFrames` |
|-------|-----------------|
| Good catch | `2` |
| Bad catch | `4` |

> [!NOTE]
> Particles and screen shake continue during hit-pause because they are updated in `draw()` / outside the `update()` block.

---

## 5. Player Net Squash & Stretch

On catch, the player net briefly squashes (flattens) then returns to normal shape over ~12 frames.

### New Variables
```js
let netSquash = 1.0;   // y-scale multiplier (1 = normal, <1 = squashed)
let netSquashTimer = 0;
```

### Integration in `drawPlayer()`
```js
// Before drawing the net shape:
ctx.save();
ctx.translate(player.x + player.width / 2, player.y + player.height / 2);
ctx.scale(1, netSquash);
ctx.translate(-(player.x + player.width / 2), -(player.y + player.height / 2));
// ... existing fillRect / roundRect draw code ...
ctx.restore();
```

### Update in `update()` (outside PLAYING guard)
```js
if (netSquashTimer > 0) {
  netSquashTimer--;
  netSquash = 0.5 + 0.5 * (1 - netSquashTimer / 12);  // ease back to 1
} else {
  netSquash = 1.0;
}
```

### Triggers
| Event | `netSquash` | `netSquashTimer` |
|-------|-------------|-----------------|
| Good catch | `0.5` | `12` |
| Bad catch | `1.5` (stretch) | `10` |

---

## 6. Score Milestone Fanfare

Every time the score crosses a milestone, trigger a fanfare + extra particle burst.

### Milestones
```js
const MILESTONES = [50, 100, 150, 200, 300, 500, 750, 1000];
let nextMilestoneIndex = 0;
```

### Logic — Add to Good-Catch Branch in `update()`
```js
if (MILESTONES[nextMilestoneIndex] && score >= MILESTONES[nextMilestoneIndex]) {
  playMilestoneFanfare();
  createMilestoneFlash(MILESTONES[nextMilestoneIndex]);
  nextMilestoneIndex++;
}
```

### Milestone Flash (`createMilestoneFlash(value)`)
- 20-particle radial burst from canvas center, random spread
- Colors: mix of `#FFBF00`, `#66FF00`, `#DA70D6`, `#87CEEB`
- Each particle: size 6–12, lifetime 40 frames
- Floating banner text: `"⭐ ${value} POINTS! ⭐"` centered on screen, fades over 80 frames
- Text color: `#FFBF00`, font: `bold 22px 'Segoe UI'`, glow `#007FFF`

### Reset on `resetGame()`
```js
nextMilestoneIndex = 0;
```

---

## 7. Last-Life Warning Pulse

When `lives === 1`, the HUD bar and screen edge pulse rhythmically.

### New Variables
```js
let lastLifePulseTimer = 0;
```

### Logic — Add to `update()` (after lives check)
```js
if (lives === 1 && gameState === "PLAYING") {
  lastLifePulseTimer++;
  // Trigger heartbeat sound every 90 frames (~1.5s)
  if (lastLifePulseTimer % 90 === 0) {
    playLastLifeWarning();
  }
} else {
  lastLifePulseTimer = 0;
}
```

### Visual Pulse in `drawHUD()`
```js
if (lives === 1) {
  const pulseAlpha = 0.15 + 0.15 * Math.sin(frame * 0.12); // 0.15–0.30 pulsing
  ctx.fillStyle = `rgba(229, 43, 80, ${pulseAlpha})`;
  ctx.fillRect(0, 0, canvas.width, canvas.height);  // screen-edge tint
  // HUD bar: flash red
  ctx.fillStyle = `rgba(229, 43, 80, ${0.5 + 0.3 * Math.sin(frame * 0.12)})`;
  ctx.fillRect(0, 0, canvas.width, 42);
}
```

---

## 8. Game Over Slow-Motion Ramp-Down

Just before game state switches to `"GAMEOVER"`, items appear to slow down dramatically for about 30 frames, then freeze.

### New Variables
```js
let slowMotionFactor = 1.0;   // multiplier for item speed (1 = normal, 0 = frozen)
let slowMotionTimer  = 0;     // counts down from 30
let gameOverPending  = false; // true during the ramp-down window
```

### Logic — Replace Lives Check in `update()`
```js
// OLD:
// if (lives <= 0) { gameState = "GAMEOVER"; }

// NEW:
if (lives <= 0 && !gameOverPending) {
  gameOverPending  = true;
  slowMotionTimer  = 35;
  shakeIntensity   = 18;
  playGameOver();
}

if (gameOverPending) {
  slowMotionTimer--;
  slowMotionFactor = Math.max(0, slowMotionTimer / 35);  // 1 → 0 over 35 frames
  // Apply to items
  for (const item of items) {
    item.y += item.speed * slowMotionFactor;
  }
  if (slowMotionTimer <= 0) {
    gameState       = "GAMEOVER";
    gameOverPending = false;
    slowMotionFactor = 1.0;
  }
  return;  // skip normal item update this frame
}
```

### Reset on `resetGame()`
```js
slowMotionFactor = 1.0;
slowMotionTimer  = 0;
gameOverPending  = false;
```

---

## 9. Audio Trigger Map (Full Summary)

| Event | Sound | Additional Feedback |
|-------|-------|---------------------|
| Good catch | `playGoodCatch()` | Hit-pause 2 frames, squash net, `+10` popup, sparkles |
| Combo ×2+ | `playComboSound(streak)` | Combo float text, escalating pitch |
| Bad catch | `playBadCatch()` | Hit-pause 4 frames, stretch net, screen shake 10, vignette |
| Lives = 1 | `playLastLifeWarning()` | Repeating every 90 frames, HUD + screen pulse red |
| Score milestone | `playMilestoneFanfare()` | 20-particle burst, banner text centered |
| Game Over | `playGameOver()` | Slow-motion 35 frames, screen shake 18, whale-song droop |

---

## 10. New Variable Additions (script.js top)

```js
// ── Sensory Feedback State ──────────────────────────────────────
let audioCtx         = null;

let shakeIntensity   = 0;
const shakeDecay     = 0.85;

let comboStreak      = 0;
let comboDisplayTimer = 0;

let hitPauseFrames   = 0;

let netSquash        = 1.0;
let netSquashTimer   = 0;

const MILESTONES     = [50, 100, 150, 200, 300, 500, 750, 1000];
let nextMilestoneIndex = 0;

let lastLifePulseTimer = 0;

let slowMotionFactor = 1.0;
let slowMotionTimer  = 0;
let gameOverPending  = false;
```

---

## 11. Updated `gameLoop()` Structure

```js
function gameLoop() {
  frame++;

  if (hitPauseFrames > 0) {
    hitPauseFrames--;
    // Particles + shake still update
    updatePassiveEffects();
    draw();
  } else {
    update();   // core logic (unchanged) + sensory triggers
    draw();     // all visual layers + shake translate
  }

  requestAnimationFrame(gameLoop);
}
```

Where `updatePassiveEffects()` handles: bubble movement, particle decay, scorePopup float, shakeIntensity decay — the parts of `update()` that should still run during a hit-pause.

---

## 12. Updated `resetGame()` Additions

```js
// Add to existing resetGame():
comboStreak        = 0;
comboDisplayTimer  = 0;
hitPauseFrames     = 0;
netSquash          = 1.0;
netSquashTimer     = 0;
nextMilestoneIndex = 0;
lastLifePulseTimer = 0;
slowMotionFactor   = 1.0;
slowMotionTimer    = 0;
gameOverPending    = false;
shakeIntensity     = 0;
```

---

## 13. Updated `drawGame()` Call Order

```
drawGame()
  ├── drawBackground()           ← Stage 2 (unchanged)
  ├── drawBubbles()              ← Stage 2 (unchanged)
  ├── drawSeabed()               ← Stage 2 (unchanged)
  ├── drawItems()                ← Stage 2 (unchanged)
  ├── drawPlayer()               ← MODIFIED: squash/stretch scale applied
  ├── drawParticles()            ← Stage 2 (unchanged)
  ├── drawHUD()                  ← MODIFIED: last-life pulse overlay added
  ├── drawComboHUD()             ← NEW: combo streak label
  ├── drawMilestoneBanner()      ← NEW: centered milestone text
  └── drawLastLifePulse()        ← NEW: screen-edge pulsing red tint
```

Screen shake wraps the entire `draw()` call via `ctx.save() / ctx.translate(sx, sy) / ctx.restore()`.

---



## Prompt to Give Your Builder Model

> You are a JavaScript game developer continuing to build the Ocean Catch game. Stage 1 (core logic) and Stage 2 (ocean visual theme) are already complete in `script.js`. You must add **Stage 3: Sensory Feedback** without changing any core logic (scoring, AABB collision, lives, game states, spawn intervals, or fall speed scaling).
>
> **Add the following — all within `script.js` only:**
>
> 1. **Web Audio API sounds** (no audio files): good catch tone, bad catch thud, combo chimes (escalating per streak), milestone fanfare, game over droop, last-life heartbeat.
> 2. **Screen shake**: translate ctx by decaying random offset — intensity 10 on bad catch, 18 on game over.
> 3. **Combo streak system**: count consecutive good catches; display floating "×N COMBO" text; play escalating sound; reset on bad catch.
> 4. **Hit-pause**: freeze `update()` for 2 frames on good catch, 4 frames on bad catch. Particles and shake still update.
> 5. **Player net squash & stretch**: scale net Y to 0.5 on good catch (squash), 1.5 on bad (stretch), easing back over 12 frames.
> 6. **Milestone fanfare**: at scores 50, 100, 150, 200, 300, 500 — 4-note arpeggio + 20-particle burst + centered banner text.
> 7. **Last-life pulse**: when lives === 1, screen edge pulses red + heartbeat sound every 90 frames.
> 8. **Game Over slow-motion**: on lives reaching 0, ramp item speeds to 0 over 35 frames, then switch to GAMEOVER state.
>
> Do not use any external libraries, audio files, or CDN links. The game must still run offline.

---

*Plan_3.md · Stage 3 Sensory Feedback · Architect: Claude Sonnet 4.6 (Thinking) · November 2026*
