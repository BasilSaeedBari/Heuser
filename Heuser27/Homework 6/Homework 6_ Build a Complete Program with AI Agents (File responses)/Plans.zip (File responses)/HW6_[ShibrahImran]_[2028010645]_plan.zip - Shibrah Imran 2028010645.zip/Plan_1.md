# Stage 1 — Core Logic Plan: Catch Game

Stage: Core Logic
Architect model: Claude Sonnet 4.6 (Thinking)
Builder model: (Gemini Flash)
Result: (Start-to-finish loop worked cleanly; paddle properly constrained to canvas width)

---

## Game Overview

A simple browser-based Catch Game where a player-controlled basket/paddle moves left and right at the bottom of the screen. Items (good and bad) fall from the top. The goal is to catch as many good items as possible without losing all your lives.

---

## Files Needed

| File        | Purpose                            |
|-------------|------------------------------------|
| index.html  | Page structure, canvas element     |
| style.css   | Basic body/canvas centering        |
| script.js   | All game logic                     |

---

## 1. Game Rules

- **Good Items** (white/green rectangles): Catching one adds **+10 points**.
- **Bad Items** (dark/red rectangles): Catching one costs **-1 life**.
- The player starts with **3 lives**.
- The game ends when lives reach **0**.
- Items that fall past the bottom of the screen are simply removed — no penalty.
- Speed of falling items **gradually increases** over time to raise difficulty.

---

## 2. Controls

| Input              | Action                        |
|--------------------|-------------------------------|
| Arrow Left key     | Move basket left              |
| Arrow Right key    | Move basket right             |
| Mouse Move         | Basket follows mouse X position |
| Click "Restart"    | Resets the game from Game Over screen |

---

## 3. Scoring & Winning

- **Score**: Starts at 0. Increases by 10 for every good item caught.
- **Lives**: Starts at 3. Decreases by 1 for every bad item caught.
- **There is no win condition** — the game is endless until all lives are lost.
- Highest score is displayed on the Game Over screen (no localStorage yet — just in memory for Stage 1).

---

## 4. Game States

The game has 3 simple states managed by a variable `gameState`:

```
"START"    → Show a Start screen with instructions and a Start button
"PLAYING"  → Run the main game loop
"GAMEOVER" → Pause everything, show final score, show Restart button
```

---

## 5. HTML Structure (index.html)

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Catch Game</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <canvas id="gameCanvas" width="480" height="600"></canvas>
  <script src="script.js"></script>
</body>
</html>
```

---

## 6. CSS Structure (style.css)

```css
/* Center the canvas on a dark background */
body {
  margin: 0;
  background: #111;
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
}

canvas {
  background: #222;
  display: block;
}
```

---

## 7. JavaScript Game Logic Plan (script.js)

### Step 1 — Set Up Canvas

```js
const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");
```

---

### Step 2 — Game Variables

```js
let gameState = "START";  // "START", "PLAYING", "GAMEOVER"

// Player basket
const player = {
  x: 200,        // horizontal position (centered)
  y: 560,        // near bottom of canvas
  width: 80,
  height: 15,
  speed: 6,
  color: "#4af"
};

// Falling items array
let items = [];

// Scoring
let score = 0;
let lives = 3;

// Item spawn timer
let spawnTimer = 0;
let spawnInterval = 80;   // frames between spawns (lower = faster)

// Fall speed (increases over time)
let fallSpeed = 3;
let speedTimer = 0;

// Keyboard input state
const keys = {};
```

---

### Step 3 — Keyboard & Mouse Input

```js
document.addEventListener("keydown", (e) => { keys[e.key] = true; });
document.addEventListener("keyup",   (e) => { keys[e.key] = false; });

canvas.addEventListener("mousemove", (e) => {
  if (gameState !== "PLAYING") return;
  const rect = canvas.getBoundingClientRect();
  player.x = e.clientX - rect.left - player.width / 2;
  // Clamp so basket stays inside canvas
  player.x = Math.max(0, Math.min(canvas.width - player.width, player.x));
});
```

---

### Step 4 — Spawn Items

```js
function spawnItem() {
  const isGood = Math.random() > 0.35;   // ~65% good, 35% bad
  items.push({
    x: Math.random() * (canvas.width - 30),
    y: -20,
    width: 30,
    height: 20,
    color: isGood ? "#6f6" : "#f44",     // green = good, red = bad
    isGood: isGood,
    speed: fallSpeed + Math.random() * 2 // slight random variation
  });
}
```

---

### Step 5 — Collision Detection (AABB)

```js
function checkCollision(item) {
  return (
    item.x < player.x + player.width  &&
    item.x + item.width  > player.x   &&
    item.y < player.y + player.height &&
    item.y + item.height > player.y
  );
}
```

---

### Step 6 — Update Function (runs every frame)

```js
function update() {
  if (gameState !== "PLAYING") return;

  // Move player with keyboard
  if (keys["ArrowLeft"])  player.x -= player.speed;
  if (keys["ArrowRight"]) player.x += player.speed;
  // Clamp player inside canvas
  player.x = Math.max(0, Math.min(canvas.width - player.width, player.x));

  // Spawn items on timer
  spawnTimer++;
  if (spawnTimer >= spawnInterval) {
    spawnItem();
    spawnTimer = 0;
  }

  // Increase speed every 300 frames
  speedTimer++;
  if (speedTimer >= 300) {
    fallSpeed += 0.5;
    spawnInterval = Math.max(30, spawnInterval - 5);
    speedTimer = 0;
  }

  // Update each item
  for (let i = items.length - 1; i >= 0; i--) {
    items[i].y += items[i].speed;

    if (checkCollision(items[i])) {
      if (items[i].isGood) {
        score += 10;
      } else {
        lives -= 1;
      }
      items.splice(i, 1);   // remove caught/hit item
      continue;
    }

    // Remove items that fall off screen
    if (items[i].y > canvas.height) {
      items.splice(i, 1);
    }
  }

  // Check game over
  if (lives <= 0) {
    gameState = "GAMEOVER";
  }
}
```

---

### Step 7 — Draw Function

```js
function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  if (gameState === "START") {
    drawStartScreen();
  } else if (gameState === "PLAYING") {
    drawGame();
  } else if (gameState === "GAMEOVER") {
    drawGameOverScreen();
  }
}

function drawGame() {
  // Draw player basket
  ctx.fillStyle = player.color;
  ctx.fillRect(player.x, player.y, player.width, player.height);

  // Draw falling items
  for (const item of items) {
    ctx.fillStyle = item.color;
    ctx.fillRect(item.x, item.y, item.width, item.height);
  }

  // Draw HUD (Score and Lives)
  ctx.fillStyle = "#fff";
  ctx.font = "18px monospace";
  ctx.fillText("Score: " + score, 10, 25);
  ctx.fillText("Lives: " + lives, canvas.width - 100, 25);
}

function drawStartScreen() {
  ctx.fillStyle = "#fff";
  ctx.font = "bold 32px monospace";
  ctx.textAlign = "center";
  ctx.fillText("CATCH GAME", canvas.width / 2, 200);

  ctx.font = "16px monospace";
  ctx.fillText("Catch GREEN items  +10 pts", canvas.width / 2, 270);
  ctx.fillText("Avoid  RED  items  -1 life", canvas.width / 2, 300);
  ctx.fillText("Use Arrow Keys or Mouse", canvas.width / 2, 340);

  ctx.fillStyle = "#4af";
  ctx.fillRect(canvas.width / 2 - 60, 390, 120, 40);
  ctx.fillStyle = "#000";
  ctx.font = "bold 18px monospace";
  ctx.fillText("START", canvas.width / 2, 416);
  ctx.textAlign = "left";
}

function drawGameOverScreen() {
  ctx.fillStyle = "#fff";
  ctx.font = "bold 36px monospace";
  ctx.textAlign = "center";
  ctx.fillText("GAME OVER", canvas.width / 2, 220);

  ctx.font = "22px monospace";
  ctx.fillText("Final Score: " + score, canvas.width / 2, 280);

  ctx.fillStyle = "#4af";
  ctx.fillRect(canvas.width / 2 - 60, 330, 120, 40);
  ctx.fillStyle = "#000";
  ctx.font = "bold 18px monospace";
  ctx.fillText("RESTART", canvas.width / 2, 356);
  ctx.textAlign = "left";
}
```

---

### Step 8 — Button Click Handling (Start & Restart)

```js
canvas.addEventListener("click", (e) => {
  const rect = canvas.getBoundingClientRect();
  const mx = e.clientX - rect.left;
  const my = e.clientY - rect.top;

  if (gameState === "START") {
    // Check click on START button (centered around canvas.width/2, y=390)
    if (mx > canvas.width/2 - 60 && mx < canvas.width/2 + 60 &&
        my > 390 && my < 430) {
      resetGame();
      gameState = "PLAYING";
    }
  }

  if (gameState === "GAMEOVER") {
    // Check click on RESTART button (centered around canvas.width/2, y=330)
    if (mx > canvas.width/2 - 60 && mx < canvas.width/2 + 60 &&
        my > 330 && my < 370) {
      resetGame();
      gameState = "PLAYING";
    }
  }
});
```

---

### Step 9 — Reset Function

```js
function resetGame() {
  score = 0;
  lives = 3;
  items = [];
  spawnTimer = 0;
  spawnInterval = 80;
  fallSpeed = 3;
  speedTimer = 0;
  player.x = 200;
  gameState = "PLAYING";
}
```

---

### Step 10 — Main Game Loop

```js
function gameLoop() {
  update();
  draw();
  requestAnimationFrame(gameLoop);
}

// Start the loop
gameLoop();
```

---

## 8. "Done When" Checklist for Stage 1

- [ ] `index.html` opens in Chrome/Edge by double-clicking — no errors in Console (F12)
- [ ] Start screen displays with a clickable START button
- [ ] Basket moves left/right with Arrow Keys
- [ ] Basket follows the mouse cursor
- [ ] Green and red rectangles fall from the top
- [ ] Catching a green item adds 10 points to the HUD
- [ ] Catching a red item removes 1 life from the HUD
- [ ] When lives reach 0, the GAME OVER screen appears with the final score
- [ ] Clicking RESTART resets everything and the game starts again cleanly
- [ ] Falling speed gradually increases over time

---

## 9. Prompt to Give Your Builder Model

> You are a JavaScript game developer. Build a complete browser-based Catch Game using an HTML5 Canvas. It must use exactly 3 files: `index.html`, `style.css`, and `script.js`.
>
> **Rules:**
> - A basket at the bottom moves left/right with Arrow Keys and follows the mouse.
> - Green rectangles fall randomly — catching one gives +10 points.
> - Red rectangles fall randomly — catching one costs -1 life. Player starts with 3 lives.
> - Items that fall past the bottom are removed with no penalty.
> - Spawn speed and fall speed gradually increase every 300 frames.
>
> **States:** `"START"` → show title and START button. `"PLAYING"` → run game. `"GAMEOVER"` → show score and RESTART button.
>
> **No external libraries, no image files, no CDN links.** Use only plain rectangles and `ctx.fillText()` for all visuals. The game must run offline by double-clicking `index.html`.
>
> Use `requestAnimationFrame` for the game loop. Use AABB collision detection. Include all logic in `script.js` and styles in `style.css`.
