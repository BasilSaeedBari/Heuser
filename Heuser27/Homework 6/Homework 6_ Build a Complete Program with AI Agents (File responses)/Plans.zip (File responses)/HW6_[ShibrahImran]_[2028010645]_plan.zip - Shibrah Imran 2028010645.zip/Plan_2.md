# Stage 2 — Visual Vibe Plan: Ocean Catch Game

Stage: Visual Theme  
Architect model: Claude Sonnet 4.6  
Builder model: (Gemini Flash)
Result: (Checked rendering performance with layered backgrounds, swaying kelp, procedural sea creatures, and bubbles.Fixed performance bug: Found a frame-rate dip caused by continuous shadowBlur during bubble renders; resolved by limiting intense glows to catch flash moments.)

---

## Game Overview

An ocean-themed reskin of the Stage 1 Catch Game. The core logic (scoring, lives, collision, states, controls) is **100% unchanged**. All changes are purely visual — drawn entirely with the HTML5 Canvas API. Zero image files. The game runs offline by double-clicking `index.html`.

---

## Files (unchanged structure)

| File | Purpose |
|------|---------|
| `index.html` | Page shell — title updated to "Ocean Catch" |
| `style.css` | Body/canvas styling — background updated to deep ocean |
| `script.js` | All game logic + new visual draw layers added |

---

## 🎨 Color Palette

### Your Specified Palette
| Swatch | Hex | Role |
|--------|-----|------|
| 🟣 Orchid | `#DA70D6` | Jellyfish glow, sparkle tints, UI accents |
| 🩷 Hot Pink | `#FF0090` | Anemone tentacles, bad-item glow, danger ring |
| 🔴 Deep Crimson | `#E52B50` | Bad items (sea urchins), life-lost flash |
| 🔵 Steel Blue | `#2072AF` | Mid-water gradient layer |
| 🩵 Ocean Blue | `#0095B6` | Water shimmer, bubble outlines |
| 🌤 Sky Blue | `#87CEEB` | Shallow surface top, HUD text glow |
| 🟢 Neon Green | `#66FF00` | Good-catch sparkle burst, seaweed tips |
| 🟢 Deep Forest | `#00563B` | Tall kelp stalks, seabed base plants |
| 🟢 Hunter Green | `#177245` | Marine plant mid-body |
| 🟢 Shamrock | `#03C03C` | Seaweed fronds, good item glow |
| 🟠 Carrot Orange | `#ED9121` | Starfish body, sand base, fish tail |
| 🔴 Dark Red | `#8B0000` | Urchin spines, danger zone edge |
| 🍑 Salmon Pink | `#F88379` | Clownfish stripes, anemone petals |
| 🍷 Burgundy | `#7F1734` | Deep-sea shadows, bad-item core |
| 🌕 Amber Gold | `#FFBF00` | Starfish highlight, treasure shimmer, score text |
| 🔵 Azure | `#007FFF` | Player net/basket, button fill |

### Supplemental Ocean Colours
| Hex | Role |
|-----|------|
| `#001F3F` | Deep ocean darkest background base |
| `#003366` | Canvas gradient bottom stop |
| `#00BFFF` | Deep sky blue — bubble shimmer ring |
| `#40E0D0` | Turquoise — decorative fish body |
| `#7FFFD4` | Aquamarine — sparkle / catch flash highlight |
| `#E0FFFF` | Light cyan — bubble inner highlight dot |
| `#FFF8DC` | Cornsilk — HUD text, screen overlay text |
| `#FFD700` | Gold — star sparkle points |
| `#FF6347` | Tomato — bad-catch screen edge flash |
| `#C0C0C0` | Silver — bubble ring glint |

---

## 🖼️ Background — Layered Ocean

### Canvas Gradient (top → bottom)
```
#87CEEB  (sky blue — shallow surface)
  ↓
#0095B6  (ocean blue — mid water)
  ↓
#2072AF  (steel blue — deeper water)
  ↓
#003366  (night ocean)
  ↓
#001F3F  (darkest floor)
```
Drawn each frame via `createLinearGradient` across full canvas height.

### Light Ray Layer
- 4–6 diagonal shafts drawn as semi-transparent triangles
- Colour: `#87CEEB` at 8% opacity
- Drift slowly leftward: `x shift += 0.2` per frame, wraps around

### Caustic Shimmer
- 8–12 small white `arc` circles at 5% opacity
- Randomly repositioned every 120 frames to simulate underwater light scatter

---

## 🫧 Bubbles Layer

Drawn **behind** game items, **above** background.

### Bubble Properties
| Property | Value |
|----------|-------|
| Count | 15–20 always active |
| Radius | 4–18 px (random per bubble) |
| Rise speed | 0.4–1.2 px/frame |
| Horizontal drift | ±0.3 px/frame (sine wobble) |
| Colour | `#0095B6` stroke + `#E0FFFF` highlight dot |
| Opacity | 40–70% |
| Reset | When y < –radius → teleport to canvas bottom at random x |

### Draw Pattern
```js
// Bubble ring
ctx.strokeStyle = "#0095B6";
ctx.lineWidth = 1.5;
ctx.beginPath();
ctx.arc(b.x, b.y, b.r, 0, Math.PI * 2);
ctx.stroke();

// Highlight dot (top-left quadrant)
ctx.fillStyle = "rgba(224,255,255,0.8)";
ctx.beginPath();
ctx.arc(b.x - b.r * 0.3, b.y - b.r * 0.3, b.r * 0.2, 0, Math.PI * 2);
ctx.fill();
```

---

## 🌿 Marine Plants Layer (Seabed)

Static decorations drawn at the bottom edge of the canvas.

### Seaweed / Kelp (5–8 stalks)
- Wavy paths via `bezierCurveTo`
- Colours alternate: `#00563B` → `#177245` → `#03C03C`
- Heights: 40–100 px from canvas bottom
- Width: 6–10 px
- Sway: control points shift by `Math.sin(frame * 0.02) * 8`

### Seaweed Fronds
- Small oval branches off each stalk
- Colour: `#66FF00` at 70% opacity

### Anemone (3–4 clusters)
- Base: `#8B0000` rounded rect
- Tentacles: 6–8 curved `bezierCurveTo` lines in `#FF0090` and `#F88379`
- Tips: small `arc` glow in `#DA70D6`

### Coral Mounds
- Overlapping `arc` bumps along the seabed floor
- Colours: `#ED9121`, `#7F1734`, `#F88379`

---

## ⭐ Starfish

### Decorative (seabed, static)
- 2–3 starfish in bottom corners
- 5-point star via alternating inner (r=8) and outer (r=20) points
- Body: `#ED9121` fill, `#FFBF00` highlight

### Falling Starfish (Good Item variant)
- Replaces 1-in-3 good item rectangles visually
- Same core item object — only the draw function changes
- Radius: ~15 px
- Catching: `+10 pts` (unchanged)

### Star Draw Function
```js
function drawStar(ctx, cx, cy, spikes, outerR, innerR, fillColor) {
  let rot = (Math.PI / 2) * 3;
  const step = Math.PI / spikes;
  ctx.beginPath();
  ctx.moveTo(cx, cy - outerR);
  for (let i = 0; i < spikes; i++) {
    ctx.lineTo(cx + Math.cos(rot) * outerR, cy + Math.sin(rot) * outerR);
    rot += step;
    ctx.lineTo(cx + Math.cos(rot) * innerR, cy + Math.sin(rot) * innerR);
    rot += step;
  }
  ctx.closePath();
  ctx.fillStyle = fillColor;
  ctx.fill();
}
```

---

## 🐠 Sea Creatures (Falling Items)

All drawn with `ctx` primitives only — no image files.

### Good Item Visual Types (replace green rectangles)

#### 1. Tropical Fish 🐟
- Body: `#FFBF00` ellipse · Tail: `#ED9121` triangle fan
- Eye: small black `arc` · Stripe: `#F88379` arc band

#### 2. Treasure Coin 🪙
- Outer circle: `#FFBF00` · Inner ring: `#ED9121`
- Centre text: `$` in `#8B0000`

#### 3. Pearl Shell 🦪
- Two `bezierCurveTo` curves forming a clamshell
- Shell: `#87CEEB` → `#E0FFFF` · Pearl: `#FFF8DC` radial gradient dot

#### 4. Starfish ⭐
- `#ED9121` fill + `#FFBF00` outline (see star function above)

### Bad Item Visual Types (replace red rectangles)

#### 1. Sea Urchin 🦔
- Core: `#7F1734` circle
- Spines: 12–16 thin lines radiating out in `#8B0000`
- Tips: tiny `arc` dots in `#E52B50`

#### 2. Toxic Jellyfish 🪼
- Bell: semi-circle in `#DA70D6` at 50% opacity
- Tentacles: 4–6 wavy `bezierCurveTo` lines in `#FF0090`
- Inner glow: `createRadialGradient` from `#FF0090` → transparent

#### 3. Dark Coral 🪸
- Angular cluster of `fillRect` shapes in `#8B0000` and `#E52B50`

---

## 🫙 Player — Net / Basket

Replaces the plain `#4af` rectangle.

### Shape
- Rounded rect: 80 × 20 px
- Fill: `#007FFF` → `#0095B6` linear gradient
- Outline: `#87CEEB` stroke, 2 px
- Net mesh: 4–5 vertical lines + 2 diagonal cross-lines in white at 40% opacity
- Glow: `ctx.shadowColor = "#007FFF"` · `ctx.shadowBlur = 12`

### Catch Flash
- Good catch: `shadowBlur` → 24, `shadowColor` → `#66FF00` for 10 frames
- Bad catch: `shadowColor` → `#E52B50` for 10 frames

---

## ✨ Sparkle / Particle System

Triggered on every item collision. Drawn above all other layers.

### Good Catch Sparkle
- 8 particles burst from catch point
- Shape: 4-point star, size 4–8 px
- Colours: `#66FF00`, `#7FFFD4`, `#FFBF00`, `#FFD700`
- Spread: radial, 2–5 px/frame · Lifetime: 20 frames, alpha fades 1 → 0

### Bad Catch Flash
- 6 particles + red screen vignette
- Colours: `#E52B50`, `#FF0090`, `#8B0000`
- Vignette: `createRadialGradient` transparent centre → `rgba(229,43,80,0.3)` edges
- Duration: 15 frames

### Score Pop Text
- `+10` floats upward from catch point
- Font: `bold 16px sans-serif` · Colour: `#66FF00`
- Rises 30 px, fades over 40 frames

---

## 🖥️ Screen Designs

### START Screen
```
[Deep ocean gradient background — animated]
[Bubbles rising · Seaweed swaying · Coral along bottom]

        🌊 OCEAN CATCH 🌊           ← #87CEEB, bold 34px, glow shadow
   Dive in and catch the treasure!  ← #FFF8DC, 15px

  🐟 Catch SEA CREATURES  +10 pts  ← #03C03C
  🦔 Avoid URCHINS & JELLY  -1 ❤️  ← #E52B50
     Use Arrow Keys or Mouse        ← #87CEEB

        [  🌊  DIVE IN!  ]          ← #007FFF bg · #FFF8DC text
                                       rounded corners · glow border
```

### PLAYING HUD
```
┌─────────────────────────────────────────┐
│  Score: 🐚 240           ❤️ ❤️ ❤️      │  ← semi-transparent dark panel, top
└─────────────────────────────────────────┘
[Ocean background + all animated layers]
[Falling sea creatures]
[Player net at bottom]
```

### GAME OVER Screen
```
[Darkened ocean bg — overlay rgba(0,0,30,0.7)]
[Bubbles still rising slowly]

       🌊 GAME OVER 🌊              ← #DA70D6, bold 36px
     Final Score: 240               ← #FFBF00, 24px
     Best Score:  310               ← #87CEEB, 18px

        [  🔄  DIVE AGAIN  ]        ← same button style as START
```

---

## 🎞️ Animation Summary

| Element | Type | Speed |
|---------|------|-------|
| Ocean background | Static gradient per frame | — |
| Light rays | Horizontal drift + wrap | 0.2 px/frame |
| Caustic shimmer | Random reposition | Every 120 frames |
| Bubbles | Rise + sine wobble | 0.4–1.2 px/frame |
| Seaweed | Sine sway (control points) | `sin(frame × 0.02) × 8` |
| Anemone tentacles | Sine sway | `sin(frame × 0.03) × 5` |
| Falling items | Downward (core logic) | `fallSpeed` (unchanged) |
| Good catch sparkle | Radial burst + fade | 20 frames |
| Bad catch vignette | Fade in/out | 15 frames |
| Score pop `+10` | Rise + fade | 40 frames |
| Player net glow | Pulse on catch | 10 frames |

---

## 🧩 Implementation Layer Map

Core logic files are **not modified**. New draw functions wrap around the existing `draw()` call.

```
gameLoop()
  ├── update()                  ← UNTOUCHED (scoring, collision, states, speed)
  └── draw()
        ├── drawBackground()         ← NEW: gradient + light rays + caustics
        ├── drawBubbles()            ← NEW: rising bubble layer
        ├── drawSeabed()             ← NEW: plants, coral, anemones, static starfish
        ├── drawItems()              ← MODIFIED: creature shapes replace plain rects
        ├── drawPlayer()             ← MODIFIED: net shape replaces plain rect
        ├── drawParticles()          ← NEW: sparkle bursts + score pop text
        └── drawHUD()                ← MODIFIED: styled hearts + score panel
```

---

## 🔧 New Variables to Add (script.js top)

```js
// ── Visual state ─────────────────────────────────────────────────
let frame = 0;               // global frame counter for animations

const bubbles   = [];        // { x, y, r, speed, drift, phase }
const particles = [];        // { x, y, vx, vy, life, maxLife, color, size }
const scorePopups = [];      // { x, y, life, text }
const seabedPlants = [];     // pre-generated static plant data (init once)
const seabedDeco   = [];     // pre-generated coral/starfish positions

// ── Palette shortcuts ────────────────────────────────────────────
const COLORS = {
  orchid:      "#DA70D6",
  hotPink:     "#FF0090",
  crimson:     "#E52B50",
  steelBlue:   "#2072AF",
  oceanBlue:   "#0095B6",
  skyBlue:     "#87CEEB",
  neonGreen:   "#66FF00",
  deepGreen:   "#00563B",
  hunterGreen: "#177245",
  shamrock:    "#03C03C",
  carrot:      "#ED9121",
  darkRed:     "#8B0000",
  salmon:      "#F88379",
  burgundy:    "#7F1734",
  amber:       "#FFBF00",
  azure:       "#007FFF",
};
```

---

## ✅ Visual "Done When" Checklist

- [ ] Background is a 5-stop deep ocean gradient
- [ ] Light rays visibly drift across the canvas
- [ ] 15+ bubbles rise continuously with highlight dots
- [ ] Seabed has swaying seaweed, coral mounds, and anemones
- [ ] At least 2 decorative starfish on the seabed
- [ ] Good items appear as fish / pearls / shells / starfish
- [ ] Bad items appear as urchins / toxic jellyfish / dark coral
- [ ] Player is a glowing blue net (no plain rectangle)
- [ ] Sparkle particles appear on every catch
- [ ] Red vignette flashes on bad catch
- [ ] Floating `+10` score text rises from catch point
- [ ] START screen reads "🌊 OCEAN CATCH 🌊" with ocean styling
- [ ] GAME OVER screen is ocean-themed with dark overlay
- [ ] HUD uses ❤️ hearts for lives and ocean-styled font
- [ ] Zero external files — no images, no CDN fonts, no libraries
- [ ] Game runs offline by double-clicking `index.html`

---

*Plan_2.md · Stage 2 Visual Theme · Architect: Claude Sonnet 4.6 (Thinking) · October 2026*
