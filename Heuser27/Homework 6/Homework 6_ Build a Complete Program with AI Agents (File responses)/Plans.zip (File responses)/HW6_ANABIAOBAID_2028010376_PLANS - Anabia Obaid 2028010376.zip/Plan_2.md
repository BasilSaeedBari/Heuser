# Plan 2 — Mochi's Virtual Pet: Visual Vibe

---

**Stage:** Visual Vibe  
**Architect model:** Gemini 3.8 Flash (Low)  
**Builder model:** Gemini 3.8 Flash (Low)  
**Result:** Passed. All Stage 1 (N1–N71) and Stage 2 (T1–T6) automated test cases verified and passing in headless browser.  

---

## Project Overview

**Mochi's Virtual Pet** is an interactive virtual pet browser game where the player cares for a bunny named Mochi in an enchanted forest. The visual aesthetic fuses:
- **Retro pixel art** (chunky silhouettes, grid-aligned features, pixel-art bunny styling).
- **Dark fantasy atmosphere** (deep twilight tones, mystical glowing accents, muted eerie forest hues).
- **Enchanted forest setting** (moss greens, night purples, glowing fireflies, subtle code-driven mist).

Stage 1 established the complete core logic, status bars, cooldown, scoring, expressions data rules, and state engine.
**Stage 2 focuses strictly on Visual Vibe:** replacing placeholder visuals with pure code-generated pixel artwork, an animated background, expressive character visuals, and enhanced thematic UI presentation—without altering core gameplay logic or violating offline/asset restrictions.

### Technical Constraints Reminder
- Exactly three code files in the workspace: `index.html`, `style.css`, `script.js`.
- No downloaded image files (no `.png`, `.jpg`, `.gif`, `.webp`).
- No downloaded font files (no web fonts, CDNs, Google Fonts).
- No downloaded sound files or external libraries.
- All visuals generated via code (HTML5 Canvas 2D, pure CSS shapes/gradients, inline SVG).
- Game runs by double-clicking `index.html` completely offline.

---

## A. Visual Scope & Architecture for Stage 2

In Stage 1, Mochi was represented by a placeholder emoji (`🐰`) inside a circular border, and the background was a static CSS gradient.
In Stage 2, we introduce:
1. **Canvas-based Pixel Art Pet Renderer (`mochiCanvas`):** A dedicated retro pixel grid rendering Mochi's bunny body, ears, paws, and face.
2. **Dynamic Pixel Expressions:** Code-drawn pixel expressions for all 6 states (Happy, Sad, Hungry, Tired, Excited, Blushing) replacing emoji placeholders.
3. **Animated Enchanted Forest Background (`bgCanvas`):** A subtle, continuous atmospheric canvas background running layered code-generated visual effects (creeping twilight fog/mist, gentle glowing fireflies/spores, silhouette forest elements) running via `requestAnimationFrame`.
4. **Retro Pixel UI & Status Bars:** Pixelated borders, stylized retro typography using CSS system font fallbacks, textured status bar fills, and distinct threshold styling.
5. **Cosmetic Clothing & Toy Rendering Foundation:** Visual hooks to render selected accessories (witch hat, cloak, bow, dark hood) and toys directly on Mochi's canvas.

---

## B. Mochi's Pixel Art Character Design

### 1. Grid & Resolution Specification
- **Resolution:** A virtual pixel resolution of **32×32 pixels** (or 48×48) scaled up with `image-rendering: pixelated;` to crisp, chunky retro proportions (e.g., rendered on a 192×192 or 256×256 canvas).
- **Base Body Anatomy:**
  - Round, soft mochi-like bunny body silhouette.
  - Long bunny ears with inner pink/dark-fantasy shaded tone.
  - Little paws and a fluffy cotton tail.
  - Color palette: Mystical pale cream/ivory (`#f5f0e8`) with dark violet-grey outline (`#1e142b`) and shadow tones (`#d6cbbe` / `#b8a99a`).

### 2. The 6 Expression Designs (Drawn via Code)
Each expression is rendered on Mochi's face using pixel-grid coordinates:

| Expression | Eye Style | Mouth Style | Special Facial Elements |
|---|---|---|---|
| **Happy** | Curved cheerful crescent eyes `^^` or shiny 2×2 pixel dot eyes with catchlights | Cute little `w` or upward curved smile | Subtle soft peach cheek dots |
| **Sad** | Downturned drooping eyes or glossy glassy pixels | Small downward trembling curve | Pale or slight tear glint |
| **Hungry** | Wide, pleading dilated circular eyes | Small open wobbly mouth or tongue peeking | Subtle empty-tummy wobble |
| **Tired** | Half-closed sleepy heavy eyelids (`--`) | Flat or gentle yawn `o` | Floating pixel `z` particle or droopy ears |
| **Excited** | Wide sparkling eyes (star or cross glints) | Open happy grin `D` | Ears perked high with subtle bounce |
| **Blushing** | Sweet happy eyes with lowered gaze | Shy little smile | Vibrant rosy/pink cheek pixel clusters (`#fb7185` / `#f43f5e`) |

---

## C. Animated Background Architecture

### 1. Rendering Technique: Dual-Layered Canvas / CSS
To keep performance high and logic decoupled:
- A background canvas element (`#bg-canvas`) positioned behind the UI (`z-index: -1`).
- Runs an independent animation loop using `window.requestAnimationFrame`.
- Does **not** interfere with the 3000ms gameplay decay timer or 1500ms action cooldown.
- **Continues animating during the `Paused` state** so the forest remains alive and atmospheric while gameplay stays frozen.

### 2. Visual Layers
1. **Distant Twilight Sky:** Deep mystical gradient from midnight obsidian (`#070a10`) to twilight forest purple (`#170f26`).
2. **Forest Silhouettes:** Code-drawn pixel/vector pine tree ridges and twisted ancient branches in deep shadowy silhouette (`#0d141c` and `#080c12`).
3. **Drifting Ground Mist / Fog:** Semi-transparent soft mist waves gently oscillating across the base using sine-wave math.
4. **Enchanted Fireflies / Spores:** 15–25 drifting glowing particles that pulse in brightness (alpha cycling) and float in organic wandering vectors.

---

## D. UI & Status Bar Visual Enhancements

### 1. Retro Pixel Aesthetic for UI
- **Typography:** Pixel-friendly monospace system font stack (`'Courier New'`, `'Lucida Console'`, monospace) formatted with letter-spacing, uppercase titles, and crisp text shadows.
- **Borders & Panels:** Chunky retro double-borders or 2px inset/outset pixel borders with fantasy metal/stone colors (`#2e3d4f`, `#1e2631`, `#d4af37` gold highlights).
- **Buttons:** Tactile retro buttons with raised pixel shadow edges that depress 2px on click, with distinct dark-fantasy colors (emerald for Feed, sapphire for Play, amethyst for Sleep, obsidian for Clean).

### 2. Visual Status Bars
- Retro segmented or textured bar look using CSS pixel patterns.
- High-contrast threshold color coding:
  - **Healthy (>= 70):** Luminous emerald forest green (`#10b981`).
  - **Caution (31–69):** Amber torch glow (`#f59e0b`).
  - **Critical (<= 30):** Pulsing or high-contrast crimson blood-red (`#ef4444`).
- Health bar given a distinct ornate dark-fantasy border and ruby heart/crest visual marker.

---

## E. Clothing & Toys Visual Architecture

Stage 1 initialized the data models (`clothingItems`, `equippedClothing`, `toyItems`, `activeToy`).
In Stage 2, we introduce the visual layer architecture:
1. **Layered Sprite Rendering Order:**
   - Layer 0: Background aura / shadow.
   - Layer 1: Mochi bunny body & ears.
   - Layer 2: Body clothing (e.g., Little Cloak).
   - Layer 3: Face expression & cheeks.
   - Layer 4: Head clothing (e.g., Witch Hat, Dark Hood, Bow Ribbon).
   - Layer 5: Held / Active Toy (Carrot, Wand, Teddy, Flower, Ball) rendered near Mochi's paw or beside the pet.
2. **Cosmetic Preview / Selection UI:**
   - Minimalist, collapsible retro wardrobe selector bar in the interface, allowing player to toggle accessories on/off to visually test Mochi's looks.

---

## F. Edge Cases & Safeguards for Stage 2

1. **Window Resize / DPI Scaling:** Canvas elements must handle high-DPI displays without blurring using `window.devicePixelRatio` while preserving crisp pixel art (`image-rendering: pixelated`).
2. **Tab Inactivity & Animation Loop:** Use `requestAnimationFrame` for background/pet rendering so browser tab throttling pauses CPU rendering naturally without breaking gameplay timers.
3. **Performance Budget:** Particle and fog loops must use lightweight mathematical steps (no heavy canvas filters, minimal allocations per frame) maintaining 60 FPS.
4. **Decoupled Game State:** Visual rendering functions must be pure projections of `gameState`. If expression switches or needs decay, the next frame automatically reflects the state without out-of-sync DOM issues.
5. **No Interference with Cooldown / State Controls:** Canvas clicks or animations must not block keydown listeners or button interactions.

---

## G. Testing Checklist for Stage 2

| # | Test | Expected Result |
|---|---|---|
| T1 | Canvas Initialization | Pet canvas and background canvas render cleanly without console errors |
| T2 | Retro Pixel Scaling | Mochi appears crisp with pixelated filtering (no fuzzy interpolation) |
| T3 | Happy Expression Render | Mochi's face displays code-drawn happy eyes and smile when all needs >= 70 |
| T4 | Hungry Expression Render | Face switches to pleading wide eyes when hunger <= 30 |
| T5 | Tired Expression Render | Face displays sleepy eyelids and droopy ears when energy <= 30 |
| T6 | Sad Expression Render | Face displays sad mouth and drooping features when happiness/cleanliness <= 30 |
| T7 | Excited Expression Render | Face sparks with star glints / bouncy ears during Play action |
| T8 | Blushing Expression Render | Face renders pink pixel cheeks on approved blushing triggers |
| T9 | Background Animation | Fireflies drift and mist breathes smoothly via `requestAnimationFrame` |
| T10| Animation during Paused | Background continues ambient animation when game is Paused |
| T11| Status Bar Visuals | Bars display distinct pixel textures and accurate color thresholds (green/amber/red) |
| T12| Offline Integrity | Zero network requests, 0 external images, 0 font files loaded |
| T13| Core Logic Invariance | 3s decay, 1.5s cooldown, recovery amounts, and scoring work identically to Stage 1 |

---

## H. Completion Criteria

Stage 2 is complete when:
- [ ] Mochi is rendered as an original code-drawn retro pixel art bunny on HTML5 Canvas.
- [ ] All 6 expressions are visually distinct, code-rendered pixel art faces.
- [ ] The enchanted forest animated background runs smoothly with mist, trees, and fireflies.
- [ ] UI features a cohesive dark-fantasy retro pixel art theme.
- [ ] Status bars visually differentiate full, warning, and critical states with retro styling.
- [ ] Layered clothing and toy rendering hooks are visually wired and toggleable.
- [ ] All core gameplay rules from Stage 1 remain 100% intact and passing.
- [ ] Zero downloaded assets or external dependencies.

---

## Decisions for Your Review & Approval

Before the Builder implements Stage 2, please confirm:
1. **Pet Rendering Mode:** Do you approve using an **HTML5 2D Canvas with 32×32 retro pixel grid** scaled to crisp display size for Mochi?
2. **Accessory Selection UI:** Would you like a small collapsible retro "Wardrobe & Toys" drawer/panel included in the UI during Stage 2 to let players equip/unequip the clothing and toys?
3. **Ear / Idle Bounce:** Do you approve a subtle 2-frame gentle breathing/ear bounce animation while idle to give Mochi extra life?
