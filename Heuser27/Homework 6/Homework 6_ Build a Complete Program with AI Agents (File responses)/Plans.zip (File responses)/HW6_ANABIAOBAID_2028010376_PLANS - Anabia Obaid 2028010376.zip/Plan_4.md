# Plan 4 — Mochi's Virtual Pet: State & Storage

---

**Stage:** State & Storage  
**Architect model:** Gemini 3.8 Flash (Low)  
**Builder model:** Gemini Pro  
**Result:** Passed. All 96 test cases across Stages 1, 2, 3, and 4 verified and passing (100%).  

---

## Project Overview

**Mochi's Virtual Pet** is an interactive browser game running completely offline. Having completed:
- **Stage 1: Core Logic** (Needs, 3s decay, 1.5s cooldown, scoring, 6 expressions, state engine)
- **Stage 2: Visual Vibe** (32×32 retro pixel art bunny, animated enchanted forest background, wardrobe & toys)
- **Stage 3: Sensory Feedback** (Web Audio API procedural non-musical forest breeze & action sound effects, separate volume controls, master mute, particle bursts)

**Stage 4 introduces State & Storage.**  
Its purpose is to provide robust session persistence so the player never loses Mochi's progress, customization choices, or audio preferences when refreshing or closing the browser tab, while adding safe data management (Auto-Save, Manual Reset, and Save Data Export/Import).

### Strict Technical & Homework Restrictions
- Exactly three code files in the final ZIP: `index.html`, `style.css`, `script.js`.
- No external libraries or database servers (100% native browser `localStorage`).
- **Preserve Halal-Friendly Audio Requirements:** Strictly non-musical soundscapes and action SFX; zero music, melodies, instruments, or singing.
- Runs completely offline by double-clicking `index.html`.
- Preserves all 87 verified tests across Stages 1, 2, and 3 without breaking existing functionality.

---

## A. State & Storage Architecture

### 1. Storage Medium & Key Namespace
All game state is serialized into JSON and stored in `window.localStorage` under a dedicated, namespaced key:
- **Storage Key:** `mochis_virtual_pet_save_v1`
- **Schema Versioning:** Version property (`version: 1`) included to allow safe future schema migrations without corrupting player saves.

### 2. Persisted State Schema

```javascript
{
  version: 1,
  timestamp: 1729987200000, // Unix epoch ms of the last save
  gameState: {
    currentState: "playing", // or "paused" / "start"
    needs: {
      hunger: 80,
      happiness: 90,
      energy: 75,
      cleanliness: 85
    },
    health: 82,
    score: 140,
    equippedClothing: {
      head: "witch-hat",
      body: "cloak",
      accessory: null
    },
    activeToy: "wand"
  },
  audioSettings: {
    isMuted: false,
    ambienceVolume: 0.3,
    sfxVolume: 0.6
  },
  statistics: {
    totalSessions: 3,
    totalActionsPerformed: 24,
    highScore: 320
  }
}
```

---

## B. Core Storage Mechanics

### 1. Auto-Save System
- **Periodic Auto-Save:** Automatically writes state to `localStorage` every **10 seconds** during active gameplay.
- **Event-Driven Auto-Save:** Instantly triggers an auto-save upon:
  - Performing any effective care action (Feed, Play, Sleep, Clean).
  - Toggling an outfit or toy.
  - Changing volume sliders or toggling Master Mute.
  - Game state transitions (Pause, Resume, End).
  - Browser lifecycle events: `window.addEventListener("beforeunload", saveGame)`.

### 2. Offline / Away Elapsed Decay (With Safety Capping)
When the player reopens the game after having closed the browser tab:
- The game calculates `elapsedSeconds = (Date.now() - savedTimestamp) / 1000`.
- If `currentState` was `"playing"`, needs decay accordingly (at the approved rate: 2 points per 3 seconds).
- **Mochi Never Dies Protection (Safeguard):**
  - Even if away for days, needs clamp at **0 minimum** (Mochi never dies).
  - An away-summary notification is displayed upon return: *"While you were away for X minutes, Mochi waited patiently in the forest."*
  - Health recalculates accurately from the clamped needs.
- If the game was saved in `"paused"` or `"ended"` state, no decay occurs while away.

### 3. Save Data Export & Import (Offline Backup)
To give players full control over their pet data without requiring a server:
- **Export Save:** Generates a downloadable `mochi_save.json` file using an offline `Blob` and dynamic `<a>` download trigger.
- **Import Save:** A file input allows loading a `mochi_save.json` file, with validation of schema, clamping of numerical bounds (0–100), and immediate rehydration of pet state and wardrobe.
- **Reset Pet:** A secure "Reset All Data" option with confirmation modal/prompt that clears `localStorage` and restarts Mochi with fresh default values.

---

## C. User Interface Additions (Stage 4)

A clean, non-intrusive retro footer panel or drawer section:
- **Save Status Indicator:** Small subtle badge showing *"Saved ✓"* or *"Auto-saved just now"*.
- **Data Management Buttons:**
  - `[💾 Export Save]` — Downloads pet backup JSON.
  - `[📂 Import Save]` — Restores pet from backup JSON.
  - `[🗑 Reset Pet]` — Clears saved data with confirmation.

---

## D. Edge Cases & Safeguards

1. **Storage Quota / Incognito Mode:** If `localStorage` is disabled or throws `QuotaExceededError` (e.g. strict private browsing), operations fail gracefully without crashing the game; a console warning is logged, and the game continues running in-memory.
2. **Corrupted or Tampered JSON:** If the save data is invalid JSON or has missing properties, `loadGame()` catches the error, logs a warning, and falls back cleanly to fresh default values without hanging.
3. **Value Clamping on Load:** All loaded need values and health are passed through `clamp(val, 0, 100)` to prevent negative or >100 glitch states.
4. **Offline Preservation:** Export and Import operate 100% locally via the browser's native `FileReader` and `URL.createObjectURL(blob)`; zero external network calls.
5. **Halal Audio Invariance:** Loaded audio settings apply directly to the Web Audio gain nodes while strictly preserving the non-musical synthesis engine.

---

## E. Testing Checklist for Stage 4

| # | Test | Expected Result |
|---|---|---|
| ST1 | Initial Save Creation | Starting game creates valid `mochis_virtual_pet_save_v1` in `localStorage` |
| ST2 | Need & Score Persistence | Refreshing page restores exact needs, health, and score values |
| ST3 | Customization Persistence | Equipped clothing and active toy persist across browser reload |
| ST4 | Audio Settings Persistence | Mute state and volume slider positions persist across reload |
| ST5 | Periodic Auto-Save | State automatically saves every 10 seconds during active gameplay |
| ST6 | Action-Driven Save | Performing a care action saves state immediately |
| ST7 | Elapsed Offline Decay | Reopening after time away calculates decay; clamps at 0; pet never dies |
| ST8 | Export Save File | Export button generates and downloads a valid `mochi_save.json` |
| ST9 | Import Save File | Importing a valid JSON file restores pet needs, clothing, and score |
| ST10| Corrupted Save Recovery | Tampered/invalid JSON in storage falls back gracefully to defaults |
| ST11| Reset Data | Reset clears `localStorage` and reloads pet to pristine 100s state |
| ST12| Halal Audio Preservation | Sound remains 100% procedural and non-musical; zero music or instruments |
| ST13| Regression Tests | All 87 tests from Stages 1, 2, and 3 continue passing with 100% success |

---

## F. Completion Criteria

Stage 4 is complete when:
- [x] Game state (needs, health, score, wardrobe, toys) persists across page reloads.
- [x] Audio volume levels and mute state persist in `localStorage`.
- [x] Elapsed time offline decay calculates safely with 0 clamp (Mochi never dies).
- [x] Export and Import save JSON functionality works completely offline.
- [x] Reset Pet clears storage cleanly with confirmation.
- [x] Corrupted/invalid data is handled safely without crashes.
- [x] All 87 prior tests (Stages 1–3) plus all Stage 4 storage tests pass cleanly.

---

## Decisions for Your Review & Approval

Please confirm or provide feedback on:
1. **Offline Decay on Reconnect:** Do you approve calculating elapsed decay when reopening a session that was left in `"playing"` state (safely clamped at 0 so Mochi never dies), or should decay *only* occur while the tab is actively open?
2. **Auto-Save Frequency:** Do you approve periodic auto-save every **10 seconds** in addition to saving after every care action and setting change?
3. **Data Management UI:** Do you approve placing the Export, Import, and Reset buttons in a collapsible or compact "Data / Save" bar at the bottom of the container?
