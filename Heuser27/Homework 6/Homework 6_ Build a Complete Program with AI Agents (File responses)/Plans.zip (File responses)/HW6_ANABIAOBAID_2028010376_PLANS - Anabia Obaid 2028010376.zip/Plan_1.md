# Plan 1 — Mochi's Virtual Pet: Core Logic

---

**Stage:** Core Logic
**Architect model:** Claude Opus 4.6 (Thinking)
**Builder model:** Gemini 3.8 Flash (High)
**Result:** Passed. All 71 test cases verified and passed in automated browser testing.

---

## Project Overview

**Mochi's Virtual Pet** is a small interactive virtual pet game that runs directly in a web browser. The player cares for a bunny named Mochi who lives in an enchanted forest. The game's overall aesthetic combines retro pixel art, dark fantasy, an enchanted forest setting, and a cute but slightly mysterious atmosphere.

The project follows a five-stage process:

1. **Core Logic** — gameplay rules, controls, scoring, and game states.
2. **Visual Vibe** — pixel art, CSS shapes, SVG, and canvas-drawn visuals.
3. **Sensory Feedback** — code-generated sounds and visual feedback effects.
4. **State & Storage** — persistence and session management.
5. **Debugging** — final testing, polish, and bug fixes.

This plan covers **Stage 1 only**.

### Technical Constraints

| Constraint | Detail |
|---|---|
| Files | Exactly three: `index.html`, `style.css`, `script.js` |
| Execution | Double-click `index.html`, no internet required |
| External assets | None — no downloaded images, sounds, fonts, or libraries |
| Visuals (later stages) | Code-drawn: CSS shapes, inline SVG, or canvas |
| Sounds (later stages) | Code-generated via Web Audio API |

---

## A. Core Gameplay Rules

### The Four Needs

Mochi has four needs, each an integer value clamped to the range **[0, 100]**:

| Need | Description | Care Action | Key |
|---|---|---|---|
| **Hunger** | How well-fed Mochi is | Feed | W |
| **Happiness** | How entertained Mochi is | Play | A |
| **Energy** | How rested Mochi is | Sleep | S |
| **Cleanliness** | How tidy Mochi is | Clean | D |

### Initial State

All four needs begin at **100** when a new session starts.

### Need Decay

While the game state is **Playing**, all four needs decrease at a regular interval. Decay stops during **Paused** and **Ended** states.

**Approved values:**

| Parameter | Value |
|---|---|
| Decay interval | Every **3 seconds** |
| Decay amount | **2 points** per need per tick |
| Time to deplete a full need | ~150 seconds (2.5 minutes) |

All four needs decay at the **same rate**.

### Care Actions

Each care action restores its corresponding need by a fixed recovery amount. The value is clamped so it never exceeds 100.

**Approved recovery amounts (differentiated):**

| Action | Recovery Amount |
|---|---|
| Feed | **+20** |
| Play | **+10** |
| Sleep | **+25** |
| Clean | **+15** |

- A care action is **effective** if it increases the need (i.e., the need was below 100 before the action).
- A care action is **ineffective** if the need is already at 100 (no improvement possible).

### Global Cooldown

**Approved:** After performing **any** care action, **all four** care actions are locked for **1.5 seconds**.

- A single cooldown timer governs all actions.
- Both buttons and keyboard shortcuts (W/A/S/D) respect the same cooldown.
- During cooldown, buttons appear visually disabled and key inputs are ignored.
- If the player attempts an action during cooldown, a brief message is displayed: **"Wait a moment..."**
- The cooldown message disappears when the cooldown expires or is replaced by the next status message.

### Zero-Value Handling

**Mochi never permanently dies.** When any need reaches 0:

- A status message is displayed indicating Mochi's distress for that need (e.g., "Mochi is starving!" for hunger at 0).
- The corresponding care action remains fully available. The player can restore the need at any time.
- Other needs continue to decay normally.
- The session does **not** automatically end.

### Keeping Mochi Healthy

The player's goal is to monitor all four needs and perform care actions before they reach critically low levels. Strategic timing of actions maximizes the score while keeping Mochi in good condition.

---

## B. Health System

**Approved:** Health is a **derived read-only indicator** calculated from the four needs using a **simple average**.

### Formula

```
health = floor((hunger + happiness + energy + cleanliness) / 4)
```

| Scenario | Need Values | Health |
|---|---|---|
| All full | 100, 100, 100, 100 | 100 |
| Balanced moderate | 60, 60, 60, 60 | 60 |
| One critically low | 100, 100, 100, 0 | 75 |
| Two critically low | 100, 100, 0, 0 | 50 |
| All zero | 0, 0, 0, 0 | 0 |

### Health at Zero

When health reaches 0:

- A prominent distress message is displayed (e.g., *"Mochi is in terrible shape! Take care of your bunny!"*).
- Mochi's expression reflects the worst active condition.
- All care actions remain available — the player can restore needs, which immediately raises health.
- The session does **not** automatically end. **Mochi never permanently dies.**

### Recalculation Timing

Health is recalculated after every **decay tick** and every **care action**.

### Display

- Labeled **"Health"**.
- Displayed separately and prominently — above the four need bars or in a distinct "overall status" area.
- Uses the same bar structure and three-threshold color classes as need bars.

---

## C. Scoring

### Point Awards

| Condition | Points |
|---|---|
| Effective care action (need was below 100 and increased) | **+10** |
| Ineffective care action (need was already at 100) | **0** |

### Rules

- The score is a non-negative integer, displayed at all times during gameplay.
- Points are awarded **immediately** when a care action is performed, after verifying effectiveness.
- A care action is effective if `need < 100` before the action is applied. The actual amount restored does not affect the point award — any effective action earns exactly 10 points.
- The score **resets to 0** when a new session starts (via restart).
- The score is **frozen** (no further changes) when the session enters the Ended state.
- The final score is displayed prominently when the session ends.

### Score Update Sequence

1. Player triggers a care action (button or key).
2. Check current game state — if not Playing, reject the action.
3. Check cooldown — if cooldown is active, display "Wait a moment..." and reject.
4. Read the current value of the corresponding need.
5. If `need < 100`: add recovery amount (clamped to 100), add 10 to score, start cooldown timer.
6. If `need == 100`: do nothing, award 0 points, **do not** start cooldown (action was ineffective).
7. Update the display.

> **Note:** Cooldown activates only on **effective** actions. Ineffective actions (need already at 100) do not trigger cooldown, allowing the player to immediately try a different action.

---

## D. Controls

### Care Action Buttons and Keyboard Shortcuts

| Button Label | Keyboard Shortcut | Action | Affected Need | Recovery |
|---|---|---|---|---|
| Feed | **W** | Restores hunger | Hunger | +20 |
| Play | **A** | Restores happiness | Happiness | +10 |
| Sleep | **S** | Restores energy | Energy | +25 |
| Clean | **D** | Restores cleanliness | Cleanliness | +15 |

### Game State Controls

| Button | Function |
|---|---|
| **Start** | Begins a new session (visible only in Start state) |
| **Pause** | Pauses the session (visible during Playing) |
| **Resume** | Resumes the session (visible during Paused) |
| **End** | Manually ends the session (visible during Playing or Paused) |
| **Restart** | Starts a fresh session (visible during Ended) |

### Input Validation

- **Game state check:** Every care action (button or keyboard) first checks whether the game is in the Playing state. If not, the action is silently ignored.
- **Cooldown check:** If the global cooldown is active, the action is rejected and a "Wait a moment..." message is displayed.
- **Key identification:** Only the W, A, S, and D keys trigger care actions. Both uppercase and lowercase are accepted. All other keys are ignored.
- **Prevent browser defaults:** `event.preventDefault()` is called on W, A, S, and D keydown events to prevent any browser-default behavior.

### Rapid-Input Handling

- **Global cooldown** (1.5 seconds) prevents action spam after effective actions.
- **`keydown` repeat filtering:** The handler checks `event.repeat` and ignores repeated keydown events caused by holding a key down. Only the initial keydown fires the action.

### Control Behavior by Game State

| State | Care Buttons | W/A/S/D Keys | State Controls Available |
|---|---|---|---|
| **Start** | Disabled | Ignored | Start |
| **Playing** | Active (subject to cooldown) | Active (subject to cooldown) | Pause, End |
| **Paused** | Disabled | Ignored | Resume, End |
| **Ended** | Disabled | Ignored | Restart |

---

## E. Game States

### State Diagram

```mermaid
stateDiagram-v2
    [*] --> Start
    Start --> Playing : Start button
    Playing --> Paused : Pause button
    Paused --> Playing : Resume button
    Playing --> Ended : End button
    Paused --> Ended : End button
    Ended --> Start : Restart button
```

### State Details

#### Start
- The initial state when the page loads or after a restart.
- All needs are set to 100. Health is 100. Score is 0.
- No decay timer is running.
- A welcome/start screen is shown.
- The player presses **Start** to begin.

#### Playing
- The decay timer is active — needs decrease every tick.
- Care actions (buttons and keys) are fully functional, subject to cooldown.
- Score can increase.
- The player may **Pause** or **End** the session.

#### Paused
- The decay timer is **stopped** (cleared).
- Care actions are **disabled**.
- Need values, health, and score are preserved (frozen in place).
- The player may **Resume** (restarts the timer) or **End** the session.

#### Ended
- The decay timer is **stopped** (cleared).
- Care actions are **disabled**.
- The final score is displayed prominently.
- Need values and health are frozen at their last values.
- The player may **Restart**, which transitions to the **Start screen** (requiring another click to begin playing).

### Transition Actions

| Transition | Actions Performed |
|---|---|
| Start → Playing | Start the decay timer. Set `isFirstAction = true`. |
| Playing → Paused | Clear the decay timer. Clear cooldown timer if active. |
| Paused → Playing | Start a new decay timer. |
| Playing → Ended | Clear the decay timer. Clear cooldown timer. Clear temporary expression timers. Display final score. |
| Paused → Ended | Ensure timer is cleared. Clear temporary expression timers. Display final score. |
| Ended → Start | Reset all needs to 100. Recalculate health to 100. Reset score to 0. Reset expression to Happy. Clear display. |

### Timer Management

A single variable (`gameTimerId`) holds the current `setInterval` ID. Every transition that stops gameplay calls `clearInterval(gameTimerId)` and sets it to `null`. Every transition that starts gameplay calls `setInterval(...)` and stores the returned ID.

Helper functions `startTimer()` and `stopTimer()` encapsulate this logic. `startTimer()` calls `stopTimer()` first as a safety guard. This guarantees:

- No duplicate timers.
- No orphaned timers after pause/resume cycles.
- Clean timer state in every game state.

A separate variable (`cooldownTimerId`) manages the global action cooldown via `setTimeout`. It is cleared on pause and end transitions.

---

## F. Mochi's Expression System

### Expression Types

| Expression | Description |
|---|---|
| **Happy** | Mochi's needs are generally well maintained |
| **Sad** | One or more needs are low |
| **Hungry** | Hunger is critically low |
| **Tired** | Energy is critically low |
| **Excited** | Mochi reacts positively to an effective Play action |
| **Blushing** | Mochi shows pink cheeks during special interactions |

### Expression Trigger Rules

| Expression | Trigger Condition |
|---|---|
| **Happy** | All needs ≥ 70 (and no temporary expression is active) |
| **Excited** | The player just performed an effective **Play** action (temporary, ~2 seconds) |
| **Blushing** | See approved triggers below (temporary, ~2.5 seconds) |
| **Hungry** | Hunger ≤ 30 and hunger is the lowest need |
| **Tired** | Energy ≤ 30 and energy is the lowest need |
| **Sad** | Any need ≤ 30 (catch-all when the lowest need is happiness or cleanliness) |

### Priority Resolution (Highest First)

| Priority | Expression | Rationale |
|---|---|---|
| 1 | **Hungry** | Critical survival need demands immediate attention |
| 2 | **Tired** | Critical survival need demands immediate attention |
| 3 | **Sad** | General distress from any low need |
| 4 | **Excited** | Temporary positive reaction; overridden by critical distress |
| 5 | **Blushing** | Temporary cosmetic reaction; overridden by distress and excitement |
| 6 | **Happy** | Default well-maintained state |

**Key rule:** A critically low need (priorities 1–3) **always** overrides temporary positive expressions (Excited, Blushing). Mochi will never blush or look excited while starving or exhausted.

**Tie-breaking:** If hunger and energy are both the lowest need at ≤ 30 (exact tie), **Hungry** takes priority.

### Approved Blushing Triggers

| Trigger | Condition |
|---|---|
| Feeding when very hungry | Player feeds Mochi when hunger ≤ 25 |
| All needs high | All four needs ≥ 90 after a care action |
| First action of session | The very first effective care action after starting a new session |

**Approved duration:** **2.5 seconds**.

**Behavior:**
- Blushing is set via a flag (`isBlushingActive = true`) and a `setTimeout` of 2500ms that clears the flag.
- If a new blushing trigger occurs while already blushing, the timer resets (extends the duration).
- Blushing is **immediately cancelled** if any need drops to ≤ 30 during the blushing window.
- Blushing does not affect needs or scoring — purely expressive.

### Approved Excited Trigger

- Excited triggers **only** on effective **Play** actions (not on Feed, Sleep, or Clean).
- **Duration:** 2 seconds.
- Same flag/timer pattern as Blushing.
- Cancelled immediately if any need drops to ≤ 30.

### Expression Evaluation Function

The expression is recalculated after every **decay tick**, every **care action**, and when a **temporary expression timer expires**.

```
function determineExpression():
    // Priority 1-3: Critical needs override everything
    if any need ≤ 30:
        cancel any active blushing/excited timer
        lowestNeed = find need with minimum value
        if lowestNeed is hunger: return "hungry"
        if lowestNeed is energy: return "tired"
        return "sad"

    // Priority 4: Temporary excited
    if isExcitedActive: return "excited"

    // Priority 5: Temporary blushing
    if isBlushingActive: return "blushing"

    // Priority 6: Default
    return "happy"
```

### Temporary Expression Management

Both **Excited** and **Blushing** use the same pattern:

1. A boolean flag (`isExcitedActive`, `isBlushingActive`) marks the expression as active.
2. A `setTimeout` ID is stored (`excitedTimerId`, `blushingTimerId`) for cancellation.
3. When the timer expires, the flag is cleared, the timer ID is nullified, and `determineExpression()` is called to revert to baseline.
4. If a new trigger occurs while already active, `clearTimeout` is called on the existing timer and a fresh timer starts.
5. If a critical need (≤ 30) is detected, the flag is cleared and its timer is cancelled immediately.

### Stage 1 Display

- The current expression is stored as a string in the game state: `currentExpression`.
- A **text label** displays the expression (e.g., *"Mochi is happy!"*, *"Mochi is blushing!"*).
- Placeholder emoji or text symbols may accompany the label:
  - Happy → 😊, Sad → 😢, Hungry → 🍽️, Tired → 😴, Excited → ⭐, Blushing → 😊💗
- Detailed pixel-art faces are deferred to **Stage 2**.

---

## G. Visual Status Bars

### Required Bars

Five bars are displayed during gameplay:

| Bar | Source Value | Range |
|---|---|---|
| Hunger | `needs.hunger` | 0–100 |
| Happiness | `needs.happiness` | 0–100 |
| Energy | `needs.energy` | 0–100 |
| Cleanliness | `needs.cleanliness` | 0–100 |
| Health | `health` (derived) | 0–100 |

### Bar Requirements

Each bar must:

1. **Represent a value between 0 and 100** — fill width proportional to the percentage.
2. **Update immediately** when the corresponding value changes.
3. **Display a numeric value** alongside the bar (e.g., "72 / 100").
4. **Never visually represent a value below 0 or above 100** — clamping enforced before rendering.
5. **Clearly distinguish three states:**
   - **Full/Healthy** (value ≥ 70): visually healthy appearance.
   - **Caution** (value 31–69): visually cautionary appearance.
   - **Critical** (value ≤ 30): visually alarming appearance.

### Stage 1 Bar Implementation

Each bar is constructed from two nested HTML elements:

```
<div class="bar-container">
  <div class="bar-fill"></div>
</div>
<span class="bar-value">72 / 100</span>
```

- The `.bar-fill` element's `width` is set as a percentage: `width: ${value}%`.
- A CSS class is toggled based on value thresholds:
  - `bar-healthy` (≥ 70)
  - `bar-caution` (31–69)
  - `bar-critical` (≤ 30)
- In Stage 1, these classes use distinct background colors. Decorative styling, gradients, and animations are deferred to Stage 2.

### Bar Update Function

```
function updateBar(needName, value):
    clampedValue = clamp(value, 0, 100)
    set bar fill width to clampedValue%
    set label text to "clampedValue / 100"
    remove all threshold classes
    add appropriate threshold class based on clampedValue
```

---

## H. Emotional Feedback System

### Design Goal

The player should always understand Mochi's condition at a glance. Three feedback channels work together:

1. **Status bars** — precise numerical state of each need and health.
2. **Expression** — Mochi's facial/emotional response.
3. **Status message** — a written text description of Mochi's condition or reaction.

These three channels must be **consistent** and never contradict each other, with one documented exception: brief temporary reactions (which are suppressed when critical needs exist).

### Feedback Coherence Rules

#### Rule 1: Bars Drive Expression

| Need State | Bars Show | Expression Shows | Status Message |
|---|---|---|---|
| All needs ≥ 70 | All bars healthy | Happy | "Mochi is happy and healthy!" |
| One need 31–69 | That bar in caution | Happy (still above threshold) | "Mochi could use some attention." |
| One need ≤ 30 | That bar critical | Hungry / Tired / Sad | "Mochi is very hungry!" etc. |
| Multiple needs ≤ 30 | Multiple bars critical | Highest-priority distress | "Mochi needs lots of care!" |
| All needs at 0 | All bars empty | Sad (or Hungry/Tired) | "Mochi is in terrible shape!" |

#### Rule 2: Temporary Reactions Are Brief and Conditional

- Excited and Blushing display for their approved durations (2s and 2.5s).
- **Critical override:** If any need is ≤ 30, temporary positive expressions are suppressed.

#### Rule 3: Actions Produce Multi-Channel Feedback

When the player performs a care action:

| Channel | What Happens |
|---|---|
| **Need bar** | The corresponding bar fill increases immediately |
| **Health bar** | Health recalculated and bar updates |
| **Expression** | Recalculated — may show Excited/Blushing if conditions met |
| **Status message** | Updated to describe the action result or reaction |
| **Score** | +10 if effective, unchanged if ineffective |
| **Cooldown** | 1.5s global cooldown starts (if action was effective) |

#### Rule 4: Decay Ticks Produce Passive Feedback

Each decay tick:

| Channel | What Happens |
|---|---|
| **Need bars** | All four bars decrease slightly |
| **Health bar** | Recalculated and updated |
| **Expression** | Recalculated — may shift if threshold crossed |
| **Status message** | Updated if a new threshold is crossed |

### Status Message Priority (Highest First)

| Priority | Condition | Example Message |
|---|---|---|
| 1 | Cooldown active and action attempted | "Wait a moment..." |
| 2 | Any need at 0 | "Mochi is starving!" / "Mochi is exhausted!" |
| 3 | Temporary reaction active, no critical need | "Mochi loved that!" / "Mochi is blushing!" |
| 4 | Any need ≤ 30 | "Mochi is very hungry…" / "Mochi is getting tired…" |
| 5 | Any need 31–69 | "Mochi could use some attention." |
| 6 | All needs ≥ 70 | "Mochi is happy and healthy!" |

When multiple needs are critical, the message reflects the **most severe** (lowest value). Ties are broken: hunger > energy > happiness > cleanliness.

### Care Action Feedback Matrix

| Action | Need Before | Bar Change | Expression | Status Message | Score |
|---|---|---|---|---|---|
| Feed | Hunger < 100 | ↑ increases | May trigger Blushing (if hunger was ≤ 25) | "Mochi munches happily!" | +10 |
| Feed | Hunger = 100 | No change | No change | "Mochi isn't hungry right now." | +0 |
| Play | Happiness < 100 | ↑ increases | Triggers Excited | "Mochi bounces with joy!" | +10 |
| Play | Happiness = 100 | No change | No change | "Mochi is already having a great time!" | +0 |
| Sleep | Energy < 100 | ↑ increases | May show Happy | "Mochi takes a cozy nap." | +10 |
| Sleep | Energy = 100 | No change | No change | "Mochi is wide awake!" | +0 |
| Clean | Cleanliness < 100 | ↑ increases | May show Happy | "Mochi sparkles after a bath!" | +10 |
| Clean | Cleanliness = 100 | No change | No change | "Mochi is already squeaky clean!" | +0 |

---

## I. Clothes and Toys Architecture

> Clothes and toys are **future features**. Stage 1 defines only the minimal data structures and architectural hooks. No visual rendering or gameplay effects are implemented yet.

### Clothes Data Structure

```
clothingItems: [
  { id: "witch-hat", name: "Witch Hat", category: "head", unlocked: true },
  { id: "cloak", name: "Little Cloak", category: "body", unlocked: true },
  { id: "bow", name: "Bow Ribbon", category: "accessory", unlocked: true },
  { id: "hood", name: "Dark Hood", category: "head", unlocked: true }
]

equippedClothing: {
  head: null,
  body: null,
  accessory: null
}
```

- Clothes categorized by **slot** (head, body, accessory) — one item per slot.
- `unlocked` flag supports future unlock mechanics.
- Equipping/unequipping has no effect on needs or score.

### Toys Data Structure

```
toyItems: [
  { id: "carrot", name: "Carrot Toy", unlocked: true },
  { id: "teddy", name: "Teddy Bear", unlocked: true },
  { id: "ball", name: "Ball", unlocked: true },
  { id: "wand", name: "Magical Wand", unlocked: true },
  { id: "flower", name: "Enchanted Flower", unlocked: true }
]

activeToy: null
```

- One toy active at a time.
- **Approved: Toys are purely cosmetic** — no effect on needs or scoring.
- Visual rendering deferred to Stage 2+.

### Architectural Hooks

- The game state object includes these properties, initialized with the data above.
- No UI for clothing/toy selection is rendered in Stage 1 (placeholder container only).
- Rendering functions read from these properties so later stages can add visuals without restructuring.

---

## J. Animated Background Architecture

### Stage 1 Approach

- The HTML includes a **background container element** (`<div id="background">`) behind the game interface.
- Styled with a **simple static CSS gradient** suggesting a forest at twilight (dark greens and deep purples).
- No animations, particles, or moving elements in Stage 1.

### Future Animation Plan

| Effect | Technique |
|---|---|
| Moving clouds/mist | CSS `@keyframes` on semi-transparent elements |
| Fireflies | Small elements or canvas particles with CSS animations or `requestAnimationFrame` |
| Tree/plant movement | SVG paths with CSS transforms or canvas oscillation |
| Atmospheric particles | Canvas overlay with `requestAnimationFrame` particle system |

### Architecture Requirements

- Background is a **separate visual layer** (`z-index` / `position: absolute`) — no interference with game UI.
- Background animations managed independently from the game timer (CSS animations or `requestAnimationFrame`, not `setInterval`).
- Background animations **continue during Paused state** (atmospheric, not gameplay).
- All effects code-generated. No external assets.

---

## K. Interface Requirements

### Elements Visible by Game State

| UI Element | Start | Playing | Paused | Ended |
|---|---|---|---|---|
| Game title ("Mochi's Virtual Pet") | ✓ | ✓ | ✓ | ✓ |
| Mochi placeholder/avatar area | ✓ | ✓ | ✓ | ✓ |
| Hunger bar + value | — | ✓ | ✓ | ✓ |
| Happiness bar + value | — | ✓ | ✓ | ✓ |
| Energy bar + value | — | ✓ | ✓ | ✓ |
| Cleanliness bar + value | — | ✓ | ✓ | ✓ |
| Health bar + value | — | ✓ | ✓ | ✓ |
| Current score | — | ✓ | ✓ | — |
| Final score (prominent) | — | — | — | ✓ |
| Mochi's expression label | — | ✓ | ✓ | ✓ |
| Mochi's status message | — | ✓ | ✓ | ✓ |
| Feed / Play / Sleep / Clean buttons | — | ✓ (active) | ✓ (disabled) | — |
| Start button | ✓ | — | — | — |
| Pause button | — | ✓ | — | — |
| Resume button | — | — | ✓ | — |
| End button | — | ✓ | ✓ | — |
| Restart button | — | — | — | ✓ |
| Keyboard shortcut hints (W/A/S/D) | — | ✓ | ✓ | — |
| Background container | ✓ | ✓ | ✓ | ✓ |
| "Paused" indicator | — | — | ✓ | — |

### Layout Plan (Stage 1)

- **Top:** Game title.
- **Center:** Mochi's avatar area (placeholder in Stage 1) with expression label and status message below.
- **Left or below avatar:** Five bars (Health prominent, then four needs) stacked vertically with labels and numeric values.
- **Below bars:** Four care action buttons in a row, with keyboard hints.
- **Below buttons:** Score display.
- **Bottom or overlay:** Game state controls (Start / Pause / Resume / End / Restart).
- **Behind everything:** Background container with static gradient.

---

## L. Technical Structure

### File Responsibilities

#### `index.html`
- Semantic HTML structure of the game interface.
- All UI containers: title, avatar area, need bars, health bar, buttons, score, state controls, status message, expression label, background container.
- Links to `style.css` and `script.js`.
- Hidden placeholder containers for future clothes/toy panels.
- Meaningful `id`/`class` attributes for CSS and JS targeting.
- No inline styles or inline scripts.

#### `style.css`
- All visual styling: layout, colors, system fonts, spacing, borders.
- Game state visual feedback: disabled buttons, paused overlay, ended screen.
- Bar styling: container, fill element, three threshold color classes (`bar-healthy`, `bar-caution`, `bar-critical`).
- Cooldown visual state for buttons.
- Background container: static color/gradient for Stage 1.
- Placeholder avatar area styling.
- CSS classes for showing/hiding elements by game state (`.state-start`, `.state-playing`, `.state-paused`, `.state-ended`).
- Responsive layout for common screen sizes.

#### `script.js`

**Game state object — single source of truth:**

```
gameState = {
    currentState: "start",          // "start", "playing", "paused", "ended"
    needs: {
        hunger: 100,
        happiness: 100,
        energy: 100,
        cleanliness: 100
    },
    health: 100,                    // derived, recalculated
    score: 0,
    currentExpression: "happy",
    isExcitedActive: false,
    excitedTimerId: null,
    isBlushingActive: false,
    blushingTimerId: null,
    isFirstAction: true,
    gameTimerId: null,
    cooldownActive: false,
    cooldownTimerId: null,
    // Future features (data structures only)
    clothingItems: [...],
    equippedClothing: { head: null, body: null, accessory: null },
    toyItems: [...],
    activeToy: null
}
```

**Core functions:**

| Function | Responsibility |
|---|---|
| `startGame()` | Initialize state, start timer, update UI |
| `pauseGame()` | Clear timers, update state, update UI |
| `resumeGame()` | Start timer, update state, update UI |
| `endGame()` | Clear all timers, show final score |
| `restartGame()` | Reset all values, transition to Start |
| `gameTick()` | Decay needs, recalculate health, recalculate expression, update UI |
| `performAction(type)` | Validate state + cooldown, apply recovery, check blushing triggers, update score/health/expression/UI, start cooldown |
| `clampValue(val, min, max)` | Utility to clamp values |
| `calculateHealth()` | Derive health from four needs |
| `determineExpression()` | Evaluate priority rules, return expression string |
| `triggerTemporaryExpression(type, ms)` | Set temp expression flag + timeout |
| `cancelTemporaryExpression(type)` | Clear flag + cancel timeout |
| `checkBlushingTriggers(type, prev)` | Evaluate blushing conditions |
| `startCooldown()` | Set cooldown flag, start 1500ms timeout, disable buttons visually |
| `endCooldown()` | Clear cooldown flag, re-enable buttons |
| `updateUI()` | Read game state, update all DOM elements |
| `updateBar(name, value)` | Update one bar's fill, class, and label |
| `updateStatusMessage()` | Set appropriate message based on state |
| `setGameStateUI(state)` | Show/hide elements per game state |
| `startTimer()` / `stopTimer()` | Encapsulated interval management |

**Event listeners:**

- Click listeners on all buttons (care actions and state controls).
- Single `keydown` listener on `document` routing W/A/S/D to `performAction()`.
- Keydown listener checks `event.repeat`, calls `event.preventDefault()` for handled keys.

**Timer management:**

- `gameTimerId`: single `setInterval` for decay. Managed by `startTimer()` / `stopTimer()`.
- `cooldownTimerId`: `setTimeout` for 1.5s global cooldown.
- `excitedTimerId`: `setTimeout` for 2s excited expression.
- `blushingTimerId`: `setTimeout` for 2.5s blushing expression.
- All timers cleared on appropriate state transitions.

### Separation of Concerns

- **HTML** — structure only.
- **CSS** — presentation only.
- **JS** — behavior only. Uses class toggling for state-dependent styling.

---

## M. Edge Cases

| # | Edge Case | Handling |
|---|---|---|
| 1 | **Need reaches 0** | Distress message displayed. Expression reflects critical need. Health drops. Care action available. Session continues. |
| 2 | **Need already at 100** | Action does nothing. 0 points. No cooldown triggered. |
| 3 | **Rapid button clicks** | Global cooldown (1.5s) blocks subsequent actions after effective one. "Wait a moment..." message shown. |
| 4 | **Rapid keyboard input** | `event.repeat` ignored. Cooldown blocks rapid discrete presses after effective action. |
| 5 | **Pause during need update** | `clearInterval` stops future ticks. In-progress tick completes (single-threaded). |
| 6 | **End during gameplay** | All timers cleared (decay, cooldown, expression). Needs/health frozen. Final score shown. |
| 7 | **Restart after end** | All needs → 100. Health → 100. Score → 0. Expression → Happy. `isFirstAction` → true. → Start screen. |
| 8 | **Repeated pause/resume** | `stopTimer()` + `startTimer()` pattern prevents duplicates. Cooldown cleared on pause. |
| 9 | **Duplicate timer prevention** | `startTimer()` always calls `stopTimer()` first. At most one active interval. |
| 10 | **Care actions while paused** | `performAction()` checks `currentState === "playing"`. Silently rejected. |
| 11 | **Care actions while ended** | Same state check. Silently rejected. |
| 12 | **Browser tab switch** | `setInterval` may slow in background. Acceptable for Stage 1. Stage 4 may address with timestamps. |
| 13 | **Invalid outfit (future)** | Equip validates against `clothingItems`. Invalid/locked items rejected. |
| 14 | **Invalid toy (future)** | Same validation against `toyItems`. |
| 15 | **Multiple needs at 0** | All distress messages shown. Expression uses priority. Health at 0. Session continues. |
| 16 | **All needs at 100** | Actions award 0 points. No cooldown. No penalty. |
| 17 | **Blushing during critical need** | Blushing suppressed. Critical expression takes priority. |
| 18 | **Excited during critical need** | Excited suppressed. Critical expression takes priority. |
| 19 | **Blushing timer expires during critical** | Flag clears. Expression stays on critical (needs unchanged). No visual flicker. |
| 20 | **Excited + Blushing simultaneous** | Excited has higher priority. Blushing flag set but not displayed until Excited expires. |
| 21 | **Health at 0** | Prominent distress message. Mochi does NOT die. All care actions available. |
| 22 | **Action during cooldown** | "Wait a moment..." message displayed. Action rejected. No score change. |
| 23 | **Cooldown expires during pause** | Cooldown timer cleared on pause. Cooldown state reset. |
| 24 | **Ineffective action: no cooldown** | Attempting an action on a need at 100 does not trigger cooldown, allowing immediate retry on another need. |

---

## N. Testing Checklist

### Game State Tests

| # | Test | Steps | Expected Result |
|---|---|---|---|
| N1 | Page load | Open `index.html` by double-clicking | Start screen. No timer. Score 0. |
| N2 | Start game | Click Start | Playing. All needs 100. Health 100. Timer begins. Buttons active. |
| N3 | Pause game | During Playing, click Pause | Needs freeze. Timer stops. Buttons disabled. "Paused" visible. |
| N4 | Resume game | During Paused, click Resume | Timer resumes. Needs decay. Buttons re-enabled. |
| N5 | End game | During Playing, click End | Timer stops. Final score. Buttons disabled. Restart visible. |
| N6 | End from Paused | During Paused, click End | Same as N5. |
| N7 | Restart game | During Ended, click Restart | Start screen. All needs 100. Health 100. Score 0. |
| N8 | Full cycle | Start → Pause → Resume → End → Restart → Start | All clean. No duplicate timers. |

### Need Decay Tests

| # | Test | Steps | Expected Result |
|---|---|---|---|
| N9 | Needs decrease | Start, wait 2 ticks | Each need −4 (2 per tick × 2 ticks). Bars shorter. |
| N10 | Needs reach 0 | Wait for need to hit 0 | Value 0. Bar empty. Distress message. Session continues. |
| N11 | Decay stops on pause | Pause, wait | Needs unchanged while paused. |
| N12 | Decay stops on end | End | Needs frozen. |

### Status Bar Tests

| # | Test | Steps | Expected Result |
|---|---|---|---|
| N13 | Bars correct at start | Start game | All bars 100%. Labels "100 / 100". |
| N14 | Bars update on decay | Wait one tick | All bars decrease. Labels update. |
| N15 | Bars update on action | Feed when hunger < 100 | Hunger bar increases immediately. |
| N16 | Bar healthy class | Need at 75 | `bar-healthy` class applied. |
| N17 | Bar caution class | Need at 50 | `bar-caution` class applied. |
| N18 | Bar critical class | Need at 20 | `bar-critical` class applied. |
| N19 | Bar max 100% | Feed at hunger 95 (+20) | Bar 100%. Label "100 / 100". |
| N20 | Bar min 0% | Need at 0 | Bar 0%. Label "0 / 100". |
| N21 | Health bar updates | Care action | Health recalculates. Bar updates. |
| N22 | Health at 0 | All needs 0 | Health bar empty. Distress message. Game continues. |

### Care Action Tests

| # | Test | Steps | Expected Result |
|---|---|---|---|
| N23 | Feed | Hunger dropped, click Feed | Hunger +20 (clamped). Score +10. Cooldown starts. |
| N24 | Play | Happiness dropped, click Play | Happiness +10 (clamped). Score +10. Cooldown starts. |
| N25 | Sleep | Energy dropped, click Sleep | Energy +25 (clamped). Score +10. Cooldown starts. |
| N26 | Clean | Cleanliness dropped, click Clean | Cleanliness +15 (clamped). Score +10. Cooldown starts. |
| N27 | Need clamped at 100 | Feed at hunger 95 | Hunger → 100. Score +10. |
| N28 | Ineffective action | Feed at hunger 100 | No change. Score unchanged. No cooldown. |
| N29 | Action at need 0 | Feed at hunger 0 | Hunger → 20. Distress clears. Score +10. |

### Cooldown Tests

| # | Test | Steps | Expected Result |
|---|---|---|---|
| N30 | Cooldown blocks actions | Effective action, immediately try another | "Wait a moment..." shown. Second action rejected. |
| N31 | Cooldown expires | Wait 1.5s after effective action | Actions available again. Buttons re-enabled. |
| N32 | Cooldown on keys | W key, immediately press A | A rejected during cooldown. |
| N33 | No cooldown on ineffective | Feed at 100, immediately Play | Play works (no cooldown from ineffective Feed). |
| N34 | Cooldown cleared on pause | Effective action, then Pause | Cooldown cancelled. On Resume, actions available. |

### Keyboard Tests

| # | Test | Steps | Expected Result |
|---|---|---|---|
| N35 | W feeds | Playing, press W | Same as Feed button. |
| N36 | A plays | Playing, press A | Same as Play button. |
| N37 | S sleeps | Playing, press S | Same as Sleep button. |
| N38 | D cleans | Playing, press D | Same as Clean button. |
| N39 | Keys disabled paused | Paused, press W/A/S/D | No effect. |
| N40 | Keys disabled ended | Ended, press W/A/S/D | No effect. |
| N41 | Held key | Hold W | Only one action fires. |
| N42 | Other keys | Press unrelated keys | No effect. No errors. |
| N43 | Case insensitivity | Press Shift+W | Same as lowercase w. |

### Scoring Tests

| # | Test | Steps | Expected Result |
|---|---|---|---|
| N44 | Score starts 0 | New session | Score 0. |
| N45 | Effective +10 | Action on need < 100 | Score +10. |
| N46 | Ineffective +0 | Action on need 100 | Score unchanged. |
| N47 | Multiple actions | Several effective actions (respecting cooldown) | Score = 10 × effective count. |
| N48 | Score frozen on end | End session | Score stops. |
| N49 | Score reset on restart | Restart | Score → 0. |

### Expression Tests

| # | Test | Steps | Expected Result |
|---|---|---|---|
| N50 | Happy | All needs ≥ 70 | "Happy" shown. |
| N51 | Hungry | Hunger ≤ 30, lowest | "Hungry" shown. |
| N52 | Tired | Energy ≤ 30, lowest | "Tired" shown. |
| N53 | Sad | Happiness/Cleanliness ≤ 30, lowest | "Sad" shown. |
| N54 | Excited | Effective Play, no critical needs | "Excited" ~2s, then reverts. |
| N55 | Blushing: hungry feed | Feed at hunger ≤ 25, no critical after | "Blushing" ~2.5s, then reverts. |
| N56 | Blushing: all high | All needs ≥ 90 after action | "Blushing" ~2.5s. |
| N57 | Blushing: first action | First effective action of session | "Blushing" ~2.5s. |
| N58 | Critical overrides Excited | Play while another need ≤ 30 | Critical expression shown, not Excited. |
| N59 | Critical overrides Blushing | Blushing trigger but need ≤ 30 | Critical shown. Blushing suppressed. |
| N60 | Excited revert | Wait for 2s timeout | Reverts to baseline. |
| N61 | Blushing revert | Wait for 2.5s timeout | Reverts to baseline. |
| N62 | Simultaneous Excited+Blushing | Conditions for both met | Excited shows (priority). Blushing may show after. |

### Emotional Feedback Coherence Tests

| # | Test | Steps | Expected Result |
|---|---|---|---|
| N63 | Coherent: healthy | All needs ≥ 70 | Bars healthy. Happy expression. Positive message. |
| N64 | Coherent: critical | Hunger 0 | Bar empty/critical. Hungry expression. "Starving" message. |
| N65 | Action feedback | Feed hungry Mochi | Bar ↑, expression reacts, message describes, score updates. All simultaneous. |
| N66 | No contradiction | Critical during blushing | Critical expression. Distress message. Blushing suppressed. |

### Edge Case Tests

| # | Test | Steps | Expected Result |
|---|---|---|---|
| N67 | Rapid clicking | 10 Feed clicks | Cooldown blocks after first. Correct score. |
| N68 | Rapid keys | Tap W 10 times | Cooldown blocks after first effective. |
| N69 | Pause/resume toggle | Rapid pause/resume | Consistent state. One timer. |
| N70 | All needs 0 | Wait for all to deplete | All distress. Health 0. Session continues. |
| N71 | Offline | No internet, open index.html | Fully functional. No errors. |

---

## O. Completion Criteria

Stage 1 is complete when **all** of the following are verified:

### Functional Requirements
- [ ] Game runs by double-clicking `index.html` with no internet.
- [ ] Only three files: `index.html`, `style.css`, `script.js`.
- [ ] No external assets, libraries, or downloaded files.

### Game States
- [ ] All four states (Start, Playing, Paused, Ended) function correctly.
- [ ] All valid transitions work. Invalid transitions impossible.
- [ ] Restart returns to Start screen.

### Needs System
- [ ] All four needs start at 100 and decay at 2 points every 3 seconds during Playing.
- [ ] Decay stops during Paused and Ended.
- [ ] Values clamped [0, 100]. Zero triggers distress, not session end.
- [ ] Recovery amounts: Feed +20, Play +10, Sleep +25, Clean +15.

### Health System
- [ ] Health derived as simple average of four needs.
- [ ] Health bar labeled "Health", updates on every decay tick and care action.
- [ ] Health at 0 does not kill Mochi.

### Status Bars
- [ ] All five bars display correctly (fill proportional, numeric label).
- [ ] Bars update immediately on value changes.
- [ ] Three visual thresholds distinguishable (healthy ≥ 70, caution 31–69, critical ≤ 30).
- [ ] Bars never exceed 100% or go below 0%.

### Cooldown
- [ ] 1.5s global cooldown after effective actions. Both buttons and keys.
- [ ] "Wait a moment..." shown on blocked attempts.
- [ ] No cooldown on ineffective actions.
- [ ] Cooldown cleared on pause/end.

### Care Actions
- [ ] All four actions work via buttons and W/A/S/D.
- [ ] Disabled during Paused and Ended.
- [ ] Held keys don't repeat.

### Scoring
- [ ] Effective = +10. Ineffective = +0.
- [ ] Score resets on restart. Frozen on end. Final score displayed.

### Expression System
- [ ] Six expressions: Happy, Sad, Hungry, Tired, Excited, Blushing.
- [ ] Priority rules correct — critical needs override temporary expressions.
- [ ] Excited: 2s on effective Play only. Blushing: 2.5s on approved triggers.
- [ ] Displayed as text with placeholder indicators in Stage 1.

### Emotional Feedback
- [ ] Bars, expression, and status message are consistent.
- [ ] Multi-channel feedback on care actions.
- [ ] No contradictions (critical always overrides positive temporary).

### Timer Management
- [ ] One decay timer during Playing. None during other states.
- [ ] No duplicate timers after any transition sequence.
- [ ] Temporary expression timers managed correctly.

### Architecture Readiness
- [ ] Game state includes clothing and toy data structures.
- [ ] Background container in HTML.
- [ ] Code supports later-stage additions without rewriting core logic.

### Testing
- [ ] All tests in Section N pass.
- [ ] No JavaScript console errors during normal gameplay.

> Stage 2 must not begin until all criteria above are met and verified through actual testing.

---

*All gameplay values in this plan are confirmed and approved. No unresolved proposals remain.*
