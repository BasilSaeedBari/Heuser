# Plan 3 — Mochi's Virtual Pet: Sensory Feedback

---

**Stage:** Sensory Feedback  
**Architect model:** Gemini 3.8 Flash (Medium)  
**Builder model:** Gemini 3.8 Flash (Medium)  
**Result:** Passed. All 87 test cases across Stages 1, 2, and 3 verified and passing in headless browser.  

---

## Project Overview

**Mochi's Virtual Pet** is an interactive virtual pet game running completely offline in a web browser. Following the successful completion and verification of Stage 1 (Core Logic) and Stage 2 (Visual Vibe), **Stage 3 introduces Sensory Feedback**.

Stage 3 adds auditory and tactile sensory feedback to bring Mochi and the enchanted forest to life:
- **Audio:** Code-synthesized procedural sound via the browser's native **Web Audio API**.
- **Tactile / Visual Feedback:** Particle bursts (sparkles, hearts, bubbles), interactive button press responses, and status alert transitions.

### Strict Technical & Homework Restrictions
- Exactly three code files in the final ZIP: `index.html`, `style.css`, `script.js`.
- No downloaded audio files (no `.mp3`, `.wav`, `.ogg`, etc.).
- No downloaded font, image, or library files.
- **Audio Restrictions (Strict):**
  - **NON-MUSICAL ONLY:** Only ambient forest atmosphere and discrete procedural sound effects.
  - **NO MUSIC, NO MELODIES, NO MUSICAL INSTRUMENTS, NO SINGING.**
- Audio must be 100% synthesized through code using standard Web Audio API oscillators, noise buffers, and filters.
- Must include **separate volume controls** (Ambience Volume, SFX Volume) and a **Master Mute** toggle.
- Preserves all Stage 1 & Stage 2 functionality without breaking existing gameplay or visuals.

---

## A. Audio Architecture (Web Audio API)

### 1. AudioContext Lifecycle & Autoplay Policy Handling
Modern web browsers require a user interaction (click or keypress) before an `AudioContext` can produce sound.
- The `AudioContext` is instantiated on page load in a `suspended` state (or created lazily on the first user interaction).
- Any user click (e.g. clicking **Start Session**, care buttons, or pressing W/A/S/D) automatically checks and calls `audioCtx.resume()` if suspended.
- Gracefully handles browser tab background throttling or hardware disconnection.

### 2. Audio Node Graph & Bus Architecture

```
[ Ambient Generators (Wind / Rustle / Stream) ] 
       │
       ▼
 [ Ambience Gain Node ] (Controlled by Ambience Slider: 0.0 – 1.0)
       │
       ├────────────────────────┐
       ▼                        ▼
[ SFX Generators ]      [ Master Gain Node ] (Controlled by Master Mute & Volume)
       │                        │
       ▼                        ▼
  [ SFX Gain Node ]     [ audioCtx.destination ]
(Controlled by SFX Slider)
```

- **Master Gain Node:** Controls global output level and handles instant Master Mute (sets gain to 0 without stopping oscillators or losing slider positions).
- **Ambience Gain Node:** Regulates ambient atmospheric generator levels.
- **SFX Gain Node:** Regulates discrete interaction and alert sound levels.

---

## B. Procedural Sound Design (Strictly Non-Musical)

### 1. Non-Musical Ambient Background Atmosphere
The ambient enchanted forest soundscape consists of subtle, continuous natural noise textures—**strictly non-melodic and non-rhythmic**:
1. **Enchanted Forest Breeze / Wind:**
   - Generated using a looped White/Pink Noise buffer passed through a low-pass filter (`BiquadFilterNode`, type `"lowpass"`, frequency modulated slowly between 180Hz and 450Hz via a low-frequency oscillator / LFO).
   - Produces a soft, gentle breathing wind effect.
2. **Night Leaf Rustle / Canopy Whisper:**
   - Bandpass filtered noise (`type: "bandpass"`, Q: 4.0, freq: ~1200Hz) with gentle random gain modulations to simulate nocturnal leaves rustling.
3. **Ambient Crickets / Night Forest Chitter (Optional Noise Impulse):**
   - Micro noise bursts shaped with an exponential decay envelope (clicks/chirps created via noise modulation, NOT tonal musical notes).

*Ambient sound runs continuously during active gameplay and pauses when the game is paused.*

### 2. Procedural Action Sound Effects (SFX)
All action effects use procedural frequency sweeps, noise envelopes, or frequency modulation—**no musical chords, arpeggios, or tunes**:

| Action | Affected Need | Sound Technique | Sonic Character |
|---|---|---|---|
| **Feed (W)** | Hunger | Rapid noise burst + pitched click envelope | Little crunchy munch / nibble sound |
| **Play (A)** | Happiness | Sine wave frequency sweep (pitch glide 300Hz &rarr; 650Hz over 180ms) | Playful rising chirp/squeak |
| **Sleep (S)** | Energy | Filtered white noise with slow swell (envelope ~1.2s) | Soft gentle exhale / breath |
| **Clean (D)** | Cleanliness | Dual bandpass noise sweep with high resonance | Splash / bubbly water swish |

### 3. State & Feedback Sound Effects
- **Effective Action Ding/Chime:** Gentle short sine blip (single pure blip, non-melodic).
- **Cooldown Blocked Alert:** Dull low-frequency thud (`type: "triangle"`, 120Hz &rarr; 60Hz quick drop over 80ms) when an action is spammed.
- **Critical Need Alarm (<= 30):** Low-frequency subtle heartbeat thump (80Hz pulse).
- **Need at 0 Distress:** Distant wind howl impulse or hollow click.
- **Blushing Reaction:** Soft high-pitched whisper glide (subtle airy flutter).
- **Session End:** Soft descending resonant noise sweep.

---

## C. Volume Controls & User Interface

### 1. Audio Control Panel in UI
A compact, retro-styled **Audio Settings** panel integrated into the interface:
- **Master Mute Button (`#btn-mute`):** One-click toggle (with dynamic visual state: 🔊 Audio ON / 🔇 Muted).
- **Ambience Volume Slider (`#slider-ambience`):** Range `0.0` to `1.0` (default: `0.3` to avoid overpowering).
- **SFX Volume Slider (`#slider-sfx`):** Range `0.0` to `1.0` (default: `0.6`).
- **Sliders styled with retro pixel track and thumb aesthetics.**

### 2. Keyboard Accessibility for Audio
- **M Key:** Global shortcut to toggle Master Mute on/off at any time during gameplay without needing to click the button.

---

## D. Visual Sensory Feedback

To complement auditory feedback with sensory richness:
1. **Interactive Floating Particles on Actions:**
   - **Feed:** Little floating food crumbs / sparkle dots.
   - **Play:** Bouncing stars / joy glints.
   - **Sleep:** Soft drifting violet 'z' particles.
   - **Clean:** Bubbly foam dots floating upward.
   - **Blushing:** Radiant floating pink heart/petal pixel bursts.
2. **Tactile Button Press Feedback:**
   - Buttons visibly depress 2px on click and on keydown (W/A/S/D).
   - Brief golden halo ripple on effective action; muted grey shake on blocked cooldown.
3. **Subtle Screen Shake on Critical Warning:**
   - When a need reaches 0, the game container gives a subtle, gentle 1-frame retro shake to alert the player.

---

## E. Edge Cases & Safeguards

1. **Autoplay Policy Block:** If the browser blocks audio before the first click, all audio calls fail silently without throwing unhandled exceptions. Audio automatically begins upon the player's first click (Start button).
2. **Rapid Input & Voice Stealing:** Limit overlapping SFX nodes. Triggering an action re-uses or terminates short-lived SFX nodes with exponential ramps to prevent audio popping/clicking.
3. **Mute State Invariance:** Toggling Master Mute preserves the individual slider settings so unmuting restores the exact previous volume levels.
4. **Pause/Resume Behavior:** Pausing gameplay fades out ambience gracefully (100ms ramp); resuming fades ambience back in without pops.
5. **No Interference with Core Game Timer:** Web Audio scheduling (`audioCtx.currentTime`) is completely independent of the 3000ms gameplay decay interval and 1500ms cooldown.

---

## F. Testing Checklist for Stage 3

| # | Test | Expected Result |
|---|---|---|
| S1 | Web Audio Initialization | AudioContext initializes properly; resumes smoothly on user gesture |
| S2 | Master Mute Toggle | Clicking mute button or pressing 'M' sets Master Gain to 0; unmuting restores previous volume |
| S3 | Ambience Slider | Adjusting Ambience slider modulates ambient noise gain proportionally |
| S4 | SFX Slider | Adjusting SFX slider modulates action sound effects gain proportionally |
| S5 | Feed Sound | Feed action produces procedural nibble/munch sound |
| S6 | Play Sound | Play action produces non-musical rising chirp/glide |
| S7 | Sleep Sound | Sleep action produces soft breath/exhale noise |
| S8 | Clean Sound | Clean action produces gentle bubble/splash noise |
| S9 | Cooldown Warning Thud | Attempting action during cooldown produces low-frequency thud |
| S10 | Ambience Pause/Resume | Ambient wind fades out on Pause and resumes smoothly on Resume |
| S11 | Visual Particle Bursts | Action buttons spawn code-drawn particle effects on canvas/DOM |
| S12 | Offline Integrity | 0 downloaded sound files, 0 external audio libraries |
| S13 | Core Logic Preservation | All 71 Stage 1 tests and 6 Stage 2 tests continue passing 100% |

---

## G. Completion Criteria

Stage 3 is complete when:
- [ ] Procedural non-musical forest ambience plays continuously during active gameplay.
- [ ] Distinct procedural action sounds trigger for Feed, Play, Sleep, and Clean.
- [ ] Separate sliders for Ambience Volume and SFX Volume are functional.
- [ ] Master Mute toggle works via UI button and 'M' keyboard shortcut.
- [ ] Visual sensory particle bursts accompany care actions.
- [ ] Strictly zero musical tunes, melodies, singing, or external audio files.
- [ ] All Stage 1, 2, and 3 automated tests pass cleanly.

---

## Decisions for Your Review & Approval

Please approve or specify modifications for:
1. **Default Volume Levels:** Do you approve the proposed defaults: **Master: 100% (Unmuted), Ambience: 30%, SFX: 60%**?
2. **Mute Shortcut:** Do you approve the **M key** as the shortcut for toggling Master Mute?
3. **Audio Controls Placement:** Should the Audio Settings panel be placed in a compact bar at the top or bottom of the game container?
