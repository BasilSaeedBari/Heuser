# Plan 5 — Mochi's Virtual Pet: Debugging and Polishing

---

**Stage:** Debugging and Polishing  
**Architect model:** Gemini 3.8 Flash (Low)  
**Builder model:** Gemini 3.8 Flash (Low)  
**Result:** Passed. All Stage 1–5 test cases verified and passing in headless browser.  

---

## Project Overview

**Mochi's Virtual Pet** is an interactive virtual pet game running completely offline in a web browser. Following the implementation of Core Logic (Stage 1), Visual Vibe (Stage 2), Sensory Feedback (Stage 3), and State & Storage (Stage 4), **Stage 5 focuses on Debugging, Polishing, and Final Quality Assurance**.

Stage 5 ensures complete code stability, smooth error recovery, zero unhandled promise/audio exceptions, precise visual rendering across all screens, full edge-case protection, and absolute adherence to single-file offline distribution constraints.

---

## A. Debugging & Code Hardening Scope

1. **State Engine Protection & Null Safety:**
   - Guaranteed null/undefined checks across all state accessors and DOM references.
   - Comprehensive error wrapping around Web Audio API nodes, localStorage access, and HTML5 canvas context calls.
2. **Timer & Loop Cleanup Assurance:**
   - Strict clearance of all active intervals (`gameTimerId`, `autoSaveTimerId`), timeouts (`cooldownTimerId`, `excitedTimerId`, `blushingTimerId`), and animation frames on state transitions.
   - Guarding against duplicate interval initialization.
3. **Storage & JSON Import Validation:**
   - Rigorous schema validation on imported `.json` save files to block invalid or malformed states from corrupting the game engine.
   - Fallback auto-recovery to initial state if `localStorage` data is corrupted.

---

## B. Canvas & Visual Rendering Polish

1. **Retina/DPI Canvas Crispness:**
   - Explicit pixel scaling and `image-rendering: pixelated;` enforcement for crisp retro rendering.
2. **Layered Accessory & Expression Precision:**
   - Fine-tuned coordinate alignment for all 6 expressions (Happy, Sad, Hungry, Tired, Excited, Blushing) and cosmetic outfit layers (Witch Hat, Dark Hood, Bow Ribbon, Little Cloak).
   - Smooth canvas particle cleanup preventing memory leaks during prolonged sessions.

---

## C. Audio System Polishing

1. **Zero-Clicking & Clean Gain Envelopes:**
   - Audio nodes use exponential and linear gain ramps (`linearRampToValueAtTime`, `exponentialRampToValueAtTime`) to eliminate pops or clicks when stopping or triggering SFX.
2. **Autoplay Policy Fallbacks:**
   - AudioContext suspended state auto-resumes smoothly on any direct user interaction (click, touch, keydown).

---

## D. Edge Cases & Safeguards Verification

| # | Edge Case | Mitigation / Handling |
|---|---|---|
| 1 | `localStorage` Disabled / Private Mode | Exception caught gracefully; in-memory fallback state used without throwing unhandled errors. |
| 2 | Malformed Import JSON | Schema validation rejects invalid files and notifies user via UI status badge. |
| 3 | Rapid Keydown Holding (Key Spamming) | `event.repeat` check ignores held keys; global 1.5s cooldown blocks rapid execution. |
| 4 | Tab Inactivity & Away Time | Away time calculation capped cleanly; background `requestAnimationFrame` throttles CPU safely. |
| 5 | Invalid AudioContext | Graceful degradation to silent mode if Web Audio API is unavailable or restricted. |

---

## E. Testing Checklist for Stage 5

| # | Test | Expected Result |
|---|---|---|
| D1 | Schema Validation | Invalid save file import triggers warning without crashing app |
| D2 | Clean Storage Reset | Reset Pet button clears localStorage and returns cleanly to Start screen |
| D3 | Timer Cleanup | Transitioning Playing -> Paused -> Ended -> Start leaves 0 orphaned timers |
| D4 | Rapid Action Spam | Blocked by 1.5s cooldown with thud sound and disabled button state |
| D5 | Expression & Wardrobe Layering | Accessories and face expressions render in proper pixel order |
| D6 | Canvas Animation Loop | Background and pet animation loops run smoothly at 60fps without lag |
| D7 | Master Mute & Volume Persistence | Volume settings persist across reloads and respond to 'M' key |
| D8 | Offline Integrity | Zero network requests, 0 external images, 0 font files loaded |

---

## F. Completion Criteria

Stage 5 is complete when:
- [ ] All code components in `index.html`, `style.css`, and `script.js` are fully integrated, syntactically clean, and free of console errors.
- [ ] All 5 stages of functional, visual, auditory, persistence, and edge-case requirements are verified.
- [ ] Game runs perfectly offline by opening `index.html` in any modern web browser.