# Plan 1 — Catch Game: Core Logic

Architect Model: Claude      Builder Model: Opus4.6

> **Goal:** A fully playable catch game in a single HTML file. Plain rectangles and text only — ugly but functional.

---

## 1. Concept

Items fall from the top of the screen. The player controls a basket (rectangle) at the bottom to **catch good items** (score points) and **dodge bad items** (lose lives). The game gets progressively harder over time.

---

## 2. Game Elements

| Element | Shape | Color | Size (px) |
|---------|-------|-------|-----------|
| **Basket (player)** | Rectangle | White with border | 100 × 20 |
| **Good item (fruit)** | Small rectangle | Green | 30 × 30 |
| **Bad item (bomb)** | Small rectangle | Red | 30 × 30 |
| **Play area** | Canvas | Dark gray (`#222`) | 480 × 640 |

- A text label inside each falling item: `"✓"` for good, `"✗"` for bad.
- Good-to-bad spawn ratio: roughly **3 good : 1 bad**.

---

## 3. Controls

| Input | Action |
|-------|--------|
| **← Arrow / A** | Move basket left |
| **→ Arrow / D** | Move basket right |
| **Mouse / Touch** | Basket follows pointer horizontally |
| **Enter / Click** | Start game / Restart after game over |

- Basket is clamped to canvas edges (cannot move off-screen).
- Keyboard movement speed: **6 px per frame**.

---

## 4. Rules & Scoring

### Catching
- A catch occurs when a falling item's bottom edge overlaps the basket's top edge **and** their horizontal ranges overlap.
- **Good item caught** → **+10 points**.
- **Bad item caught** → **−1 life**.

### Missing
- A good item that falls past the bottom of the screen with no catch → **−1 life**.
- A bad item that falls past the bottom → nothing happens (safe dodge).

### Lives
- Player starts with **3 lives**, displayed as `♥ ♥ ♥` in the top-right corner.
- At **0 lives** → game over.

---

## 5. Difficulty Progression

Difficulty increases based on the current **score**:

| Score Threshold | Fall Speed (px/frame) | Spawn Interval (ms) |
|-----------------|-----------------------|----------------------|
| 0 | 2 | 1200 |
| 50 | 3 | 1000 |
| 150 | 4 | 800 |
| 300 | 5 | 600 |

- Each new item spawns at a random horizontal position along the top edge.
- Only one speed/interval tier is active at a time (highest threshold met).

---

## 6. Game States & Flow

```mermaid
stateDiagram-v2
    [*] --> Title
    Title --> Playing : Press Enter / Click
    Playing --> GameOver : Lives = 0
    GameOver --> Playing : Press Enter / Click
```

### Title Screen
- Canvas shows: **"CATCH GAME"** (large text, centered) and **"Press Enter or Click to Start"** (smaller text below).
- No items falling, no score visible.

### Playing
- Score (`Score: 0`) top-left, lives (`♥ ♥ ♥`) top-right.
- Items spawn on a timer and fall each frame.
- Player moves the basket freely.

### Game Over
- All items freeze / clear.
- Canvas shows: **"GAME OVER"**, the final score, and **"Press Enter or Click to Restart"**.
- High score for the session is tracked and displayed: **"Best: 120"**.

---

## 7. Game Loop (per frame)

```
1. Read input  → update basket position
2. Spawn check → if spawn timer elapsed, create a new item (random type & x)
3. Move items  → each item.y += fallSpeed
4. Collision    → for each item, check overlap with basket
     • good + overlap  → score += 10, remove item
     • bad  + overlap  → lives -= 1, remove item
     • item.y > canvas height → if good: lives -= 1; remove item
5. Check lives → if 0, switch to GameOver state
6. Draw         → clear canvas, draw basket, items, HUD (score, lives)
7. requestAnimationFrame(loop)
```

---

## 8. Technical Approach

- **Single file:** `index.html` containing inline `<style>` and `<script>`.
- **Rendering:** HTML5 `<canvas>` with 2D context (`fillRect`, `fillText`).
- **Loop:** `requestAnimationFrame` for smooth 60fps.
- **State management:** A simple `gameState` variable (`"title"` | `"playing"` | `"gameover"`).
- **Items array:** `[{ x, y, type: "good"|"bad" }, ...]` — items are spliced out on catch or when off-screen.
- **No external dependencies.** No images, no libraries.

---

## 9. File Structure

```
index.html   ← everything lives here (HTML + CSS + JS)
```

---

## 10. Stage 1 Acceptance Criteria

- [x] Game starts on the title screen; pressing Enter or clicking begins play.
- [x] Good (green) and bad (red) rectangles fall from random positions.
- [x] Basket moves with arrow keys, A/D, and mouse/touch.
- [x] Catching a good item adds 10 points; catching a bad item removes a life.
- [x] Missing a good item removes a life.
- [x] Game ends at 0 lives and shows score + high score.
- [x] Player can restart without refreshing the page.
- [x] Difficulty increases as score climbs.
- [x] Runs in any modern browser from a local file — no server needed.
