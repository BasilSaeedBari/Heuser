# Sky Temple — Visual Overhaul Plan

Architect Model: Claude      Builder Model: Opus4.6

> **Target file:** `index.html` (single-file game, all code inline)
> **Drawing method:** Canvas 2D API only — `fillRect`, `arc`, `moveTo/lineTo`, gradients, `fillText`. **No image files.**
> **Rule:** Do not change game logic (movement, collision boxes, spawning ratios, scoring, lives, difficulty ramp). Only change how things *look*.

---

## 1 — Color Palette (define once as constants)

Add these right after the existing game-constant block (~line 49). Every later phase references these names, never raw hex.

```js
// ── Sky Temple Palette ──────────────────────────────────
const CLR_SKY_TOP      = '#87CEEB'; // light cerulean — top of sky gradient
const CLR_SKY_BOT      = '#D4EEFF'; // pale ice-blue  — bottom of sky gradient
const CLR_CLOUD        = '#F5F0EB'; // warm off-white  — clouds, stone highlights
const CLR_STONE        = '#E8E0D4'; // light sandstone — platform, temple stone
const CLR_STONE_DARK   = '#C4B8A8'; // muted tan       — stone shadow / outline
const CLR_MOSS         = '#7EC8A0'; // soft sage-green  — moss, vines, UI accents
const CLR_MOSS_DARK    = '#5DA87A'; // deeper green     — moss shadow / outline
const CLR_GOLD         = '#FFD666'; // warm sunlight    — collectibles, glow
const CLR_GOLD_BRIGHT  = '#FFE59E'; // pale gold        — highlight / sparkle
const CLR_STORM        = '#8B8FAA'; // muted lavender-gray — bad items
const CLR_STORM_DARK   = '#5C5F75'; // dark slate       — bad item outline
const CLR_TEXT_SHADOW   = 'rgba(0,0,0,0.35)'; // text drop-shadow
```

**Where each color is used (quick map):**

| Color | Usage |
|---|---|
| `CLR_SKY_TOP / _BOT` | Background gradient (Phase 1) |
| `CLR_CLOUD` | Drifting clouds, cloud platform edge (Phases 2, 4) |
| `CLR_STONE / _DARK` | Ground platform, distant temple, game-over panel (Phases 3, 4, 9) |
| `CLR_MOSS / _DARK` | Catcher bowl rim detail, vine accents, HUD accent (Phases 5, 8) |
| `CLR_GOLD / _BRIGHT` | Good items (sun gems), catch sparkle, score highlight (Phases 6, 8, 9) |
| `CLR_STORM / _DARK` | Bad items (storm wisps) (Phase 7) |
| `CLR_TEXT_SHADOW` | All text shadow (Phase 8) |

---

## 2 — Drawing Recipes

### 2.1 Sky Gradient
- `createLinearGradient(0, 0, 0, CANVAS_HEIGHT)` → stop 0 = `CLR_SKY_TOP`, stop 1 = `CLR_SKY_BOT`.
- Fill full canvas rect. Drawn first every frame.

### 2.2 Drifting Clouds
- Maintain an array of 5–7 cloud objects: `{ x, y, w, h, speed, opacity }`.
- Each cloud: draw 3 overlapping ellipses (`arc`) filled with `CLR_CLOUD` at the cloud's `opacity` (0.3–0.7).
  - Center ellipse: `w × h`. Left ellipse offset ‑`w*0.3`, scaled 0.7. Right ellipse offset +`w*0.3`, scaled 0.8.
- `w` range 80–160, `h` = `w * 0.4`. `speed` 0.15–0.4 px/frame.
- Clouds drift right; when `x > CANVAS_WIDTH + w` wrap to `x = -w`.
- Clouds sit in the **upper 60 %** of the canvas (y range 20–380).

### 2.3 Distant Temple Silhouette
- Drawn **after** clouds, centered at x ≈ 240, y ≈ 180 (mid-background).
- Use `CLR_STONE` at **0.35 opacity** so it looks muted / distant.
- Shape recipe (all `moveTo/lineTo` paths, then fill):
  - **Base block:** rect 120×60 centered.
  - **Roof / pagoda tier:** trapezoid on top of base, 100 wide at bottom → 60 wide at top, 30 tall.
  - **Spire:** thin triangle centered, 10 wide × 40 tall.
- Single `fill()` call; no stroke. This is just atmosphere.

### 2.4 Ground / Platform
- Full-width band at bottom: y from `BASKET_Y - 10` to `CANVAS_HEIGHT` (≈ 50 px tall).
- Fill with `CLR_STONE`.
- Top edge: 2 px line of `CLR_MOSS` across full width (moss strip).
- Optional: 3–4 small semi-circle bumps along top edge using `arc` in `CLR_CLOUD` to suggest worn stone.
- Below the moss line, draw 2–3 faint horizontal lines (`CLR_STONE_DARK`, lineWidth 1, globalAlpha 0.3) to suggest stone blocks.

### 2.5 Catcher — Offering Bowl / Lotus Dish
- **Replace** the white `fillRect` basket with a bowl shape. Keep same `basket.x`, `basket.y`, `basket.width`, `basket.height` for collision — only change the draw.
- Drawing order:
  1. **Bowl body (arc):** half-ellipse (bottom half of an ellipse). `ellipse(cx, cy, rx, ry, 0, 0, Math.PI)` where `cx = basket.x + basket.width/2`, `cy = basket.y + 4`, `rx = basket.width/2`, `ry = basket.height * 0.9`. Fill `CLR_STONE`.
  2. **Bowl rim:** same ellipse but `ry = 4`, full `0–2π`, filled `CLR_MOSS`. Gives a green rim.
  3. **Inner glow:** smaller half-ellipse inside, `rx - 8`, `ry - 4`, filled `CLR_GOLD_BRIGHT` at globalAlpha 0.25.
  4. **Rim highlight:** 2 px arc on the top-left quarter of the rim in `CLR_CLOUD` at alpha 0.5.
- Approximate pixel size stays ~100 × 20. Collision box unchanged.

### 2.6 Good Items — Sun Gems
- **Replace** the green `fillRect` + "✓".
- Centered on `item.x + ITEM_SIZE/2`, `item.y + ITEM_SIZE/2`; radius = `ITEM_SIZE / 2 - 2` (≈ 13).
- Drawing order:
  1. **Outer glow:** circle radius + 4, filled `CLR_GOLD` at alpha 0.25.
  2. **Main circle:** filled `CLR_GOLD`.
  3. **Highlight crescent:** smaller arc (radius × 0.55) offset ‑3 px x/y, filled `CLR_GOLD_BRIGHT` — gives a shiny bevel.
  4. **Sparkle:** tiny 4-point star (two crossed 2 px lines, `CLR_CLOUD`) at top-right of gem, rotated slowly with `performance.now() * 0.003`.
- Collision box (`item.x, item.y, item.width, item.height`) is untouched.

### 2.7 Bad Items — Storm Wisps
- **Replace** the red `fillRect` + "✗".
- Drawing order:
  1. **Base cloud puff:** 3 overlapping arcs (like a miniature cloud) filled `CLR_STORM`. Radii 8, 7, 6, overlapping horizontally.
  2. **Dark core:** central circle radius 5, filled `CLR_STORM_DARK`.
  3. **Lightning bolt:** `moveTo/lineTo` zig-zag (3 segments) from center downward, stroked `CLR_GOLD` lineWidth 1.5, giving the "storm" look.
- Overall bounding ≈ 30 × 30, matching `ITEM_SIZE`. Collision box untouched.

### 2.8 Score / HUD Text
- Font: `'bold 22px system-ui, sans-serif'` (system fonts only).
- Score top-left (20, 24): draw text twice — first pass offset (+1,+1) in `CLR_TEXT_SHADOW`, second pass in `CLR_CLOUD`. Prefix with a small filled circle (r=4) in `CLR_GOLD` as a coin icon.
- Lives top-right: keep hearts but fill `CLR_GOLD` instead of red; shadow pass same as score.
- All `textBaseline = 'top'`, `textAlign = 'left'` / `'right'` as before.

### 2.9 Effects & Game-Over

**Catch effect (good item):**
- On catch, push a particle burst to a `particles[]` array: 6 tiny circles, `CLR_GOLD_BRIGHT`, random velocity outward, alpha fading from 1→0 over 20 frames. Remove when alpha ≤ 0.

**Miss effect (good item falls off-screen or bad item caught):**
- Small puff: 4 circles `CLR_STORM` expanding outward and fading over 15 frames.

**Title screen:**
- Sky gradient background (reuse).
- "SKY TEMPLE" in `bold 40px system-ui`, `CLR_CLOUD`, shadow `CLR_TEXT_SHADOW`. Vertically centered −50 px.
- Subtitle "Catch the Light" in `22px`, `CLR_GOLD`. Centered −10 px.
- "Press Enter or Tap to Begin" in `18px`, `CLR_MOSS`, alpha pulsing `0.5 + 0.5 * Math.sin(now * 0.003)`. Centered +40 px.
- Draw a large sun gem in the upper area using the Phase 6 recipe at 2× scale as decoration.

**Game-over screen:**
- Dim overlay: full-canvas rect `rgba(0,0,0,0.45)`.
- Centered stone panel: `fillRect` 280×200 in `CLR_STONE`, 2 px border `CLR_STONE_DARK`, slight rounded corners via `roundRect` if available (fallback: plain rect).
- "Temple Closed" in `bold 34px`, `CLR_STORM_DARK`, shadow. y = center −50.
- "Score: {score}" in `24px`, `CLR_CLOUD`. y = center −5.
- "Best: {highScore}" in `20px`, `CLR_GOLD`. y = center +30.
- "Tap or Enter to Reopen" in `16px`, `CLR_MOSS`, pulsing alpha. y = center +70.

---

## 3 — Phased Implementation

> **Key principle:** after each phase, the game must load and be fully playable. Commit / save after each.

---

### Phase 1 — Palette Constants + Sky Gradient Background

**Files to edit:** `index.html`

**What to do:**
1. Add the full palette constant block (Section 1) after line 56 (after `const BASKET_Y = …`).
2. In `render()`, replace the `ctx.fillStyle = '#222222'; ctx.fillRect(…)` with a linear gradient fill using `CLR_SKY_TOP` → `CLR_SKY_BOT`. Create the gradient once outside the game loop and store it in a variable (`skyGradient`) for performance.
3. Update the CSS: change `body` `background-color` from `#111` to `#4A90B8` (a medium blue that matches the canvas edge). Change canvas `background-color` from `#222` to `CLR_SKY_BOT` hex (`#D4EEFF`). Change canvas `border` to `2px solid #B0D4E8`.

**How to verify:** Open the file in a browser. Canvas shows a smooth blue gradient from cerulean top to pale blue bottom. Game text is still visible (white on blue). Click to play — gameplay unchanged.

**Risks:** The white HUD text may be harder to read on light blue. That's fine — Phase 8 adds text shadows. For now it's acceptable.

---

### Phase 2 — Drifting Clouds

**Files to edit:** `index.html`

**What to do:**
1. Add a `clouds` array initialized with 6 cloud objects (random x across full width, y in 20–380, w 80–160, speed 0.15–0.4, opacity 0.3–0.7).
2. Add a `drawClouds()` function per recipe 2.2.
3. Add an `updateClouds()` function that moves each cloud by its speed each frame, wrapping when off-screen right.
4. Call `updateClouds()` at the **start** of `update()` (or in `render()` before other draws, since clouds drift in all game states).
5. Call `drawClouds()` in `render()` right after the sky gradient fill, before any other draw calls.

**How to verify:** Clouds drift slowly right across the sky in all game states (title, playing, game over). They wrap seamlessly. They're behind all game elements.

**Risks:** Too many or too opaque clouds could obscure items. Keep count ≤ 7 and max opacity ≤ 0.7.

---

### Phase 3 — Distant Temple Silhouette

**Files to edit:** `index.html`

**What to do:**
1. Add a `drawTemple()` function per recipe 2.3.
2. Call it in `render()` **after** `drawClouds()` and **before** gameplay elements.

**How to verify:** A faint sandstone temple shape is visible in the mid-background. It sits behind clouds that pass in front of it. It doesn't move. It's subtle enough not to distract.

**Risks:** If the temple looks too prominent, lower its opacity to 0.25.

---

### Phase 4 — Ground Platform

**Files to edit:** `index.html`

**What to do:**
1. Add a `drawPlatform()` function per recipe 2.4.
2. Call it in `render()` during the `'playing'` state, **before** `drawBasket()` and `drawItems()`.

**How to verify:** A stone-colored band covers the bottom of the canvas with a green moss strip along its top edge. The basket (still a white rectangle at this point) sits on top of it.

**Risks:** Ensure the platform top edge is at or above `BASKET_Y` so the catcher doesn't float above it. Use `BASKET_Y - 10` as the top.

---

### Phase 5 — Catcher (Offering Bowl)

**Files to edit:** `index.html`

**What to do:**
1. Rewrite `drawBasket()` internals per recipe 2.5.
2. Do **not** change `basket.x`, `basket.y`, `basket.width`, `basket.height`, or any collision logic.

**How to verify:** The white rectangle is replaced by a rounded bowl shape with a green rim. Move it left/right — still responsive. Catch a good item — still registers. Collision box is the same invisible rectangle.

**Risks:** `ellipse()` is widely supported but verify it renders. Fallback: use `arc()` and `scale()` transform.

---

### Phase 6 — Good Items (Sun Gems)

**Files to edit:** `index.html`

**What to do:**
1. Rewrite the good-item branch inside `drawItems()` per recipe 2.6.
2. The sparkle rotation uses `performance.now()` — pass `now` from `gameLoop` into `render()` → `drawItems()` (or capture `performance.now()` locally inside `drawItems`).

**How to verify:** Good items appear as golden glowing circles with a sparkle, not green rectangles. They still fall, still get caught, still score +10.

**Risks:** Sparkle rotation requires saving/restoring the canvas transform — use `ctx.save()` / `ctx.restore()` to avoid affecting other draws.

---

### Phase 7 — Bad Items (Storm Wisps)

**Files to edit:** `index.html`

**What to do:**
1. Rewrite the bad-item branch inside `drawItems()` per recipe 2.7.

**How to verify:** Bad items look like small gray cloud puffs with a lightning bolt, clearly different from the golden sun gems. Catching them still removes a life. Dodging them is still safe.

**Risks:** Ensure the storm wisp is visually distinct enough from the drifting background clouds. The darker fill (`CLR_STORM_DARK`) and the lightning bolt achieve this.

---

### Phase 8 — HUD / Score Text Restyle

**Files to edit:** `index.html`

**What to do:**
1. Rewrite `drawHUD()` per recipe 2.8: shadow pass, new colors, coin icon dot.
2. Change font to `'bold 22px system-ui, sans-serif'`.
3. Hearts use `CLR_GOLD` instead of `#ff4444`.

**How to verify:** Score text top-left is crisp and readable over the sky gradient (shadow provides contrast). Lives hearts are gold. A tiny gold dot sits before the score number.

**Risks:** None significant. System fonts are guaranteed available.

---

### Phase 9 — Effects + Title Screen + Game Over Screen

**Files to edit:** `index.html`

**What to do:**
1. Add a `particles` array and `updateParticles()` / `drawParticles()` functions.
2. In the collision section of `update()` (where `items.splice` happens), push catch-sparkle or miss-puff particles as described in recipe 2.9. **Do not change the `if/else` logic or score/lives math — only add particle spawns alongside.**
3. Call `updateParticles()` at end of `update()`. Call `drawParticles()` in `render()` after items and before HUD.
4. Rewrite `drawTitleScreen()` per recipe 2.9 (sky gradient + clouds already draw in all states, so the title inherits them).
5. Rewrite `drawGameOverScreen()` per recipe 2.9.

**How to verify:**
- **Title:** Shows "SKY TEMPLE" with a pulsing start prompt over the cloudy sky, plus a decorative sun gem.
- **Catch a good item:** small gold sparkle burst at catch point.
- **Lose a life:** small gray puff.
- **Game over:** dimmed sky with a stone panel showing score, best, and restart prompt.
- **All gameplay** still works identically: same score values, same life loss rules, same difficulty ramp.

**Risks:**
- Particle array could grow if not cleaned up. Always splice particles whose alpha ≤ 0.
- The game-over overlay must not block the click/touch handler for restarting. The handler is on the `<canvas>` element, so it works regardless of what's drawn.

---

## 4 — Final Checklist (after all phases)

- [ ] Palette constants defined once, no raw hex anywhere else in drawing code.
- [ ] No `<img>` tags, no `drawImage()`, no external asset URLs.
- [ ] `basket.x/y/width/height` unchanged. `ITEM_SIZE` unchanged. Collision rects unchanged.
- [ ] `spawnItem()`, `getDifficulty()`, score/lives logic — zero changes.
- [ ] Game runs in latest Chrome, Firefox, Safari, Edge.
- [ ] Canvas size still 480 × 640. Touch + mouse + keyboard input unchanged.
- [ ] Clouds animate in title, playing, and game-over states (ambient life).
- [ ] Performance: no per-frame gradient re-creation (cache it). Particle array stays small.
