# Stage 5: Debugging and Polish — Implementation Plan (`plan5.md`)

Architect Model: Gemini Builder Model: Flash 3.8

## 1. Bug Log

| # | Short Title | Evidence (File / Line) | How to Reproduce | Planned Fix | Status |
|---|-------------|------------------------|------------------|-------------|--------|
| 1 | Web Audio Autoplay Suspension Lock | `index.html`: lines 146–161 (`initAudio`) & line 677 (`mousemove`) | Refresh page. Move mouse over canvas before clicking anything. Autoplay policy suspends `AudioContext` on `mousemove`. `audioInitialised` is set to `true`. When clicking "Begin", line 147 returns immediately, leaving `audioCtx` permanently suspended with no audio playing. | Remove `initAudio()` from `mousemove`. In gesture listeners (`click`, `keydown`, `touchstart`), check `if (audioCtx && audioCtx.state === 'suspended') audioCtx.resume();`. | Found |
| 2 | Movement Keys Stuck on Window Blur | `index.html`: lines 650–656 (`keyup`), lines 761–765 (`blur`) | Start a game, hold `D` or `ArrowRight`, and Alt-Tab to another window. Tab back in and resume: `keyup` was never captured, leaving `keys.right === true`. Basket slides right continuously without user input. | In the `blur` event handler, explicitly reset `keys.left = false; keys.right = false;`. | Found |
| 3 | Missing Reset-Data Feature & Corrupted Storage Handling | `index.html`: lines 89–133 (`loadStorage`), lines 431–438 (buttons) | Inspect buttons: no Reset Data button exists. If `localStorage` contains `{ highScore: 999999999999 }` or an outdated schema, the score overflows HUD panels and cannot be reset from within the game. | Add a "Reset Data" button on Title/Pause screens calling a new `resetData()` function with defaults, clamp numerical bounds (`highScore` max 999,999), and validate versioning. | Found |
| 4 | Premature Restart & Audio Bleed During Dying Sequence | `index.html`: lines 1852–1859 (`drawGameOverScreen` in dying), line 262 (`playSpokenLose`), line 563 (`startGame`) | Die from lightning. At 1800ms (during game-over fade), click "Play Again". `startGame()` runs while sad jingle (1400–2150ms) and voice lose utterance (2120ms) are still queued or speaking. The previous game's lose speech plays over the new game. | Keep `restartButton` inactive until `gameState === 'gameover'` (elapsed >= 2200ms). In `startGame()`, call `window.speechSynthesis.cancel()` and cleanly cancel lingering audio nodes. | Found |
| 5 | Key Repeat Spamming on Enter Multi-Starts & Bloats `gamesPlayed` | `index.html`: lines 633–638 (`keydown` Enter), lines 593–594 (`startGame`) | On Title or Game Over screen, hold down `Enter`. Browser key repeat fires ~30 times/sec, triggering `startGame()` repeatedly, playing 30 audio noises/sec, and inflating `gamesPlayed` in `localStorage` by dozens of counts. | Add `if (e.repeat) return;` at the top of the `keydown` listener, and debounce `startGame()` with a 250ms guard. | Found |
| 6 | Fixed Canvas Dimensions Cut Off Gameplay on Short Screens | `index.html`: lines 21–38 (`body`, `canvas` CSS), line 42 (`canvas` attributes) | Resize browser window height to under 650px (e.g. laptop or devtools open). `body { overflow: hidden; }` clips the canvas; the basket at Y=600 is pushed entirely off-screen, making the game unplayable. | Add CSS `max-width: 100vw; max-height: 96vh; width: auto; height: auto; aspect-ratio: 480 / 640;` to `#gameCanvas` for responsive fit while preserving mouse/touch coordinate mapping. | Found |
| 7 | Right-Click Context Menu Freezes Basket Movement | `index.html`: missing `contextmenu` listener on `canvas` | Right-click canvas during play. The browser context menu opens. The game continues running items downward, but keyboard and mouse tracking are halted, causing guaranteed life loss. | Add `canvas.addEventListener('contextmenu', (e) => e.preventDefault());`. | Found |
| 8 | Basket Snaps Back Intact on Game Over Screen Post-Obliteration | `index.html`: line 981 (`basketDestroyed = false`), line 1862 (`drawBasket`) | Watch basket crumble to pieces during the lightning sequence. At 2200ms when Game Over appears, `basketDestroyed` resets to `false`, and `drawBasket` abruptly renders an intact offering bowl beneath the dialog. | Keep `basketDestroyed = true` while `gameState === 'gameover'`, only restoring basket integrity inside `startGame()`. | Found |

---

## 2. Edge Case Checklist

### 1. Rapid Clicking & Key Mashing
- **What to look for**: Start, pause, restart, mute, reset spamming; double-triggered state transitions; lightning sequence retriggering.
- **Expected Behavior**: State transitions must be atomic and idempotent. Mashing buttons or keys should never trigger duplicate timers, overlapping sound glitches, or double-invoked game loops. Restarting during dying must be prevented until the sequence completes.
- **Manual Test Steps**:
  1. Mash `Enter` and click "Begin" rapidly 10+ times on Title screen. Verify only 1 game starts and `gamesPlayed` increments by exactly 1.
  2. Rapidly hammer `P` and `Escape` during gameplay. Verify game smoothly toggles between `playing` and `paused` without items jumping or spawning in clumps.
  3. Rapidly click Mute button 20 times. Verify audio icon toggles cleanly and no audio clipping or gain spikes occur.
  4. Mash clicks while dying from lightning strike. Verify lightning animation runs to completion without resetting early.

### 2. Resizing the Window
- **What to look for**: Canvas scaling, CSS layout, mouse/touch position mapping, HUD placement, background and cloud positions.
- **Expected Behavior**: Canvas must scale responsively to fit any viewport aspect ratio without overflowing or cutting off controls/platform. Pointer and touch coordinates via `getCanvasCoords` must accurately map to the internal 480×640 grid at all window sizes.
- **Manual Test Steps**:
  1. Shrink window height to 400px, then width to 300px. Verify entire canvas (HUD to basket) remains visible and letterboxed/centered.
  2. Move mouse / touch across extreme corners. Verify basket aligns exactly with pointer X position at all zoom levels.
  3. Maximize to 4K / full screen. Verify clouds and temple render with crisp proportions and buttons remain fully clickable.

### 3. Switching Tabs or Losing Focus
- **What to look for**: Auto-pause behavior, timer delta accumulation, audio continuation/cutting, items bunching up on return.
- **Expected Behavior**: Switching tabs during gameplay immediately pauses the game. Timers and spawn intervals must freeze. When returning and unpausing, falling items resume at their exact previous heights without an avalanche.
- **Manual Test Steps**:
  1. Start playing, let 3 items appear on screen.
  2. Switch to another browser tab for 10 seconds.
  3. Return to the game tab. Verify game is in `paused` state.
  4. Click "Resume" or press `P`. Verify items continue falling at normal speed with no instant clump spawn.
  5. Test Alt-Tabbing during the dying lightning sequence; verify audio and visual state resume gracefully.

### 4. Unexpected Input
- **What to look for**: Held keys, keys released while unfocused, multiple simultaneous keys, touch and mouse together, right-click, pressing keys during lightning sequence or menus.
- **Expected Behavior**: Directional keys must clear on blur. Pressing opposing keys (`Left` + `Right` or `A` + `D`) should cancel movement cleanly. Right-clicks must not summon context menus. Game keys (`ArrowLeft`, `P`, `Space`) must prevent default page scrolling.
- **Manual Test Steps**:
  1. Hold `ArrowLeft` and `ArrowRight` together. Verify basket stays stationary.
  2. Hold `A` and click outside the browser window. Release `A`, refocus window, and unpause. Verify basket does not auto-move left.
  3. Right-click canvas while moving. Verify context menu does not appear.
  4. Press `Space` and `ArrowDown` repeatedly. Verify browser page does not scroll.

### 5. Broken Saved Data
- **What to look for**: Missing `localStorage`, corrupted JSON, wrong data types, negative/massive values, blocked storage (incognito), old data version migrations.
- **Expected Behavior**: The game must gracefully fall back to default storage values (`highScore: 0`, `bestCombo: 0`, `muted: false`) if data is corrupt, blocked, or invalid. Reset-data button wipes `localStorage` and resets in-memory high score and stats immediately.
- **Manual Test Steps**:
  1. Run `localStorage.setItem('skytemple_v1', '{invalid json}')` in console and refresh. Verify game loads with default 0 high score without throwing errors.
  2. Run `localStorage.setItem('skytemple_v1', JSON.stringify({ highScore: -999, bestCombo: "broken", gamesPlayed: 1e12 }))` and refresh. Verify numbers are sanitized (`highScore >= 0`, `gamesPlayed` clamped).
  3. Click "Reset Data" button. Verify `localStorage` is cleared, UI updates to `Best: 0`, and subsequent refreshes retain the clean state.
  4. Block storage via browser site settings. Verify game runs seamlessly with in-memory state without crashing.

### 6. Audio, Cleanup & Memory
- **What to look for**: Audio starting before user interaction, leftover particles/timers after restart, combo/score resetting, particle/fragment memory growth.
- **Expected Behavior**: Web Audio begins exclusively on valid user gestures (`click`, `keydown`, `touchstart`). Particle arrays and floating texts must be hard-capped and cleared on `startGame()`. No DOM or Web Audio nodes leak over long sessions.
- **Manual Test Steps**:
  1. Hard refresh page with devtools console open. Move cursor over canvas without clicking. Verify zero autoplay warnings and `audioCtx` is not created until first click.
  2. Score 100+ points with a combo, then click "Play Again". Verify score resets to 0, combo resets to 0, and no floating score texts or particles linger.
  3. Play continuously for 5 minutes or leave paused. Monitor heap memory in devtools; verify particle and item arrays do not grow unboundedly.

---

## 3. Polish List (Cheap & High-Impact)

1. **Mute Icon Contrast**: Replace the dark lavender `CLR_STORM` cross lines on the mute button with `CLR_CLOUD` or a white-outlined slash so mute status is instantly discernible on the sage-green button.
2. **SFX Harshness Tuning**: Reduce high-pass button click noise gain from `0.08` to `0.04` and adjust decay to avoid harsh popping when clicking rapidly.
3. **Reset Data UI Integration**: Add a clean, muted stone "Reset Data" button to the Title screen and Pause menu with a quick confirmation tap ("Confirm Reset?").
4. **Game Over Visual Continuity**: Keep the offering bowl basket hidden or in its shattered fragment state on Game Over rather than snapping back into a brand new basket.
5. **HUD Alignment & Heart Spacing**: Give the score text and heart indicators explicit padding and consistent font rendering (`CANVAS_WIDTH - 24`), preventing text jitter during single/double-digit score transitions.
6. **Focus Ring Styling**: Enhance keyboard focus indicator from a subtle green outline to a crisp dual-layer gold ring (`CLR_GOLD`) for clear accessibility visibility.
7. **Pause Overlay Soft Fade**: Give the pause dim overlay a slight 3-frame alpha blend for a smoother transition into pause.

---

## 4. Phased Fix Order

### Phase 1: Audio System Robustness & Autoplay Compliance (Highest Impact)
- **Files to Edit**: `index.html`
- **What to Change**:
  - Remove `initAudio()` call from `mousemove` event listener.
  - In `initAudio()` and gesture handlers (`click`, `keydown`, `touchstart`), check `if (audioCtx && audioCtx.state === 'suspended') audioCtx.resume();`.
  - Add `window.speechSynthesis.cancel()` on `startGame()` and `toggleMute()` to prevent voice bleed.
  - Soften button click audio gain from `0.08` to `0.04`.
- **How to Verify**: Load fresh page, hover over canvas, click "Begin". Verify audio plays cleanly on first click with zero console autoplay warnings. Die and restart rapidly; verify speech stops immediately on restart.

### Phase 2: Input Handling, Event Safety & Debouncing
- **Files to Edit**: `index.html`
- **What to Change**:
  - Add `canvas.addEventListener('contextmenu', (e) => e.preventDefault());`.
  - In `window.addEventListener('keydown')`, add `if (e.repeat && (e.key === 'Enter' || e.key === ' ')) return;`.
  - Prevent default browser scrolling on `ArrowLeft`, `ArrowRight`, `ArrowUp`, `ArrowDown`, and `Space`.
  - In `window.addEventListener('blur')`, reset `keys.left = false; keys.right = false;`.
  - In `updateBasketToPointer`, ignore pointer X updates if hovering top-bar buttons (`pos.y < 50`).
- **How to Verify**: Hold `Enter` on Title screen (confirm game only starts once). Hold `D` and Alt-Tab out and back; verify basket does not run away. Right-click canvas during play (confirm menu is blocked).

### Phase 3: State Transitions, Dying Sequence & Visual Integrity
- **Files to Edit**: `index.html`
- **What to Change**:
  - Keep `restartButton` inactive until `gameState === 'gameover'` (elapsed >= 2200ms).
  - In `gameState === 'gameover'`, keep `basketDestroyed = true` so the bowl does not instantly resurrect on the defeat screen.
  - Ensure `focusedButtonIndex` resets to `-1` and all button `.focused` flags clear whenever `gameState` changes.
- **How to Verify**: Trigger game over via lightning. Verify "Play Again" button cannot be clicked before the sequence completes, voice lines do not bleed over, and basket stays obliterated until "Play Again" is clicked.

### Phase 4: Storage Hardening & Reset-Data Implementation
- **Files to Edit**: `index.html`
- **What to Change**:
  - Implement `resetData()`: resets `storageData` to `DEFAULT_STORAGE`, clears `localStorage.removeItem(STORAGE_KEY)`, sets `highScore = 0`, `bestCombo = 0`, and saves.
  - Create and register `resetButton` on Title and Pause screens.
  - In `loadStorage()`, add upper bound clamping (`Math.min(999999, parsed.highScore)`) and version validation (`parsed.version === 1`).
- **How to Verify**: Corrupt `localStorage` in devtools; verify graceful fallback. Click "Reset Data"; verify high score resets to 0 instantly on UI and in storage.

### Phase 5: Responsive Canvas & Viewport Scaling
- **Files to Edit**: `index.html`
- **What to Change**:
  - Update `#gameCanvas` CSS with `max-width: 100vw; max-height: 96vh; width: auto; height: auto; aspect-ratio: 480 / 640;`.
  - Verify `getCanvasCoords(clientX, clientY)` handles fractional scale factors correctly across window resize events.
- **How to Verify**: Resize browser to extreme portrait, extreme landscape, and small 400px window. Verify entire canvas is visible and basket tracks mouse/touch accurately.

### Phase 6: Final Polish & Visual Contrast
- **Files to Edit**: `index.html`
- **What to Change**:
  - Update `drawMuteIcon` muted slash to high-contrast `CLR_CLOUD` with dark drop-shadow.
  - Refine button focus ring styling with `CLR_GOLD`.
  - Verify HUD heart spacing and text shadow consistency.
- **How to Verify**: Inspect mute button in muted state across both title and gameplay; verify clear visual distinction. Tab through buttons to inspect clean golden focus rings.

---

## 5. Short Final Test Run

Step-by-step manual run-through:
1. **Fresh Page Load**: Open game in a fresh incognito window. Verify Title screen displays "SKY TEMPLE", "Catch the Light", "Begin" button, "Mute" icon (unmuted), and "Reset Data" button.
2. **Audio Gesture Test**: Hover mouse over canvas; verify no audio starts and no console errors. Click "Begin". Verify chime tone plays and game enters `playing` state.
3. **Gameplay & Controls**: Catch 5 gold sun gems in a row. Verify score updates, combo counter rises (`×5 COMBO`), pitch ascends, and particle bursts appear. Move using both `A`/`D` and mouse.
4. **Pause & Resume**: Press `P` or click pause icon. Verify game pauses, falling items freeze, and pause menu displays "Resume", "Restart", "Mute Audio", and "Reset Data". Press `Escape` or click "Resume" to continue.
5. **Game Over via Lightning**: Allow 3 bad items to hit or miss 3 good items so lives drop to 0. Verify lightning sequence triggers: sky darkens, thunder cracks, screen shakes, basket shatters into fragments, sad jingle plays, and "Temple Closed" modal fades in.
6. **Restart**: Click "Play Again". Verify basket respawns intact at center, score and combo reset to 0, lives reset to 3, and previous sad audio is silenced.
7. **Refresh Persistence**: Catch gems to set a score of 80+. Refresh browser tab (`F5`). Verify Title screen displays `Best: 80`.
8. **Reset Data**: Click "Reset Data". Verify `Best: 80` vanishes back to default. Refresh once more to verify `localStorage` persistence of the reset state.
