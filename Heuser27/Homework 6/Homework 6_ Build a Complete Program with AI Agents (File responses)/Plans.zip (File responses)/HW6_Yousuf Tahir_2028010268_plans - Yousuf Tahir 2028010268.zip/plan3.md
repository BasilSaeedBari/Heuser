# Stage 3 — Sensory Feedback

Architect Model: Claude Builder Model: Opus 4.4

> **Target file:** `index.html` (single-file game, all code inline)
> **Audio method:** Web Audio API — `OscillatorNode`, `GainNode`, `BiquadFilterNode`, buffer sources. **No audio files.**
> **Visual method:** Canvas 2D API only. **No image files.**
> **Rule:** Keep all existing game logic (movement, collision boxes, spawning ratios, lives, difficulty ramp) unchanged, **except** add the combo system described in §4.

---

## Palette Reference (already defined in `index.html`)

| Constant | Hex | Stage 3 Usage |
|---|---|---|
| `CLR_SKY_TOP` | `#87CEEB` | darken target during lightning |
| `CLR_SKY_BOT` | `#D4EEFF` | flash fade-back colour |
| `CLR_CLOUD` | `#F5F0EB` | screen-flash, miss splash particles |
| `CLR_STONE` | `#E8E0D4` | catcher scorch base |
| `CLR_STONE_DARK` | `#C4B8A8` | scorched catcher tint |
| `CLR_MOSS` | `#7EC8A0` | button default fill, focus ring |
| `CLR_GOLD` | `#FFD666` | combo text, catch sparkles, milestone bursts |
| `CLR_GOLD_BRIGHT` | `#FFE59E` | particle highlight, chime sparkle |
| `CLR_STORM` | `#8B8FAA` | bad-catch flash, combo-lost text |
| `CLR_STORM_DARK` | `#5C5F75` | loss effects |
| `CLR_TEXT_SHADOW` | `rgba(0,0,0,0.35)` | text shadows (existing) |
| `CLR_OVERLAY` | `rgba(0,0,0,0.45)` | game-over dim (existing) |

---

## Existing Code Structure (quick reference for each phase)

- **Game states**: `gameState` — `'title'` · `'playing'` · `'gameover'`  (Stage 3 adds `'dying'`)
- **Catcher**: `basket` object `{ x, y, width, height }` — drawn by `drawBasket()` (lines 463-499)
- **Items**: `items[]` — each `{ x, y, width, height, type:'good'|'bad' }`
- **Scoring**: `score += 10` on good catch (line 279); `highScore` tracked (line 280-282)
- **Lives**: `lives` starts at 3; decremented on bad catch (line 297) and good-item miss (line 319); game over when `lives <= 0` (lines 341-345)
- **Particles**: `particles[]` with `updateParticles()` and `drawParticles()` — basic fade-out circles (lines 92-93, 232-242, 591-601)
- **Canvas**: fixed 480 × 640 (`CANVAS_WIDTH`, `CANVAS_HEIGHT`)
- **Game loop**: `gameLoop(now)` → `update(now)` → `render(now)` → `requestAnimationFrame`
- **Input**: keyboard (`keydown`/`keyup`), mouse (`mousemove`, `click`), touch (`touchstart`, `touchmove`)
- **Restart**: `startGame()` resets score, lives, items, particles, basket position (lines 131-139)
- **No existing audio code, combo system, or button abstraction.**

---

## Action-to-Reaction Table

| # | Action | Visual Reaction | Audio Reaction |
|---|--------|----------------|----------------|
| 1 | Catch good item | Gold sparkle burst at catch point (enhanced existing) + basket bounce + score pop-up floats upward | Soft sine chime (pitch rises with combo) |
| 2 | Catch bad item | Red flash on basket + screen border red pulse + basket recoil | Harsh square-wave buzz (150 Hz, 120 ms) |
| 3 | Miss good item (falls off screen) | `CLR_CLOUD` splash particles at bottom + heart-row shakes before greying | Quiet low sine thud (80 Hz, 100 ms) |
| 4 | Bad item falls off screen (dodged) | Faint `CLR_STORM` puff at bottom (existing, fewer particles) | *(silent — not a player error)* |
| 5 | Combo grows | Combo counter scales up then settles + gold ring pulse on basket rim | Catch chime pitch += 40 Hz per combo level (capped at +400 Hz) |
| 6 | Combo milestone (×5, ×10, …) | Large gold starburst + sparkle shower from top + combo text flashes white | Rising arpeggio (3 fast ascending chimes) |
| 7 | Combo lost (≥ 2 → 0) | "×N" text shatters outward in `CLR_STORM_DARK` fragments + basket dims briefly | Descending two-note "wah" (triangle, 300→200 Hz, 200 ms) |
| 8 | Game over (lives → 0) | Full lightning sequence (see §1) | Thunder crack → sad descending jingle (see §2) |
| 9 | Button hover | Button brightens, slight scale-up (1.05×) | *(silent)* |
| 10 | Button press | Button darkens, scale-down (0.95×), brief gold ripple | Quiet noise click (30 ms) |
| 11 | Button focus (keyboard Tab) | `CLR_MOSS` 2 px glow ring around button | *(silent)* |
| 12 | Mute toggle | Icon swaps (speaker ↔ speaker-with-X), brief icon scale pop | *(silent)* |
| 13 | Basket idle | Gentle vertical bob (sin-based, ±2 px, period ~2 s) | *(silent)* |

---

## §1 — Lightning Loss Sequence

### Trigger
`lives` drops to 0 (from bad catch or missed good item).

### Sequence Timeline (total ≈ 2 200 ms)

| Time (ms) | Event |
|-----------|-------|
| 0 | Set `gameState = 'dying'`. Record `deathSequenceStart = now`. **Block all input** (ignore mouse/touch move, clicks, and keyboard except mute). Stop spawning items. Freeze all falling items in place. |
| 0–300 | **Sky darken**: multiply a `darkFactor` from 1.0 → 0.4 (linear interpolation on `elapsed / 300`). Apply to the sky gradient by drawing a black overlay at `globalAlpha = 1 - darkFactor` over the normal sky. |
| 300 | **Lightning bolt appears**: generate a jagged polyline from `(CANVAS_WIDTH/2, 0)` down to `(basket.x + basket.width/2, basket.y)`. Build as 15–20 segments: each steps downward 25–40 px with random horizontal offset ±30 px, clamping x to the range `[CANVAS_WIDTH * 0.2, CANVAS_WIDTH * 0.8]`. Store points in `boltPoints[]`. At 3–4 random main segments, create a short 3-segment branch fork at ±30–45° angle, stored in `boltBranches[]`. |
| 300–500 | **Flash + shake**: fill canvas with `rgba(255,255,255, alpha)` where alpha goes 0.9 → 0 over 200 ms. Apply screen shake: before all draw calls in `render()`, do `ctx.save(); ctx.translate(shakeX, shakeY); … ctx.restore()` where `shakeX = (Math.random()-0.5) * 12 * (1 - elapsed/200)` and `shakeY = (Math.random()-0.5) * 8 * (1 - elapsed/200)` (decaying). Play **thunder crack** sound (see §2). |
| 300–500 | **Bolt draws**: main bolt — stroke `boltPoints` as a connected polyline, `CLR_CLOUD`, lineWidth 3. Branches — stroke each fork polyline, `CLR_CLOUD` at alpha 0.5, lineWidth 1. |
| 500–900 | **Bolt fade + catcher scorch**: bolt alpha fades from 1 → 0 over 200 ms (500–700). The basket's fill alternates between `CLR_STONE_DARK` and `CLR_STONE` every 60 ms for 400 ms (≈6 flickers). Spawn 10 ember particles upward from basket centre: colours `CLR_STORM_DARK` and `CLR_GOLD`, radius 2–3 px, velocity upward 40–80 px/s + slight random x, gravity 60 px/s², life 400 ms. |
| 900–1 400 | **Basket crumble**: split the basket into 6–8 rectangular fragments. Each fragment ≈ `basket.width/4` × `basket.height/2`. Assign each a random velocity (outward x: ±40–100 px/s, initial y: -30 to +20 px/s) and gravity (200 px/s²) and rotation speed (±2 rad/s). Fragments fade alpha from 1 → 0 over 500 ms. Stop drawing the intact basket (set a `basketDestroyed` flag). |
| 1 400–1 800 | **Pause on dark**: screen stays darkened. At t = 1 400, play the **sad jingle** (see §2). |
| 1 800–2 200 | **Game-over overlay fades in**: draw the existing game-over panel (reuse `drawGameOverScreen(now)`) but with an alpha that ramps from 0 → 1 over 400 ms. At t = 2 200, set `gameState = 'gameover'`, re-enable input. |

### Implementation Notes
- Add `'dying'` to `gameState`. In `update(now)`: if dying, run only the timeline logic (no item spawn, no collision, no basket movement). In `render(now)`: if dying, draw sky (with darken), clouds, temple, platform, frozen items, basket (or fragments), bolt, flash, particles — then the fading game-over panel at the end.
- In every input handler (`keydown`, `click`, `touchstart`, `touchmove`, `mousemove`): if `gameState === 'dying'`, only allow the mute button interaction; ignore everything else.
- Store timeline state in: `deathSequenceStart`, `boltPoints[]`, `boltBranches[]`, `fragments[]`, `basketDestroyed`.
- On transition to `'gameover'`, clear these arrays. On `startGame()`, also reset `basketDestroyed = false` and restore basket draw.

---

## §2 — Loss Sound Design

### Synced to the Lightning Sequence (§1)

**A. Thunder Crack** (triggered at `elapsed = 300` of the death sequence):
- Create a 0.4 s `AudioBuffer` (mono, sample rate = `audioCtx.sampleRate`).
- Fill with white noise: `Math.random() * 2 - 1` per sample.
- Play through: `BufferSourceNode` → `BiquadFilterNode` (type `'lowpass'`, frequency 800, Q 1.0) → `GainNode` → `sfxGain`.
- Gain envelope: start at 0.7, `exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.4)`.
- Result: a short punchy rumble.

**B. Sad Descending Jingle** (triggered at `elapsed = 1400`):
- Three notes, each an `OscillatorNode` with type `'triangle'`.
- Frequencies: 440 Hz → 370 Hz → 294 Hz (A4 → F♯4 → D4 — descending, mournful).
- Each note: 220 ms total. `GainNode` envelope: ramp to 0.2 over 20 ms (attack), then `exponentialRampToValueAtTime(0.001, …)` over remaining 200 ms (decay).
- Timing: note 1 at +0 ms, note 2 at +250 ms, note 3 at +500 ms (total ≈ 720 ms).
- Optional vibrato: connect an `OscillatorNode` (type `'sine'`, freq 5 Hz) to each note's `frequency` via a `GainNode` with value 8 (wobbles pitch ±8 Hz).

**C. Spoken "You Lose" (bonus, optional)**:
- After the jingle ends (~`elapsed = 2120`), check `window.speechSynthesis`.
- If available and not muted: `new SpeechSynthesisUtterance('You lose')`, set `pitch = 0.7`, `rate = 0.8`, `volume = 0.5`, then call `speechSynthesis.speak(utterance)`.
- If unavailable or if `audioMuted`: skip silently. The jingle is the guaranteed fallback.
- Gate behind a `const ENABLE_SPEECH = true` constant so it's easy to disable.

---

## §3 — Catch Sound Effects

### A. Good Catch — Chime
- **Trigger**: good item caught (in the collision `if (item.type === 'good')` block, line 278).
- **Sound**: `OscillatorNode`, type `'sine'`.
  - Base frequency: 660 Hz.
  - Combo modifier: `freq = 660 + Math.min(comboCount * 40, 400)`.
  - `GainNode`: instant to 0.18, `exponentialRampToValueAtTime(0.001, currentTime + 0.2)`.
  - Stop oscillator after 200 ms.
- **Optional shimmer layer**: a second oscillator at `freq * 1.5` (perfect fifth), gain 0.06, same envelope. Adds sparkle.

### B. Bad Catch — Buzz
- **Trigger**: bad item caught (in the collision `else` block, line 296).
- **Sound**: `OscillatorNode`, type `'square'`, frequency 150 Hz.
- Gain 0.15, decay over 120 ms. Stop after 120 ms.

### C. Miss — Thud
- **Trigger**: good item falls past `CANVAS_HEIGHT` (in the `if (item.y > CANVAS_HEIGHT)` block, line 317).
- **Sound**: `OscillatorNode`, type `'sine'`, frequency 80 Hz.
- Gain 0.10, decay over 100 ms. Stop after 100 ms.

### D. Button Click
- **Trigger**: any button is pressed (start, restart/play-again, mute).
- **Sound**: create a 0.03 s `AudioBuffer` of white noise, play through `BiquadFilterNode` (type `'highpass'`, frequency 2000) at gain 0.08.
- Duration: 30 ms.

---

## §4 — Combo System

### Rules

| Combo Count | Multiplier | Notes |
|-------------|-----------|-------|
| 0 (no streak) | ×1 | — |
| 1–4 | ×1 | Counter appears at ≥2 but no score bonus yet |
| 5–9 | ×2 | Milestone burst at 5 |
| 10–14 | ×3 | Milestone burst at 10 |
| 15–19 | ×4 | Milestone burst at 15 |
| 20+ | ×5 (cap) | Milestone burst at 20 |

- **Increment**: each good catch increments `comboCount` by 1.
- **Reset**: catching a bad item OR missing a good item resets `comboCount` to 0. Trigger the "combo lost" reaction only if the previous `comboCount` was ≥ 2.
- **Score formula**: `score += 10 * multiplier` per good catch (replaces the current `score += 10`).

### New State Variables (add near line 97)
```
let comboCount = 0;
let comboMultiplier = 1;
let comboDisplayTimer = 0;   // ms remaining for scale-pop animation
let comboLostTimer = 0;      // ms remaining for shatter animation
let comboLostValue = 0;      // the combo that was lost (for shatter display)
```

### Multiplier Function
```js
function getMultiplier(combo) {
  if (combo >= 20) return 5;
  if (combo >= 15) return 4;
  if (combo >= 10) return 3;
  if (combo >= 5)  return 2;
  return 1;
}
```

### Display — Combo Counter
- **Position**: top-right area, below the mute button. Use `(CANVAS_WIDTH - 60, 70)` as the anchor (right-aligned). This avoids the score (top-left, `36, 24`) and hearts (top-right, `CANVAS_WIDTH - 20, 24`) and the mute button (top-right corner, see §7).
- **Visible only when `comboCount >= 2`**:
  - Main text: `"×{comboCount}"` in `CLR_GOLD`, font `'bold 28px system-ui, sans-serif'`, right-aligned.
  - Below (smaller, 14 px): `"COMBO"` in `CLR_MOSS`.
  - If `comboMultiplier > 1`, also show `"({multiplier}× pts)"` in `CLR_CLOUD`, 13 px, below "COMBO".
  - Subtle gold text-shadow (blur 6 px) behind the number.
- **Scale-pop on increment**: when `comboCount` increases, set `comboDisplayTimer = 300`. During those 300 ms, draw the combo text at scale `1.0 + 0.4 * (comboDisplayTimer / 300)` (1.4× → 1.0×, ease-out). Use `ctx.save() → ctx.translate(anchorX, anchorY) → ctx.scale(s, s) → draw at (0,0) → ctx.restore()`.
- **Hidden when `comboCount < 2`**: don't draw.

### Combo Milestone Effect (at counts 5, 10, 15, 20)
- **Trigger**: `comboCount` equals 5, 10, 15, or 20 after incrementing.
- **Visual**:
  - Starburst: spawn 25 particles from the combo text position. Colours: `CLR_GOLD` (70 %) and `CLR_GOLD_BRIGHT` (30 %). Radius 3–5 px, velocity outward 80–200 px/s in full 360°, gravity 50 px/s², life 600 ms, alpha-fade.
  - Sparkle shower: spawn 15 particles at random x across the top of the canvas (`y = 0`), falling at 40–60 px/s, `CLR_GOLD_BRIGHT` at alpha 0.6, life 1000 ms, radius 2–3 px. Only one shower active at a time (skip if a shower is still alive — track via a `showerActive` flag or count).
  - Flash the combo text to `CLR_CLOUD` for 100 ms then back to `CLR_GOLD`.
- **Audio**: rising arpeggio — three `playTone` calls: 660 Hz, 830 Hz, 1046 Hz. Each 80 ms duration, gain 0.15. Stagger with delays: 0 ms, 50 ms, 100 ms.

### Combo Lost Reaction
- **Trigger**: `comboCount` resets to 0 from ≥ 2.
- **Visual**: the last displayed combo text `"×N"` "shatters":
  - Create 5–6 small rectangles (each ~10 × 8 px) at the combo text position.
  - Each gets random outward velocity (x: ±60–120 px/s, y: -20 to +40 px/s), gravity 150 px/s², rotation speed ±3 rad/s.
  - Colour: `CLR_STORM_DARK`. Alpha fades from 1 → 0 over 500 ms.
  - Store in `comboShatterFragments[]`, update/draw alongside particles, auto-remove when alpha ≤ 0.
  - Basket dims: set `basketDimTimer = 300` (ms). During dim, draw basket at `globalAlpha = 0.6`.
- **Audio**: triangle oscillator starting at 300 Hz, `linearRampToValueAtTime(200, currentTime + 0.2)`, gain 0.12, duration 200 ms.

### Reset on Restart
In `startGame()`, add: `comboCount = 0; comboMultiplier = 1; comboDisplayTimer = 0; comboLostTimer = 0; comboLostValue = 0;` and clear `comboShatterFragments`.

---

## §5 — Animations & Particles

### Upgrade the Existing Particle System
The current `particles[]` uses per-frame fade (`p.alpha -= p.fade`). To support time-based durations and gravity, extend each particle object:

```
{
  x, y,           // position
  vx, vy,         // velocity (px per frame, as current)
  r,              // radius
  color,          // fill colour string
  alpha,          // current alpha
  fade,           // alpha decrement per frame (existing)
  gravity         // vy increment per frame (new, default 0)
}
```

- In `updateParticles()`, after `p.y += p.vy`, add: `if (p.gravity) p.vy += p.gravity;`.
- **Hard cap**: before pushing new particles, check `particles.length < 150`. If at cap, skip the spawn. This prevents performance issues.
- Add helper function:
```js
function burstParticles(x, y, count, options) {
  // options: { colors[], speedMin, speedMax, radiusMin, radiusMax, fadeMin, fadeMax, gravity }
  for (let i = 0; i < count && particles.length < 150; i++) {
    const angle = Math.random() * Math.PI * 2;
    const speed = options.speedMin + Math.random() * (options.speedMax - options.speedMin);
    particles.push({
      x, y,
      vx: Math.cos(angle) * speed,
      vy: Math.sin(angle) * speed,
      r: options.radiusMin + Math.random() * (options.radiusMax - options.radiusMin),
      color: options.colors[Math.floor(Math.random() * options.colors.length)],
      alpha: 1,
      fade: options.fadeMin + Math.random() * (options.fadeMax - options.fadeMin),
      gravity: options.gravity || 0
    });
  }
}
```

### Floating Score Text System
Add a `floatingTexts[]` array (separate from particles). Each entry:
```
{ text, x, y, alpha, timer }
```
- `timer` starts at 800 (ms) or 48 (frames at ~60 fps — use frames to match the existing frame-based system).
- Each frame: `y -= 0.7` (float upward), `alpha -= 1/48` (fade over ~48 frames). Remove when `alpha <= 0`.
- Draw: `CLR_GOLD`, font `'bold 18px system-ui, sans-serif'`, `textAlign = 'center'`, at `globalAlpha = alpha`.
- Cap: 10 entries max.
- Add `updateFloatingTexts()` and `drawFloatingTexts()`. Call update in `update()`, draw in `render()` after items and before HUD.

### Specific Effect Recipes

**A. Enhanced Catch Sparkle (good catch)** — replace the existing 6-particle burst (lines 284-295):
- Use `burstParticles(cx, cy, 12, { colors: [CLR_GOLD, CLR_GOLD_BRIGHT], speedMin: 1, speedMax: 3, radiusMin: 2, radiusMax: 4, fadeMin: 1/25, fadeMax: 1/18, gravity: 0.08 })` where `cx = item.x + item.width/2`, `cy = item.y + item.height/2`.
- Also push a floating text: `floatingTexts.push({ text: '+' + (10 * comboMultiplier), x: cx, y: cy, alpha: 1, timer: 48 })`.

**B. Basket Bounce (good catch)**:
- Add `basket.bounceTimer = 0` (initialized in game state). On good catch, set `basket.bounceTimer = 12` (frames).
- In `drawBasket()`, if `basket.bounceTimer > 0`: compute `offsetY = Math.sin(basket.bounceTimer / 12 * Math.PI) * -8` (quick upward pop). Apply by shifting the basket draw up: `ctx.translate(0, offsetY)` before drawing, `ctx.restore()` after.
- In `update()`, if `basket.bounceTimer > 0`, decrement by 1 each frame.

**C. Basket Recoil (bad catch)**:
- Add `basket.recoilTimer = 0`. On bad catch, set `basket.recoilTimer = 9` (frames).
- In `drawBasket()`, if `basket.recoilTimer > 0`: shift basket draw down by 5 px. Also tint the bowl fill to `CLR_STORM` for the first 6 frames (100 ms), then back to `CLR_STONE`.
- In `update()`, decrement `basket.recoilTimer` each frame if > 0.

**D. Basket Idle Bob**:
- In `drawBasket()`, if `gameState === 'playing'` and `basket.bounceTimer <= 0` and `basket.recoilTimer <= 0`:
- Apply `ctx.translate(0, Math.sin(now / 1000 * Math.PI) * 2)` — slow 2 px vertical oscillation.
- This requires passing `now` into `drawBasket(now)` — add the parameter.

**E. Miss Splash (good item missed)** — enhance the existing 4-particle puff (lines 321-332):
- Change colours from `CLR_STORM` to `CLR_CLOUD`.
- Increase count to 7.
- Add upward bias: `vy: (Math.random() - 0.8) * 3` (mostly upward).
- Add `gravity: 0.12`.

**F. Bad-Item Dodge Puff (bad item falls off screen)**:
- The current code just splices the item with no effect (line 335). Add a small puff: 3 particles at `(item.x + ITEM_SIZE/2, CANVAS_HEIGHT - 5)`, colours `CLR_STORM`, alpha starting at 0.5, fade 1/12. This is subtle — it's not a penalty.

**G. Heart Shake (on life loss)**:
- Add `heartShakeTimer = 0`. On any life loss (bad catch or good miss), set `heartShakeTimer = 18` (frames, ≈300 ms).
- In `drawHUD()` (line 604), when drawing hearts: if `heartShakeTimer > 0`, offset the hearts' x/y by `(Math.random()-0.5) * 6 * (heartShakeTimer/18)` and `(Math.random()-0.5) * 4 * (heartShakeTimer/18)` (decaying shake).
- Decrement `heartShakeTimer` in `update()`.

### Performance Note
With the 150-particle cap, `burstParticles` skipping when full, and all particles being simple `arc` fills — this should maintain 60 fps easily on any device that runs the current game.

---

## §6 — Button Hover & Press States

### Button Abstraction
Create a lightweight object factory. Each button:
```js
function createButton(label, onClick) {
  return {
    x: 0, y: 0, width: 0, height: 0,  // set each frame based on layout
    label,
    hovered: false,
    pressed: false,
    focused: false,
    currentScale: 1.0,
    ripple: null,   // { x, y, radius, alpha } or null
    onClick
  };
}
```

### Button Drawing (shared function)
```js
function drawButton(btn, now) {
  // Compute target scale
  const targetScale = btn.pressed ? 0.95 : (btn.hovered ? 1.05 : 1.0);
  btn.currentScale += (targetScale - btn.currentScale) * 0.2;  // lerp

  ctx.save();
  const cx = btn.x + btn.width / 2;
  const cy = btn.y + btn.height / 2;
  ctx.translate(cx, cy);
  ctx.scale(btn.currentScale, btn.currentScale);
  ctx.translate(-cx, -cy);

  // Fill colour: brighten on hover, darken on press
  let fill = CLR_MOSS;
  if (btn.pressed) fill = CLR_MOSS_DARK;
  else if (btn.hovered) fill = '#96D4B4'; // lighter CLR_MOSS

  // Rounded rect body
  ctx.fillStyle = fill;
  ctx.strokeStyle = CLR_GOLD;
  ctx.lineWidth = 2;
  ctx.beginPath();
  if (typeof ctx.roundRect === 'function') {
    ctx.roundRect(btn.x, btn.y, btn.width, btn.height, 8);
  } else {
    ctx.rect(btn.x, btn.y, btn.width, btn.height);
  }
  ctx.fill();
  ctx.stroke();

  // Focus glow ring
  if (btn.focused) {
    ctx.shadowColor = CLR_MOSS;
    ctx.shadowBlur = 6;
    ctx.stroke();
    ctx.shadowBlur = 0;
  }

  // Label text
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  drawTextWithShadow(btn.label, cx, cy, 'bold 18px system-ui, sans-serif', CLR_CLOUD, CLR_TEXT_SHADOW);

  // Ripple effect
  if (btn.ripple) {
    ctx.beginPath();
    ctx.arc(btn.ripple.x, btn.ripple.y, btn.ripple.radius, 0, Math.PI * 2);
    ctx.strokeStyle = CLR_GOLD;
    ctx.globalAlpha = btn.ripple.alpha;
    ctx.lineWidth = 2;
    ctx.stroke();
    btn.ripple.radius += 2;
    btn.ripple.alpha -= 0.03;
    if (btn.ripple.alpha <= 0) btn.ripple = null;
  }

  ctx.restore();
}
```

### Applying to Game Screens

**Title screen** — convert the pulsing "Press Enter or Tap to Begin" text into a proper button:
- Create `startButton = createButton('Begin', () => startGame())`.
- Each frame in `drawTitleScreen(now)`: set `startButton.x = CANVAS_WIDTH/2 - 80`, `startButton.y = centerY + 25`, `startButton.width = 160`, `startButton.height = 40`. Call `drawButton(startButton, now)`.
- Remove the old pulsing text draw for the start prompt.

**Game-over screen** — replace the full-screen click with an explicit "Play Again" button:
- Create `restartButton = createButton('Play Again', () => startGame())`.
- Each frame in `drawGameOverScreen(now)`: set `restartButton.x = CANVAS_WIDTH/2 - 90`, `restartButton.y = centerY + 55`, `restartButton.width = 180`, `restartButton.height = 40`. Call `drawButton(restartButton, now)`.
- Remove the old pulsing "Tap or Enter to Reopen" text.

**Active buttons list**: maintain `let activeButtons = []`. At the start of each `render()` call, clear it. Each screen pushes its visible buttons into it. The mute button is always pushed. Input handlers iterate `activeButtons`.

### Input Handler Changes

**`mousemove`**: loop `activeButtons`, set `btn.hovered = true` if cursor is inside `(btn.x, btn.y, btn.width, btn.height)`, else `false`. If any button is hovered, set `canvas.style.cursor = 'pointer'`; otherwise `canvas.style.cursor = 'default'`.

**`click`**: loop `activeButtons`. If the click point is inside a button, call `btn.onClick()`, set `btn.pressed = true` (reset next frame), create `btn.ripple = { x: clickX, y: clickY, radius: 0, alpha: 0.5 }`, play the button click sound (§3D). If the click is NOT on any button, don't trigger any action (this changes game-over from "click anywhere to restart" to "click the button to restart").

**`touchstart`**: same as click for buttons. Also reset `hovered` on `touchend` (to prevent sticky hover on mobile).

**`keydown` (`Tab`)**: track `focusedButtonIndex`. On Tab, cycle through `activeButtons`, set `focused = true` on the current one, `false` on all others. On `Enter` or `Space`, trigger the focused button's `onClick`.

**`keydown` (`Enter`)**: change from directly calling `startGame()` to: find the focused or first visible button and call its `onClick()`. If no button system is active yet, fall back to `startGame()` for safety. This preserves the keyboard-only experience.

---

## §7 — Mute Button

### Position & Size
- **Location**: top-right corner, hit area at `(CANVAS_WIDTH - 44, 8, 36, 36)` — i.e., `x = 436, y = 8, width = 36, height = 36`. This sits above the hearts row (`y = 24`).
- **Always visible** in all game states, including `'dying'`. Drawn last in `render()` so it's on top.

### Icon (drawn in code)
Create `drawMuteIcon(x, y, size, muted)`:

**Unmuted (speaker + waves)**:
- Speaker body: small filled rect (6 × 8 px) at `(x + 4, y + size/2 - 4)`.
- Speaker cone: triangle from the right edge of the rect extending 8 px right and flaring ±6 px vertically. Fill both with `CLR_CLOUD`.
- Sound waves: 2 arcs to the right of the cone (`ctx.arc` partial, from -45° to +45°), stroked `CLR_CLOUD`, lineWidth 2, at radii 6 and 11 from the cone tip.

**Muted (speaker + X)**:
- Same speaker body and cone as above.
- No arcs. Instead, draw an "X" overlaid: two lines (from `(x+22, y+8)` to `(x+32, y+28)` and `(x+32, y+8)` to `(x+22, y+28)`), stroked `CLR_STORM`, lineWidth 2.5.

### Behaviour
- Create the mute button using the button abstraction: `muteButton = createButton('', toggleMute)`. Override its draw to use `drawMuteIcon` instead of a text label.
- On click: toggle `audioMuted`.
  - Muting: `masterGain.gain.setValueAtTime(0, audioCtx.currentTime)`.
  - Unmuting: `masterGain.gain.setValueAtTime(MASTER_VOLUME, audioCtx.currentTime)`.
- **Persist**: `localStorage.setItem('skyTemple_muted', audioMuted ? '1' : '0')`. On load: `audioMuted = localStorage.getItem('skyTemple_muted') === '1'`.
- **Scale-pop**: on toggle, set `muteButton.currentScale = 1.3` (it will lerp back to 1.0 over a few frames).
- Always add `muteButton` to `activeButtons` in every game state.

---

## §8 — Audio Engine

### Architecture
```
AudioContext
  └── masterGain (GainNode, gain = MASTER_VOLUME = 0.3)
        └── sfxGain (GainNode, gain = 1.0)
              ├── all OscillatorNode → GainNode chains connect here
              └── all BufferSourceNode → filter → GainNode chains connect here
```

### Initialisation — On First User Interaction
In the first `mousedown` / `touchstart` / `keydown` handler:
```js
function initAudio() {
  if (audioInitialised) return;
  audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  if (audioCtx.state === 'suspended') audioCtx.resume();
  masterGain = audioCtx.createGain();
  masterGain.gain.value = audioMuted ? 0 : MASTER_VOLUME;
  masterGain.connect(audioCtx.destination);
  sfxGain = audioCtx.createGain();
  sfxGain.gain.value = 1.0;
  sfxGain.connect(masterGain);
  audioInitialised = true;
}
```
Call `initAudio()` at the very top of each input event handler (before any other logic). The one-time flag ensures it only runs once. This satisfies autoplay policy (AudioContext created inside a user gesture).

### Constants & Variables
```js
const MASTER_VOLUME = 0.3;
const ENABLE_SPEECH = true;
let audioCtx = null;
let masterGain = null;
let sfxGain = null;
let audioInitialised = false;
let audioMuted = false;  // read from localStorage on load
```

### Helper Functions

```js
function playTone(frequency, type, gainValue, durationMs, delayMs = 0) {
  if (!audioInitialised) return;
  const t = audioCtx.currentTime + delayMs / 1000;
  const osc = audioCtx.createOscillator();
  const gain = audioCtx.createGain();
  osc.type = type;
  osc.frequency.setValueAtTime(frequency, t);
  gain.gain.setValueAtTime(gainValue, t);
  gain.gain.exponentialRampToValueAtTime(0.001, t + durationMs / 1000);
  osc.connect(gain);
  gain.connect(sfxGain);
  osc.start(t);
  osc.stop(t + durationMs / 1000 + 0.05);
  return osc;  // return for optional pitch bending
}

function playNoise(durationSec, filterType, filterFreq, gainValue) {
  if (!audioInitialised) return;
  const sampleRate = audioCtx.sampleRate;
  const buffer = audioCtx.createBuffer(1, sampleRate * durationSec, sampleRate);
  const data = buffer.getChannelData(0);
  for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
  const src = audioCtx.createBufferSource();
  src.buffer = buffer;
  const filter = audioCtx.createBiquadFilter();
  filter.type = filterType;
  filter.frequency.value = filterFreq;
  const gain = audioCtx.createGain();
  gain.gain.setValueAtTime(gainValue, audioCtx.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + durationSec);
  src.connect(filter);
  filter.connect(gain);
  gain.connect(sfxGain);
  src.start();
  src.stop(audioCtx.currentTime + durationSec + 0.05);
}
```

### Safety
- All oscillator/buffer nodes self-stop and get garbage-collected. No cleanup array needed.
- If `audioCtx` not initialised: all `play*` functions return immediately (no-op).
- If muted: `masterGain.gain.value` is 0, so sounds produce no audible output. This is simpler than conditionally skipping creation.

---

## Implementation Phases

---

### Phase 1 — Audio Engine & Mute Button

**Files to edit:** `index.html`

**What to build:**
1. Add constants: `MASTER_VOLUME = 0.3`, `ENABLE_SPEECH = true`.
2. Add variables: `audioCtx`, `masterGain`, `sfxGain`, `audioInitialised`, `audioMuted`.
3. On page load, read mute state: `audioMuted = localStorage.getItem('skyTemple_muted') === '1'`.
4. Add `initAudio()` function (as specified in §8). Call it at the top of the `keydown`, `click`, `touchstart` event handlers.
5. Add `playTone()` and `playNoise()` helper functions (§8).
6. Add `createButton()` factory and `drawButton()` function (§6) — needed now for the mute button, and will be reused later.
7. Add `muteButton` instance. Add `drawMuteIcon()` function (§7). Wire the toggle: on click → flip `audioMuted`, update `masterGain.gain.value`, save to `localStorage`.
8. Add `activeButtons` array. In `render()`, clear it at the start, push `muteButton` always. Draw the mute button last (after all other draws, in every game state).
9. Update `mousemove` handler to check `activeButtons` for hover detection and cursor change.
10. Update `click` handler to check `activeButtons` first for button clicks.
11. Update `touchstart` handler similarly. Reset `hovered` on `touchend`.

**How to verify:**
- Game loads, plays exactly as before (no audio yet, no errors in console).
- Mute button icon (speaker shape) visible in top-right corner on all three screens (title, playing, gameover).
- Clicking the mute icon toggles it between speaker and speaker-with-X.
- After first click, open console: `audioCtx` exists, `audioCtx.state === 'running'`.
- Refresh the page → mute state persists (check `localStorage.getItem('skyTemple_muted')`).
- Hovering the mute button shows pointer cursor and button brightens slightly.

**Risks:**
- `AudioContext` may stay `'suspended'` if `resume()` isn't called inside a direct user gesture handler. **Mitigation:** `initAudio()` is called directly in the event listener, not deferred.
- The mute button hit area must not overlap the hearts display. **Mitigation:** mute button at `y = 8`, hearts at `y = 24` — no overlap on a 480px-wide canvas.

---

### Phase 2 — Catch Sound Effects

**Files to edit:** `index.html`

**What to build:**
1. In the good-catch code path (line 278, inside `if (item.type === 'good')`): call `playTone(660, 'sine', 0.18, 200)`. (Combo pitch adjustment comes in Phase 3.)
2. Optionally add the shimmer harmonic: `playTone(990, 'sine', 0.06, 200)`.
3. In the bad-catch code path (line 296, `else` block): call `playTone(150, 'square', 0.15, 120)`.
4. In the good-item-missed path (line 318, `if (item.type === 'good')` inside the fall-off check): call `playTone(80, 'sine', 0.10, 100)`.
5. Add the button click sound: in the button click handler (from Phase 1), call `playNoise(0.03, 'highpass', 2000, 0.08)`.

**How to verify:**
- Unmute (if muted). Catch a good item → hear a bright, soft chime.
- Catch a bad item → hear a short, harsh buzz.
- Let a good item fall off the bottom → hear a quiet, low thud.
- Let a bad item fall off → silence (correct — no penalty).
- Click the mute button → hear a soft click sound, then all subsequent sounds are silent.
- Unmute → sounds return.
- All sounds are quiet, non-jarring, and blend with the peaceful temple aesthetic.

**Risks:**
- Multiple rapid catches could layer sounds. **Mitigation:** individual gains are low (0.18 max), and sine waves mix cleanly at these levels without clipping.

---

### Phase 3 — Combo System

**Files to edit:** `index.html`

**What to build:**
1. Add combo state variables: `comboCount`, `comboMultiplier`, `comboDisplayTimer`, `comboLostTimer`, `comboLostValue`, `comboShatterFragments = []` (see §4).
2. Add `getMultiplier(combo)` function (§4).
3. In the good-catch path (line 278):
   - Increment `comboCount` by 1.
   - Update `comboMultiplier = getMultiplier(comboCount)`.
   - Change `score += 10` to `score += 10 * comboMultiplier`.
   - Set `comboDisplayTimer = 18` (frames, ≈300 ms at 60fps).
   - Adjust catch chime pitch: change the `playTone` call to `playTone(660 + Math.min(comboCount * 40, 400), 'sine', 0.18, 200)`.
   - Check milestone: if `comboCount` is exactly 5, 10, 15, or 20, play the rising arpeggio: `playTone(660, 'sine', 0.15, 80, 0)`, `playTone(830, 'sine', 0.15, 80, 50)`, `playTone(1046, 'sine', 0.15, 80, 100)`. (Visual milestone effects deferred to Phase 4.)
4. In both the bad-catch and miss-good-item paths:
   - Before resetting, check: if `comboCount >= 2`, save `comboLostValue = comboCount`, set `comboLostTimer = 30` (frames), play the descending wah: create an oscillator with `playTone(300, 'triangle', 0.12, 200)` and immediately ramp its frequency: `osc.frequency.linearRampToValueAtTime(200, audioCtx.currentTime + 0.2)`.
   - Then reset: `comboCount = 0; comboMultiplier = 1;`.
5. Add `drawComboCounter(now)` function: draws the combo text at the position specified in §4 (right-aligned at `CANVAS_WIDTH - 60, 70`), with scale-pop animation based on `comboDisplayTimer`. Decrement `comboDisplayTimer` each frame in `update()`.
6. Call `drawComboCounter(now)` in `render()` during the `'playing'` state, after `drawHUD()`.
7. In `startGame()`, reset all combo variables to 0 and clear `comboShatterFragments`.

**How to verify:**
- Catch 2 good items in a row → "×2" appears in top-right area with a scale-pop, no overlap with score or hearts.
- Catch 5 → "×5" shown, "(2× pts)" below it, ascending arpeggio plays. Score now increments by +20 per catch.
- Catch 10 → "(3× pts)", another arpeggio.
- Miss a good item or catch a bad item → combo disappears, descending "wah" plays (if combo was ≥ 2). Multiplier resets to ×1.
- At combo 20+, multiplier stays at ×5 (cap).
- Restart → combo resets to 0.
- Chime pitch gets higher with each combo level — noticeable by combo 5–10.
- Score text in top-left, hearts in top-right, combo display below mute button — no overlap at 480px canvas width.

**Risks:**
- Chime at max pitch (1060 Hz) might sound shrill. **Mitigation:** it's a sine wave at gain 0.18 — still soft. If harsh, reduce the cap to +300 Hz.
- Score multiplier significantly increases scores. **Mitigation:** this is intentional — it rewards sustained skill.

---

### Phase 4 — Particles & Animations

**Files to edit:** `index.html`

**What to build:**
1. Extend the particle system: add `gravity` field to particle objects, apply it in `updateParticles()` (§5). Add the 150-particle hard cap.
2. Add `burstParticles(x, y, count, options)` helper (§5).
3. Add `floatingTexts[]` array with `updateFloatingTexts()` and `drawFloatingTexts()` (§5).
4. **Good-catch sparkle** — replace the current 6-particle burst (lines 284-295) with the enhanced `burstParticles` call (§5A, 12 particles, gold, with gravity). Also push a floating score text.
5. **Basket bounce** — add `basket.bounceTimer`. On good catch set to 12 frames. In `drawBasket()`, apply y-offset. Decrement in `update()` (§5B).
6. **Basket recoil** — add `basket.recoilTimer`. On bad catch set to 9 frames. In `drawBasket()`, apply y-offset and colour tint. Decrement in `update()` (§5C).
7. **Basket idle bob** — in `drawBasket()`, pass `now` as a parameter. Apply sine-based y-offset when no bounce/recoil active (§5D).
8. **Miss splash** — replace the current 4-particle puff for missed good items (lines 321-332) with 7 `CLR_CLOUD` particles with upward bias and gravity (§5E).
9. **Bad-item dodge puff** — add 3 subtle `CLR_STORM` particles when a bad item falls off screen (§5F).
10. **Heart shake** — add `heartShakeTimer`. On life loss, set to 18 frames. Apply shake offset in `drawHUD()`. Decrement in `update()` (§5G).
11. **Combo milestone visuals** (deferred from Phase 3) — on milestone hits (5, 10, 15, 20): call `burstParticles` for the starburst (25 particles) + spawn 15 falling sparkle particles from canvas top. Flash combo text white for 6 frames (§4 milestones).
12. **Combo lost shatter** — add `comboShatterFragments[]`. On combo break (from ≥ 2), create 5-6 fragments at the combo text position with outward velocity, gravity, rotation, fade. Update and draw alongside particles. Add `basketDimTimer` — 18 frames of dimmed basket (§4 combo lost).
13. In `startGame()`, reset: `basket.bounceTimer = 0`, `basket.recoilTimer = 0`, `heartShakeTimer = 0`, `basketDimTimer = 0`, `floatingTexts = []`, `comboShatterFragments = []`.

**How to verify:**
- Catch a good item → 12 gold sparkles burst outward (with gravity arc), "+10" text floats up and fades. Basket bounces up briefly.
- Catch a bad item → basket recoils down, flashes `CLR_STORM` briefly.
- Basket gently bobs when idle (no bounce/recoil active).
- Miss a good item → white splash at bottom, hearts shake.
- Let a bad item fall → subtle grey puff at bottom.
- Hit combo ×5 → big starburst from combo text + gold sparkles fall from top of screen.
- Lose a combo of ≥5 → red fragments fly out from where combo text was, basket dims.
- Play actively for 30 s with many catches → check devtools Performance tab. Frame rate stays above 55 fps. `particles.length` never exceeds 150 (add a temporary `console.log` to verify, then remove).
- Floating texts cap at 10, don't pile up.

**Risks:**
- Replacing existing particle spawns could break if line numbers shifted from earlier phases. **Mitigation:** search for the existing particle push patterns by content (e.g., `CLR_GOLD_BRIGHT` and the `for (let p = 0; p < 6; p++)` loop), not by line number.
- Too many particles on rapid catches. **Mitigation:** hard cap of 150 prevents runaway.

---

### Phase 5 — Button Hover & Press States

**Files to edit:** `index.html`

**What to build:**
1. Convert the title screen's pulsing "Press Enter or Tap to Begin" text into the `startButton` (§6). Remove the old pulsing text code from `drawTitleScreen()`. Set button bounds in `drawTitleScreen()` each frame, push to `activeButtons`, call `drawButton()`.
2. Convert the game-over screen: replace the full-screen-click restart with a "Play Again" `restartButton` (§6). Remove the old pulsing "Tap or Enter to Reopen" text from `drawGameOverScreen()`. Set button bounds, push to `activeButtons`, call `drawButton()`.
3. Update `click` handler: remove the direct `if (gameState === 'title' || gameState === 'gameover') startGame()` logic. Instead, all restarts flow through button clicks (already handled via `activeButtons` from Phase 1).
4. Update `touchstart` handler similarly: remove direct `startGame()` calls; let button system handle it.
5. Update `keydown` handler for `Enter`: instead of directly calling `startGame()`, trigger the first button's `onClick` in `activeButtons` (or the focused button if Tab focus is active).
6. Add `Tab` key focus cycling: track `focusedButtonIndex`. On `Tab`, cycle through `activeButtons`, set `focused = true` on one, `false` on others. On `Enter` or `Space`, call the focused button's `onClick`.
7. On `touchend`: set `hovered = false` on all buttons (prevent sticky hover on mobile).
8. Ensure the button click sound (from Phase 2) plays on every button press.

**How to verify:**
- **Title screen**: "Begin" button visible, properly styled with `CLR_MOSS` fill and `CLR_GOLD` border.
  - Hover → button brightens and scales to 1.05×.
  - Click → button darkens, scales to 0.95×, gold ripple expands, click sound plays, game starts.
- **Game-over screen**: "Play Again" button visible below the score panel.
  - Same hover/click behavior.
  - Clicking outside the button does **not** restart (changed from current "click anywhere" behavior).
- **Mute button**: also responds to hover/press (already from Phase 1, verify it still works).
- **Keyboard**: Tab cycles focus between visible buttons (green glow ring on focused one). Enter/Space activates the focused button.
- **Touch**: tap on buttons works. After lifting finger, no lingering hover state.

**Risks:**
- Changing game-over from "click anywhere" to "click the button" might feel less convenient. **Mitigation:** make the button large (180 × 40) and clearly labelled "Play Again".
- The `Enter` key must still work to start/restart the game for keyboard users. **Mitigation:** `Enter` triggers the focused (or first visible) button's `onClick`, which calls `startGame()`.

---

### Phase 6 — Lightning Loss Sequence

**Files to edit:** `index.html`

**What to build:**
1. Add `'dying'` to `gameState`. Where `lives <= 0` currently triggers `gameState = 'gameover'` (line 343), change to `gameState = 'dying'` and set `deathSequenceStart = now` (current timestamp from `update(now)`). Keep `items = []` (clear items).
2. Add death sequence state variables: `deathSequenceStart`, `boltPoints = []`, `boltBranches = []`, `fragments = []`, `basketDestroyed = false`, `deathDarkFactor = 1.0`.
3. In `update(now)`: add an `else if (gameState === 'dying')` branch (after the `'playing'` check at line 249). Inside, compute `elapsed = now - deathSequenceStart` and run the timeline logic:
   - 0–300 ms: `deathDarkFactor = 1.0 - 0.6 * (elapsed / 300)`.
   - At 300 ms (once): generate `boltPoints` and `boltBranches` arrays. Play thunder crack (`playNoise(0.4, 'lowpass', 800, 0.7)` with gain envelope).
   - 300–500 ms: compute screen shake offset. Compute flash alpha.
   - 500–900 ms: compute bolt fade alpha. Compute catcher flicker state (every 60 ms).
   - At 900 ms (once): generate `fragments` from basket dimensions.
   - 900–1400 ms: update fragment positions (velocity + gravity), rotations, alpha. Set `basketDestroyed = true`.
   - At 1400 ms (once): play sad jingle (§2B). Schedule speech if enabled (§2C).
   - 1400–1800 ms: hold.
   - At 2200 ms: set `gameState = 'gameover'`, `basketDestroyed = false`. Clear `boltPoints`, `boltBranches`, `fragments`. Restore `deathDarkFactor = 1.0`.
4. In `render(now)`: add `else if (gameState === 'dying')` branch. Draw:
   - Sky gradient, then darken overlay: `ctx.fillStyle = 'black'; ctx.globalAlpha = 1 - deathDarkFactor; ctx.fillRect(0,0,CANVAS_WIDTH,CANVAS_HEIGHT); ctx.globalAlpha = 1;`.
   - Clouds, temple, platform (all at their current state).
   - If not `basketDestroyed`: draw basket (with flicker tint). Else: draw fragments (rotated, fading rectangles in `CLR_STONE`).
   - Draw bolt polyline (if bolt alpha > 0).
   - Draw screen flash overlay (if flash alpha > 0).
   - Draw particles (ember particles from catcher scorch).
   - If `elapsed >= 1800`: draw game-over overlay with `globalAlpha = Math.min(1, (elapsed - 1800) / 400)` then call `drawGameOverScreen(now)` with that alpha.
   - Always draw the mute button (last).
   - Apply screen shake by wrapping the entire render in `ctx.save(); ctx.translate(shakeX, shakeY); … ctx.restore();` (except the mute button, which should not shake — draw it outside the translate).
5. Block input during `'dying'`:
   - In `mousemove`: add `if (gameState === 'dying') return;` (but still allow mute button hover check).
   - In `click`: add `if (gameState === 'dying')` → only check mute button, ignore all else.
   - In `touchstart` / `touchmove`: same — only mute button during dying.
   - In `keydown`: only allow mute-related keys during dying.
6. In `startGame()`: reset `basketDestroyed = false`, clear `boltPoints`, `boltBranches`, `fragments`, set `deathDarkFactor = 1.0`.

**How to verify:**
- Play until you lose. The full 2.2 s sequence plays:
  1. Sky darkens over 300 ms.
  2. Lightning bolt strikes from top to basket with a flash and screen shake. Thunder rumbles.
  3. Basket flickers between normal and scorched colour. Embers fly upward.
  4. Basket crumbles into fragments that fall, rotate, and fade.
  5. Brief dark pause. Sad jingle plays (three descending notes).
  6. Game-over panel fades in smoothly.
- During the sequence: mouse movement does NOT move the basket. Clicking does NOT restart. The game is "locked."
- The mute button still works during the sequence (clicking it mutes/unmutes).
- After the sequence, the "Play Again" button works normally.
- If muted before dying: all visuals play, all sounds are silent.
- If `ENABLE_SPEECH` is true and `speechSynthesis` exists: "You lose" is spoken softly after the jingle. If not available: no error, no speech, jingle still plays.
- Restarting after death: basket reappears intact, sky is normal brightness, all death-sequence state is cleared.

**Risks:**
- The 2.2 s delay might frustrate impatient players. **Mitigation:** it's cinematic and short. If playtesting shows frustration, the 1400–1800 hold can be shortened to 100 ms (reducing total to ≈1.5 s).
- Bolt generation could produce a wild path going off-screen. **Mitigation:** clamp x to `[CANVAS_WIDTH * 0.2, CANVAS_WIDTH * 0.8]` after each segment.
- The `'dying'` state must be handled in every input handler and render branch. **Mitigation:** add it as an explicit check at the top of each handler; the mute button works because it's always in `activeButtons`.
- `drawGameOverScreen()` currently draws its own overlay. During the dying→gameover fade-in, the overlay alpha needs to be modulated. **Mitigation:** wrap the call in a `ctx.save(); ctx.globalAlpha = fadeAlpha; … ctx.restore();` or pass the alpha as a parameter.

---

### Phase 7 — Polish & Integration Testing

**Files to edit:** `index.html`

**What to build / verify:**
1. **Full play-through audit**: play from title → game → death → restart, 3+ times. Verify every row in the Action-to-Reaction Table produces both its visual and audio response. Check off each row.
2. **Autoplay compliance**: load the page fresh (hard refresh). Wait 3 seconds. Confirm absolute silence — no sounds until first click/tap/keypress. Check console for AudioContext warnings.
3. **Mute audit**: toggle mute at every stage — title screen, mid-game, during a combo, during the death sequence, on the game-over screen. Confirm:
   - Muting: all audio stops instantly. Visuals continue.
   - Unmuting: sounds resume on next action.
   - Mute persists across page reload.
4. **Performance audit**: open devtools Performance tab. Play a busy stretch: build combo to 10+, trigger milestone bursts, lose lives. Confirm 60 fps sustained. Check `particles.length` stays ≤ 150.
5. **Layout audit at 480px width**: verify no overlap between score (top-left), hearts (top-right), mute button (top-right corner), and combo counter (below mute). All text is readable. All buttons are tappable.
6. **Audio balance**: play with headphones. Confirm:
   - No sound is too loud or harsh.
   - Sad jingle is audible (not drowned by thunder — they play at different times, so this should be fine).
   - Button click is subtle.
   - Max-combo chime (1060 Hz) doesn't hurt.
   - Adjust individual gains if anything is off.
7. **Edge cases**:
   - Lose on the very first item (combo = 0) → no combo-lost effect, just the death sequence.
   - Get combo to exactly 5, then immediately die → milestone burst plays, then death sequence (milestone particles may overlap with death visuals — that's fine, they'll fade independently).
   - Rapidly catch 3 items in < 0.5 s → sounds layer without distortion.
   - No `console.log` debug statements remain.
8. **Code cleanup**: comment the major new sections (audio engine, combo system, enhanced particles, button system, death sequence). Ensure all new variables are initialised in `startGame()`.

**How to verify:**
- 3 full play-throughs (quick loss, medium run with combos, long run hitting combo 20+) → zero console errors.
- The game feels responsive: every catch, miss, combo change, and loss has immediate feedback.
- Audio is atmospheric and low-volume, matching the peaceful sky-temple theme.
- Lightning loss sequence is dramatic but not too long.
- Game is fully playable and enjoyable from title to death and back.

**Risks:**
- Integration bugs where death-sequence variables aren't reset on restart. **Mitigation:** `startGame()` should be the single source of truth for all resets. Audit it to ensure every new variable from Phases 1–6 is reset there.
- Mobile `touchmove` might trigger both button hover and basket movement. **Mitigation:** in `touchmove`, only move the basket if no button in `activeButtons` contains the touch point.

---

## Summary of All New State Variables

| Variable | Type | Default | Purpose |
|----------|------|---------|---------|
| `MASTER_VOLUME` | `const number` | `0.3` | Master audio level |
| `ENABLE_SPEECH` | `const bool` | `true` | Enable "You lose" speech |
| `audioCtx` | `AudioContext\|null` | `null` | Web Audio context |
| `masterGain` | `GainNode\|null` | `null` | Master volume control |
| `sfxGain` | `GainNode\|null` | `null` | SFX sub-mix |
| `audioInitialised` | `bool` | `false` | Whether AudioContext has been created |
| `audioMuted` | `bool` | from localStorage | Whether audio is muted |
| `comboCount` | `int` | `0` | Consecutive good catches |
| `comboMultiplier` | `int` | `1` | Score multiplier (1–5) |
| `comboDisplayTimer` | `int` | `0` | Frames remaining for combo scale-pop |
| `comboLostTimer` | `int` | `0` | Frames remaining for combo shatter |
| `comboLostValue` | `int` | `0` | Last combo value (for shatter display) |
| `comboShatterFragments` | `array` | `[]` | Flying text shatter pieces |
| `floatingTexts` | `array` | `[]` | Score pop-ups (max 10) |
| `basket.bounceTimer` | `int` | `0` | Good-catch bounce frames |
| `basket.recoilTimer` | `int` | `0` | Bad-catch recoil frames |
| `heartShakeTimer` | `int` | `0` | Heart shake frames |
| `basketDimTimer` | `int` | `0` | Basket dim on combo-lost frames |
| `deathSequenceStart` | `number` | `0` | Timestamp when death began |
| `deathDarkFactor` | `number` | `1.0` | Sky darken interpolation |
| `boltPoints` | `array` | `[]` | Lightning main segment positions |
| `boltBranches` | `array` | `[]` | Lightning fork data |
| `fragments` | `array` | `[]` | Basket crumble pieces |
| `basketDestroyed` | `bool` | `false` | Whether basket is crumbled |
| `activeButtons` | `array` | `[]` | Currently interactable buttons |
| `startButton` | `object` | created once | Title screen start button |
| `restartButton` | `object` | created once | Game-over play-again button |
| `muteButton` | `object` | created once | Mute toggle button (always visible) |
| `focusedButtonIndex` | `int` | `-1` | Keyboard focus tracking |
