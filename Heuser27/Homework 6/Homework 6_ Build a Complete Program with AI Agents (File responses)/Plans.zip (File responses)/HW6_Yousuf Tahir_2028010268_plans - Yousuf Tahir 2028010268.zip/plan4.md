# Stage 4 Implementation Plan: State & Storage

Architect Model: Gemini Builder Model: Flash 3.8

## Overview
This plan establishes persistent browser storage and a robust game state machine for the Sky Temple catch game. It introduces versioned storage with in-memory fallbacks, formalizes game states (`menu`, `playing`, `paused`, `dying`, `over`), implements a seamless pause and resume system with time-jump protection, run restart handling, high-score tracking with celebratory reactions, and a themed data-reset flow.

---

## 1. Saved Data Architecture

### Root Storage Specification
- **Storage Root Key**: `"skytemple_v1"`
- **Storage Mechanism**: `window.localStorage` wrapped in defensive `try / catch` blocks.
- **Fault-Tolerance Fallback**: If storage access throws (e.g. cookies disabled, private browsing sandbox, or quota limits), the game seamlessly falls back to a volatile in-memory copy without crashing or alerting errors.

### Schema & Data Dictionary
All state is bundled into a single JSON object under `"skytemple_v1"`:

| Field Path | Type | Default | When Saved | Description & Validation |
| :--- | :--- | :--- | :--- | :--- |
| `version` | `number` | `1` | Initialization | Schema version for future migrations. |
| `highScore` | `number` | `0` | Run ends (or instantly when surpassed) | Non-negative integer (`Math.max(0, Math.floor(n))`). |
| `bestCombo` | `number` | `0` | When run ends or when combo surpasses record | Non-negative integer tracking highest combo streak achieved. |
| `gamesPlayed` | `number` | `0` | At the start of each run (`startGame()`) | Positive integer incremented per attempt. |
| `settings.muted` | `boolean` | `false` | When mute button/key is toggled | Boolean flag controlling audio output. |
| `settings.volume`| `number` | `0.3` | When master volume is adjusted | Floating-point clamp between `0.0` and `1.0`. |

### Validation & Fallback Rules
1. **Load Routine (`loadStorage`)**:
   - Wrap `localStorage.getItem('skytemple_v1')` in `try / catch`.
   - If key does not exist or JSON parsing fails, clone defaults:
     ```javascript
     const DEFAULT_STORAGE = {
       version: 1,
       highScore: 0,
       bestCombo: 0,
       gamesPlayed: 0,
       settings: {
         muted: false,
         volume: 0.3
       }
     };
     ```
   - Field validation:
     - `highScore`: Must be a finite number `>= 0`; otherwise `0`.
     - `bestCombo`: Must be a finite number `>= 0`; otherwise `0`.
     - `gamesPlayed`: Must be a finite number `>= 0`; otherwise `0`.
     - `settings.muted`: Must be strict `boolean`; otherwise `false`.
     - `settings.volume`: Must be finite number in range `[0.0, 1.0]`; otherwise `0.3`.
   - Migration check: Check and migrate legacy standalone key `'skyTemple_muted'` if present, then safely remove the legacy key.
2. **Save Routine (`saveStorage`)**:
   - Write updated state back into memory cache and attempt `localStorage.setItem('skytemple_v1', JSON.stringify(storageData))`.
   - Silent catch on quota or permission exceptions: updates persist in memory for the active session.

---

## 2. Game State Machine

### State Definitions
Single state variable `gameState` with 5 distinct states:
- `'menu'`: Title screen. Catcher idle, title floating, "Begin" and "Reset Data" buttons displayed. High score and best combo shown.
- `'playing'`: Active run. Basket moves via pointer/keys, items spawn and drop, combo counter active, HUD visible.
- `'paused'`: Game suspended. All physics, particle simulation, item spawning, and animations frozen. Pause modal displayed.
- `'dying'`: Lightning loss sequence (~2200ms). Input strictly locked. Basket struck by lightning, darkens sky, shakes screen, crumbles catcher, plays thunder and sad audio.
- `'over'`: Final score panel displayed over frozen game field. Play Again and Menu buttons active. High score reaction displayed if beaten.

### State Transition Table

| Current State | Target State | Trigger Event | Allowed Conditions | Actions Taken |
| :--- | :--- | :--- | :--- | :--- |
| `'menu'` | `'playing'` | "Begin" button click or `Space`/`Enter` | Confirmation modal not open | Increment `gamesPlayed`, reset run variables, start spawning. |
| `'playing'` | `'paused'` | Pause button click, `P` key, `Escape` key, window blur / tab switch | Run is active | Store `pauseStartTime`, freeze audio nodes, push pause UI buttons. |
| `'paused'` | `'playing'` | "Resume" button click, `P` key, or `Escape` key | Pause modal active | Calculate pause duration, offset `lastSpawnTime`, resume run loop. |
| `'paused'` | `'playing'` | "Restart" button click | Pause modal active | Calculate offset or full reset; reset run state, start immediately. |
| `'paused'` | `'menu'` | "Exit to Menu" button | Optional navigation | Tear down run, return to title screen. |
| `'playing'` | `'dying'` | Lives drop to `0` (heart lost / bad item caught) | Transition guard | Lock all player input, set `deathSequenceStart = now`, trigger lightning sequence. |
| `'dying'` | `'over'` | Elapsed sequence timer `>= 2200ms` | Sequence completes | Save high score & best combo if beaten, build game-over UI buttons. |
| `'over'` | `'playing'` | "Play Again" button or `Space`/`Enter` | Game over modal active | Reset run variables, increment `gamesPlayed`, start run. |
| `'over'` | `'menu'` | "Menu" button (or return trigger) | Game over modal active | Reset run, return to menu screen. |

### Lightning Loss Sequence Placement
- The sequence sits **strictly between `'playing'` and `'over'`**.
- State is `'dying'`.
- All movement keys (`A`, `D`, Arrows, pointer drag) are completely ignored.
- The pause trigger (`P`, `Esc`, Pause button) is disabled during `'dying'` to prevent interrupting death animations.
- Once elapsed time hits `2200ms`, the state machine automatically transitions from `'dying'` to `'over'`.

---

## 3. Pause System & Time Jump Prevention

### Activation Triggers
1. **Physical Keypress**: `P`, `p`, or `Escape`.
2. **On-Screen Button**: Themed stone pause icon button (e.g. `||` symbol) placed on top-right HUD (adjacent to Mute button).
3. **Automatic Tab Focus Loss**: Window `blur` event and `document.visibilitychange` (`document.hidden === true`). Auto-pauses only if `gameState === 'playing'`.

### Complete Freeze Behavior
While in `'paused'`:
- **Updates Suspended**: `updateBasket()`, `updateItems()`, `updateParticles()`, `updateFloatingTexts()`, `updateClouds()`, and all combo countdown timers are bypassed.
- **Audio Suspended**: Web Audio nodes muted or clamped to zero output; no sound effects triggered while paused.
- **Visuals Preserved**: Active items, basket position, particles, and clouds remain frozen in place behind a semi-transparent modal.

### Time Jump & Avalanche Prevention
- **The Issue**: Spawning and animations calculate intervals using `now - lastSpawnTime`. If paused for 10 seconds, unpausing would cause `now - lastSpawnTime` to jump by 10,000ms, spawning a massive clump of items instantly.
- **The Solution**:
  - When entering `'paused'`: capture `pauseStartTime = performance.now()`.
  - When exiting `'paused'`: compute `pausedDuration = performance.now() - pauseStartTime`.
  - Adjust timing references:
    ```javascript
    lastSpawnTime += pausedDuration;
    ```
  - This ensures delta timings resume with sub-millisecond continuity.

### Themed Pause UI
- **Backdrop**: Semi-transparent twilight veil `rgba(30, 40, 50, 0.6)`.
- **Stone Panel**: Centered rounded stone slate (`CLR_STONE` #E0D6C8 with `CLR_STONE_DARK` #C4B8A8 border).
- **Header**: Warm golden title "PAUSED" with subtle text shadow.
- **Action Buttons**:
  - **"Resume"** (accented soft green `CLR_MOSS` hover glow) - resumes game.
  - **"Restart"** (temple stone) - restarts the run from scratch.
  - **"Mute / Unmute"** (toggle button with speaker icon and status text) - toggles audio instantly and keeps top-bar mute button in sync.

---

## 4. Restart Flow

### Triggers
- From Pause modal: "Restart" button.
- From Game Over screen: "Play Again" button or `Space` / `Enter`.

### Reset Scope (Pure Run Reset)
Restart strictly resets transient in-game variables without touching saved player progress:
- `score = 0`
- `lives = 3`
- `items = []`
- `particles = []`
- `floatingTexts = []`
- `comboCount = 0`, `comboMultiplier = 1`, all combo display & flash timers = `0`
- Basket repositioned to horizontal center (`(CANVAS_WIDTH - BASKET_WIDTH) / 2`)
- Basket bounce & recoil timers = `0`
- Screen shake values = `0`
- `lastSpawnTime = performance.now()`
- Increment persistent `gamesPlayed` count and save to storage.
- Does **not** modify `highScore`, `bestCombo`, or audio settings.
- Sets `gameState = 'playing'`.

---

## 5. High Score & Record Handling

### Verification & Save Timing
- High score is compared both continuously (`score > storageData.highScore`) and finalized upon entering game over.
- Only saved to persistent storage if beaten (`if (score > storageData.highScore) { storageData.highScore = score; saveStorage(); }`).
- Same logic applied to `bestCombo`.

### Display & Reactions
1. **Menu Screen**:
   - Displays `Best: {highScore}` in warm gold (`CLR_GOLD`) beneath the title.
   - Displays `Best Streak: {bestCombo}x` in soft moss green.
2. **During Gameplay**:
   - The moment current score surpasses previous high score (for non-zero high scores), trigger a one-time celebratory banner: floating text `NEW HIGH SCORE!` in gold with a shower of spark particles (`CLR_GOLD`).
3. **Game Over Screen**:
   - If a new record was set during this run, show an animated badge/text `NEW HIGH SCORE!` with gold pulsation above the final score.
   - Otherwise, display current score and static `Best: {highScore}`.

---

## 6. Reset Data Feature

### Location & Appearance
- Placed on `'menu'` screen at the bottom (`y = CANVAS_HEIGHT - 45`).
- Styled as an understated, low-profile stone button: `"Clear Data"` or `"Reset Records"`.

### Themed Confirmation Dialogue
- Clicking "Reset Records" sets `isResetConfirmOpen = true`.
- Renders an interactive modal box:
  - **Container**: Weathered stone dialogue with warning accent.
  - **Title**: `"Reset All Records?"` in muted storm slate (`CLR_STORM_DARK`).
  - **Body Text**: `"Clear high score, streaks, and settings? This cannot be undone."`
  - **Buttons**:
    - `"Cancel"`: dismisses modal, returns to normal menu.
    - `"Confirm Reset"`: executes data wipe.

### Execution & Immediate Synchronization
Upon confirmation:
- Overwrite storage with `DEFAULT_STORAGE` via `localStorage.setItem('skytemple_v1', JSON.stringify(DEFAULT_STORAGE))`.
- Update runtime variables:
  - `storageData = JSON.parse(JSON.stringify(DEFAULT_STORAGE))`
  - `highScore = 0`
  - `bestCombo = 0`
  - `gamesPlayed = 0`
  - `audioMuted = false`
- Immediately update audio hardware: `masterGain.gain.setValueAtTime(MASTER_VOLUME, audioCtx.currentTime)`.
- Reset button scales and dismiss modal. All menu text immediately reflects `Best: 0`.

---

## 7. Boot Lifecycle & Page Refresh

- On initial page load or browser refresh:
  - Execute `loadStorage()`.
  - Apply `storageData.settings.muted` to master gain and mute button state.
  - Initialize `highScore = storageData.highScore`.
  - **Always set `gameState = 'menu'`**. Never restore mid-run or mid-pause states across refreshes.
  - No prompt, no alert, and no unhandled exceptions if cookies/localStorage are blocked.

---

## Phased Implementation Roadmap

### Phase 1: Storage Layer & Versioned Schema
- **Files to Edit**: `index.html`
- **What to Build**:
  - Implement `STORAGE_KEY = 'skytemple_v1'` and `DEFAULT_STORAGE` constant.
  - Create memory cache `storageData`.
  - Implement `loadStorage()` with schema validation, migration from `skyTemple_muted`, and fallback to default object on missing or malformed data.
  - Implement `saveStorage()` with defensive `try / catch`.
  - Replace standalone `audioMuted` reading with `storageData.settings.muted`.
- **Verification**:
  - Open console: verify `skytemple_v1` is created in localStorage on boot.
  - Corrupt the entry manually (`localStorage.setItem('skytemple_v1', 'corrupt{json')`), refresh, and verify game safely boots with defaults.
  - Disable localStorage (test via incognito or mocked throw) and confirm game operates cleanly via in-memory storage.
- **Risk**: *Accessing localStorage in restrictive browser sandbox can throw a SecurityError; must wrap all interactions in try/catch.*

---

### Phase 2: State Machine Formalization & Input Routing
- **Files to Edit**: `index.html`
- **What to Build**:
  - Formalize `gameState`: `'menu'`, `'playing'`, `'paused'`, `'dying'`, `'over'` (migrating `'title'` -> `'menu'`, `'gameover'` -> `'over'`).
  - Map transitions explicitly via transition table guards.
  - Restructure `update(now)` and `render(now)` to branch strictly on the unified `gameState`.
  - Keep `'dying'` sequence between `'playing'` and `'over'`, ensuring all keyboard and pointer movement inputs are blocked during `'dying'`.
- **Verification**:
  - Start game -> play -> lose all lives -> confirm lightning strike plays uninterrupted -> confirm gameover screen appears only after 2200ms.
  - Verify keys/clicks cannot move the basket or trigger actions while catcher is being destroyed.
- **Risk**: *Mismatched state string literals across render branches can cause blank frames; use constant definitions or explicit checks.*

---

### Phase 3: Pause System & Time Jump Prevention
- **Files to Edit**: `index.html`
- **What to Build**:
  - Add Pause button (`||`) to HUD adjacent to the Mute button.
  - Add keydown listener for `KeyP` and `Escape` to toggle pause state when in `'playing'` or `'paused'`.
  - Implement `window.onblur` and `document.onvisibilitychange` auto-pause.
  - Record `pauseStartTime` on pause entry and add `pausedDuration` to `lastSpawnTime` on resume.
  - Build Sky Temple styled Pause Screen modal with "Resume", "Restart", and "Mute" buttons.
- **Verification**:
  - Press `P` during active item falling: verify items, clouds, and particles freeze completely.
  - Wait 10 seconds, press `P` or click "Resume": verify items continue at exact pre-pause trajectory with zero item cluster or speed jump.
  - Switch tabs and return: verify game is safely paused.
- **Risk**: *Unaccounted timers (e.g. combo countdown or item spawn timers) can expire during pause if not offset by `pausedDuration`.*

---

### Phase 4: Restart Flow
- **Files to Edit**: `index.html`
- **What to Build**:
  - Build `restartGame()` function that performs complete run reset: score, combo, items, particles, timers, basket centering.
  - Hook "Restart" button in Pause modal to call `restartGame()`.
  - Hook "Play Again" button in Game Over modal to call `restartGame()`.
  - Increment `storageData.gamesPlayed` and persist to storage.
- **Verification**:
  - Pause mid-game with score > 0, items falling, and combo active -> Click "Restart" -> Verify run starts fresh with 3 lives, score 0, combo 1x, centered basket.
  - Die -> Game Over screen -> Click "Play Again" -> Verify run restarts cleanly without retained particles or falling items.
- **Risk**: *Stray item or particle references left in arrays can trigger instant collision or visual glitch on frame 0 of restart.*

---

### Phase 5: High Score Tracking & Reaction UI
- **Files to Edit**: `index.html`
- **What to Build**:
  - Compare score against `storageData.highScore`.
  - Update `highScore` and call `saveStorage()` when surpassed.
  - Track `isNewHighScoreRun` flag for game over banner.
  - Add floating golden celebration text `"NEW HIGH SCORE!"` and particle burst when high score is beaten during play.
  - Render `Best: {highScore}` on Menu screen and Game Over screen with sky temple typography and gold tone.
  - Track and display `bestCombo` alongside high score.
- **Verification**:
  - Play game and score points to beat existing high score: observe celebratory particle burst.
  - Let run finish: verify Game Over screen proclaims "NEW HIGH SCORE!".
  - Return to menu / refresh page: verify high score persists.
- **Risk**: *Saving to storage every frame while beating high score can spam localStorage; only save on delta milestones or run conclusion.*

---

### Phase 6: Reset Data Button & Themed Confirmation Modal
- **Files to Edit**: `index.html`
- **What to Build**:
  - Add "Clear Records" button to Menu screen.
  - Create confirmation state flag `isResetConfirmOpen`.
  - Render themed Sky Temple modal dialogue asking `"Reset All Records?"` with "Cancel" and "Confirm Reset" buttons.
  - Wire confirmation logic: replace storage data with `DEFAULT_STORAGE`, write to localStorage, reset live audio and display values immediately.
- **Verification**:
  - Set a high score and mute audio. Click "Clear Records" -> modal appears.
  - Click "Cancel": modal closes, high score and mute status unchanged.
  - Click "Confirm Reset": modal closes, high score resets to 0, mute resets to unmuted, audio plays.
  - Refresh page: verify all records remain at 0.
- **Risk**: *Double clicking confirmation or clicking outside buttons could trigger unintended menu clicks if pointer hits active buttons underneath.*

---

## Short Test Checklist

- [ ] **Refresh Keeps Data**: Score points, beat high score, toggle mute, refresh page -> high score and mute state remain intact, game opens on Menu screen.
- [ ] **Pause & Resume Continuity**: Press `P` or Pause button while items fall; confirm everything freezes. Wait 5 seconds, resume; confirm items fall smoothly with zero time jump or instant multi-spawn.
- [ ] **Auto-Pause on Tab Switch**: Switch to another browser tab during play; switch back and confirm game is paused.
- [ ] **Restart from Both Screens**: Restart from Pause menu and Game Over screen; verify score, combo, items, and timers are 100% reset to 0 while high score is preserved.
- [ ] **Reset Wipes Everything**: Click "Clear Records" -> confirm dialogue -> confirm all stats (high score, combo, games played) wipe to defaults and audio un-mutes immediately.
- [ ] **Storage Failure / Sandbox Safety**: Simulate `localStorage` throwing an exception; verify game functions flawlessly using in-memory fallback without crashing or throwing errors.
- [ ] **Rapid Clicking & State Immunity**: Rapidly spam Pause, Resume, Restart, and Start buttons; verify state machine never corrupts, deadlocks, or transitions to an invalid state.
