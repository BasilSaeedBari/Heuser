Stage: Stage 4: State & Storage
Architect model: Gemini 3.5 Pro   Builder model: Gemini 3.5 Flash
Result: Implemented robust JSON localStorage state persistence, auto-save, corruption protection, and reset data actions.

# Plan 4 — State Persistence & LocalStorage Management

## 1. Purpose & Scope
Stage 4 ensures that player progress, pet stats, survival time, and sleeping states persist reliably across browser reloads or tab closures using Web Storage APIs.

## 2. Key Features
- **Auto-Save**: State serialized to JSON and saved on every stat tick and action.
- **Corrupted Data Safety**: `try-catch` JSON parser that catches invalid or corrupted storage and safely falls back to initial defaults.
- **Data Reset**: One-click clear saved data feature with confirmation dialogue.
