Stage: Stage 1: Core Logic
Architect model: Gemini 3.5 Pro   Builder model: Gemini 3.5 Flash
Result: Successfully implemented core gameplay loop, hunger, happiness, energy stat management, decay algorithms, action constraints, and game-over conditions.

# Plan 1 — Core Logic Implementation

## 1. Purpose & Scope
The objective of Stage 1 is to establish the fundamental virtual pet mechanics for Pixel, ensuring all gameplay actions, stat calculations, timing rules, and state transitions behave strictly according to requirements.

## 2. Core Features & Requirements
- **Stats**: Hunger (0-100), Happiness (0-100), Energy (0-100).
- **Actions**:
  - **Feed**: Increases Hunger by +25. Disabled when full or sleeping.
  - **Play**: Increases Happiness by +25, decreases Energy by -15. Requires minimum 15 Energy. Disabled when sleeping.
  - **Sleep**: Toggles sleeping state. Restores Energy (+4/sec), decreases Hunger (-1/sec).
- **Game Over**: Triggered immediately when any stat reaches 0%.
- **State Management**: Game running, paused, sleeping, and game over states.

## 3. Implementation Verification & Acceptance Criteria
- [x] All 3 main actions alter stats as expected.
- [x] Stat bounds (0 to 100) are strictly enforced.
- [x] Automatic background decay occurs every second.
- [x] Game Over triggers properly upon stat depletion.
