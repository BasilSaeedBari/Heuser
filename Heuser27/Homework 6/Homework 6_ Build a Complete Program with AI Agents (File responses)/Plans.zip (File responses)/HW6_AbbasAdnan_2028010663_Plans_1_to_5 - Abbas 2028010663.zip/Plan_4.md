Stage: State & Storage
Architect model: GPT-6 (planning role)    Builder model: GPT-6 (implementation role)
Result: The best score and mute preference are saved in local storage, while transient gameplay values are reset for each new run. Pause, resume, replay, and saved-data reset controls are included.

# Stage 4 — State & Storage Plan

## Data to remember
- **Best score:** maximum score reached across runs.
- **Mute preference:** whether generated sound effects are disabled.

## Data not to persist
- Current score, lives, level, player position, falling objects, particles, spawn timer, and pressed keys. These belong to a single run and reset when a new mission starts.

## Storage design
- Store one JSON object under the key `starcatch-save-v1`.
- Load and validate the saved object at startup.
- Accept the best score only if it is a finite non-negative number; accept mute only if it is a boolean.
- Wrap local storage reads/writes in `try/catch`. If storage is blocked or corrupted, start with safe defaults and continue playing.
- Save when the best score improves, when mute changes, and when saved data is reset.

## State transitions
- Menu → Playing: Start mission.
- Playing → Paused: Space, Escape, window blur, or hidden tab.
- Paused → Playing: Resume mission button or Space.
- Playing → Over: lives reach zero.
- Over → Playing: Play again resets the run.
- Any state → reset saved data: Reset Data button after confirmation. It clears best score and restores sound to On without deleting unrelated browser storage.

## Reset behavior
- A new game resets score to zero, lives to three, level to one, player position, objects, particles, input flags, and timing.
- The reset-data button asks for confirmation, clears only the game's storage key, and updates the visible best-score and mute controls.

## Done-when checks
- Best score and mute setting survive refresh.
- Pause and resume work without a sudden delta-time jump.
- Restart produces a clean run.
- Corrupted or unavailable local storage does not crash the game.
