Stage: Debugging
Architect model: GPT-6 (planning role)    Builder model: GPT-6 (implementation role)
Result: The final review targets input, timing, storage, and responsive-layout edge cases. Three concrete issues are addressed in the implementation and listed below; final manual browser checks should be completed before submission.

# Stage 5 — Debugging Plan

## Edge cases to test
1. Hold movement keys while the game pauses or the browser loses focus.
2. Switch to another tab during play and return after several seconds.
3. Resize the browser or play on a narrow touch screen.
4. Rapidly click Start/Resume or repeatedly press Space.
5. Try malformed, missing, or unavailable local storage data.
6. Mute/unmute repeatedly and use the game if Web Audio is unsupported.
7. Let multiple items overlap the player in one frame and verify each item is processed once.
8. Check that off-screen objects and expired particles are removed.
9. Confirm the player stays within the playfield when pointer input is near an edge.
10. Restart after game over and verify score/lives/level reset.

## Bug list: issues found during code review and fixes

### Bug 1 — Stuck movement after focus changes
**What happened:** If a movement key was held when the browser lost focus or the game paused, the key state could remain true and move the ship unexpectedly after resuming.
**Fix:** Clear both movement flags when pausing and on the window `blur` event. The player must intentionally resume.

### Bug 2 — Large movement jump after returning to a tab
**What happened:** A long delay between animation frames could create a huge delta time and move objects through the play area in one update.
**Fix:** Clamp each frame's delta time to at most 0.033 seconds and pause when the document becomes hidden. The game remains paused when the player returns.

### Bug 3 — Corrupt saved data could break startup
**What happened:** A malformed JSON value in local storage could throw while the game was loading.
**Fix:** Wrap parsing in `try/catch`, validate saved values, and use safe defaults if the saved record is missing or invalid.

### Additional hardening
- Guard against repeated Start clicks while already playing.
- Clamp the player's horizontal position to the canvas boundaries.
- Remove caught objects immediately and remove objects after they pass the bottom.
- Handle unavailable local storage and Web Audio without blocking the game.
- Clear the previous toast timeout before scheduling another one.

## Final test checklist
- [ ] Open `index.html` by double-clicking it with the internet disconnected.
- [ ] Play from start to game over and restart.
- [ ] Verify star scoring, meteor damage, and level increases.
- [ ] Verify keyboard, pointer, and touch controls.
- [ ] Verify pause/resume and automatic pause on tab switching.
- [ ] Verify sound mute and saved best score after refresh.
- [ ] Verify Reset Data clears only Starcatch's saved settings.
- [ ] Check desktop and mobile-sized browser widths.
- [ ] Confirm the ZIP contains exactly `index.html`, `style.css`, and `script.js`.

Note: These plans describe the intended architecture and code-review fixes. The required separate Architect/Builder agent workflow and final hands-on browser test should be honestly completed/documented by the student if the instructor checks process evidence.
