Stage: Sensory Feedback
Architect model: GPT-6 (planning role)    Builder model: GPT-6 (implementation role)
Result: Important actions now produce visible reactions through glow, particles, toast messages, button feedback, and generated tones. A persistent mute control is included.

# Stage 3 — Sensory Feedback Plan

## Visual feedback
- Give the player ship a cyan glow and a small animated engine flame.
- Rotate stars and meteors as they fall.
- Spawn short-lived particles when a star is caught or a meteor hits the ship.
- Show a toast message after a meteor hit and at score milestones.
- Use hover and pressed states on buttons, with visible keyboard focus.
- Animate the overlay's appearance/disappearance with opacity and blur.
- Keep particle life short and delete expired particles to avoid unbounded growth.

## Sound feedback
- Generate sound effects in JavaScript with the Web Audio API; do not load sound files.
- Use a short high tone for collecting a star, a low rough tone for a meteor hit, a short start tone, and a low game-over tone.
- Create the audio context only when needed, and resume it after user interaction if the browser has suspended it.
- Catch audio-related errors so a browser that blocks audio can still play the game.
- Include a Sound: On/Off button. Store the mute preference in local storage.

## Input response
- Buttons respond visually to hover and press.
- Keyboard movement is continuous while a key is held.
- Pointer/touch movement updates the ship position immediately.
- Toast messages are temporary and their prior timeout is cleared before a new one is scheduled.

## Done-when checks
- Catching a star or hitting a meteor creates a visible particle burst.
- Important actions create generated sound when sound is enabled.
- The mute button turns sound off/on and accurately reflects its state.
- The game remains fully playable when sound is unavailable or muted.
