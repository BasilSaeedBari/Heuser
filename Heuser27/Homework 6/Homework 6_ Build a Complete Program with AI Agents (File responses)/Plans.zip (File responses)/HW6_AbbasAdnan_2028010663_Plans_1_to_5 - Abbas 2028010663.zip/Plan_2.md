Stage: Visual Vibe
Architect model: GPT-6 (planning role)    Builder model: GPT-6 (implementation role)
Result: The plain prototype is styled as a cosmic arcade game using CSS and canvas drawing. The rules are unchanged; all visuals are drawn by code with no image assets.

# Stage 2 — Visual Vibe Plan

## Theme and mood
Use a deep-space arcade theme: dark navy background, blue/cyan highlights, bright golden collectible stars, and red-pink meteors. The visual tone should feel energetic and readable rather than cluttered.

## Palette
- Background: near-black navy (`#080d1d`) with a blue radial glow.
- Canvas: dark blue gradient.
- Player: luminous cyan (`#70e1f5`) with a pale cockpit and orange engine flame.
- Collectibles: gold (`#ffd166`) with a light outline and glow.
- Hazards: red-pink (`#ff667d`) with darker crater marks.
- Supporting text: pale white and muted blue-gray.

## Layout
- Responsive centered game panel with title and utility buttons at the top.
- Four compact stat panels for score, best score, lives, and level.
- Canvas occupies the main focus area with rounded corners and a subtle border/shadow.
- Menu, pause, and game-over overlays use a translucent dark card with a primary action button.
- A footer legend explains stars and meteors.
- On narrow screens, controls and stat cards wrap and reduce padding.

## Drawing everything with code
- Draw the background gradient, faint horizontal grid lines, and randomized tiny stars on the canvas.
- Draw the spaceship using a series of canvas paths and simple shapes.
- Draw collectibles as ten-point stars created from alternating outer and inner radii.
- Draw meteors as irregular polygon shapes with small crater circles.
- Use CSS gradients, borders, shadows, and typography for the surrounding interface.
- Use only system fonts; no external fonts, images, sound files, frameworks, or libraries.

## Accessibility and readability
- Keep score/lives/level as normal HTML text so the information is not only inside canvas.
- Provide button focus outlines and meaningful labels.
- Maintain sufficient contrast between game objects and the background.
- Ensure the canvas remains touch-friendly and scales with the viewport.

## Done-when checks
- The page looks like a cohesive space-themed game.
- Every game object is drawn with canvas/CSS code.
- The project can run offline and contains no image files.
