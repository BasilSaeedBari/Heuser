Stage: Core Logic
Architect model: GPT-6 (planning role)    Builder model: GPT-6 (implementation role)
Result: The core rules and game loop are specified as a small canvas catch game. The implementation includes start, play, pause, game-over, scoring, lives, increasing difficulty, and replay.

# Stage 1 — Core Logic Plan

## Project choice
Build **Starcatch**, a browser-based catch game. The player controls a small spaceship near the bottom of the play area. Gold stars fall from above and red meteors are hazards.

## Rules and controls
- Move left/right with the Left and Right arrow keys or A and D.
- Pointer/touch input can move the ship horizontally on the canvas.
- Catching a gold star adds 10 points.
- Touching a red meteor removes one of the player's three lives.
- Missing a star or meteor has no penalty.
- The game ends when lives reach zero.
- The score determines the level: one level is added for each 100 points. Higher levels increase falling speed and spawn frequency.
- The player can start again after game over. Space or Escape pauses/resumes; switching tabs or losing window focus pauses the game.

## Game states
1. **Menu** — introductory overlay and Start mission button.
2. **Playing** — animation loop updates input, spawns objects, checks collisions, updates score/lives/level, and draws the scene.
3. **Paused** — gameplay loop stops changing the world and an overlay offers Resume mission.
4. **Over** — a final-score overlay appears with Play again.

## Technical approach
- Use one HTML page, one CSS stylesheet, and one JavaScript file.
- Use a fixed logical canvas size of 900 × 540 and scale it responsively with CSS.
- Use `requestAnimationFrame` and delta time for movement.
- Use circle-versus-rectangle collision checks between falling objects and the ship.
- Keep the player's horizontal position within the canvas bounds.
- Keep code-created objects and particles in arrays and remove them when collected or off-screen.

## Done-when checks
- A player can start, catch stars, lose lives to meteors, reach game over, and replay.
- Arrow keys and A/D work; pointer/touch movement works.
- The ship cannot leave the left or right edge.
- The game remains playable when the window is resized.
- No downloaded assets or external libraries are required.
