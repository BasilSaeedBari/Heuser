print("================================")
print("       WOMEN IN STEM")
print("         GUESS WHO?")
print("================================")

def show_question():
    print("\nChoose a woman to learn about:")
    print("1. Ada Lovelace")
    print("2. Marie Curie")
    print("3. Katherine Johnson")
    print("4. Quit")

def ada_lovelace():
    print("\nAda Lovelace")
    print("She was a mathematician who wrote an")
    print("early algorithm intended for a computer.")
    print("She is often recognised as an early computer programmer.")

def marie_curie():
    print("\nMarie Curie")
    print("She was a physicist and chemist.")
    print("Her research on radioactivity helped advance science.")
    print("She won Nobel Prizes in two different scientific fields.")

def katherine_johnson():
    print("\nKatherine Johnson")
    print("She was a mathematician who worked at NASA.")
    print("Her calculations helped support early human spaceflight.")

while True:
    show_question()
    choice = input("\nEnter your choice (1-4): ")

    if choice == "1":
        ada_lovelace()
    elif choice == "2":
        marie_curie()
    elif choice == "3":
        katherine_johnson()
    elif choice == "4":
        print("\nThanks for exploring Women in STEM!")
        break
    else:
        print("\nInvalid choice. Please enter 1, 2, 3, or 4.")